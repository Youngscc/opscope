#!/usr/bin/python3
# -*- coding: utf-8 -*-
# -------------------------------------------------------------------------
# This file is part of the MindStudio project.
# Copyright (c) 2025 Huawei Technologies Co.,Ltd.
#
# MindStudio is licensed under Mulan PSL v2.
# You can use this software according to the terms and conditions of the Mulan PSL v2.
# You may obtain a copy of Mulan PSL v2 at:
#
#          http://license.coscl.org.cn/MulanPSL2
#
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
# EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
# MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
# See the Mulan PSL v2 for more details.
# -------------------------------------------------------------------------
import json
import os


class ConfigLoader:
    """负责输入 JSON 配置的加载与 accelerator 路径解析。"""

    def __init__(self, arc_config_dir: str):
        """
        Args:
            arc_config_dir: tilesim 内置 arc_config 目录的绝对路径，
                            用于按芯片型号自动搜索 YAML 文件。
        """
        self._arc_config_dir = arc_config_dir

    def load(self, json_path: str) -> list[dict]:
        """从 JSON 文件加载配置列表，并将 accelerator 相对路径转为绝对路径。

        Args:
            json_path: 输入 JSON 文件路径（绝对或相对路径均可）。

        Raises:
            FileNotFoundError: 文件不存在。
            json.JSONDecodeError: JSON 格式错误。
        """
        if not os.path.exists(json_path):
            raise FileNotFoundError(f"Input JSON file not found: {json_path}")
        abs_path = os.path.abspath(json_path)
        base_dir = os.path.dirname(abs_path)
        with open(abs_path, "r", encoding="utf-8") as f:
            configs = json.load(f)
        if not isinstance(configs, list):
            raise ValueError(
                f"Input JSON must be a list of operator configs, got {type(configs).__name__}"
            )
        for cfg in configs:
            accelerator = cfg.get("accelerator", "")
            if accelerator:
                try:
                    cfg["accelerator"] = self._find_accelerator(accelerator, base_dir)
                except FileNotFoundError as e:
                    raise FileNotFoundError(
                        f"Cannot resolve accelerator for op '{cfg.get('op_name', '?')}': {e}"
                    ) from e
        return configs

    def resolve_accelerators(
        self,
        configs: list[dict],
        soc_type: str | None,
    ) -> tuple[list[dict], str]:
        """统一处理 accelerator 解析：soc_type 优先，否则校验配置中是否已全部指定。

        Returns:
            (处理后的 configs, 供调用方记录的提示信息)

        Raises:
            FileNotFoundError: soc_type 对应的 YAML 文件找不到。
            ValueError: soc_type 为空且存在未指定 accelerator 的配置项。
        """
        if soc_type:
            self.apply_soc_type(configs, soc_type)
            return (
                configs,
                f"Using SoC type ['{soc_type}'] for prediction (set via -s argument)",
            )

        missing = list(
            dict.fromkeys(
                cfg.get("op_name", f"index={i}")
                for i, cfg in enumerate(configs)
                if not cfg.get("accelerator")
            )
        )
        if missing:
            raise ValueError(
                "No SoC type specified; set it via -s or provide 'accelerator' "
                f"in the config. Missing for: {', '.join(missing)}"
            )
        accelerators = sorted(
            {
                os.path.splitext(os.path.basename(cfg["accelerator"]))[0]
                for cfg in configs
            }
        )
        return (
            configs,
            "Using SoC type "
            f"{str(accelerators)} for prediction "
            "(resolved from 'accelerator' field in config)",
        )

    def apply_soc_type(self, configs: list[dict], soc_type: str) -> list[dict]:
        """查找 <soc_type>.yaml 并覆盖所有配置中的 accelerator 字段。

        原地修改每个配置项的 accelerator 字段，同时返回该列表。

        Args:
            configs: 已加载的配置列表。
            soc_type: 芯片型号，如 "910B1"、"910B4"。

        Raises:
            FileNotFoundError: 在 arc_config_dir 下找不到对应 YAML 文件。
        """
        yaml_abs = self._find_accelerator(soc_type, self._arc_config_dir)
        for cfg in configs:
            cfg["accelerator"] = yaml_abs
        return configs

    def _find_accelerator(self, accelerator: str, base_dir: str) -> str:
        """三级优先级路径解析。

        1. 绝对路径 → 直接返回（不校验是否存在，由调用方决定）
        2. 相对路径 → 先尝试相对于 base_dir
        3. 若不存在 → 在 arc_config_dir 下递归查找同名文件

        Raises:
            FileNotFoundError: 三级查找均未命中时抛出，含明确的搜索路径提示。
        """
        if os.path.isabs(accelerator):
            if not os.path.isfile(accelerator):
                raise FileNotFoundError(f"Accelerator file not found: {accelerator}")
            return accelerator

        candidate = os.path.normpath(os.path.join(base_dir, accelerator))
        if os.path.isfile(candidate):
            return candidate

        basename = os.path.basename(accelerator)
        filename = basename if basename.endswith(".yaml") else f"{basename}.yaml"
        for root, _, files in os.walk(self._arc_config_dir):
            if filename in files:
                return os.path.join(root, filename)

        raise FileNotFoundError(f"Accelerator config file '{filename}' not found.")
