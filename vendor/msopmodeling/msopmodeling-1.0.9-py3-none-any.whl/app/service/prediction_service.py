#!/usr/bin/python3
# -*- coding: utf-8 -*-
# -------------------------------------------------------------------------
# This file is part of the MindStudio project.
# Copyright (c) 2025 Huawei Technologies Co.,Ltd.
#
# MindStudio is licensed under Mulan PSL v2.
# You can use this software according to the terms and conditions of the Mulan PSL v2.
# You may obtain a copy of Mulan PSL v2 at:
#
#          http://license.coscl.org.cn/MulanPSL2
#
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
# EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
# MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
# See the Mulan PSL v2 for more details.
# -------------------------------------------------------------------------
import logging

from tilesim.api.operator_api.op_latency_predict import op_latency_predict
from tilesim.api.operator_api.op_latency_predict_engineering import op_latency_predict as op_latency_predict_engineering

logger = logging.getLogger(__name__)


class PredictionService:
    """封装批量算子性能预测，不关心输入/输出的 I/O 细节。"""

    @staticmethod
    def _select_predictor(op_input_data: dict):
        backend_type = op_input_data.get("backend_type")
        if backend_type == "theo":
            return op_latency_predict
        if backend_type == "eng":
            return op_latency_predict_engineering
        raise ValueError("backend_type must be 'theo' or 'eng'")

    @staticmethod
    def _normalize_predict_output(predict_output):
        if isinstance(predict_output, tuple):
            return predict_output
        return predict_output, []

    @staticmethod
    def predict_batch(configs: list[dict]) -> tuple[dict, dict, list[str]]:
        """遍历配置列表，逐个调用 op_latency_predict。

        Args:
            configs: 已加载并规范化的算子配置列表。

        Returns:
            results:    {"OP_0": {...}, "OP_1": {...}, ...}
            hints_map:  {"OP_0": [hint, ...], ...}  仅包含有优化建议的条目
            failed_ids: 预测失败的 OP id 列表（结果中含 'error' 字段）
        """
        results: dict = {}
        hints_map: dict = {}
        failed_ids: list[str] = []

        for idx, op_input_data in enumerate(configs):
            op_id = f"OP_{idx}"
            exception_raised = False
            try:
                predictor = PredictionService._select_predictor(op_input_data)
                predict_output = predictor(op_input_data)
                result, optimization_hints = PredictionService._normalize_predict_output(predict_output)
            except Exception as e:  # noqa: BLE001
                result = {"error": str(e)}
                optimization_hints = []
                exception_raised = True
                logger.error("%s prediction failed", op_id, exc_info=True)
            results[op_id] = result
            if "error" in result:
                failed_ids.append(op_id)
                if not exception_raised:
                    logger.error("%s prediction failed: %s", op_id, result["error"])
            else:
                if optimization_hints:
                    hints_map[op_id] = optimization_hints
                    logger.info("%s has %d optimization hint(s)", op_id, len(optimization_hints))

        return results, hints_map, failed_ids
