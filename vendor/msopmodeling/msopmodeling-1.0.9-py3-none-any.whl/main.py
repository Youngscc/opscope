#!/usr/bin/python3
# -*- coding: utf-8 -*-
# -------------------------------------------------------------------------
# This file is part of the MindStudio project.
# Copyright (c) 2025 Huawei Technologies Co.,Ltd.
#
# MindStudio is licensed under Mulan PSL v2.
# You can use this software according to the terms and conditions of the Mulan PSL v2.
# You may obtain a copy of Mulan PSL v2 at:
#
#          http://license.coscl.org.cn/MulanPSL2
#
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
# EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
# MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
# See the Mulan PSL v2 for more details.
# -------------------------------------------------------------------------
import json
import logging
import os
import sys

logger = logging.getLogger(__name__)


def _write_stdout_message(message: str) -> None:
    stdout_logger = logging.getLogger(f"{__name__}.stdout")
    stdout_logger.setLevel(logging.INFO)
    stdout_logger.propagate = False

    if stdout_logger.handlers:
        handler = stdout_logger.handlers[0]
        if getattr(handler, "stream", None) is not sys.stdout:
            stdout_logger.handlers.clear()

    if not stdout_logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(logging.Formatter("%(message)s"))
        stdout_logger.addHandler(handler)

    stdout_logger.info(message)

_SRC_DIR = os.path.dirname(os.path.abspath(__file__))
_ARC_CONFIG_DIR = os.path.join(_SRC_DIR, "tilesim", "core", "config", "arc_config")


def _setup_path() -> None:
    """将 tilesim 包目录加入 sys.path。

    tilesim 内部文件使用 "from api.xxx" / "from core.xxx" 的裸路径导入，
    需要将 tilesim 包目录本身加入 sys.path 才能解析这些导入。
    """
    tilesim_dir = os.path.join(_SRC_DIR, "tilesim")
    if tilesim_dir not in sys.path:
        sys.path.append(tilesim_dir)


def run() -> int:
    """主运行逻辑，返回进程退出码（0=成功，非 0=失败）。"""
    _setup_path()

    # 延迟导入：app 子模块依赖 tilesim，须在 _setup_path() 之后导入
    from app.cli.argument_parser import CliArgumentParser
    from app.config.config_loader import ConfigLoader
    from app.writers.result_writer import ResultWriter
    from app.service.prediction_service import PredictionService

    cli = CliArgumentParser()
    args = cli.parse()
    cli.setup_logging(args.verbose)
    logger.debug("Args: %s", args)

    loader = ConfigLoader(arc_config_dir=_ARC_CONFIG_DIR)
    try:
        configs = loader.load(args.input)
    except FileNotFoundError as e:
        logger.error(str(e))
        return 1
    except json.JSONDecodeError as e:
        logger.error("Failed to parse input JSON: %s", e)
        return 1
    except ValueError as e:
        logger.error("%s", e)
        return 1

    try:
        configs, msg = loader.resolve_accelerators(configs, args.soc_type)
        _write_stdout_message(f"[KeyInfo]: {msg}")
    except (FileNotFoundError, ValueError) as e:
        logger.error("%s", e)
        return 1

    service = PredictionService()
    results, hints_map, failed_ids = service.predict_batch(configs)

    writer = ResultWriter(output_path=args.output)
    try:
        writer.write_results(results)
        writer.write_hints(hints_map)
    except OSError as e:
        logger.error("Failed to write output: %s", e)
        return 1

    if failed_ids:
        logger.error("The following OPs failed prediction: %s", ", ".join(failed_ids))
        return 1

    return 0


def main() -> None:
    """whl 安装后的 CLI 入口点（msopmodeling 命令）。"""
    sys.exit(run())


if __name__ == "__main__":
    main()
