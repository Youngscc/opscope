# 使用方法(以TTIR建模为例)
## export python根目录
```bash
export PYTHONPATH={your_path_to/tilesim}:$PYTHONPATH
```

## 执行样例
```bash
cd your_path_to/tilesim/examples/api/operator_api
```
```bash
cd ttir_examples
python ./ttir_eng_op_example.py # Costmodel样例
# 或
python ./ttir_theo_op_example.py # 理论极限样例
```
### 输入格式参考：
```bash
input_example_engineering_ttir.json # Costmodel样例
input_example_theoretical_ttir.json # 理论极限样例
```
### 参数说明：
```python
  {
    "op_name": "TTIR",
    "input_shapes": [[128,568,568]],
    "output_shapes": [[128,568,568]],
    "input_precision": ["FLOAT32", "FLOAT32"],
    "output_precision": ["FLOAT32"],
    "backend_type": "eng",
    "core_num": 56,
    "accelerator": "../../../../core/config/arc_config/davidV100/davidV100.yaml",
    "extra_param": {
      "ttir_path": "./ttir_code/triton_unk_fused_cat_8.ttir",
      "input_list": [[], [], 128, 568]
    }
  }
# 需要填的项目
# backend_type - 后端模型{eng, theo}
# accelerator - 在tilesim/core/config/arc_config目录下选择支持的芯片类型
# ttir_path - TTIR路径
# input_list - 算子调用时传入的标量参数（如有）
# 其余可保持默认
```
### 输出建模结果：
```bash
output_example_engineering_ttir.json
# 或
output_example_theoretical.json
```

# 源码打包
```bash
python3 -m build
```
