# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import csv
from dataclasses import asdict
from pathlib import Path

import yaml
import traceback

from api.operator_api.models.operator_api_models import OperatorPredictRequest, OperatorPredictResponse
from core.backend.tile_op_costmodel.tile_op_registry import reset_tile_op_cache
from core.common import op_registry
from core.common.entity import OpType, BackendType, CoreType
from core.common.log_format import logging
from core.common.op_registry import init_registry
from core.pipeline.basic_operator import OperatorResult

logger = logging.getLogger(__name__)


def init():
    init_registry()
    reset_tile_op_cache()


def op_latency_predict(op_input_data: dict | OperatorPredictRequest) -> tuple[dict, list]:
    """
    算子性能预测对外接口
    Args:
        op_input_data:   算子输入

    Returns:
        计算结果
    """
    logger.info(f'[API.OP_LATENCY_PREDICT] receive new request for operator costmodel :{op_input_data}')
    try:
        init()
        if isinstance(op_input_data, OperatorPredictRequest):
            op_input_data = asdict(op_input_data)
        op_input_data = _reset_core_num(op_input_data)
        if op_input_data.get('input_dict') is None:
            # 有input_dict的情况下，可以不给input_precision和output_precision
            op_input_data['input_dtypes'] = op_input_data['input_precision']
            op_input_data['output_dtypes'] = op_input_data['output_precision']
        op_type = OpType.from_str(op_input_data.get('op_name'))
        backend_type = BackendType.from_str(op_input_data.get('backend_type'))

        op_model = op_registry.get_handler(op_type, backend_type)
        op_input = op_model.op_input_convert(op_input_data)
        op_instance = op_model(op_input)
        predict_result = op_instance.run()
        op_output, optimization_hints = _output_format(op_instance.op_name(), predict_result)

        return op_output, optimization_hints
    except Exception as e:
        error_stack = traceback.format_exc()
        traceback.print_exc()
        logger.error(f"[API.OP_LATENCY_PREDICT] failed to predict operator costmodel : {e}")
        logger.error(error_stack)
        return {'error': str(e), 'error_stack': error_stack}, []


def _get_arc_config(accelerator: str) -> dict:
    config_path = Path(accelerator)
    with open(config_path, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
    return data


def _reset_core_num(op_input: dict) -> dict:
    accelerator = op_input.get("accelerator")
    op_name = op_input.get("op_name")
    core_num = op_input.get("core_num")

    arc_config = _get_arc_config(accelerator)
    op_type = OpType.from_str(op_name)
    default_cube_core = arc_config.get("core_config").get("cube_core_num")
    default_vec_core = arc_config.get("core_config").get("vec_core_num")

    if core_num is None:
        aic_core = default_cube_core
        aiv_core = default_vec_core
    else:
        aic_core = core_num
        aiv_core = core_num
        if op_type.core_type == CoreType.AIV:
            aic_core = default_cube_core
        elif op_type.core_type == CoreType.AIC:
            aiv_core = default_vec_core
        else:
            aiv_core = int(default_vec_core / default_cube_core * core_num)

    op_input['aic_core_num'] = aic_core
    op_input['aiv_core_num'] = aiv_core
    return op_input


def _generate_optimization_hints(predict_result: OperatorResult) -> list:
    """生成性能优化提示表格

    Returns:
        优化提示列表，每个元素是一个字典包含：
        - 算子性能影响表征: 访存/计算/流水排布/负载均衡
        - 根因: 如小包搬运
        - 瓶颈定位结果: 小包搬运量占比
    """
    # 计算小包搬运量占比
    small_pkt_total = sum(predict_result.small_pkt_transfer.values()) if predict_result.small_pkt_transfer else 0
    data_transfer_total = sum(predict_result.data_transfer.values()) if predict_result.data_transfer else 0

    if data_transfer_total > 0:
        small_pkt_ratio = small_pkt_total / data_transfer_total * 100
    else:
        small_pkt_ratio = 0.0

    # 构建优化提示表格
    hints = []

    # 如果有小包搬运，填充访存行的信息
    if small_pkt_total > 0:
        hints.append({"算子性能影响表征": "访存",
                      "根因": "小包搬运",
                      "瓶颈定位结果": f"小包搬运量占比 {small_pkt_ratio:.2f}%"})
    return hints


def _output_format(op_type, predict_result: OperatorResult) -> tuple[dict, list]:
    """对仿真结果进行统一格式化输出"""
    component_latency = {
        "CUBE": predict_result.aic_cube_time,
        "MTE1": predict_result.aic_mte1_time,
        "MTE2": predict_result.aic_mte2_time,
        "FIXPIPE": predict_result.aic_fixpipe_time,
        "VEC": predict_result.aiv_vec_time,
        "MTE2_AIV": predict_result.aiv_mte2_time,
        "MTE3": predict_result.aiv_mte3_time,
    }

    tiling_info = predict_result.tuning_result

    mem_volume = predict_result.data_transfer
    compute_workload = {
        "CUBE": predict_result.aic_cycles,
        "VEC": predict_result.aiv_cycles
    }

    # 生成优化提示
    optimization_hints = _generate_optimization_hints(predict_result)

    op_output = OperatorPredictResponse(
        op_name=op_type,
        latency=predict_result.latency,
        component_latency=component_latency,
        l2_hit_rate=predict_result.l2_access_rate,
        cube_utilization_rate=component_latency.get("CUBE") / predict_result.latency,
        vec_utilization_rate=component_latency.get("VEC") / predict_result.latency,
        mem_volume=mem_volume,
        compute_workload=compute_workload,
        gm_volume=0,
        tiling_info=tiling_info
    )
    return asdict(op_output), optimization_hints


def save_optimization_hints_csv(hints: list, output_path: str):
    """保存优化提示到CSV文件

    Args:
        hints: 优化提示列表
        output_path: 输出文件路径
    """
    with open(output_path, 'w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['算子性能影响表征', '根因', '瓶颈定位结果'])
        writer.writeheader()
        writer.writerows(hints)
