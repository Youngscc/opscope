# Copyright (c) Huawei Technologies Co., Ltd. 2025-2026. All rights reserved.
from core.backend.engineering_costmodel.op_model.pto.entity import PTOTile
from core.backend.tile_op_costmodel.pypto_ops.functions import inst_pto_projection
from core.backend.tile_op_costmodel.pypto_ops.pto import pto_dispatch
from core.backend.tile_op_costmodel.pypto_ops.pto.pto_interface import BinaryInst
from core.common import DType

binary_map_inst = ["TADD"]


def pto_isa_latency_predict(pto_inst_name: str, pto_inst_params: list[dict]):
    # NEXT: 根据pto_inst_name找到合适的转化类binary.py，将pto_inst_params转为多个PTOTile，最终组装为BinaryInst

    if pto_inst_name in binary_map_inst:
        src0 = PTOTile(pto_inst_params[0]["row"], pto_inst_params[0]["col"], DType.from_str(pto_inst_params[0]["data_type_str"]), 0x0)
        src1 = PTOTile(pto_inst_params[1]["row"], pto_inst_params[1]["col"], DType.from_str(pto_inst_params[1]["data_type_str"]), 0x4000)
        dst = PTOTile(pto_inst_params[2]["row"], pto_inst_params[2]["col"], DType.from_str(pto_inst_params[2]["data_type_str"]), 0x8000)

        pto_inst = inst_pto_projection(pto_inst_name)
        latency = pto_dispatch(pto_inst, BinaryInst(dst, src0, src1))

    return latency


#测试用例1
pto_dict_params = {"row": 1, "col": 256, "data_type_str": "FP32"}
pto_list_params = [pto_dict_params, pto_dict_params, pto_dict_params]

res = pto_isa_latency_predict("TADD", pto_list_params)
print(f"latency is {res}")
