# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import re
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List

from core.backend.engineering_costmodel.op_model.pto.cce.config.configs import update_cce_config_cache
from core.backend.tile_op_costmodel.tile_op_backend_entity import TileEntity, TileOpEntity, TileOpLatency, TileOpContext
from core.backend.tile_op_costmodel.tile_op_registry import TileOpCode
from core.common import DType, MemLoc
from core.config.arc_spec import load_arc_config

# 驼峰字段名映射 (snake_case -> camelCase)
_CAMEL_FIELD_MAP = {
    'data_type_str': 'dataTypeStr',
    'buffer_type': 'bufferType',
    'raw_magic': 'rawMagic',
    'raw_shape': 'rawShape',
    'i_operand': 'iOperand',
    'o_operand': 'oOperand',
}


def to_camel(s: str) -> str:
    """Convert snake_case to camelCase."""
    parts = s.split('_')
    return parts[0] + ''.join(p.capitalize() for p in parts[1:])


def to_snake(s: str) -> str:
    """Convert camelCase to snake_case."""
    s1 = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', s)
    return re.sub('([a-z0-9])([A-Z])', r'\1_\2', s1).lower()


@dataclass
class TilePredictRequest:
    """Tile predict request."""
    magic: int
    data_type_str: DType | str
    buffer_type: MemLoc | str
    offset: List[int]
    shape: List[int]
    raw_magic: int
    raw_shape: List[int]

    @classmethod
    def model_validate(cls, data: dict) -> 'TilePredictRequest':
        """Validate and create model from dict (support camelCase keys)."""
        processed_data = {}
        for key, value in data.items():
            snake_key = to_snake(key)
            processed_data[snake_key] = value

        return cls(
            magic=processed_data.get('magic', 0),
            data_type_str=processed_data.get('data_type_str'),
            buffer_type=processed_data.get('buffer_type'),
            offset=processed_data.get('offset', []),
            shape=processed_data.get('shape', []),
            raw_magic=processed_data.get('raw_magic', 0),
            raw_shape=processed_data.get('raw_shape', []),
        )

    def model_dump(self, by_alias: bool = False) -> dict:
        """Convert model to dict."""
        data = asdict(self)
        if by_alias:
            return {to_camel(k): v for k, v in data.items()}
        return data

    def to_domain(self) -> TileEntity:
        # Handle buffer_type - convert from string if needed
        if isinstance(self.buffer_type, str):
            buf_type = MemLoc.from_str(self.buffer_type)
        else:
            buf_type = self.buffer_type

        # Handle data_type_str - convert from string/tuple if needed
        if isinstance(self.data_type_str, str):
            dtype = DType.from_str(self.data_type_str)
        elif isinstance(self.data_type_str, list):
            dtype = DType.from_str(self.data_type_str[-1])
        elif isinstance(self.data_type_str, tuple):
            dtype = DType.from_str(self.data_type_str[-1])
        else:
            dtype = self.data_type_str

        return TileEntity(
            magic=self.magic,
            data_type_str=dtype,
            buffer_type=buf_type,
            offset=list(self.offset),
            shape=list(self.shape),
            raw_magic=self.raw_magic,
            raw_shape=list(self.raw_shape),
        )


@dataclass
class TIleOpPredictResponse:
    """Tile operation latency response."""
    latency: float
    cycles: float

    @classmethod
    def from_domain(cls, tile_op_lat: TileOpLatency) -> "TIleOpPredictResponse":
        return cls(
            latency=tile_op_lat.latency,
            cycles=tile_op_lat.cycles,
        )

    def model_dump(self, by_alias: bool = False) -> dict:
        """Convert model to dict."""
        data = asdict(self)
        if by_alias:
            return {to_camel(k): v for k, v in data.items()}
        return data


@dataclass
class TileOpPredictRequest:
    """Tile operation predict request."""
    magic: int
    opcode: str
    i_operand: List[dict]
    o_operand: List[dict]

    @classmethod
    def model_validate(cls, data: dict) -> 'TileOpPredictRequest':
        """Validate and create model from dict (support camelCase keys)."""
        processed_data = {}
        for key, value in data.items():
            snake_key = to_snake(key)
            processed_data[snake_key] = value

        i_operand = processed_data.get('i_operand', processed_data.get('iOperand', []))
        o_operand = processed_data.get('o_operand', processed_data.get('oOperand', []))

        return cls(
            magic=processed_data.get('magic', 0),
            opcode=processed_data.get('opcode', ''),
            i_operand=i_operand,
            o_operand=o_operand,
        )

    def model_dump(self, by_alias: bool = False) -> dict:
        """Convert model to dict."""
        data = asdict(self)
        if by_alias:
            return {to_camel(k): v for k, v in data.items()}
        return data

    def to_domain(self) -> TileOpEntity:
        # Handle opcode - may be string or already a TileOpCode enum
        if isinstance(self.opcode, TileOpCode):
            opcode = self.opcode
        else:
            opcode = TileOpCode.from_str(self.opcode)
        current_module_path = Path(__file__).resolve()
        current_module_dir = current_module_path.parent
        config_file_path = current_module_dir / "../../../core/config/arc_config/910B1/910B1.yaml"
        config_file_path = config_file_path.resolve()
        arc_config = load_arc_config(config_file_path)
        update_cce_config_cache(arc_config.vec_no_bank_conflict_intrinsics_dict)
        context = TileOpContext(
            arc_config=arc_config,
            core_num=24,
            barrier=False,
            enable_small_pkt_bw=True
        )

        # 将嵌套的字典转换为 TilePredictRequest
        i_tiles = [TilePredictRequest.model_validate(t) for t in self.i_operand]
        o_tiles = [TilePredictRequest.model_validate(t) for t in self.o_operand]

        return TileOpEntity(
            magic=self.magic,
            opcode=opcode,
            i_operand=[t.to_domain() for t in i_tiles],
            o_operand=[t.to_domain() for t in o_tiles],
            context=context
        )
