# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import traceback
from copy import copy

from api.tile_op_api.models.tile_op_api_models import TileOpPredictRequest, TIleOpPredictResponse
from core.backend.tile_op_costmodel.tile_op_registry import TileOpType, tile_op_dispatch
from core.common.log_format import logging
from core.common.tile_op_enum import TileOpCode

logger = logging.getLogger(__name__)

_OP_CODE_CONVERT = {
        # PyPTO类型的操作
        "ADD": TileOpCode.ADD,
        "MUL": TileOpCode.MUL,
        "SUB": TileOpCode.SUB,
        "DIV": TileOpCode.DIV,
        "ADDS": TileOpCode.ADDS,
        "MULS": TileOpCode.MULS,
        "SUBS": TileOpCode.SUBS,
        "DIVS": TileOpCode.DIVS,
        "RSQRT": TileOpCode.RSQRT,
        "SQRT": TileOpCode.SQRT,
        "EXTRACT": TileOpCode.EXTRACT,
        "CAST": TileOpCode.CAST,
        "EXPAND": TileOpCode.BROADCAST,
        "GATHER_ELEMENT": TileOpCode.GATHER,
        "ROWSUM_SINGLE": TileOpCode.ROWSUM_SINGLE,
        "ROWMAX_SINGLE": TileOpCode.ROWMAX_SINGLE,
        "ROWMIN_SINGLE": TileOpCode.ROWMIN_SINGLE,
        "ROWSUM_LINE": TileOpCode.REDUCE_SUM,
        "ROWMAX_LINE": TileOpCode.REDUCE_MAX,
        "ROWMIN_LINE": TileOpCode.REDUCE_MIN,
        "BITSORT": TileOpCode.BITSORT,
        "MRGSORT": TileOpCode.MRGSORT,
        "TILEDMRGSORT": TileOpCode.TILEDMRGSORT,
        "WHERE_TT": TileOpCode.SELECT,
        "MAXIMUM": TileOpCode.MAX,
        "MINIMUM": TileOpCode.MIN,
        "PAIRSUM": TileOpCode.PAIRSUM,
        "PAIRMIN": TileOpCode.PAIRMIN,
        "PAIRMAX": TileOpCode.PAIRMAX,
        "ONEHOT": TileOpCode.ONEHOT,
        "VEC_DUP": TileOpCode.VEC_DUP,
        "RANGE": TileOpCode.RANGE,
        "BRCB": TileOpCode.ROWEXPAND,
        "TRANSPOSE_VNCHWCONV": TileOpCode.TRANSPOSE_VNCHWCONV,
        "TRANSPOSE_MOVEIN": TileOpCode.TRANSPOSE_MOVEIN,
        "TRANSPOSE_MOVEOUT": TileOpCode.TRANSPOSE_MOVEOUT,
        "L0C_COPY_UB": TileOpCode.COPY,
        "UB_COPY_IN": TileOpCode.COPY,
        "UB_COPY_OUT": TileOpCode.COPY,
        "COPY_IN": TileOpCode.COPY,
        "ABS": TileOpCode.ABS,
    }


def tile_op_latency_predict_pypto(tile_op: dict, config: dict = None) -> dict:
    """
    PyPTO TileOp性能预测对外接口
    Args:
        tile_op:    TileOp的接口实体类
        config:     其他参数，暂时无用

    Returns:
        计算结果
    """

    logger.info(f'[API.TILE_OP_COST_PYPTO] receive new request for tile op costmodel :{tile_op}')
    tile_op = copy(tile_op)
    try:

        if tile_op['opcode'].upper() not in _OP_CODE_CONVERT:
            logger.info(f"OP CODE NOT SUPPORTED: {tile_op['opcode']}")
            ret = TIleOpPredictResponse(latency=0)
            return ret.model_dump()

        tile_op['opcode'] = _OP_CODE_CONVERT[tile_op['opcode'].upper()]
        dto = TileOpPredictRequest.model_validate(tile_op)
        tile_op_entity = dto.to_domain()
        tile_op_latency = 0
        try:
            op_type = TileOpType.PyPTO
            tile_op_latency = tile_op_dispatch(tile_op_entity, op_type)
        except Exception as e:
            op_type = TileOpType.PLAIN
            tile_op_latency = tile_op_dispatch(tile_op_entity, op_type)

        latency_dto = TIleOpPredictResponse.from_domain(tile_op_latency)
        logger.info(f'[API.TILE_OP_COST_PYPTO] predict success! costmodel result :{latency_dto}')
        return latency_dto.model_dump()
    except Exception as e:
        error_stack = traceback.format_exc()
        traceback.print_exc()
        logger.error(f"[API.TILE_OP_COST_PYPTO] failed to predict operator costmodel : {e}")
        logger.error(error_stack)
        return {'error': str(e), 'error_stack': error_stack}
