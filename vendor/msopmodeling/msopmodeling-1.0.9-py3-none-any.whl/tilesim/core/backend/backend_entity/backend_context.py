# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from copy import copy
from dataclasses import field, dataclass


@dataclass
class PhiFuncEntity:
    id: str
    result_name: str
    referred_name: list[str]
    activated_name: str = None
    # key: scope_id, value: referred_name，表示 scope_id 激活 referred_name
    scope_referrers: dict[str, str] = field(default_factory=dict)

    def activate(self, scope_id: str):
        if scope_id not in self.scope_referrers.keys():
            raise ValueError(f'scope_id {scope_id} not in phi func scope_referrers')
        self.activated_name = self.scope_referrers[scope_id]


def bind_version(name: str, version: int):
    if version == 0:
        return name
    else:
        return f'{name}.{version}'


def resolve_versioned_name(name: str, version_info):
    """Resolve a name with version info.

    version_info can be:
    - ('use_activated_name', activated_name): use the phi activated name directly
    - int: traditional version binding
    """
    use_activated_name, activated_name = version_info
    if use_activated_name:
        # Phi function is activated, use the activated name directly
        return activated_name
    else:
        # Traditional version binding
        return bind_version(name, activated_name)


@dataclass
class EvalCtxEntity:
    env: dict[str, int | float | bool]
    version_manager: dict[str, int] = field(default_factory=dict)
    # k - scope_id, v - 对应的，需要激活的phi func
    phi_func_by_scope: dict[str, list[PhiFuncEntity]] = field(default_factory=dict)
    # k - phi merge后的变量名， v - 对应的phi func
    phi_func_by_name: dict[str, PhiFuncEntity] = field(default_factory=dict)

    def assign(self, name: str, value: int | float | bool):
        self.env[name] = value

    def assign_dict(self, kv_dict: dict[str, int | float | bool]):
        for k, v in kv_dict.items():
            self.env[k] = v

    def update_version(self, name: str, version: int):
        self.version_manager[name] = version

    def get_version(self, name: str):
        # Normal case: return version number
        if name not in self.version_manager:
            self.version_manager[name] = 0
        return self.version_manager[name]

    def get_version_by_phi(self, name: str):
        # First check if we have an activated phi function for this name
        activated_name = self._get_merge_phi_name(name)
        if activated_name != name:
            # Phi function is activated - the activated_name is already versioned
            # Return a sentinel value to indicate this
            return True, activated_name
        activated_name = self.get_version(name)
        return False, activated_name

    def create_tmp_ctx(self) -> 'EvalCtxEntity':
        tmp_ctx = EvalCtxEntity(
            env=self.env,
            version_manager=self.version_manager,
            phi_func_by_scope=self.phi_func_by_scope,
            phi_func_by_name=self.phi_func_by_name
        )
        return tmp_ctx

    def activate_phi(self, scope_id: str):
        phi_func_list = self.phi_func_by_scope.get(scope_id, [])
        for phi_func in phi_func_list:
            phi_func.activate(scope_id=scope_id)

    def _get_merge_phi_name(self, name: str):
        if name in self.phi_func_by_name.keys():
            phi_func = self.phi_func_by_name[name]
            if phi_func.activated_name is None:
                # Phi function not yet activated, return original name
                return name
            return phi_func.activated_name
        return name
