# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import numbers
from abc import ABC, abstractmethod
from copy import copy
from dataclasses import dataclass

import numpy as np

from core.backend.backend_entity.backend_math import ExprEntity, MathEntity, EvalCtxEntity, RangeEntity, VarExprEntity, ConstExprEntity
from core.common.entity import DType, MemLoc


@dataclass
class ObjEntity(ABC):
    name: str

    def __init__(self):
        pass

    @abstractmethod
    def eval(self, ctx: EvalCtxEntity) -> 'ObjEntity':
        pass


@dataclass
class VarEntity(ObjEntity):
    value: MathEntity

    def eval(self, ctx: EvalCtxEntity) -> 'VarEntity':
        ret_var = copy(self)
        if isinstance(self.value, ExprEntity):
            if isinstance(self.value, ConstExprEntity) and self.value.value is None:
                ret_var.value = ctx.env.get(self.name)
            else:
                ret_var.value = self.value.eval(ctx)
        elif isinstance(self.value, RangeEntity):
            ret_var.value = self.value.eval(ctx)
        return ret_var


def _eval_list(val_list: list[int | ExprEntity], ctx: EvalCtxEntity) -> list[int]:
    ret_list = []
    for val in val_list:
        if isinstance(val, int):
            eval_res = val
        elif isinstance(val, ExprEntity):
            eval_res = val.eval(ctx)
        else:
            raise ValueError(f'不支持的类型: {type(val)}')
        if not isinstance(eval_res, numbers.Number):
            raise ValueError(f'评估错误, 未展开彻底: {type(eval_res)}')
        ret_list.append(eval_res)

    return ret_list


@dataclass
class TensorEntity(ObjEntity):
    # 数据形状
    shape: list[int | ExprEntity]
    # 张量数据格式
    dtype: DType | VarExprEntity
    # 张量所处位置
    mem_loc: MemLoc | VarExprEntity
    # 原始张量名称 NEXT 默认是自身
    raw_name: str = None
    # 原始张量shape
    raw_shape: list[int | ExprEntity] = None
    # 相较于原始张量的位置
    offset: list[int | ExprEntity] = None

    def get_size(self) -> int:
        num_elements = np.prod(self.shape) if self.shape else 0
        return int(num_elements * self.dtype.size)

    def overlaps_with(self, other: 'TensorEntity') -> bool:
        """检查两个张量是否有重叠（必须是同一个raw_name）"""
        if self.raw_name != other.raw_name:
            return False

        # 检查每个维度是否有重叠
        for i in range(len(self.shape)):
            self_start = self.offset[i]
            self_end = self.offset[i] + self.shape[i]
            other_start = other.offset[i]
            other_end = other.offset[i] + other.shape[i]

            # 如果任何维度不重叠，则整体不重叠
            if self_end <= other_start or other_end <= self_start:
                return False

        return True

    def get_overlap_size(self, other: 'TensorEntity') -> int:
        """计算与另一个张量的重叠大小（字节数）"""
        if not self.overlaps_with(other):
            return 0

        # 计算重叠区域的shape
        overlap_shape = []
        shape_size = len(self.shape)
        for i in range(shape_size):
            self_start = self.offset[i]
            self_end = self.offset[i] + self.shape[i]
            other_start = other.offset[i]
            other_end = other.offset[i] + other.shape[i]

            overlap_start = max(self_start, other_start)
            overlap_end = min(self_end, other_end)
            overlap_shape.append(overlap_end - overlap_start)

        # 计算重叠区域的字节数
        num_elements = np.prod(overlap_shape) if overlap_shape else 0
        return int(num_elements * self.dtype.size)

    def get_elements(self) -> int:
        elements = 1
        for dim in self.shape:
            elements *= dim
        return elements

    def eval(self, ctx: EvalCtxEntity) -> 'ObjEntity':
        ret_tensor = copy(self)
        # shape转换
        ret_tensor.shape = _eval_list(self.shape, ctx)
        # dtype转换
        if issubclass(ret_tensor.dtype.__class__, ExprEntity):
            ret_tensor.dtype = ret_tensor.dtype.eval(ctx)
        # mem_loc转换
        if issubclass(ret_tensor.mem_loc.__class__, ExprEntity):
            ret_tensor.mem_loc = ret_tensor.mem_loc.eval(ctx)
        # 原始张量信息转换
        if self.raw_shape is not None:
            ret_tensor.raw_shape = _eval_list(self.raw_shape, ctx)
            ret_tensor.offset = _eval_list(self.offset, ctx)
            dim_size = len(ret_tensor.shape)
            for i in range(dim_size):
                dim = ret_tensor.shape[i]
                dim_offset = ret_tensor.offset[i]
                raw_dim = ret_tensor.raw_shape[i]
                ret_tensor.shape[i] = min(dim, raw_dim - dim_offset)

        return ret_tensor

    def get_slice_name(self):
        # NEXT: 不能直接用offset来判断，还需要包含的位置，后续看看怎么高效一点计算
        if self.raw_name is not None:
            slice_name = f'{self.raw_name}_{self.offset}'
        else:
            slice_name = f'{self.name}_{self.offset}'
        return slice_name

    def __hash__(self):
        """使Tensor可以作为字典的key"""
        return hash(self.name)

    def __eq__(self, other):
        """判断两个张量是否相同"""
        if not isinstance(other, TensorEntity):
            return False
        return self.name == other.name
