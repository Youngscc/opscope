# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from abc import ABC, abstractmethod
from copy import copy
from dataclasses import dataclass, field

from core.backend.backend_entity.backend_context import EvalCtxEntity, bind_version
from core.backend.backend_entity.backend_entity import ObjEntity, VarEntity, TensorEntity
from core.backend.backend_entity.backend_math import CompareExprEntity, LogicalExprEntity, RangeEntity, MathEntity, VarExprEntity, ExprEntity
from core.common.tile_op_enum import TileOpCode
from core.common.backend_config import TaskIndexConfig
from core.common.entity import OpLevel, CoreType


def _eval_config(config: dict, ctx: EvalCtxEntity) -> dict:
    """递归求值config中的表达式"""
    if config is None:
        return None
    result = {}
    for k, v in config.items():
        if isinstance(v, ExprEntity):
            result[k] = v.eval(ctx)
        elif isinstance(v, list):
            result[k] = [item.eval(ctx) if isinstance(item, ExprEntity) else item for item in v]
        elif isinstance(v, dict):
            result[k] = _eval_config(v, ctx)
        else:
            result[k] = v
    return result


# 运算逻辑，包装的具体的运算
class LogisticEntity(ABC):
    OP_ID = 0

    def __init__(self):
        self.op_id = LogisticEntity.OP_ID
        LogisticEntity.OP_ID += 1

    @abstractmethod
    def expand(self, ctx: EvalCtxEntity) -> list['OpEntity']:
        """根据EvalCtxEntity将LogisticEntity中的值确定下来，转化成SimEvent列表"""
        pass

    @abstractmethod
    def get_ops(self) -> list['OpEntity']:
        pass


def _eval_check(obj: ObjEntity):
    if isinstance(obj, VarEntity):
        if issubclass(obj.value.__class__, MathEntity):
            if isinstance(obj.value, RangeEntity) and obj.value.evaluated():
                return
            raise ValueError(f'{obj.name} not evaluated')

    if isinstance(obj, TensorEntity):
        for dim in obj.shape:
            if issubclass(dim.__class__, MathEntity):
                raise ValueError(f'{obj.name} shape not evaluated')
        if isinstance(obj.mem_loc, VarExprEntity):
            raise ValueError(f'{obj.name} mem_loc not evaluated')
        if isinstance(obj.dtype, MathEntity):
            raise ValueError(f'{obj.name} dtype not evaluated')


@dataclass
class OpEntity(LogisticEntity):
    level: OpLevel
    op_code: TileOpCode
    inputs: list[ObjEntity]
    outputs: list[ObjEntity]
    config: dict = None

    def __post_init__(self):
        super().__init__()

    def expand(self, ctx: EvalCtxEntity) -> list['OpEntity']:
        new_op = copy(self)
        inputs = []

        for obj in self.inputs:
            obj_eval = obj.eval(ctx)
            _eval_check(obj_eval)
            obj_eval.name = bind_version(obj.name, ctx.get_version(obj.name))
            inputs.append(obj_eval)
        outputs = []
        for obj in self.outputs:
            obj_eval = obj.eval(ctx)
            _eval_check(obj_eval)
            outputs.append(obj_eval)

            obj_version = ctx.get_version(obj.name)
            if self.op_code != TileOpCode.STORE:
                obj_version += 1

            obj_eval.name = bind_version(obj.name, obj_version)
            ctx.update_version(obj.name, obj_version)
            if isinstance(obj_eval, VarEntity):
                ctx.assign(obj_eval.name, obj_eval.value)

        new_op.inputs = inputs
        new_op.outputs = outputs
        # 求值 config 中的表达式
        new_op.config = _eval_config(self.config, ctx)

        return [new_op]

    def get_ops(self) -> list['OpEntity']:
        return [self]


@dataclass
class TaskEntity(LogisticEntity):
    name: str
    core_type: CoreType
    indices: list[VarEntity]
    body: list[LogisticEntity]
    input_tensors: list[TensorEntity]
    output_tensors: list[TensorEntity]
    pre_task: list['TaskEntity'] = None
    task_index_configs: list[TaskIndexConfig] = field(default_factory=list)

    def __post_init__(self):
        super().__init__()

    def expand(self, ctx: EvalCtxEntity) -> list['OpEntity']:
        raise NotImplementedError('task should not be expanded, use subtask instead')

    def get_ops(self) -> list['OpEntity']:
        op_list = []
        for op in self.body:
            op_list.extend(op.get_ops())
        return op_list


@dataclass
class SubTaskEntity(LogisticEntity):
    root_task_name: str
    index: int
    core_idx: int
    indices: dict[str, int] = field(default_factory=dict)
    name: str = None
    pre_sub_task: list['SubTaskEntity'] = None
    root_task: TaskEntity = None
    task_start_time: float = 0.0
    task_end_time: float = 0.0

    def __post_init__(self):
        self.name = f'{self.root_task_name}_subtask_{self.index}'
        super().__init__()

    def expand(self, ctx: EvalCtxEntity) -> list['OpEntity']:
        op_list = []
        for op in self.root_task.body:
            op_list.extend(op.expand(ctx))
        return op_list

    def get_ops(self) -> list['OpEntity']:
        op_list = []
        for op in self.root_task.body:
            op_list.extend(op.get_ops())
        return op_list


@dataclass
class ForEntity(LogisticEntity):
    scope_id: str
    range: VarEntity
    body: list[LogisticEntity]

    def __post_init__(self):
        super().__init__()

    def expand(self, ctx: EvalCtxEntity) -> list['OpEntity']:

        ctx.activate_phi(self.scope_id)

        range_var: VarEntity = self.range.eval(ctx)
        range_value = range_var.value

        if not isinstance(range_value, RangeEntity):
            raise ValueError('for entity range not evaluated to RangeEntity')

        start, end, step = range_value.start, range_value.end, range_value.step
        if not isinstance(start, int) or not isinstance(end, int) or not isinstance(step, int):
            raise ValueError('range entity not evaluated')

        op_list = []
        tmp_ctx = ctx.create_tmp_ctx()

        for i in range(start, end, step):
            use_activated_name, activated_name = tmp_ctx.get_version_by_phi(self.range.name)
            # Handle the version info format
            if use_activated_name:
                # Phi activated - use the activated name directly
                var_name = activated_name
            else:
                # Normal version binding
                var_name = bind_version(self.range.name, activated_name)
            tmp_ctx.assign(var_name, i)
            for op in self.body:
                op_list.extend(op.expand(tmp_ctx))
        return op_list

    def get_ops(self) -> list['OpEntity']:
        op_list = []
        for op in self.body:
            op_list.extend(op.get_ops())
        return op_list


@dataclass
class IfEntity(LogisticEntity):
    condition: CompareExprEntity | LogicalExprEntity
    if_body: list[LogisticEntity]
    else_body: list[LogisticEntity] = None
    else_phi_func_dict: dict[str, str] = field(default_factory=dict)
    scope_id: str = None
    if_scope_id: str = None
    else_scope_id: str = None

    def __post_init__(self):
        super().__init__()

    def expand(self, ctx: EvalCtxEntity) -> list['OpEntity']:
        condition_value = self.condition.eval(ctx)
        ctx.activate_phi(self.scope_id)

        op_list = []
        if condition_value:
            ctx.activate_phi(self.if_scope_id)
            for op in self.if_body:
                op_list.extend(op.expand(ctx))
        else:
            if self.else_body is not None:
                ctx.activate_phi(self.else_scope_id)
                for op in self.else_body:
                    op_list.extend(op.expand(ctx))
        return op_list

    def get_ops(self) -> list['OpEntity']:
        op_list = []
        for op in self.if_body:
            op_list.extend(op.get_ops())
        return op_list
