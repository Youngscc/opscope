# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from dataclasses import dataclass

from core.backend.backend_entity.backend_context import EvalCtxEntity
from core.backend.backend_entity.backend_logistic import TaskEntity, SubTaskEntity, LogisticEntity
from core.common.entity import DType, MemLoc, OpLevel
from core.frontend.ir.core.ir import KernelIR
from core.frontend.ir.core.ir_logistic import TaskIR, OpIR


@dataclass
class BackendEntity:
    """包含预测时延所需的所有信息"""
    task_dict: dict[str, TaskEntity]
    tensor_dict: dict[str, int]
    eval_ctx: EvalCtxEntity
    host_ops: list['OpEntity']
    sub_task_dict: dict[str, SubTaskEntity] = None
    # 在没有task包裹的时候的入口，主要是理论极限用
    op_list: list[LogisticEntity] = None


def _deal_phi_func(kernel_ir: KernelIR):
    # Phi函数处理
    # 注意：同一个phi可能被多个scope引用，但为了支持激活，
    # 我们需要将每个scope的phi列表分开
    phi_func_by_scope = {}
    phi_func_by_name = {}

    # 遍历所有scope，为每个scope创建独立的phi实体
    all_phi_ir_entities = {}  # phi_ir.id -> phi_entity，避免重复转换

    for scope_id, phi_ir_list in kernel_ir.phi_func_dict.items():
        phi_entity_list = []
        for phi_ir in phi_ir_list:
            if phi_ir.id not in all_phi_ir_entities:
                # 第一次遇到这个phi，转换为实体
                phi_entity = phi_ir.to_entity()
                all_phi_ir_entities[phi_ir.id] = phi_entity
            else:
                # 使用已转换的实体
                phi_entity = all_phi_ir_entities[phi_ir.id]
            phi_entity_list.append(phi_entity)
        phi_func_by_scope[scope_id] = phi_entity_list

    # 建立phi_func_by_name索引 - 用原始变量名索引第一个遇到的phi
    for phi_entity in all_phi_ir_entities.values():
        # 提取原始变量名（无版本号的那个）
        original_name = None
        for ref_name in phi_entity.referred_name:
            if '.' not in ref_name:
                original_name = ref_name
                break
        if original_name is None and phi_entity.referred_name:
            original_name = phi_entity.referred_name[0].split('.')[0]
        if original_name and original_name not in phi_func_by_name:
            phi_func_by_name[original_name] = phi_entity

    # 收集所有 phi 函数中引用的所有变量名（包括版本化的）
    # 这些变量需要在 env 中有初始值
    all_phi_referred_vars = set()
    for phi_entity in all_phi_ir_entities.values():
        for ref_name in phi_entity.referred_name:
            all_phi_referred_vars.add(ref_name)

    return phi_func_by_scope, phi_func_by_name, all_phi_referred_vars


def backend_entity_build(
        kernel_ir: KernelIR,
        variable_ctx: dict[str, int | float | bool | MemLoc | DType],
        task_kernel: bool = True
) -> BackendEntity:
    task_dict = {}
    tensor_dict = {}
    host_ops = []
    op_list = []
    for op in kernel_ir.ops:
        logistic_entity = op.to_entity()
        if isinstance(op, TaskIR):
            task_dict[logistic_entity.name] = logistic_entity
        elif isinstance(op, OpIR) and op.level == OpLevel.HOST_OP:
            host_ops.append(logistic_entity)
        elif task_kernel:
            raise ValueError("kernel_ir.ops must be TaskIR or host OpIR")

        op_list.append(logistic_entity)

    phi_func_by_scope, phi_func_by_name, all_phi_referred_vars = _deal_phi_func(kernel_ir)

    # 为这些变量添加初始值到 env
    complete_env = dict(variable_ctx)  # 复制原有的 variable_ctx
    for var_name in all_phi_referred_vars:
        if var_name not in complete_env:
            # 为循环索引变量等添加默认初始值 0
            complete_env[var_name] = 0

    eval_ctx = EvalCtxEntity(env=complete_env, phi_func_by_scope=phi_func_by_scope, phi_func_by_name=phi_func_by_name)
    return BackendEntity(
        task_dict=task_dict,
        tensor_dict=tensor_dict,
        eval_ctx=eval_ctx,
        host_ops=host_ops,
        op_list=op_list,
    )
