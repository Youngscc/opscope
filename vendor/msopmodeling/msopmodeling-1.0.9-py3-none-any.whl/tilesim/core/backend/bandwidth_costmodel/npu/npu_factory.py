from core.backend.bandwidth_costmodel.npu.npu_type import NPUTYPE
from core.common.log_format import logging

# 创建一个日志记录器
logger = logging.getLogger(__name__)


class NPUFactory:

    def get_npu(self, npu_type: NPUTYPE):
        if npu_type not in self.npu_dict:
            # 未注册的，默认使用David100的带宽计算公式
            logger.warning(f"use default npu type, and {npu_type} not in {self.npu_dict}")
            return self.npu_dict[NPUTYPE.DavidV100]
        return self.npu_dict[npu_type]
