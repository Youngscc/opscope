from core.common.log_format import logging
from enum import Enum
from abc import ABCMeta, abstractmethod
from core.common.entity import MemLoc


class NPUBandwidth(metaclass=ABCMeta):
    @abstractmethod
    def get_bandwidth(self, path: tuple[MemLoc, MemLoc], core_num: int = -1) -> float:
        pass

    @abstractmethod
    def check_path(self, path: tuple[MemLoc, MemLoc]) -> bool:
        pass


# 创建一个日志记录器
logger = logging.getLogger(__name__)


class NPUTYPE(Enum):
    DavidV100 = "davidV100"
    DavidV120 = "davidV120"

    @staticmethod
    def from_str(npu_type):
        for npu in NPUTYPE:
            if npu.value == npu_type:
                return npu
        logger.error(f"NPU type {npu_type} is not supported")
        return None