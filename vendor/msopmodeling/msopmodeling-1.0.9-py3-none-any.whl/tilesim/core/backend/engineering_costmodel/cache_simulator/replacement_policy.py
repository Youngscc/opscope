# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from abc import ABC, abstractmethod
from enum import Enum
from typing import Dict, Optional, OrderedDict, List

import numpy as np


class ReplacementPolicyType(Enum):
    FIFO = "FIFO"
    LRU = "LRU"
    P_LRU = "Pseudo-LRU"


class ReplacementPolicy(ABC):
    """替换策略抽象基类"""

    def __init__(self):
        self._access_record: Dict[str, any] = {}

    @abstractmethod
    def on_access(self, tensor_name: str) -> None:
        """当访问某个张量时调用"""
        pass

    @abstractmethod
    def on_insert(self, tensor_name: str) -> None:
        """当插入新张量时调用"""
        pass

    @abstractmethod
    def on_remove(self, tensor_name: str) -> None:
        """当移除张量时调用"""
        pass

    @abstractmethod
    def get_victim(self) -> Optional[str]:
        """获取需要被替换的张量名称"""
        pass

    @abstractmethod
    def reset(self) -> None:
        """重置策略状态"""
        pass


class FIFOPolicy(ReplacementPolicy):
    """先进先出（FIFO）替换策略"""

    def __init__(self):
        super().__init__()
        self._queue: List[str] = []

    def on_access(self, tensor_name: str) -> None:
        """FIFO策略下，访问不改变顺序"""
        pass

    def on_insert(self, tensor_name: str) -> None:
        """插入到队尾"""
        if tensor_name not in self._queue:
            self._queue.append(tensor_name)

    def on_remove(self, tensor_name: str) -> None:
        """从队列中移除"""
        if tensor_name in self._queue:
            self._queue.remove(tensor_name)

    def get_victim(self) -> Optional[str]:
        """返回队首元素"""
        return self._queue[0] if self._queue else None

    def reset(self) -> None:
        """重置队列"""
        self._queue.clear()


class LRUPolicy(ReplacementPolicy):
    """最近最少使用（LRU）替换策略"""

    def __init__(self):
        super().__init__()
        self._access_order: OrderedDict[str, None] = OrderedDict()

    def on_access(self, tensor_name: str) -> None:
        """访问时移动到最后（最近使用）"""
        if tensor_name in self._access_order:
            self._access_order.move_to_end(tensor_name)

    def on_insert(self, tensor_name: str) -> None:
        """插入到最后"""
        self._access_order[tensor_name] = None
        self._access_order.move_to_end(tensor_name)

    def on_remove(self, tensor_name: str) -> None:
        """从记录中移除"""
        if tensor_name in self._access_order:
            del self._access_order[tensor_name]

    def get_victim(self) -> Optional[str]:
        """返回最久未使用的元素"""
        return next(iter(self._access_order)) if self._access_order else None

    def reset(self) -> None:
        """重置访问记录"""
        self._access_order.clear()


class PseudoLRUPolicy(ReplacementPolicy):
    """伪LRU（pseudo-LRU）替换策略
    使用树形结构，降低LRU的复杂度
    """

    def __init__(self):
        super().__init__()
        self._tensor_list: List[str] = []
        self._tensor_index: Dict[str, int] = {}
        self._tree_bits: List[bool] = []

    def _init_tree(self, size: int) -> None:
        """初始化树结构"""
        if size <= 1:
            self._tree_bits = []
            return

        # 树的节点数量（满二叉树）
        tree_size = size - 1
        self._tree_bits = [False] * tree_size

    def _get_victim_index(self) -> int:
        """根据树形结构获取victim的索引"""
        if not self._tree_bits:
            return 0

        index = 0
        node = 0
        size = len(self._tensor_list)

        while node < len(self._tree_bits):
            if self._tree_bits[node]:
                # 向左走
                self._tree_bits[node] = False
                node = 2 * node + 1
            else:
                # 向右走
                self._tree_bits[node] = True
                node = 2 * node + 2

            # 计算当前位置
            level = int(np.log2(node + 2))
            offset = node - (2 ** level - 1)
            index = offset * (size // (2 ** level))

        return min(index, size - 1)

    def _update_tree(self, index: int) -> None:
        """更新访问路径上的树节点"""
        if not self._tree_bits:
            return

        size = len(self._tensor_list)
        node = 0

        while node < len(self._tree_bits):
            level = int(np.log2(node + 2))
            mid = size // (2 ** (level + 1))

            if index < mid:
                # 在左子树
                self._tree_bits[node] = True
                node = 2 * node + 1
            else:
                # 在右子树
                self._tree_bits[node] = False
                node = 2 * node + 2
                index -= mid

    def on_access(self, tensor_name: str) -> None:
        """访问时更新树"""
        if tensor_name in self._tensor_index:
            index = self._tensor_index[tensor_name]
            self._update_tree(index)

    def on_insert(self, tensor_name: str) -> None:
        """插入新张量"""
        if tensor_name not in self._tensor_index:
            self._tensor_list.append(tensor_name)
            self._tensor_index[tensor_name] = len(self._tensor_list) - 1
            self._init_tree(len(self._tensor_list))

    def on_remove(self, tensor_name: str) -> None:
        """移除张量"""
        if tensor_name in self._tensor_index:
            index = self._tensor_index[tensor_name]
            self._tensor_list.pop(index)

            # 重建索引
            self._tensor_index.clear()
            for i, name in enumerate(self._tensor_list):
                self._tensor_index[name] = i

            self._init_tree(len(self._tensor_list))

    def get_victim(self) -> Optional[str]:
        """获取victim"""
        if not self._tensor_list:
            return None

        index = self._get_victim_index()
        return self._tensor_list[index]

    def reset(self) -> None:
        """重置状态"""
        self._tensor_list.clear()
        self._tensor_index.clear()
        self._tree_bits.clear()
