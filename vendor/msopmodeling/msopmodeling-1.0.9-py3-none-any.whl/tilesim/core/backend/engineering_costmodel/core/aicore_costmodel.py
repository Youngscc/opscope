# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

import math

from scipy.interpolate import interp1d

from core.common.entity import Cube, DType, Tile, CycleType, MemLoc
from core.backend.engineering_costmodel.core.vector_op import VectorBasicOp
from core.config.arc_spec import ArcConfig


class AICoreCostModel:

    def __init__(self, arc_config: ArcConfig, fixpipe_calculate: int = 1, pure_fp32: int = 1):
        """
        某个芯片的AIC核硬件参数
        所有时间计算返回单位都是 us
        """
        self.arc_config = arc_config
        self.fixpipe_calculate = fixpipe_calculate
        self.pure_fp32 = pure_fp32

    def time_mte1(self, cube: Cube, right_tile: Tile) -> float:
        curr_mem = cube.m * cube.k * cube.precision.size

        bw_result, _ = self.arc_config.lookup_bw(MemLoc.L1, MemLoc.L0A)
        if isinstance(bw_result, dict):
            # NEXT -- 此处只在Conv算子用到，npu_spec整改后暂时不会进入这个分支
            mem_values = [int(k) for k in self.npu_spec.l1_l0a_bw]
            bw_values = list(self.npu_spec.l1_l0a_bw.values())
            bw = interp1d(mem_values, bw_values, kind="linear", fill_value="extrapolate", )(curr_mem / 1024)
        else:
            bw = bw_result

        delta = 1e-3
        time_a = curr_mem / bw + delta
        if right_tile.op_name == "Conv2D" and right_tile.input_bias == 1:
            time_b = 0
        else:
            l0b_bw, _ = self.arc_config.lookup_bw(MemLoc.L1, MemLoc.L0B)
            time_b = cube.n * cube.k * cube.precision.size / l0b_bw + delta

        return time_a + time_b

    def time_cube(self, cube: Cube) -> float:
        if cube.precision not in self.arc_config.cube_config.cube_throughput.keys():
            raise ValueError(f"cube.precision: {cube.precision} not right precision type!")
        basic_mkn = self.arc_config.cube_config.cube_throughput.get(cube.precision)
        repeats = (
                math.ceil(cube.m / basic_mkn[0])
                * math.ceil(cube.k / basic_mkn[1])
                * math.ceil(cube.n / basic_mkn[2])
                / self.arc_config.clock_freq
        )

        time = repeats * self.arc_config.cube_config.cube_repeat_cycles.get(cube.precision)
        return time

    def time_fixpipe(self, m, n, precision: DType, core_num) -> float:
        if not self.fixpipe_calculate:
            return 0

        # NEXT -- nz2nd = 0/1 都需要补充上
        delta_nz2nd = 14e-3
        fixpipe_bw, _ = self.arc_config.lookup_bw(MemLoc.L0C, MemLoc.GM, core_num)
        time = m * n * precision.size / fixpipe_bw + delta_nz2nd
        return time

    def time_mte2_aic(self, tile: Tile, core_num) -> float:
        data_volume = tile.size * tile.precision.size

        if tile.l1_hit == 1:
            return 0

        # NEXT -- core num 需要融入到公式里面去
        if tile.op_name == "Conv2D" and tile.input_bias == 1:
            gm_bw, _ = self.arc_config.lookup_bw(MemLoc.GM, MemLoc.L0B, core_num)
        else:
            gm_bw, _ = self.arc_config.lookup_bw(MemLoc.GM, MemLoc.L1, core_num)
        l2_bw, _ = self.arc_config.lookup_bw(MemLoc.L2, MemLoc.L1, core_num)

        delta_miss = 14e-3
        miss_time = delta_miss + data_volume / (gm_bw / 1)

        delta_hit = 3e-3
        hit_time = delta_hit + data_volume / (l2_bw / 1)
        return hit_time * tile.l2_hit + miss_time * (1 - tile.l2_hit)

    def time_mte2_aiv(
            self,
            data_volumes: list[float],
            hit_rate: float,
            core_num: int,
            small_pack: bool = True,
    ) -> float:
        mte2_time = 0.0
        for data_volume in data_volumes:
            if small_pack:
                eff = min(1.533e-4 * data_volume + 0.0084369, 1)  # 小包搬运拟合值
            else:
                eff = 1
            gm_ub_bw, _ = self.arc_config.lookup_bw(MemLoc.GM, MemLoc.UB, core_num)
            miss_time = data_volume / gm_ub_bw / eff

            if hit_rate == 0:
                mte2_time += miss_time
            else:
                l2_ub_bw, _ = self.arc_config.lookup_bw(MemLoc.L2, MemLoc.UB, core_num)
                hit_time = data_volume / l2_ub_bw
                mte2_time += hit_time * hit_rate + miss_time * (1 - hit_rate)
        return mte2_time

    def time_mte3(
            self,
            data_volumes: list[float],
            hit_rate: float,
            core_num: int,
            small_pack: bool = True,
    ) -> float:
        delta_miss = 1e-3
        delta_hit = 141e-3
        mte3_time = 0.0
        for data_volume in data_volumes:
            if small_pack:
                eff = min(7.37e-5 * data_volume + 0.0061727, 1)  # 小包搬运拟合值
            else:
                eff = 1
            ub_gm_bw, _ = self.arc_config.lookup_bw(MemLoc.UB, MemLoc.GM, core_num)
            miss_time = delta_miss + data_volume / ub_gm_bw / eff

            if hit_rate == 0:
                mte3_time += miss_time
            else:
                ub_l2_bw, _ = self.arc_config.lookup_bw(MemLoc.UB, MemLoc.L2, core_num)
                hit_time = delta_hit + data_volume / ub_l2_bw
                mte3_time += hit_time * hit_rate + miss_time * (1 - hit_rate)
        return mte3_time

    def time_mte3_load(self, data_volumes: list[float]) -> float:
        mte3_time = 0.0
        for data_volume in data_volumes:
            ub_shm_bw, _ = self.arc_config.lookup_bw(MemLoc.UB, MemLoc.SHM)
            mte3_time += data_volume / ub_shm_bw + 50  # 认为卡间通信有50us头开销
        return mte3_time

    def time_vec(self, op_list: list[VectorBasicOp], element_cnt_map: dict[int, float]):
        if len(op_list) == 0:
            return 0, 0

        total_cycles = self.arc_config.lookup_vec_cycle(
            op_list[0].op_type, op_list[0].precision, CycleType.HEAD_CYCLES
        )

        for op in op_list:
            op_element_cnt = element_cnt_map.get(op.id)
            throughput = self.arc_config.vec_config.vec_size_single_repeat[op.precision] / op.precision.size

            # vec组件计算花费时间
            basic_computation_blocks = math.ceil(op_element_cnt / throughput)
            cycles = (
                    self.arc_config.lookup_vec_cycle(
                        op.op_type, op.precision, CycleType.COMPUTING_CYCLES
                    )
                    * basic_computation_blocks
            )

            # 同步花费时间
            if op.pipe_barrier:
                cycles += self.arc_config.lookup_vec_cycle(
                    op.op_type, op.precision, CycleType.INTERVAL_CYCLES
                )

            total_cycles += cycles

        time = total_cycles / self.arc_config.clock_freq
        return time, total_cycles
