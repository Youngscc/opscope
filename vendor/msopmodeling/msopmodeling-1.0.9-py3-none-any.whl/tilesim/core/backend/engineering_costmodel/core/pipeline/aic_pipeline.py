# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.common.entity import Tile, Cube, ResultKey, PipeAnaConfig, CoreUnit
from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.backend.engineering_costmodel.core.pipeline.util import calculate_tail_blocks_pipeline_time
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam


def _validate_and_preprocess_tiles(input_tiles: list[Tile], output_tiles: list[Tile]):
    """验证输入输出 tiles 的一致性，并进行预处理，构建索引"""
    if set([t.idx_in_section for t in input_tiles]) != set(
            [t.idx_in_section for t in output_tiles]
    ):
        raise ValueError(f"set of idx_in_section of input_tiles not equal")

    # 同一个idx_in_section表示的是同一个m,n的计算
    l1_input_idx_set = [(t.idx_in_section, t.col_start) for t in input_tiles]
    l1_input_idx_set.sort(key=lambda x: (x[0], x[1]))

    input_tiles_by_idx = {idx: [] for idx in l1_input_idx_set}
    for tile in input_tiles:
        input_tiles_by_idx[(tile.idx_in_section, tile.col_start)].append(tile)
    output_tiles_by_idx = {}
    for tile in output_tiles:
        if output_tiles_by_idx.get(tile.idx_in_section) is not None:
            raise ValueError(f"tile.idx_in_section is not None")
        output_tiles_by_idx[tile.idx_in_section] = tile

    return input_tiles_by_idx, output_tiles_by_idx


def _is_last_tile_in_k_axis(tile: Tile) -> bool:
    if tile.input_bias != 0:
        raise ValueError(f"tile.input_bias is not 0")
    k = tile.section.k
    tile_k = tile.col_start + tile.cols
    if tile_k > k:
        raise ValueError(f"tile_k is larger than k")
    return tile_k == k


class AICPipeline:
    def __init__(
            self,
            aicore: AICoreCostModel,
            tiling_param: TilingParam,
            delta_l0: float = 0,
            delta_l1: float = 0,
    ):
        """
        AIC 核内并行流水时间计算
        :param aicore:          AIC核costmodel
        :param tiling_param:    tiling配置
        :param delta_l0:        l0层的时间调整系数
        :param delta_l1:        l1层的时间调整系数
        """
        self.aicore = aicore
        self.tiling_param = tiling_param
        self.delta_l1 = delta_l1
        self.delta_l0 = delta_l0

        self.statistic_record = {}
        self.pipe_ana_config = PipeAnaConfig()

    def _init_pipe(self, config: PipeAnaConfig):
        self.statistic_record = {
            ResultKey.MTE2_TIME_AIC: 0,
            ResultKey.MTE1_TIME: 0,
            ResultKey.CUBE_TIME: 0,
            ResultKey.FIXPIPE_TIME: 0,
            ResultKey.CORE_TIME: 0,
            ResultKey.AIC_TIME: 0,
        }

        if config is None:
            config = PipeAnaConfig()
        self.pipe_ana_config = config

    def _calculate_l0_time(self, left_tile: Tile, right_tile: Tile) -> float:
        """ 给定一个L1 层的tile块，计算其L0 层的花费时间这里是切k轴的计算，计算结果L0C上累加，也即，一次l1tile，一次fixpipe搬运，所以，fixpipe时间先不放这里"""
        if left_tile.precision != right_tile.precision:
            raise ValueError(f"left_tile.precision not equal")
        left_l0 = left_tile.split_l0(self.tiling_param)
        right_l0 = right_tile.split_l0(self.tiling_param)
        if self.tiling_param.align_tiles:
            if len(left_l0) > len(right_l0):
                left_l0 = left_l0[: len(right_l0)]
            else:
                right_l0 = right_l0[: len(left_l0)]
        if len(left_l0) != len(right_l0):
            raise ValueError(f"left_l0 and right_l0 not equal")

        # 按照K轴从大到小、M\N轴从大到小排序
        left_l0.sort(key=lambda x: (x[1], x[0]), reverse=True)
        right_l0.sort(key=lambda x: (x[1], x[0]), reverse=True)

        # 生成L0 tile
        l0_tiles = []
        mkn = ()
        has_tail = False
        for (m, ka), (n, kb) in zip(left_l0, right_l0):
            if ka != kb:
                raise ValueError(f"ka and kb not equal")

            l0_tiles.append(Cube(m, ka, n, left_tile.precision))

            if not has_tail and not mkn:
                mkn = (m, ka, n)
            else:
                if (m != mkn[0]) or (ka != mkn[1]) or (n != mkn[2]):
                    has_tail = True

        if has_tail:
            # 如果有尾块，则按照通用累加公式计算时间
            data_time = []
            for tile in l0_tiles:
                time_mte1 = self.aicore.time_mte1(tile, right_tile)
                time_cube = self.aicore.time_cube(tile)
                if (CoreUnit.AIC_MTE1, CoreUnit.CUBE) in self.pipe_ana_config.un_parallel_components:
                    data_time.append((time_mte1 + time_cube))
                else:
                    data_time.append((time_mte1, time_cube))
                self.statistic_record[ResultKey.MTE1_TIME] += time_mte1
                self.statistic_record[ResultKey.CUBE_TIME] += time_cube

            l0_time = calculate_tail_blocks_pipeline_time(data_time)

        else:
            # 如果无尾块，直接套用公式
            tile = l0_tiles[0]
            time_mte1 = self.aicore.time_mte1(tile, right_tile)
            time_cube = self.aicore.time_cube(tile)

            self.statistic_record[ResultKey.MTE1_TIME] += time_mte1 * len(l0_tiles)
            self.statistic_record[ResultKey.CUBE_TIME] += time_cube * len(l0_tiles)

            if (CoreUnit.AIC_MTE1, CoreUnit.CUBE) in self.pipe_ana_config.un_parallel_components:
                l0_time = len(l0_tiles) * (time_mte1 + time_cube) + self.delta_l0
            else:
                time_bn = max(time_mte1, time_cube)
                l0_time = (len(l0_tiles) - 1) * time_bn + time_mte1 + time_cube + self.delta_l0

        return l0_time

    def _process_tile_pair_time(self, input_tiles_by_idx, output_tiles_by_idx) -> list[tuple]:
        """处理所有 L1 tile 组，计算时间"""
        time_data = []

        for idx, input_tiles in input_tiles_by_idx.items():
            # 默认L1层tiling AB是一样的。k1a、k1b不同切法的情况后续再考虑
            if len(input_tiles) != 2:
                raise ValueError(f"len of input_tiles is not 2")
            input_tiles.sort(key=lambda t: t.input_bias)
            output_tile = output_tiles_by_idx.get(idx[0], None)

            if output_tile is None:
                continue

            # 计算时间
            time_mte2 = 0
            for tile in input_tiles:
                time_mte2 += self.aicore.time_mte2_aic(tile, self.tiling_param.parallel_core_num)
            time_l0 = self._calculate_l0_time(input_tiles[0], input_tiles[1])

            time_fixpipe = 0
            if _is_last_tile_in_k_axis(input_tiles[0]) and input_tiles[0].section.copy_out:
                time_fixpipe = self.aicore.time_fixpipe(output_tile.rows, output_tile.cols, output_tile.precision, self.tiling_param.parallel_core_num)

            self.statistic_record[ResultKey.MTE2_TIME_AIC] += time_mte2
            self.statistic_record[ResultKey.FIXPIPE_TIME] += time_fixpipe

            if (CoreUnit.AIC_MTE2, CoreUnit.CUBE) in self.pipe_ana_config.un_parallel_components:
                tile_time = (time_mte2 + time_l0, time_fixpipe)
            elif (CoreUnit.CUBE, CoreUnit.AIC_FIXPIPE) in self.pipe_ana_config.un_parallel_components:
                tile_time = (time_mte2, time_l0 + time_fixpipe)
            elif (CoreUnit.AIC_MTE2, CoreUnit.AIC_FIXPIPE) in self.pipe_ana_config.un_parallel_components:
                tile_time = (time_mte2 + time_fixpipe, time_l0)
            else:
                tile_time = (time_mte2, time_l0, time_fixpipe)
            time_data.append(tile_time)
        return time_data

    def calculate_time(self, input_tiles: list[Tile], output_tiles: list[Tile], pip_ana_config: PipeAnaConfig = None):
        """计算多个 L1 tile块的计算时间"""
        self._init_pipe(pip_ana_config)

        # 1. 验证和预处理
        input_tiles_by_idx, output_tiles_by_idx = _validate_and_preprocess_tiles(input_tiles, output_tiles)

        # 2. 计算 L1 tile 时间并判断尾块
        time_data = self._process_tile_pair_time(input_tiles_by_idx, output_tiles_by_idx)

        # 3. 计算最终 L1 时间
        time_l1 = calculate_tail_blocks_pipeline_time(time_data)

        self.statistic_record[ResultKey.AIC_TIME] = time_l1
        self.statistic_record[ResultKey.CORE_TIME] = time_l1
        return self.statistic_record