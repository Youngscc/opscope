# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from tqdm import tqdm

from core.common.entity import (
    CoreType,
    Tile,
    DirectionType,
    Section,
)
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_check_tools import (
    plot_animation,
    check_tensor_for_output,
)
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam


class LoopParam:
    def __init__(
            self,
            outer_max,
            outer_step,
            inner_max,
            inner_step,
            direction: DirectionType,
            snake=True,
    ):
        self.outer_max = outer_max
        self.outer_step = outer_step
        self.outer_idx = 0

        self.inner_max = inner_max
        self.inner_min = 0
        self.inner_step = inner_step
        self.inner_idx = 0

        self.direction = direction
        self.snake = snake

        self.rows_max = outer_max if direction == DirectionType.Z else inner_max
        self.cols_max = inner_max if direction == DirectionType.Z else outer_max

        # snake型移动需要，如果是1则表示正向从小到大移动。-1则表示从大到小
        self.inner_dir = 1
        # 用于处理转角处的数值
        self.last_inner_step = inner_step
        self.corner_step = False

    def set_bound(self, upper_loop):
        """
        根据外围的循环，来确定本层循环的范围。本层循环的范围 min、max 为上层循环的一个step范围，需要和上层的bound取交集
        Args:
            upper_loop: 上层的循环

        Returns:

        """
        upper_inner_step = (
            upper_loop.last_inner_step
            if upper_loop.corner_step
            else upper_loop.inner_step
        )

        # 如果与上层循环的方向一致，那么 这层的outer - 上层的outer
        if self.direction == upper_loop.direction:
            # 本层的 outer max = 上层的outer的当前idx+步长，但不应当超过外围的max
            self.outer_max = min(
                upper_loop.outer_step, upper_loop.outer_max - upper_loop.outer_idx
            )
            self.inner_max = min(
                upper_inner_step, upper_loop.inner_max - upper_loop.inner_idx
            )
            self.inner_min = 0
        # 如果与上层循环的方向相反，那么 这层的outer - 上层的inner
        else:
            self.outer_max = min(
                upper_loop.outer_step, upper_loop.inner_max - upper_loop.inner_idx
            )
            self.inner_max = min(
                upper_inner_step, upper_loop.outer_max - upper_loop.outer_idx
            )
            self.inner_min = 0

        self.rows_max = (
            self.outer_max if self.direction == DirectionType.Z else self.inner_max
        )
        self.cols_max = (
            self.inner_max if self.direction == DirectionType.Z else self.outer_max
        )
        # 重置方向
        self.inner_dir = 1
        self.last_inner_step = min(self.inner_step, self.inner_max - self.inner_min)

    def update_inner_idx(self):
        if self.inner_dir == 1:
            # 如果超出max范围（到转角了）
            if self.inner_idx + self.inner_step >= self.inner_max:
                self.last_inner_step = self.inner_max - self.inner_idx
                self.inner_idx = self.inner_max
            else:
                self.inner_idx += self.inner_step
        else:
            self.inner_idx -= self.inner_step
        self.corner_step = False

    def init_inner_idx(self):
        if self.inner_dir == 1:
            self.inner_idx = 0
        else:
            self.inner_idx = self.inner_max - self.last_inner_step

    def update_outer_idx(self):
        self.outer_idx += self.outer_step
        if self.outer_idx > self.outer_max:
            self.outer_idx = self.outer_max
        # outer更新完之后，如果是snake形式，则方向反向
        if self.snake:
            self.inner_dir *= -1
            if self.inner_dir == -1:
                self.corner_step = True

    def not_reach_inner_bound(self):
        # 从小到大，按照max来判断
        if self.inner_dir == 1:
            return self.inner_idx < self.inner_max
        else:
            return self.inner_idx >= self.inner_min

    def inner_idx_reach_ultra_bound(self, ultra_loop):
        if self.direction == ultra_loop.direction:
            return self.inner_idx == ultra_loop.inner_max
        else:
            return self.inner_idx == ultra_loop.outer_max

    def get_rows_cols(self, tm, tn):

        inner_remain = self.inner_max - self.inner_idx
        outer_remain = self.outer_max - self.outer_idx

        if self.corner_step:
            inner_remain = self.last_inner_step

        rows = (
            min(outer_remain, tm)
            if self.direction == DirectionType.Z
            else min(inner_remain, tn)
        )
        cols = (
            min(inner_remain, tn)
            if self.direction == DirectionType.Z
            else min(outer_remain, tm)
        )

        return rows, cols


def generate_tiles_one_direction(
        multi_core_loop: LoopParam,
        core_loop: LoopParam,
        stride_loop: LoopParam,
        section: Section,
        open_check=False,
        open_bar=False,
) -> tuple[list[Tile], list[Tile]]:
    """
    给定多核循环、核心循环和步长循环参数，完成分核和L1 tiling
    """
    tiling_param = section.tiling_param
    # 处理k方向分核（均分）
    k_core_split_lens = _calculate_k_core_split_lens(section, tiling_param)

    pbar = tqdm(total=multi_core_loop.outer_max, desc="generate tiles", unit=" tiles") if open_bar else None

    input_tiles, output_tiles = _process_multi_core_loop(
        multi_core_loop, core_loop, stride_loop, section,
        tiling_param, k_core_split_lens, open_bar, pbar
    )

    if open_check:
        _check_and_plot_output_tiles(output_tiles, multi_core_loop, section, k_core_split_lens)

    if open_bar and pbar:
        pbar.close()

    return input_tiles, output_tiles


def _process_multi_core_loop(
        multi_core_loop: LoopParam,
        core_loop: LoopParam,
        stride_loop: LoopParam,
        section: Section,
        tiling_param,
        k_core_split_lens,
        open_bar,
        pbar
) -> tuple[list[Tile], list[Tile]]:
    input_tiles, output_tiles = [], []
    core_idx_in_section_offset = 0
    max_idx_in_section = 0

    while multi_core_loop.outer_idx < multi_core_loop.outer_max:
        multi_core_loop.init_inner_idx()
        while multi_core_loop.not_reach_inner_bound():
            core_input_tiles, core_output_tiles, new_max_idx = _process_core_loop(
                multi_core_loop, core_loop, stride_loop, section,
                tiling_param, k_core_split_lens, core_idx_in_section_offset
            )

            input_tiles.extend(core_input_tiles)
            output_tiles.extend(core_output_tiles)
            max_idx_in_section = max(max_idx_in_section, new_max_idx)

            multi_core_loop.update_inner_idx()

        if open_bar and pbar:
            pbar.update(multi_core_loop.outer_step)
        multi_core_loop.update_outer_idx()

    return input_tiles, output_tiles


def _process_core_loop(
        multi_core_loop: LoopParam,
        core_loop: LoopParam,
        stride_loop: LoopParam,
        section: Section,
        tiling_param,
        k_core_split_lens,
        core_idx_in_section_offset
) -> tuple[list[Tile], list[Tile], int]:
    input_tiles, output_tiles = [], []
    max_idx_in_section = 0

    multi_core_row_offset, multi_core_col_offset = _get_multi_core_offsets(
        multi_core_loop, tiling_param.swizzle_direction
    )

    core_loop.set_bound(multi_core_loop)
    core_loop.outer_idx = 0
    core_idx = 0

    while core_loop.outer_idx < core_loop.outer_max:
        core_loop.init_inner_idx()
        while core_loop.not_reach_inner_bound():
            stride_input_tiles, stride_output_tiles, new_idx = _process_stride_loop(
                multi_core_row_offset, multi_core_col_offset,
                core_loop, stride_loop, section,
                tiling_param, k_core_split_lens,
                core_idx, core_idx_in_section_offset
            )

            input_tiles.extend(stride_input_tiles)
            output_tiles.extend(stride_output_tiles)
            max_idx_in_section = max(max_idx_in_section, new_idx)

            core_idx += tiling_param.d
            core_loop.update_inner_idx()
        core_loop.update_outer_idx()

    return input_tiles, output_tiles, max_idx_in_section


def _process_stride_loop(
        multi_core_row_offset,
        multi_core_col_offset,
        core_loop: LoopParam,
        stride_loop: LoopParam,
        section: Section,
        tiling_param,
        k_core_split_lens,
        core_idx,
        idx_in_section
) -> tuple[list[Tile], list[Tile], int]:
    input_tiles, output_tiles = [], []
    max_idx_in_section = idx_in_section

    core_row_offset, core_col_offset = _get_core_offsets(
        core_loop, tiling_param.swizzle_direction
    )

    stride_loop.set_bound(core_loop)
    stride_loop.outer_idx = 0

    while stride_loop.outer_idx < stride_loop.outer_max:
        stride_loop.init_inner_idx()
        while stride_loop.not_reach_inner_bound():
            input_tiles_per_core, output_tiles_per_core = _process_single_stride(
                multi_core_row_offset, multi_core_col_offset,
                core_row_offset, core_col_offset,
                stride_loop, section,
                tiling_param, k_core_split_lens,
                core_idx, idx_in_section
            )

            input_tiles.extend(input_tiles_per_core)
            output_tiles.extend(output_tiles_per_core)
            # 每个stride，idx_in_section加一
            max_idx_in_section = max(max_idx_in_section, idx_in_section)

            idx_in_section += 1
            stride_loop.update_inner_idx()
        stride_loop.update_outer_idx()

    return input_tiles, output_tiles, max_idx_in_section


def _process_single_stride(
        multi_core_row_offset,
        multi_core_col_offset,
        core_row_offset,
        core_col_offset,
        stride_loop: LoopParam,
        section: Section,
        tiling_param,
        k_core_split_lens,
        core_idx,
        idx_in_section
) -> tuple[list[Tile], list[Tile]]:
    stride_row_offset, stride_col_offset = _get_stride_offsets(
        stride_loop, tiling_param.swizzle_direction
    )

    row_start, col_start = _calculate_row_col_start(
        multi_core_row_offset, core_row_offset, stride_row_offset,
        multi_core_col_offset, core_col_offset, stride_col_offset
    )

    rows, cols = stride_loop.get_rows_cols(tiling_param.m1, tiling_param.n1)

    return _generate_tiles(
        section, core_idx, row_start, col_start, rows, cols,
        tiling_param, k_core_split_lens, idx_in_section
    )


def _calculate_k_core_split_lens(section: Section, tiling_param: TilingParam) -> list[int]:
    """
    计算k方向分核的长度
    """
    if section.core_type == CoreType.AIC:
        k_core_split_lens = []
        former_k = section.k // tiling_param.d
        tail_cnt = section.k % tiling_param.d
        for idx in range(tiling_param.d):
            k_core_split_lens.append(former_k + 1 if idx < tail_cnt else former_k)
    else:
        k_core_split_lens = [section.k]
    return k_core_split_lens


def _get_multi_core_offsets(multi_core_loop: LoopParam, direction: DirectionType) -> tuple[int, int]:
    """
    获取多核循环的行和列偏移
    """
    multi_core_row_offset = (
        multi_core_loop.outer_idx if direction == DirectionType.Z else multi_core_loop.inner_idx
    )
    multi_core_col_offset = (
        multi_core_loop.inner_idx if direction == DirectionType.Z else multi_core_loop.outer_idx
    )
    return multi_core_row_offset, multi_core_col_offset


def _get_core_offsets(core_loop: LoopParam, direction: DirectionType) -> tuple[int, int]:
    """
    获取核心循环的行和列偏移
    """
    core_row_offset = core_loop.outer_idx if direction == DirectionType.Z else core_loop.inner_idx
    core_col_offset = core_loop.inner_idx if direction == DirectionType.Z else core_loop.outer_idx
    return core_row_offset, core_col_offset


def _get_stride_offsets(stride_loop: LoopParam, direction: DirectionType) -> tuple[int, int]:
    """
    获取步长循环的行和列偏移
    """
    stride_row_offset = stride_loop.outer_idx if direction == DirectionType.Z else stride_loop.inner_idx
    stride_col_offset = stride_loop.inner_idx if direction == DirectionType.Z else stride_loop.outer_idx
    return stride_row_offset, stride_col_offset


def _calculate_row_col_start(
        multi_core_row_offset: int,
        core_row_offset: int,
        stride_row_offset: int,
        multi_core_col_offset: int,
        core_col_offset: int,
        stride_col_offset: int,
) -> tuple[int, int]:
    """
    计算行和列的起始位置
    """
    row_start = multi_core_row_offset + core_row_offset + stride_row_offset
    col_start = multi_core_col_offset + core_col_offset + stride_col_offset
    return row_start, col_start


def _generate_tiles(
        section: Section,
        core_idx: int,
        row_start: int,
        col_start: int,
        rows: int,
        cols: int,
        tiling_param: TilingParam,
        k_core_split_lens: list[int],
        idx_in_section: int,
) -> tuple[list[Tile], list[Tile]]:
    """
    根据核类型生成输入和输出Tile
    """
    if section.core_type == CoreType.AIC:
        return _generate_aic_tiles(
            section, core_idx, row_start, col_start, rows, cols,
            tiling_param, k_core_split_lens, idx_in_section
        )
    else:
        return _generate_aiv_tiles(
            section, core_idx, row_start, col_start, rows, cols,
            idx_in_section
        )


def _generate_aic_tiles(
        section: Section,
        core_idx: int,
        row_start: int,
        col_start: int,
        rows: int,
        cols: int,
        tiling_param: TilingParam,
        k_core_split_lens: list[int],
        idx_in_section: int,
) -> tuple[list[Tile], list[Tile]]:
    """
    生成AIC核的输入和输出Tile
    """
    input_tiles_m1_n1_k1 = []
    output_tiles_m1_n1_k1 = []

    k_offset = 0
    k_core_offset = 0
    for k_len_single_core in k_core_split_lens:
        k_core = k_core_offset + core_idx
        # C矩阵
        c_tile = Tile(section, k_core, row_start, col_start, rows, cols, idx_in_section, section.output_precision, -1,
                      depth_start=k_offset, depth=k_len_single_core)
        output_tiles_m1_n1_k1.append(c_tile)
        for k_iter in range(0, k_len_single_core, tiling_param.k1a):
            k_len = (
                tiling_param.k1a
                if k_iter + tiling_param.k1a <= k_len_single_core
                else k_len_single_core - k_iter
            )
            k_start = k_offset + k_iter

            # A矩阵
            a_tile = Tile(section, k_core, row_start, k_start, rows, k_len, idx_in_section, section.input_precision, 0,
                          depth_start=k_offset, depth=k_len_single_core)
            input_tiles_m1_n1_k1.append(a_tile)
            # B矩阵
            b_tile = Tile(section, k_core, col_start, k_start, cols, k_len, idx_in_section, section.input_precision, 1,
                          depth_start=k_offset, depth=k_len_single_core)
            input_tiles_m1_n1_k1.append(b_tile)
        k_offset += k_len_single_core
        k_core_offset += 1

    return input_tiles_m1_n1_k1, output_tiles_m1_n1_k1


def _generate_aiv_tiles(
        section: Section,
        core_idx: int,
        row_start: int,
        col_start: int,
        rows: int,
        cols: int,
        idx_in_section: int,
) -> tuple[list[Tile], list[Tile]]:
    """
    生成AIV核的输入和输出Tile
    """
    input_tiles_m1_n1 = []

    # 生成输入tile
    for i in range(0, section.input_cnt):
        input_tiles_m1_n1.append(
            Tile(
                section,
                core_idx,
                row_start,
                col_start,
                rows,
                cols,
                idx_in_section,
                section.input_precision,
                i,
            )
        )
    # 生成输出tile
    output_tile_m1_n1 = Tile(
        section,
        core_idx,
        row_start,
        col_start,
        rows,
        cols,
        idx_in_section,
        section.output_precision,
        -1,
    )
    return input_tiles_m1_n1, [output_tile_m1_n1]


def _check_and_plot_output_tiles(
        output_tiles: list[Tile],
        multi_core_loop: LoopParam,
        section: Section,
        k_core_split_lens: list[int],
) -> None:
    """
    检查并绘制输出Tile
    """
    m = (
        multi_core_loop.outer_max
        if multi_core_loop.direction == DirectionType.Z
        else multi_core_loop.inner_max
    )
    n = (
        multi_core_loop.inner_max
        if multi_core_loop.direction == DirectionType.Z
        else multi_core_loop.outer_max
    )
    check_tensor_for_output(output_tiles, m, n, k_core_split_lens)

    output_tiles_by_depth_start = {}
    for tile in output_tiles:
        if tile.depth_start not in output_tiles_by_depth_start:
            output_tiles_by_depth_start[tile.depth_start] = []
        output_tiles_by_depth_start[tile.depth_start].append(tile)

    for depth_start, tiles in output_tiles_by_depth_start.items():
        plot_animation(tiles, f"depth = {depth_start}")


def generate_tiles(
        section: Section, open_check=False, open_bar=False
) -> tuple[list[Tile], list[Tile]]:
    """
    对于某个AIC section的输入矩阵，按照tiling参数划分成tiles
    """
    tiling_param = section.tiling_param
    (
        multi_core_m_step,
        multi_core_n_step,
        core_m_step,
        core_n_step,
        stride_m_step,
        stride_n_step,
    ) = tiling_param.get_loop_step()
    if tiling_param.outer_dir == DirectionType.Z:
        multi_core_loop_param = LoopParam(
            section.m,
            multi_core_m_step,
            section.n,
            multi_core_n_step,
            tiling_param.outer_dir,
        )
    else:
        multi_core_loop_param = LoopParam(
            section.n,
            multi_core_n_step,
            section.m,
            multi_core_m_step,
            tiling_param.outer_dir,
        )

    # 单核的遍历方向无所谓，遍历的最大值是根据多核整体的边界的迭代次数算出来的，这里随便设置什么值都可以
    core_loop_param = LoopParam(
        section.m, core_m_step, section.n, core_n_step, DirectionType.Z, snake=False
    )

    # stride遍历的最大值是根据多核移动+stride移动的迭代次数算出来的，这里随便设置什么值都可以
    if tiling_param.inner_dir == DirectionType.Z:
        stride_loop_param = LoopParam(
            section.m, stride_m_step, section.n, stride_n_step, tiling_param.inner_dir
        )
    else:
        stride_loop_param = LoopParam(
            section.n, stride_n_step, section.m, stride_m_step, tiling_param.inner_dir
        )

    input_tiles, output_tiles = generate_tiles_one_direction(
        multi_core_loop_param,
        core_loop_param,
        stride_loop_param,
        section,
        open_check,
        open_bar,
    )
    return input_tiles, output_tiles