# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

import matplotlib
import matplotlib.animation as animation
import matplotlib.patches as patches
import matplotlib.pyplot as plt

from core.common.entity import Tile
from core.common.log_format import logging

# 创建一个日志记录器
logger = logging.getLogger(__name__)


def plot_multi_k(tiles: list[Tile], title="", by_tile=False):
    # 按照k轴分
    tiles_by_k = {}
    for tile in tiles:
        if tile.depth_start not in tiles_by_k:
            tiles_by_k[tile.depth_start] = []
        tiles_by_k[tile.depth_start].append(tile)

    for k, tile_list in tiles_by_k.items():
        plot_animation(tile_list, f"{title} k={k}", by_tile)


def plot_animation(tiles: list[Tile], title="", by_tile=False):
    matplotlib.use("TkAgg")

    # 按照stride分组
    if by_tile:
        tiles.sort(key=lambda x: (x.idx_in_section, x.core))
        update_id = range(0, len(tiles))
    else:
        update_id = set([t.idx_in_section for t in tiles])
    sorted(update_id)
    tiles_by_idx = {idx: [t for t in tiles if t.idx_in_section == idx] for idx in update_id}

    # x,y 最大值
    ax_max = max([t.col_start + t.cols for t in tiles])
    ay_max = max([t.row_start + t.rows for t in tiles])

    fig, ax = plt.subplots()
    ax.set_xlim(0, ax_max)
    ax.set_ylim(0, ay_max)
    ax.invert_yaxis()
    ax.set_aspect("equal")

    squares = []
    color = plt.get_cmap("viridis")
    cores_list = list(set([t.core for t in tiles]))
    x = 0
    for t in tiles:
        logger.info("%s : %s", t.id, x)
        t.id = x
        x += 1

    def init():
        return squares

    def update(frame):
        logger.info("--------%s---------", frame)
        if frame < len(update_id):

            if by_tile:
                tile = tiles[frame]
                ax.text(
                    tile.col_start + tile.cols / 2,
                    tile.row_start + tile.rows / 2,
                    f"{tile.core}",
                    ha="center",
                    va="center",
                    fontsize=6,
                )
                square = patches.Rectangle(
                    (tile.col_start, tile.row_start),
                    tile.cols,
                    tile.rows,
                    facecolor=color(cores_list.index(tile.core) / len(cores_list)),
                    edgecolor="black",
                    alpha=0.7,
                )
                ax.add_patch(square)
                squares.append(square)
            else:
                idx_tiles = tiles_by_idx[frame]

                # 绘制多个核
                for tile in idx_tiles:
                    ax.text(
                        tile.col_start + tile.cols / 2,
                        tile.row_start + tile.rows / 2,
                        f"{tile.id}",
                        ha="center",
                        va="center",
                        fontsize=6,
                    )
                    square = patches.Rectangle(
                        (tile.col_start, tile.row_start),
                        tile.cols,
                        tile.rows,
                        facecolor=color(cores_list.index(tile.core) / len(cores_list)),
                        edgecolor="black",
                        alpha=0.7,
                    )
                    ax.add_patch(square)
                    squares.append(square)
        return squares

    ani = animation.FuncAnimation(
        fig,
        update,
        frames=len(update_id),
        init_func=init,
        blit=False,
        repeat=False,
        interval=100,
    )
    plt.title(title)
    plt.show()


def check_tensor_for_output(tiles: list[Tile], m, n, k_core_split_lens):
    # 大小校验
    total_size = sum([t.size for t in tiles])
    if total_size != m * n * len(k_core_split_lens):
        raise ValueError("Total size does not match the expected size")

    # 按照depth_start分组
    tiles_by_depth_start = group_tiles_by_depth_start(tiles)
    depth_start_set = list(set([t.depth_start for t in tiles]))
    if len(depth_start_set) != len(k_core_split_lens):
        raise ValueError("Length of depth_start_set does not match the length of k_core_split_lens")

    for depth_start, k_len in zip(depth_start_set, k_core_split_lens):
        tiles_single_depth = tiles_by_depth_start.get(depth_start)
        if tiles_single_depth is None:
            raise ValueError("tiles_single_depth get None")

        data = [[1 for _ in range(n)] for _ in range(m)]
        check_depth_and_update_data(tiles_single_depth, k_len, data, m, n)

    logger.info("output tiles check pass!")


def group_tiles_by_depth_start(tiles):
    tiles_by_depth_start = {}
    for tile in tiles:
        if tile.depth_start not in tiles_by_depth_start:
            tiles_by_depth_start[tile.depth_start] = []
        tiles_by_depth_start[tile.depth_start].append(tile)
    return tiles_by_depth_start


def check_depth_and_update_data(tiles_single_depth, k_len, data, m, n):
    for tile in tiles_single_depth:
        if tile.depth != k_len and tile.depth != 0:
            raise ValueError(f"tile.depth = {tile.depth} does not match k_len = {k_len} or 0")
        update_data_with_tile(data, tile)

    check_data_coverage(data, m, n)


def update_data_with_tile(data, tile):
    for i in range(int(tile.row_start), int(tile.row_start + tile.rows)):
        for j in range(int(tile.col_start), int(tile.col_start + tile.cols)):
            if data[i][j] != 1:
                raise ValueError(f"({i},{j}) 数据重复, tile_id = {tile.id}, bias = {tile.input_bias}")
            data[i][j] = 0


def check_data_coverage(data, m, n):
    for i in range(m):
        for j in range(n):
            if data[i][j] != 0:
                raise ValueError(f"({i},{j}) 数据未被覆盖")


def check_input_tensor(
        input_tiles: list[Tile], output_tiles: list[Tile], k_core_split_lens
):
    matrix_a_by_k_start = {}
    matrix_b_by_k_start = {}
    for tile in input_tiles:
        if tile.input_bias == 0:
            if tile.depth_start not in matrix_a_by_k_start:
                matrix_a_by_k_start[tile.depth_start] = []
            matrix_a_by_k_start[tile.depth_start].append(tile)
        else:
            if tile.depth_start not in matrix_b_by_k_start:
                matrix_b_by_k_start[tile.depth_start] = []
            matrix_b_by_k_start[tile.depth_start].append(tile)

    output_by_k_start = {}
    for tile in output_tiles:
        if tile.depth_start not in output_by_k_start:
            output_by_k_start[tile.depth_start] = []
        output_by_k_start[tile.depth_start].append(tile)

    k_start_list = list(set([t.depth_start for t in output_tiles]))
    if len(k_start_list) != len(k_core_split_lens):
        raise ValueError("k_start_list length does not match k_core_split_lens length")
    for k_start, k_len in zip(k_start_list, k_core_split_lens):
        matrix_a = matrix_a_by_k_start.get(k_start)
        matrix_b = matrix_b_by_k_start.get(k_start)
        output_tiles = output_by_k_start.get(k_start)
        if matrix_a is None or matrix_b is None or output_tiles is None:
            raise ValueError("matrix_a or matrix_b or output_tiles get None")

        check_pair_tensor(matrix_a, matrix_b, output_tiles, k_len)
        logger.info("k_start = %s check pass!", k_start)


def check_pair_tensor(matrix_a: list[Tile], matrix_b: list[Tile], output_tiles: list[Tile], k):
    # 按照idx in section分组
    a_by_m, b_by_n = group_tiles_by_section(matrix_a, matrix_b, output_tiles)

    for c in output_tiles:
        m = int(c.row_start)
        n = int(c.col_start)
        a = filter_tiles_by_core(a_by_m[(m, c.idx_in_section)], c.core)
        b = filter_tiles_by_core(b_by_n[(n, c.idx_in_section)], c.core)

        a_data = [[1 for _ in range(k)] for _ in range(c.rows)]
        b_data = [[1 for _ in range(k)] for _ in range(c.cols)]

        check_and_update_data(a, a_data, m, c.depth_start, c.rows, c.cols)
        check_and_update_data(b, b_data, n, c.depth_start, c.cols, k)

    logger.info("pair tensor check pass!")


def group_tiles_by_section(matrix_a, matrix_b, output_tiles):
    m_set = set([(t.row_start, t.idx_in_section) for t in output_tiles])
    n_set = set([(t.col_start, t.idx_in_section) for t in output_tiles])

    a_by_m = {
        (m, idx): [t for t in matrix_a if t.row_start == m and t.idx_in_section == idx]
        for m, idx in m_set
    }
    b_by_n = {
        (n, idx): [t for t in matrix_b if t.row_start == n and t.idx_in_section == idx]
        for n, idx in n_set
    }
    return a_by_m, b_by_n


def filter_tiles_by_core(tiles, core):
    return [t for t in tiles if t.core == core]


def check_and_update_data(tiles, data, offset, depth_start, rows, cols):
    for tile in tiles:
        update_data_with_tile(data, tile, offset, depth_start)
    check_data_coverage(data, rows, cols)


def update_data_with_tile(data, tile, offset, depth_start):
    for i in range(int(tile.row_start), int(tile.row_start + tile.rows)):
        for j in range(int(tile.col_start), int(tile.col_start + tile.cols)):
            if data[i - offset][j - depth_start] != 1:
                raise ValueError(f"({i},{j}) 数据重复, tile_id = {tile.id}, bias = {tile.input_bias}")
            data[i - offset][j - depth_start] = 0


def check_data_coverage(data, rows, cols):
    for i in range(rows):
        for j in range(cols):
            if data[i][j] != 0:
                raise ValueError(f"({i},{j}) 数据未被覆盖")