# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.common.entity import Tile
from core.backend.engineering_costmodel.core.tiling_and_core_split import TilingStrategy
from core.backend.engineering_costmodel.core.tiling_and_core_split import (
    TilingStrategyEnum,
)


class UnfoldingTiling(TilingStrategy):

    def __init__(self):
        super().__init__(TilingStrategyEnum.UNFOLD)

    def generate_tiles(self, section):
        step = section.tiling_param.m1 * section.tiling_param.n1
        core_num = section.tiling_param.w
        total_len = section.m * section.n
        tiling_len = 0

        core_idx = 0
        idx_in_section = 0

        input_tiles = []
        output_tiles = []
        while tiling_len < total_len:
            rows = min(step, total_len - tiling_len)
            tile = Tile(
                section,
                core_idx,
                tiling_len,
                0,
                rows,
                1,
                idx_in_section,
                section.input_precision,
                0,
            )
            input_tiles.append(tile)
            core_idx += 1
            if core_idx >= core_num:
                core_idx = 0
                idx_in_section += 1

            tiling_len += rows
        return input_tiles, output_tiles
