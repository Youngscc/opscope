# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.


# ------------------------------ 数据模型层 ------------------------------
class Block:
    """内存块（Block）类，存储block编号及对应的bank/group信息"""
    def __init__(self, block_id: int):
        self.block_id = block_id
        # 计算所属bank_row（1-3）：2048 = 16列 * 128行/每个bank
        self.bank_row = (block_id // 2048) + 1
        # 计算所属bank_col（1-16）：每个Space行包含16个block
        self.bank_col = (block_id % 16) + 1
        # 计算所属bank_group（1-16）：同一列的3个bank组成一个group
        self.bank_group = self.bank_col
        # 计算bank编号（0-47）：用于读写冲突判断
        self.bank_id = (self.bank_row - 1) * 16 + (self.bank_col - 1)

    # 重写__hash__和__eq__方法，用于集合操作
    def __hash__(self):
        # 返回对象的哈希值，通常使用对象的属性的哈希值
        return hash((self.block_id, self.bank_group, self.bank_id))

    def __eq__(self, other):
        # 判断两个对象是否相等，通常比较对象的属性
        if isinstance(other, Block):
            return (self.block_id, self.bank_group, self.bank_id) == (other.block_id, other.bank_group, other.bank_id)
        return False

    def __repr__(self):
        return f"Block(id={self.block_id}, group={self.bank_group}, bank={self.bank_id})"

    