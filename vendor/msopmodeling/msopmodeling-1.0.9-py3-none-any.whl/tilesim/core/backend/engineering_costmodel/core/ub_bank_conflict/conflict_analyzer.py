# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.


import logging
from typing import List, Dict, Tuple
import copy

from core.backend.engineering_costmodel.core.ub_bank_conflict.block import Block
from core.backend.engineering_costmodel.core.ub_bank_conflict.cycle import Cycle
from core.backend.engineering_costmodel.core.ub_bank_conflict.operand import Operand
from core.backend.engineering_costmodel.core.ub_bank_conflict.pipeline_stage import PipelineStage

logger = logging.getLogger(__name__)


# ------------------------------ 冲突分析层 ------------------------------
class ConflictAnalyzer:
    @staticmethod
    def group_blocks_by_group(blocks: List[Block]) -> Dict[int, List[Block]]:
        group_map = {}
        for block in blocks:
            if block.bank_group not in group_map:
                group_map[block.bank_group] = []
            group_map[block.bank_group].append(block)
        return group_map

    @staticmethod
    def group_blocks_by_cycle(blocks: List[Block], base: int) -> List[List[Block]]:
        cycle_blocks = []
        bank_group_list = []
        block_cycle_list = []
        for block in blocks:
            if block.bank_group in bank_group_list:
                cycle_blocks.append(copy.deepcopy(block_cycle_list))
                block_cycle_list.clear()
                block_cycle_list.append(block)
                bank_group_list.clear()
                bank_group_list.append(block.bank_group)
            else:
                block_cycle_list.append(block)
                bank_group_list.append(block.bank_group)

            if len(block_cycle_list) == 8:
                stride = len(block_cycle_list) // base
                for i in range(0, len(block_cycle_list), stride):
                    cycle_blocks.append(block_cycle_list[i:i + stride])
                block_cycle_list.clear()

        if block_cycle_list:
            cycle_blocks.append(copy.deepcopy(block_cycle_list))

        return cycle_blocks

    @staticmethod
    def check_bank_group_conflict(src0_blocks: List[Block], src1_blocks: List[Block]) -> bool:
        for src0_block in src0_blocks:
            for src1_block in src1_blocks:
                if src0_block.bank_group == src1_block.bank_group:
                    return True
        return False


    @staticmethod
    def analyze_read_conflict(
            src0_operand: Operand,
            src1_operand: Operand,
            src0_blocks: List[Block],
            src1_blocks: List[Block],
            base: int
    ) -> Tuple[PipelineStage, int, bool]:
        """
        优化点2核心实现：
        1. 新增并行判断：src0和src1参数完全一致时视为并行
        2. 并行时src0和src1无读读冲突，仅需分析单个操作数内部冲突
        3. 返回值新增是否并行的标识
        """
        read_stage = PipelineStage("read")

        # 并行判断：三个关键参数完全一致
        is_src_parallel = False if src1_operand is None else (
                src0_operand.start_block_id == src1_operand.start_block_id and
                src0_operand.blk_stride == src1_operand.blk_stride and
                src0_operand.rep_stride == src1_operand.rep_stride
        )

        # 并行时合并block（去重，因src0和src1完全一致），非并行时保留所有block
        if is_src_parallel:
            # 去重逻辑：按block_id唯一标识
            block_dict = {block.block_id: block for block in src0_blocks}
            all_read_blocks = list(block_dict.values())
        else:
            all_read_blocks = src0_blocks + src1_blocks

        # 冲突分析：仅考虑同一group的block冲突（并行时无跨操作数冲突）
        group_map = ConflictAnalyzer.group_blocks_by_group(all_read_blocks)

        src0_read_cycle_blocks = ConflictAnalyzer.group_blocks_by_cycle(src0_blocks, base)
        src1_read_cycle_blocks = ConflictAnalyzer.group_blocks_by_cycle(src1_blocks, base)

        # 计算src0、src1内部bank冲突以及互相间bank冲突，并依次交替分配blocks到cycle上
        cycle_index = 0
        for i in range(min(len(src0_read_cycle_blocks), len(src1_read_cycle_blocks))):
            src0_blocks = src0_read_cycle_blocks[i]
            src1_blocks = src1_read_cycle_blocks[i]
            if ConflictAnalyzer.check_bank_group_conflict(src0_blocks, src1_blocks):
                cycle_index += 1
                ConflictAnalyzer.add_cycle_to_stage(cycle_index, read_stage, src0_blocks)
                cycle_index += 1
                ConflictAnalyzer.add_cycle_to_stage(cycle_index, read_stage, src1_blocks)
            else:
                cycle_index += 1
                src_blocks = src0_blocks + src1_blocks
                ConflictAnalyzer.add_cycle_to_stage(cycle_index, read_stage, src_blocks)

        if len(src0_read_cycle_blocks) < len(src1_read_cycle_blocks):
            for j in range(len(src0_read_cycle_blocks), len(src1_read_cycle_blocks)):
                cycle_index += 1
                ConflictAnalyzer.add_cycle_to_stage(cycle_index, read_stage, src1_read_cycle_blocks[j])
        elif len(src0_read_cycle_blocks) > len(src1_read_cycle_blocks):
            for j in range(len(src1_read_cycle_blocks), len(src0_read_cycle_blocks)):
                cycle_index += 1
                ConflictAnalyzer.add_cycle_to_stage(cycle_index, read_stage, src0_read_cycle_blocks[j])

        conflict_count = 0
        if cycle_index > base:
            conflict_count = cycle_index - base

        return read_stage, conflict_count, is_src_parallel

    @staticmethod
    def add_cycle_to_stage(cycle_index, read_stage, src0_blocks):
        src0_cycle = Cycle(f"read_{cycle_index}", cycle_index)
        src0_cycle.add_blocks(src0_blocks)
        read_stage.add_cycle(src0_cycle)

    @staticmethod
    def analyze_write_conflict(dst_blocks: List[Block], base: int) -> Tuple[PipelineStage, int]:
        write_stage = PipelineStage("write")

        dst_write_cycle_blocks = ConflictAnalyzer.group_blocks_by_cycle(dst_blocks, base)
        cycle_index = 0
        for write_blocks in (dst_write_cycle_blocks):
            cycle_index += 1
            ConflictAnalyzer.add_cycle_to_stage(cycle_index, write_stage, write_blocks)

        conflict_count = cycle_index - base

        return write_stage, conflict_count

    @staticmethod
    def has_rw_conflict(read_cycle: Cycle, write_cycle: Dict[str, any]) -> bool:
        """判断单个read cycle与历史write cycle是否存在读写冲突"""
        # 1. 时间重叠判断：read_cycle的时间范围与write_cycle有交集
        time_overlap = (
                (read_cycle.start_time < write_cycle['end']) and
                (read_cycle.start_time + 1 > write_cycle['start'])
        )
        # 2. bank冲突判断：两者有共同的bank_id
        read_banks = {block.bank_id for block in read_cycle.blocks}
        bank_conflict = len(read_banks & write_cycle['bank_ids']) > 0
        return time_overlap and bank_conflict