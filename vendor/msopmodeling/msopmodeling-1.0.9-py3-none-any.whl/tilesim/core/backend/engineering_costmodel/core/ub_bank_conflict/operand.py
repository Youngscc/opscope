# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.


from typing import List
from core.backend.engineering_costmodel.core.ub_bank_conflict.block import Block


class Operand:
    def __init__(self, name: str, start_block_id: int, blk_stride: int, rep_stride: int):
        self.name = name
        self.start_block_id = start_block_id
        self.blk_stride = blk_stride
        self.rep_stride = rep_stride

    def get_blocks(self, repeat_idx: int) -> List[Block]:
        current_start = self.start_block_id + self.rep_stride * (repeat_idx - 1)
        block_ids = [current_start + i * self.blk_stride for i in range(8)]
        return [Block(bid) for bid in block_ids]

    def __repr__(self):
        return (
            f"Operand({self.name}, "
            f"start={self.start_block_id}, "
            f"blk_step={self.blk_stride}, "
            f"rep_step={self.rep_stride})"
        )
