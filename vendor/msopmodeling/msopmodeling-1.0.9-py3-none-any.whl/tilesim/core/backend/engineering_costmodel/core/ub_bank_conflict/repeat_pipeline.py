# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Dict, Optional, List
from core.backend.engineering_costmodel.core.ub_bank_conflict.conflict_analyzer import ConflictAnalyzer
from core.backend.engineering_costmodel.core.ub_bank_conflict.cycle import Cycle
from core.backend.engineering_costmodel.core.ub_bank_conflict.pipeline_stage import PipelineStage
from core.common.log_format import logging
from core.backend.engineering_costmodel.core.ub_bank_conflict.operand import Operand


logger = logging.getLogger(__name__)


# ------------------------------ 流水线管理层 ------------------------------
class RepeatPipeline:
    def __init__(self, repeat_idx: int, src0: Operand, src1: Operand, dst: Operand,
                 prev_pipeline: Optional['RepeatPipeline'], k: int, base: int):
        self.repeat_idx = repeat_idx
        self.prev_pipeline = prev_pipeline  # 前一个Repeat的流水线（n-1）
        self.k = k
        self.base = base
        self.src0 = src0
        self.src1 = src1
        self.dst = dst

        self.is_src_parallel = False
        self.read_stage: PipelineStage = None
        self.compute_stage: PipelineStage = None
        self.write_stage: PipelineStage = None
        self.start_time: float = 0.0  # 当前Repeat的read阶段开始时间
        self.end_time: float = 0.0
        self.read_conflict_cnt: int = 0
        self.write_conflict_cnt: int = 0
        self.rw_conflict_cnt: int = 0
        self.has_rw_conflict: bool = False
        self.read_cross_rw_delay: float = 0.0  # 跨Repeat读写冲突导致的read阶段总延迟
        self.max_conflict: int = 0
        # 新增：跨Repeat写写冲突延迟时间
        self.write_cross_ww_delay: float = 0.0

        self._build_pipeline()

    def _collect_historical_write_cycles(self) -> List[Dict[str, any]]:
        """收集所有前序Repeat（1~n-1）的write阶段cycle信息"""
        historical_write_cycles = []
        current_prev = self.prev_pipeline
        while current_prev is not None:
            write_stage = current_prev.write_stage
            for write_cycle in write_stage.cycles:
                historical_write_cycles.append({
                    'start': write_cycle.start_time,
                    'end': write_cycle.end_time,
                    'bank_ids': {block.bank_id for block in write_cycle.blocks}
                })
            current_prev = current_prev.prev_pipeline
        return historical_write_cycles

    def _check_conflict(self, adjusted_cycle: Cycle, write_cycle: Dict) -> bool:
        """检查当前读周期与写周期是否存在冲突"""
        time_overlap = (
                (adjusted_cycle.start_time < write_cycle['end']) and
                (adjusted_cycle.start_time + 1 > write_cycle['start'])
        )
        bank_conflict = len({block.bank_id for block in adjusted_cycle.blocks} & write_cycle['bank_ids']) > 0
        return time_overlap and bank_conflict

    def _adjust_cycle(self, adjusted_cycle: Cycle, historical_write_cycles: List[Dict]) -> int:
        """调整周期以解决冲突，并返回延迟的周期数"""
        delay_count = 0
        conflict = True
        while conflict:
            conflict = False
            for write_cycle in historical_write_cycles:
                if self._check_conflict(adjusted_cycle, write_cycle):
                    delay_count += 1
                    adjusted_cycle.start_time += 1
                    adjusted_cycle.end_time += 1
                    conflict = True
                    break
        return delay_count

    def _print_RR_delay_info(self, adjusted_cycle: Cycle, delay_count: int):
        """打印延迟信息"""
        if delay_count > 0:
            logger.info(
                "  Repeat %s %s cross repeat Read Write delay %s cycles. (final:"
                "%.0f - %.0f)",
                self.repeat_idx, adjusted_cycle.stage_type, delay_count,
                adjusted_cycle.start_time, adjusted_cycle.end_time
            )

    def _adjust_read_cycle_for_cross_rw_conflict(
            self,
            original_read_cycles: List[Cycle],
            read_offset: float
    ) -> List[Cycle]:
        """调整read cycle时间，解决跨Repeat读写冲突（递归延迟）"""
        historical_write_cycles = self._collect_historical_write_cycles()
        adjusted_cycles = []
        prev_cycle_end = read_offset  # 初始为当前Repeat的start_time（前序read结束时间）

        for original_cycle in original_read_cycles:
            current_start = prev_cycle_end
            adjusted_cycle = Cycle(original_cycle.stage_type, current_start)
            adjusted_cycle.add_blocks(original_cycle.blocks)

            # 调整周期以解决冲突

            delay_count = self._adjust_cycle(adjusted_cycle, historical_write_cycles)
            self.rw_conflict_cnt = delay_count

            # 打印延迟信息
            self._print_RR_delay_info(adjusted_cycle, delay_count)

            adjusted_cycles.append(adjusted_cycle)
            prev_cycle_end = adjusted_cycle.end_time  # 保持read阶段内部连续

        # 更新跨Repeat延迟总时间
        self.read_cross_rw_delay = prev_cycle_end - read_offset - len(original_read_cycles)
        return adjusted_cycles

    def _print_WW_delay_info(self, adjusted_cycle: Cycle, delay_count: int):
        """打印延迟信息"""
        if delay_count > 0:
            logger.debug(
                "  Repeat %s %s:"
                "Cross Repeat WW delay %s cycles (final："
                "%.0f - %.0f）",
                self.repeat_idx, adjusted_cycle.stage_type, delay_count,
                adjusted_cycle.start_time, adjusted_cycle.end_time
            )

    def _adjust_write_cycle_for_cross_ww_conflict(
            self,
            original_write_cycles: List[Cycle],
            write_offset: float
    ) -> List[Cycle]:
        """处理跨Repeat写写冲突，调整write cycle时间"""
        historical_write_cycles = self._collect_historical_write_cycles()
        adjusted_cycles = []
        prev_cycle_end = write_offset  # 初始为当前Repeat的start_time（前序write结束时间）

        for original_cycle in original_write_cycles:
            current_start = prev_cycle_end
            adjusted_cycle = Cycle(original_cycle.stage_type, current_start)
            adjusted_cycle.add_blocks(original_cycle.blocks)

            # 调整周期以解决冲突
            delay_count = self._adjust_cycle(adjusted_cycle, historical_write_cycles)

            # 打印延迟信息
            self._print_WW_delay_info(adjusted_cycle, delay_count)

            adjusted_cycles.append(adjusted_cycle)
            prev_cycle_end = adjusted_cycle.end_time  # 保持write阶段内部连续

        # 更新跨Repeat延迟总时间
        self.write_cross_ww_delay = prev_cycle_end - write_offset - len(original_write_cycles)
        return adjusted_cycles

    def _determine_start_time(self):
        """
        核心优化：Repeat间强衔接逻辑
        repeat=n+1的start_time = repeat=n的read阶段结束时间
        彻底替代原有的“基于前序冲突次数的延迟”
        """
        if self.prev_pipeline is None:
            self.start_time = 0.0  # 第一个Repeat从0时刻开始
        else:
            # 关键：当前Repeat的read开始时间 = 前一个Repeat的read结束时间
            self.start_time = self.prev_pipeline.read_stage.get_end_time()
            logger.debug("  Repeat %s bridge preorder：start_time=%.0f(preorder read finish time)",
                         self.repeat_idx, self.start_time)

    def _build_read_stage(self):
        """
        核心优化：read阶段基础偏移 = 基准start_time + max(读读冲突数, 写写冲突数)
        步骤：1. 计算当前Repeat的读读/写写冲突 → 2. 计算max_conflict → 3. 确定read基础偏移 → 4. 处理跨冲突延迟
        """
        # 1. 第一步：获取当前Repeat的所有操作数blocks
        src0_blocks = self.src0.get_blocks(self.repeat_idx)
        src1_blocks = [] if self.src1 is None else self.src1.get_blocks(self.repeat_idx)
        dst_blocks = self.dst.get_blocks(self.repeat_idx)  # 提前获取dst blocks，计算写写冲突

        # 2. 第二步：计算读读冲突数（内部）和并行标识
        original_read_stage, self.read_conflict_cnt, self.is_src_parallel = ConflictAnalyzer.analyze_read_conflict(
            self.src0, self.src1, src0_blocks, src1_blocks, self.base
        )

        # 3. 第三步：计算写写冲突数（内部，提前到read阶段计算）
        _, self.write_conflict_cnt = ConflictAnalyzer.analyze_write_conflict(dst_blocks, self.base)

        # 4. 第四步：核心优化：计算max_conflict和read基础偏移
        additional_bias = self.write_conflict_cnt - self.read_conflict_cnt
        self.max_conflict = additional_bias if additional_bias > 0 else 0
        read_offset = self.start_time + self.max_conflict  # 基础偏移 = 基准start_time + 最大冲突数
        logger.info(
            f"  Repeat %s conflict analysis: WW Conflict = %s cycles, RR Conflict= %s cycles -> "
            f"max_conflict= %s cycles -> read basic offset = %.0f",
            self.repeat_idx, self.read_conflict_cnt, self.write_conflict_cnt,
            self.max_conflict, read_offset
        )

        # 5. 第五步：处理跨Repeat读写冲突，调整read cycle
        adjusted_cycles = self._adjust_read_cycle_for_cross_rw_conflict(
            original_read_cycles=original_read_stage.cycles,
            read_offset=read_offset  # 使用优化后的基础偏移
        )

        # 6. 第六步：构建最终read阶段
        self.read_stage = PipelineStage("read")
        for cycle in adjusted_cycles:
            self.read_stage.add_cycle(cycle)

    def _build_compute_stage(self):
        """compute阶段紧跟read阶段结束时间"""
        compute_start = self.read_stage.get_end_time()
        self.compute_stage = PipelineStage("compute")
        for _ in range(self.base):
            self.compute_stage.add_cycle(Cycle("compute", compute_start))
            compute_start += 1

    def _build_write_stage(self):
        """
        核心优化：整合跨Repeat写写冲突处理
        流程：1. 内部写写冲突分析 → 2. 计算基础write_start → 3. 处理内部读写冲突 → 4. 处理跨Repeat写写冲突 → 5. 构建最终write阶段
        """
        dst_blocks = self.dst.get_blocks(self.repeat_idx)
        # 1. 内部写写冲突分析（复用原有逻辑）
        original_write_stage, _ = ConflictAnalyzer.analyze_write_conflict(dst_blocks, self.base)

        # 2. 计算基础write_start（read结束时间 + m-1，m=k+max_conflict）
        m = self.k + self.max_conflict
        write_start = self.read_stage.get_end_time() + (m - 1)

        # 3. 处理本Repeat内部的读写冲突（复用原有逻辑）
        src0_blocks = self.src0.get_blocks(self.repeat_idx)
        src1_blocks = [] if self.src1 is None else self.src1.get_blocks(self.repeat_idx)
        all_read_blocks = src0_blocks + src1_blocks
        temp_read_cycle = Cycle("temp", self.read_stage.get_start_time())
        temp_read_cycle.add_blocks(all_read_blocks)
        self.has_rw_conflict = ConflictAnalyzer.has_rw_conflict(
            temp_read_cycle,
            {
                'start': write_start,
                'end': write_start + original_write_stage.total_cycles,
                'bank_ids': {b.bank_id for b in dst_blocks}
            }
        )
        if self.has_rw_conflict:
            write_start = max(write_start, self.read_stage.get_end_time() + 1)
            logger.debug(f"  Repeat %s Inner Read Write Conflict: write_start adjust to %.0f",
                         self.repeat_idx, write_start)

        # 4. 核心新增：处理跨Repeat写写冲突，调整write cycle时间
        adjusted_cycles = self._adjust_write_cycle_for_cross_ww_conflict(
            original_write_cycles=original_write_stage.cycles,
            write_offset=write_start  # 基于处理完内部冲突后的write_start作为基础偏移
        )

        # 5. 构建最终的write阶段
        self.write_stage = PipelineStage("write")
        for cycle in adjusted_cycles:
            self.write_stage.add_cycle(cycle)

    def _build_pipeline(self):
        """流水线构建顺序：确定start_time→read→compute→write"""
        self._determine_start_time()
        self._build_read_stage()
        self._build_compute_stage()
        self._build_write_stage()
        self.end_time = self.write_stage.get_end_time()

    def __repr__(self):
        """日志优化：显示衔接信息和延迟详情"""
        parallel_str = "parallel" if self.is_src_parallel else "non-parallel"
        cross_delay_str = f"cross RW delay {self.read_cross_rw_delay:.0f} cycles" if self.read_cross_rw_delay > 0 else "without cross RW delay"
        prev_read_end = self.prev_pipeline.read_stage.get_end_time() if self.prev_pipeline else 0
        return (
            f"RepeatPipeline({self.repeat_idx}, start={self.start_time:.1f}(pre-order read end:{prev_read_end:.1f}), "
            f"end={self.end_time:.1f}, R_conflict={self.read_conflict_cnt}, W_conflict={self.write_conflict_cnt}, "
            f"src={parallel_str}, {cross_delay_str})")
