# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.common.entity import VecOpType, TensorData


class VectorBasicOp:
    BASIC_VEC_OP_ID = 0

    def __init__(
        self,
        op_type: VecOpType,
        inputs: list[TensorData],
        outputs: list[TensorData],
        pipe_barrier: bool = True,
    ):
        """
        基础vector操作算子（VADD、MUL、MULS这些）
        :param inputs:          输入tensor列表
        :param outputs:         输出tensor列表
        :param op_type:         操作类型（VADD、MUl、VMULS）
        :param pipe_barrier:    依据具体实现而定，主要逻辑：是否需要添加同步，如果依赖其前序操作的输出，则需要添加（如果前序操作是输入，则不需要加）
        """
        self.op_type = op_type
        self.pipe_barrier = pipe_barrier
        self.id = VectorBasicOp.BASIC_VEC_OP_ID
        VectorBasicOp.BASIC_VEC_OP_ID += 1
        self.inputs = inputs
        self.outputs = outputs
        self.precision = (
            inputs[op_type.vec_op_depend_on].precision
            if op_type.vec_op_depend_on >= 0
            else outputs[-1 - op_type.vec_op_depend_on].precision
        )


class FusedVectorOp:
    FUSED_VEC_OP_ID = 0

    def __init__(self, basic_op_list: list[VectorBasicOp]):
        self.fused_op_list = basic_op_list
        self.id = FusedVectorOp.FUSED_VEC_OP_ID
        FusedVectorOp.FUSED_VEC_OP_ID += 1