# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math
import uuid
from typing import Tuple

from core.backend.backend_entity.backend_entity import TensorEntity
from core.backend.backend_entity.backend_logistic import SubTaskEntity, OpEntity
from core.backend.backend_entity.backend_math import EvalCtxEntity
from core.backend.engineering_costmodel.cache_simulator.cache_simulator import create_cache
from core.backend.engineering_costmodel.evaluation.by_rule_pipeline.pipe_manager import PipeManager
from core.backend.engineering_costmodel.evaluation.eng_evaluation import EngEvaluation
from core.backend.tile_op_costmodel import tile_op_dispatch
from core.backend.tile_op_costmodel.tile_op_backend_entity import TileOpEntity, TileEntity, TileOpContext
from core.common.backend_config import BackendConfig, FitParamKey
from core.common.entity import CoreUnit, CoreType, MemLoc, OpLevel
from core.common.log_format import logging
from core.common.tile_op_enum import TileOpCode, TileOpType
from core.config.arc_spec import load_arc_config
from core.pipeline.basic_operator import OperatorResult

logger = logging.getLogger(__name__)


def _get_pre_task_ready_time(sub_task: SubTaskEntity):
    ready_time = 0
    if sub_task.pre_sub_task is None:
        return ready_time
    for pre_task in sub_task.pre_sub_task:
        ready_time = max(pre_task.task_end_time, ready_time)
    return ready_time


def _get_core_units(op: OpEntity) -> list[CoreUnit]:
    if op.op_code == TileOpCode.COPY:
        src_mem = op.inputs[0].mem_loc
        dst_mem = op.outputs[0].mem_loc
        core_units = op.op_code.get_core_units(src_mem, dst_mem)
    else:
        core_units = op.op_code.get_core_units()

    return core_units


class EvalRulePipeImpl(EngEvaluation):

    def __init__(self, backend_config: BackendConfig, eval_ctx: EvalCtxEntity):
        super().__init__(backend_config, eval_ctx)
        self.pipe_exclusive_config = backend_config.eval_config.pipe_exclusive_config
        self.arc_config = load_arc_config(backend_config.accelerator)
        self.pipe_manager = PipeManager()
        self.l2_cache = create_cache(self.arc_config.lookup_cache_size(MemLoc.L2)[1])
        self._fit_coeff()
        self._reset_state()

    def _reset_state(self):
        self.output_tensors = set()
        self.pipe_barrier_flag = False
        self.data_transfer = dict()
        self.small_pkt_transfer = dict()
        self.l2_cache.reset()
        self.l2_hit_stat = {
            "hit_byte": 0,
            "miss_byte": 0,
        }
        self._clear_trace()

    def _fit_coeff(self):
        self.arc_config.clock_freq *= self.eval_config.fit_param[FitParamKey.COMP_COEFF]
        self.arc_config.set_bw_coeff(self.eval_config.fit_param[FitParamKey.BW_COEFF])

    def _assign_ctx(self, sub_task: SubTaskEntity) -> EvalCtxEntity:
        ctx = self.eval_ctx.create_tmp_ctx()
        for k, v in sub_task.indices.items():
            ctx.assign(k, v)
        return ctx

    def _pipe_barrier(self, input_tensor_names: list[str]):
        """判断是否需要增加pipe barrier"""
        if self.eval_config.enable_auto_pipe:
            return not self.output_tensors.isdisjoint(input_tensor_names)
        else:
            return self.pipe_barrier_flag

    def _l2_access(self, src_tensor: TileEntity, dst_tensor: TileEntity, ori_tensor: TensorEntity) -> Tuple[float, float]:
        src_mem = src_tensor.buffer_type
        dst_mem = dst_tensor.buffer_type

        # 如果是往外搬，一定命中L2
        if dst_mem == MemLoc.GM and src_mem in [MemLoc.L1, MemLoc.L0C, MemLoc.UB]:
            dst_tensor.buffer_type = MemLoc.L2
            data_size = math.prod(src_tensor.shape) * src_tensor.data_type_str.size
            return data_size, 0

        # 如果是往里搬
        if src_mem == MemLoc.GM and dst_mem in [MemLoc.L1, MemLoc.UB]:
            hit_byte, miss_byte = self.l2_cache.access(ori_tensor)
            if hit_byte > 0:
                src_tensor.buffer_type = MemLoc.L2
            return hit_byte, miss_byte

        return 0.0, 0.0

    def _to_tile_op(self, op: OpEntity, core_units: list[CoreUnit], input_tensor_names: list[str]) -> TileOpEntity:
        """将OpEntity转换成TileOp Costmodel的入口参数"""
        inputs = [TileEntity.from_op_entity(inp) for inp in op.inputs]
        outputs = [TileEntity.from_op_entity(out) for out in op.outputs]
        core_num = self.backend_config.aic_core_num
        for core_unit in core_units:
            if core_unit.core_type == CoreType.AIV:
                core_num = self.backend_config.aiv_core_num
                break

        if op.op_code == TileOpCode.COPY:
            hit, miss = self._l2_access(inputs[0], outputs[0], op.inputs[0])
            self.l2_hit_stat["hit_byte"] += hit
            self.l2_hit_stat["miss_byte"] += miss
            data_transfer_describe = MemLoc.path_name(op.inputs[0].mem_loc, op.outputs[0].mem_loc)
            self.data_transfer[data_transfer_describe] = self.data_transfer.setdefault(
                data_transfer_describe, 0) + math.prod(inputs[0].shape) * inputs[0].data_type_str.size
        context = TileOpContext(
            arc_config=self.arc_config,
            core_num=core_num,
            barrier=self._pipe_barrier(input_tensor_names),
            enable_small_pkt_bw=True
        )

        return TileOpEntity(
            magic=uuid.uuid4().int,
            i_operand=inputs,
            o_operand=outputs,
            context=context,
            opcode=op.op_code
        )

    def _process_set_flag(self, op: OpEntity):
        """
        处理 SET_FLAG 操作（包括 sync_block_set）
        """
        src_unit = op.config.get("src_unit")
        dst_unit = op.config.get("dst_unit")
        if "flag_id" not in op.config:
            raise ValueError("flag_id not in op config")
        flag_id = op.config.get("flag_id")

        self.pipe_manager.set_unit_flag(src_unit, dst_unit, flag_id)

    def _process_wait_flag(self, op: OpEntity, core_type):
        """
        处理 WAIT_FLAG 操作（包括 sync_block_wait）
        """
        if "flag_id" not in op.config:
            raise ValueError("flag_id not in op config")

        flag_id = op.config.get("flag_id")

        # 对于跨核同步（sync_block_wait），使用 op.config 中的 core_type
        # 这是等待方的核类型
        src_unit = op.config.get("src_unit")
        dst_unit = op.config.get("dst_unit")

        sync_ready_time = self.pipe_manager.wait_unit_flag(src_unit, dst_unit, flag_id)

        # sync_block_wait 阻塞本核所有组件
        # 判断是否是 sync_block_wait：dst_unit 为None且 flag_id 以 block_ 开头
        is_block_all = flag_id.startswith("block_") and dst_unit is None

        if is_block_all:
            # 更新本核所有组件的时间到 sync_ready
            core_type_list = []
            for unit in CoreUnit:
                if unit.core_type == core_type:
                    core_type_list.append(unit)
        else:
            core_type_list = [op.config.get("dst_unit")]
        self.pipe_manager.update_pipe(core_type_list, sync_ready_time)

    def _calc_subtask_pipe(self, sub_task: SubTaskEntity):

        pre_task_ready = _get_pre_task_ready_time(sub_task)
        self.pipe_manager.update_core_index(sub_task.core_idx)
        ctx = self._assign_ctx(sub_task)
        op_list = sub_task.expand(ctx)

        for op in op_list:
            if op.level == OpLevel.HOST_OP:
                continue

            if op.op_code == TileOpCode.SET_FLAG:
                self._process_set_flag(op)
                continue

            if op.op_code == TileOpCode.WAIT_FLAG:
                core_type = sub_task.root_task.core_type  # 当前任务的核类型
                self._process_wait_flag(op, core_type)
                continue

            core_units = _get_core_units(op)
            input_tensor_names = [inp.get_slice_name() for inp in op.inputs]
            output_tensor_names = [out.get_slice_name() for out in op.outputs]

            # 获取组件的 ready 时间
            unit_ready = self.pipe_manager.get_pipe(core_units, self.pipe_exclusive_config)
            # 获取前序张量的计算完成时间
            tensor_ready = self.pipe_manager.get_pipe(input_tensor_names)

            # 计算tile op花费时间
            tile_op = self._to_tile_op(op, core_units, input_tensor_names)
            latency = tile_op_dispatch(tile_op=tile_op, op_type=TileOpType.PLAIN)

            # 时间计算
            start_time = max(pre_task_ready, unit_ready, tensor_ready)

            duration = latency.latency
            end_time = start_time + duration

            # 更新pipe时间
            self.pipe_manager.update_pipe(core_units, end_time)
            self.pipe_manager.update_pipe(output_tensor_names, end_time)
            self.pipe_manager.update_pipe_working(latency.unit_latency)
            self._add_trace(op, start_time, duration, core_units, sub_task.core_idx)

            # 更新pipe_barrier
            self.pipe_barrier_flag = op.op_code in [TileOpCode.BARRIER, TileOpCode.WAIT_FLAG]

            # 汇总小包搬运数据量
            for path, data_size in latency.small_pkt_transfer.items():
                self.small_pkt_transfer[path] = self.small_pkt_transfer.get(path, 0) + data_size

            # 更新task完成时间
            sub_task.task_end_time = max(sub_task.task_end_time, end_time)

    def eval(self, sub_task_list: list[SubTaskEntity]) -> OperatorResult:

        # 两阶段仿真：
        # 第一阶段：执行一次仿真，收集所有跨核同步标志的时间
        # 第二阶段：使用收集到的时间，重新执行仿真

        # 初始化
        self.pipe_manager.reset_pipe_state()
        self._reset_state()
        pre_pass_flags = {}
        for sub_task in sub_task_list:
            sub_task.task_end_time = 0.0

        # 首次仿真时间
        for sub_task in sub_task_list:
            self._calc_subtask_pipe(sub_task)

        # 循环仿真直至组件间同步时间收敛
        loop_threshold = 10
        loop_count = 0
        while not self.pipe_manager.is_cross_core_flags_converged(pre_pass_flags):
            if loop_count >= loop_threshold:
                logger.warning("cross_core_flags is not converged")
                break
            pre_pass_flags = self.pipe_manager.get_cross_core_flags_snapshot()
            self.pipe_manager.cross_core_flags = pre_pass_flags
            self.pipe_manager.reset_pipe_state()
            self._reset_state()
            for sub_task in sub_task_list:
                sub_task.task_end_time = 0.0

            for sub_task in sub_task_list:
                self._calc_subtask_pipe(sub_task)
            loop_count += 1

        sim_result = OperatorResult()
        self.pipe_manager.set_eng_result(sim_result)
        sim_result.trace = self._get_trace()
        sim_result.aic_cycles = round(sim_result.aic_cube_time * self.arc_config.clock_freq)
        sim_result.aiv_cycles = round(sim_result.aiv_vec_time * self.arc_config.clock_freq)
        sim_result.data_transfer = self.data_transfer
        sim_result.small_pkt_transfer = self.small_pkt_transfer
        l2_hit = self.l2_hit_stat.get("hit_byte", 0)
        l2_miss = self.l2_hit_stat.get("miss_byte", 0)
        sim_result.l2_access_rate = l2_hit / (l2_hit + l2_miss) if (l2_hit + l2_miss) > 0 else 0

        return sim_result
