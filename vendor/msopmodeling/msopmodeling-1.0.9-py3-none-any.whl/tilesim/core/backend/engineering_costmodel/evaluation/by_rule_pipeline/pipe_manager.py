# Copyright (c) Huawei Technologies Co., Ltd. 2026-2026. All rights reserved.
from dataclasses import dataclass, field

from core.common.backend_config import MutexComponents
from core.common.entity import CoreUnit, CoreType
from core.common.log_format import logging
from core.pipeline.basic_operator import OperatorResult

logger = logging.getLogger(__name__)


@dataclass
class CoreUnitPipeKey:
    raw_key: CoreUnit | str
    core_idx: int = 0

    def __hash__(self):
        return hash((self.raw_key, self.core_idx))

    def __eq__(self, other):
        return self.__hash__() == other.__hash__()


@dataclass
class PipeManager:
    pipe_dict: dict[CoreUnitPipeKey, float] = field(default_factory=dict)  # pipe累计时间
    pipe_working_dict: dict[CoreUnitPipeKey, float] = field(default_factory=dict)  # pipe忙时间
    core_index: int = 0

    max_latency_core: int = 0
    max_latency: float = 0.0
    pipe_start_time: dict[CoreUnitPipeKey, float] = field(default_factory=dict)  # pipe开始时间，用于计算aic_time和aiv_time

    # 需要同步的组件信息（核内同步）
    unit_wait_manager: dict[str, dict[CoreUnitPipeKey, float]] = field(default_factory=dict)

    # 跨核同步标志（AIC/AIV之间）- flag_id -> {core_unit: 完成时间}，类似组件间传递的消息
    # 例如：{"block_0": {CoreUnit.AIV_MTE2: 100.0}}，其中block后面的数字对应hivm的flag
    cross_core_flags: dict[str, dict[CoreUnitPipeKey, float]] = field(default_factory=dict)

    def update_core_index(self, core_index: int):
        self.core_index = core_index

    def reset_pipe_state(self):
        """
        重置流水线状态，但保留跨核同步标志

        用于多轮迭代仿真，每轮迭代需要重新计算流水线时间，
        但跨核同步标志需要保留以实现正确的同步语义。
        """
        self.pipe_dict.clear()
        self.pipe_working_dict.clear()
        self.pipe_start_time.clear()
        self.unit_wait_manager.clear()
        self.max_latency_core = 0
        self.max_latency = 0.0
        # 注意：cross_core_flags 不清除，保留上一轮的值用于迭代收敛

    def get_cross_core_flags_snapshot(self) -> dict[str, dict[CoreUnitPipeKey, float]]:
        """获取跨核同步标志的快照"""
        # 深拷贝，避免外部修改
        return {flag_id: dict(core_times) for flag_id, core_times in self.cross_core_flags.items()}

    def is_cross_core_flags_converged(self, prev_snapshot: dict[str, dict[CoreUnitPipeKey, float]],
                                      tolerance: float = 1e-6) -> bool:
        """
        检查跨核同步标志是否收敛

        Args:
            prev_snapshot: 上一轮的跨核同步标志快照
            tolerance: 时间容差（微秒）

        Returns:
            True 如果所有标志值的变化都在容差范围内
        """
        if set(self.cross_core_flags.keys()) != set(prev_snapshot.keys()):
            return False
        for flag_id, current_core_times in self.cross_core_flags.items():
            prev_core_times = prev_snapshot.get(flag_id, {})
            if set(current_core_times.keys()) != set(prev_core_times.keys()):
                return False
            for unit_type, current_time in current_core_times.items():
                prev_time = prev_core_times.get(unit_type, 0.0)
                if abs(current_time - prev_time) > tolerance:
                    return False
        return True

    def set_unit_flag(self, src_unit: CoreUnit, dst_unit: CoreUnit, flag_id: str):
        """
        设置同步标志

        Args:
            src_unit: 查询是否已经完成的组件
            dst_unit: 发送信号的组件
            flag_id: 同步标志ID
        """
        if src_unit is None or dst_unit is None:
            raise ValueError("[set_unit_flag] src_unit or dst_unit is None")
        src_key = CoreUnitPipeKey(src_unit, self.core_index)
        dst_key = CoreUnitPipeKey(dst_unit, self.core_index)
        # 检查是否是跨核同步标志（block_ 开头）
        is_cross_core = flag_id.startswith("block_")

        if is_cross_core:
            # 跨核同步：存储到 cross_core_flags
            # sync_block_set 语义：当本核指定组件的操作完成后，发送信号给对方核
            # 需要记录指定组件的完成时间
            unit_finish_time = self.pipe_dict.get(src_key, 0.0)

            # 更新跨核标志：按核类型存储设置方的完成时间
            if flag_id not in self.cross_core_flags:
                self.cross_core_flags[flag_id] = {}

            # 同一个组件可能多次设置同一个 flag，取最大值
            if src_key in self.cross_core_flags[flag_id]:
                self.cross_core_flags[flag_id][src_key] = max(self.cross_core_flags[flag_id][src_key], unit_finish_time)
            else:
                self.cross_core_flags[flag_id][src_key] = unit_finish_time
        else:
            # 核内同步：存储到 unit_wait_manager
            flag_wait_manager = self.unit_wait_manager.get(flag_id, {})
            flag_wait_manager[dst_key] = self.pipe_dict.get(src_key, 0.0)
            self.unit_wait_manager[flag_id] = flag_wait_manager

    def wait_unit_flag(self, src_unit: CoreUnit, dst_unit: CoreUnit, flag_id: str) -> float:
        """
        等待同步标志，如果src_unit还没有完成，则阻塞dst_unit

        Args:
            src_unit: 查询的组件
            dst_unit: 阻塞的组件
            flag_id: 同步标志ID

        Returns:
            wait指令阻塞组件的可用时间
        """
        if src_unit is None:
            raise ValueError("[src_unit] query_core_unit is None")
        src_key = CoreUnitPipeKey(src_unit, self.core_index)
        dst_key = CoreUnitPipeKey(dst_unit, self.core_index)
        # 检查是否是跨核同步标志（block_ 开头）
        is_cross_core = flag_id.startswith("block_")

        if is_cross_core:
            # 跨核同步：从 cross_core_flags 获取对方核的时间
            block_pipe_origin_time = self.pipe_dict.get(src_key, 0.0)
            # 如果 flag 还未被设置，返回 0（第一遍执行时可能还没遇到 set）
            flag_data = self.cross_core_flags.get(flag_id, {})
            if not flag_data:
                return block_pipe_origin_time
            wait_time = flag_data.get(src_key, block_pipe_origin_time)
            return wait_time
        else:
            # 核内同步：从 unit_wait_manager 获取时间
            block_pipe_origin_time = self.pipe_dict.get(dst_key, 0.0)
            flag_wait_manager = self.unit_wait_manager.get(flag_id, {})
            if not flag_wait_manager:
                return block_pipe_origin_time
            wait_time = flag_wait_manager.get(src_key, block_pipe_origin_time)
            return wait_time

    def update_pipe(self, keys: list[str | CoreUnit], value: float):
        # 当key是str类型时，表示tensor的名称
        for key in keys:
            k = CoreUnitPipeKey(key, self.core_index)
            if isinstance(key, CoreUnit):
                # 记录当前耗时最长的核
                if value > self.max_latency:
                    self.max_latency_core = self.core_index
                    self.max_latency = value

                # 更新每个pipe的开始时间
                if k not in self.pipe_start_time:
                    self.pipe_start_time[k] = value

            self.pipe_dict[k] = max(self.pipe_dict.get(k, 0), value)

    def get_pipe(self, keys: list[str | CoreUnit], pipe_exclusive_config: MutexComponents = None) -> float:
        pipe_time = 0
        for key in keys:
            k = CoreUnitPipeKey(key, self.core_index)
            mutex_k_list = []
            if isinstance(key, CoreUnit):
                mutex_keys = pipe_exclusive_config.get_mutex(key)
                mutex_k_list = [CoreUnitPipeKey(mutex_key, self.core_index) for mutex_key in mutex_keys]
            if k in self.pipe_dict:
                pipe_time = max(pipe_time, self.pipe_dict[k])
            for mutex_k in mutex_k_list:
                if mutex_k in self.pipe_dict:
                    pipe_time = max(pipe_time, self.pipe_dict[mutex_k])

        return pipe_time

    def update_pipe_working(self, core_unit_latency: dict[CoreUnit, float]):
        for k, v in core_unit_latency.items():
            key = CoreUnitPipeKey(k, self.core_index)
            working_time = self.pipe_working_dict.get(key, 0) + v
            self.pipe_working_dict[key] = working_time

    def _get_pipe_working(self, core_unit: CoreUnit, core_idx: int):
        return self.pipe_working_dict.get(CoreUnitPipeKey(core_unit, core_idx), 0)

    def set_eng_result(self, sim_result: OperatorResult):
        sim_result.latency = self.max_latency

        for k, v in self.pipe_dict.items():
            if k.core_idx != self.max_latency_core:
                continue

            core_unit = k.raw_key
            if not isinstance(core_unit, CoreUnit):
                continue

            if core_unit.core_type == CoreType.AIC:
                sim_result.aic_time = max(sim_result.aic_time, v) - self.pipe_start_time.get(CoreUnitPipeKey(CoreUnit.AIC_MTE2, self.max_latency_core), 0)
            if core_unit.core_type == CoreType.AIV:
                sim_result.aiv_time = max(sim_result.aiv_time, v) - self.pipe_start_time.get(CoreUnitPipeKey(CoreUnit.AIV_MTE2, self.max_latency_core), 0)

        sim_result.aic_cube_time = self._get_pipe_working(CoreUnit.CUBE, self.max_latency_core)
        sim_result.aic_mte2_time = self._get_pipe_working(CoreUnit.AIC_MTE2, self.max_latency_core)
        sim_result.aic_mte1_time = self._get_pipe_working(CoreUnit.AIC_MTE1, self.max_latency_core)
        sim_result.aic_fixpipe_time = self._get_pipe_working(CoreUnit.AIC_FIXPIPE, self.max_latency_core)
        sim_result.aiv_vec_time = self._get_pipe_working(CoreUnit.VEC, self.max_latency_core)
        sim_result.aiv_mte2_time = self._get_pipe_working(CoreUnit.AIV_MTE2, self.max_latency_core)
        sim_result.aiv_mte3_time = self._get_pipe_working(CoreUnit.AIV_MTE3, self.max_latency_core)
