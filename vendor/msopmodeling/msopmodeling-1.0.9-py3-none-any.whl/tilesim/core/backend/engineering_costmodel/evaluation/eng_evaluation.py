# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from abc import ABC, abstractmethod
from copy import copy

from core.backend.backend_entity.backend_logistic import SubTaskEntity, OpEntity
from core.backend.backend_entity.backend_math import EvalCtxEntity
from core.common.entity import CoreUnit
from core.common.tile_op_enum import TileOpCode
from core.common.backend_config import BackendConfig
from core.pipeline.basic_operator import OperatorResult


class EngEvaluation(ABC):

    def __init__(self, backend_config: BackendConfig, eval_ctx: EvalCtxEntity):
        self.backend_config = copy(backend_config)
        self.eval_ctx = copy(eval_ctx)
        self.eval_config = self.backend_config.eval_config
        self.trace = []
        self.event_cnt = 0

    def _get_trace(self):
        return {"traceEvents": self.trace}

    def _clear_trace(self):
        """清空trace记录"""
        self.trace = []
        self.event_cnt = 0

    def _add_trace(self, op: OpEntity, start_time: float, duration: float, core_units: list[CoreUnit], core_idx=0):
        """记录trace"""
        if duration == 0:
            return

        core = core_units[0].core_type
        event = op.op_code.value
        if op.op_code == TileOpCode.COPY:
            event = f"{op.op_code.value}_{op.inputs[0].mem_loc.name}_to_{op.outputs[0].mem_loc.name}"

        for unit in core_units:
            self.trace.append({
                'name': event,
                'cat': f"{op.op_id}_{self.event_cnt}::::{op.__str__()}",
                'ph': 'X',
                'ts': start_time,
                'dur': duration,
                'pid': f'{core.name}_{core_idx}',
                'tid': unit.name,
            })
            self.event_cnt += 1

    @abstractmethod
    def eval(self, sub_task_list: list[SubTaskEntity]) -> OperatorResult:
        pass
