# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.backend.backend_entity.backend_logistic import SubTaskEntity
from core.backend.backend_entity.backend_math import EvalCtxEntity
from core.common.backend_config import BackendConfig, EvaluationType
from core.backend.engineering_costmodel.evaluation.by_rule_pipeline.eval_by_rule_pipe import EvalRulePipeImpl
from core.pipeline.basic_operator import OperatorResult


def eng_eval_dispatch(backend_input: BackendConfig, eval_ctx: EvalCtxEntity, sub_task_list: list[SubTaskEntity], eval_type: EvaluationType = EvaluationType.ENG_PIPE_BY_RULE) -> OperatorResult:
    if eval_type == EvaluationType.ENG_PIPE_BY_RULE:
        eng_eval = EvalRulePipeImpl(backend_input, eval_ctx)
    else:
        raise ValueError(f'Unsupported eval type: {eval_type}')

    return eng_eval.eval(sub_task_list)
