# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.common.entity import (
    CoreType,
    VecOpType,
    DType,
    ResultKey,
    Section,
    TensorData,
    MemLoc,
)
from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.backend.engineering_costmodel.core.pipeline.aiv_pipeline import AIVPipeline
from core.backend.engineering_costmodel.core.tiling_and_core_split.catlass_tiling import CatlassTiling
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.core.vector_op import VectorBasicOp
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel
from core.common.log_format import logging
from core.backend.engineering_costmodel.utils import binocular_op_shape_parse

# 创建一个日志记录器
logger = logging.getLogger(__name__)


class ABSModel(BasicOperatorModel):
    def __init__(self, input_precision: DType, output_precision: DType, **kwargs):
        super().__init__(
            "aclnn_abs_abs_abs", CoreType.AIV, input_precision, output_precision
        )
        self.section_list = None
        row, col = "row", "col"
        input_x = TensorData("input_x", DType.FP32, [row, col], MemLoc.GM)
        out = TensorData("out", DType.FP32, [row, col], MemLoc.GM)

        self.abs_op = [
            VectorBasicOp(
                VecOpType.VABS, [input_x], [out], pipe_barrier=False
            )  # abs(input_x)
        ]

        self.row = row
        self.col = col

    def time_predict(
            self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel
    ) -> dict[ResultKey, float]:
        rows, cols = binocular_op_shape_parse(shapes)

        section = Section(
            0,
            CoreType.AIV,
            rows,
            0,
            cols,
            tiling_param[0],
            self.input_precision,
            self.output_precision,
        )
        tiling = CatlassTiling()
        input_tiles, output_tiles = tiling.generate_tiles(section)
        logger.info("len(input_tiles) = %s", len(input_tiles))
        for tile in input_tiles:
            tile.fused_op = self.abs_op
            shape_dict = {self.row: tile.rows, self.col: tile.cols}
            tile.shape_dict = shape_dict

        aiv_pipe = AIVPipeline(aicore, tiling_param[0], mte3_hit_rate=1)

        core_set = {tile.core for tile in input_tiles}
        size_by_core = {
            core: sum([t.size for t in input_tiles if t.core == core])
            for core in core_set
        }
        max_size_core = max(size_by_core.items(), key=lambda x: x[1])[0]
        input_tiles_new = [tile for tile in input_tiles if tile.core == max_size_core]

        return aiv_pipe.calculate_time(input_tiles_new, output_tiles)