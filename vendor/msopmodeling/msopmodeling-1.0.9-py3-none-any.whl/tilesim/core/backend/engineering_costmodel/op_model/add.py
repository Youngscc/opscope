# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.common.entity import CoreType, VecOpType, DType, ResultKey, Section, TensorData, MemLoc, PipeAnaConfig, CoreUnit
from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.backend.engineering_costmodel.core.pipeline.aiv_pipeline import AIVPipeline
from core.backend.engineering_costmodel.core.tiling_and_core_split.catlass_tiling import CatlassTiling
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.core.vector_op import VectorBasicOp
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel
from core.common.log_format import logging
from core.backend.engineering_costmodel.utils import binocular_op_shape_parse

# 创建一个日志记录器
logger = logging.getLogger(__name__)


class AddModel(BasicOperatorModel):
    def __init__(self, input_precision: DType, output_precision: DType, **kwargs):
        super().__init__(
            "aclnn_add_add_add", CoreType.AIV, input_precision, output_precision
        )
        self.section_list = None
        self.row = "row"
        self.col_other = "col_other"
        self.col = "col"
        if input_precision == DType.BF16:
            self._generate_op_bf16()
        else:
            self._generate_op_fp32()

    def _generate_op_fp32(self):
        input_x = TensorData("input_x", DType.FP32, [self.row, self.col], MemLoc.GM)
        s_mul_other = TensorData("s_mul_other", DType.FP32, [self.row, self.col], MemLoc.UB)
        out = TensorData("out", DType.FP32, [self.row, self.col], MemLoc.GM)
        self.add_op = [VectorBasicOp(VecOpType.AXPY, [input_x, s_mul_other], [out], pipe_barrier=False)]

    def _generate_op_bf16(self):
        input_x = TensorData("input_x", DType.BF16, [self.row, self.col], MemLoc.GM)
        input_other = TensorData("input_other", DType.BF16, [self.row, self.col_other], MemLoc.GM)
        input_x_ub = TensorData("s_mul_other", DType.FP32, [self.row, self.col], MemLoc.UB)
        input_other_ub = TensorData("input_other_ub", DType.FP32, [self.row, self.col_other], MemLoc.UB)
        self.add_op = [
            VectorBasicOp(VecOpType.CONV_BF162F32, [input_x, input_other], [input_x_ub, input_other_ub],
                          pipe_barrier=False),
            VectorBasicOp(VecOpType.VADD, [input_x_ub, input_other_ub], [input_x_ub]),
            VectorBasicOp(VecOpType.CONV_F322BF16, [input_x_ub], [input_x])
        ]

    def time_predict(
            self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel
    ) -> dict[ResultKey, float]:
        rows, cols = binocular_op_shape_parse(shapes)
        logger.info("rows = %s", rows)
        logger.info("cols = %s", cols)

        section = Section(
            0,
            CoreType.AIV,
            rows,
            0,
            cols,
            tiling_param[0],
            self.input_precision,
            self.output_precision,
        )
        tiling = CatlassTiling()
        input_tiles, output_tiles = tiling.generate_tiles(section)
        logger.info("len(input_tiles) = %s", len(input_tiles))
        for tile in input_tiles:
            tile.fused_op = self.add_op
            shape_dict = {self.row: tile.rows, self.col: tile.cols}
            if len(shapes) == 2 and shapes[0] == shapes[1]:
                shape_dict[self.col_other] = tile.cols
            else:
                shape_dict[self.col_other] = 1
            tile.shape_dict = shape_dict

        aiv_pipe = AIVPipeline(aicore, tiling_param[0], mte3_hit_rate=1)

        core_set = {tile.core for tile in input_tiles}
        size_by_core = {
            core: sum([t.size for t in input_tiles if t.core == core])
            for core in core_set
        }
        max_size_core = max(size_by_core.items(), key=lambda x: x[1])[0]
        input_tiles_new = [tile for tile in input_tiles if tile.core == max_size_core]
        pipe_ana_config = PipeAnaConfig([(CoreUnit.AIV_MTE2, CoreUnit.AIV_MTE3)])
        ret = aiv_pipe.calculate_time(input_tiles_new, output_tiles, pipe_ana_config)
        mte2_time_aiv = ret[ResultKey.MTE2_TIME_AIV]
        if mte2_time_aiv > ret[ResultKey.VEC_TIME] and mte2_time_aiv > ret[ResultKey.MTE3_TIME]:
            ret[ResultKey.MTE2_TIME_AIV] += mte2_time_aiv
            ret[ResultKey.CORE_TIME] += mte2_time_aiv
            ret[ResultKey.AIV_TIME] += mte2_time_aiv
        return ret