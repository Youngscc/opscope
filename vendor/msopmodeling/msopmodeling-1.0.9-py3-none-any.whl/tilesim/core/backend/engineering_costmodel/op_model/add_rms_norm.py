# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.common.entity import CoreType, VecOpType, DType, ResultKey, Section, TensorData, MemLoc, PipeAnaConfig, CoreUnit
from core.backend.engineering_costmodel.core.pipeline.aiv_pipeline import AIVPipeline
from core.backend.engineering_costmodel.core.tiling_and_core_split.catlass_tiling import CatlassTiling
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.core.vector_op import VectorBasicOp
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel
from core.common.log_format import logging

# 创建一个日志记录器
logger = logging.getLogger(__name__)


class AddRmsNormModel(BasicOperatorModel):
    def __init__(self, input_precision: DType, output_precision: DType, **kwargs):
        """
        初始化AddRmsNormForward类
        """
        super().__init__("AddRmsNormForward", CoreType.AIV, input_precision, output_precision)

        self.row, self.col, self.col_half = self._initialize_dimensions()
        self._initialize_tensors(input_precision)
        if input_precision == DType.BF16:
            self._initialize_operations_bf16()
        else:
            self._initialize_operations_fp32()

    def _initialize_dimensions(self) -> tuple[str, str, str]:
        """
        初始化维度变量
        """
        row = "row"
        col = "col"
        col_half = "col_half"
        return row, col, col_half

    def _initialize_tensors(self, input_precision) -> None:
        """
        初始化TensorData对象
        """
        self.input_x1 = TensorData("input_x1", input_precision, [self.row, self.col], MemLoc.GM)
        self.input_x2 = TensorData("input_x2", input_precision, [self.row, self.col], MemLoc.GM)
        self.input_gamma = TensorData("input_gamma", input_precision, [self.col], MemLoc.GM)
        self.tmp_x = TensorData("tmp_x", input_precision, [self.row, self.col], MemLoc.UB)
        self.ub_gamma = TensorData("ub_gamma", DType.FP32, [self.col], MemLoc.UB)
        self.x1_add_x2 = TensorData("x1_add_x2", DType.FP32, [self.row, self.col], MemLoc.UB)
        self.x_square = TensorData("x_square", DType.FP32, [self.row, self.col], MemLoc.UB)
        self.x_square_per_dim = TensorData("x_square_per_dim", DType.FP32, [self.row, self.col], MemLoc.UB)
        self.vadd_1 = TensorData("vadd_1", DType.FP32, [self.row, self.col_half], MemLoc.UB)
        self.vadd_2 = TensorData("vadd_2", DType.FP32, [self.row, self.col_half], MemLoc.UB)
        self.reduce_sum_result = TensorData("reduce_sum_result", DType.FP32, [self.row, 1], MemLoc.UB)
        self.reduce_sum_add_eps = TensorData("reduce_sum_add_eps", DType.FP32, [self.row, 1], MemLoc.UB)
        self.sqrt_result = TensorData("sqrt_result", DType.FP32, [self.row, 1], MemLoc.UB)
        self.rstd = TensorData("rstd", DType.FP32, [self.row, 1], MemLoc.UB)
        self.rstd_gm = TensorData("rstd_gm", DType.FP32, [self.row, 1], MemLoc.GM)
        self.broadcast = TensorData("broadcast", DType.FP32, [self.row, self.col], MemLoc.UB)
        self.x1_add_x2_mul_broadcast = TensorData("x1_add_x2_mul_broadcast",
                                                  DType.FP32,
                                                  [self.row, self.col],
                                                  MemLoc.UB)
        self.out = TensorData("out", input_precision, [self.row, self.col], MemLoc.GM)

    def _initialize_operations_bf16(self) -> None:
        """
        初始化VectorBasicOp操作列表
        """
        self.add_rms_norm_op = [
            VectorBasicOp(VecOpType.CONV_BF162F32, [self.input_x1, self.input_x2], [self.x1_add_x2, self.x1_add_x2],
                          pipe_barrier=False),  # 纯搬运 + 数据类型转换
            VectorBasicOp(VecOpType.VADD, [self.x1_add_x2, self.x1_add_x2], [self.x1_add_x2]),
            VectorBasicOp(VecOpType.CONV_F322BF16, [self.x1_add_x2], [self.out]),
            VectorBasicOp(VecOpType.CONV_BF162F32, [self.tmp_x], [self.x1_add_x2]),
            VectorBasicOp(VecOpType.VMUL_SELF, [self.x1_add_x2, self.x1_add_x2], [self.x_square]),
            VectorBasicOp(VecOpType.VMULS, [self.x_square], [self.x_square_per_dim]),
            VectorBasicOp(VecOpType.MOVEV, [self.x_square_per_dim], [self.x_square_per_dim]),
            VectorBasicOp(VecOpType.VADD, [self.vadd_1, self.vadd_1], [self.vadd_1]),
            VectorBasicOp(VecOpType.VADD, [self.vadd_2, self.vadd_2], [self.vadd_2]),
            VectorBasicOp(VecOpType.VCADD, [self.vadd_2], [self.reduce_sum_result]),
            VectorBasicOp(VecOpType.VADDS, [self.reduce_sum_result], [self.reduce_sum_add_eps]),
            VectorBasicOp(VecOpType.VSQRT, [self.reduce_sum_add_eps], [self.sqrt_result]),
            VectorBasicOp(VecOpType.VDIV, [self.sqrt_result], [self.rstd, self.rstd_gm]),
            VectorBasicOp(VecOpType.VBRCB, [self.rstd], [self.broadcast]),
            VectorBasicOp(VecOpType.VCOPY, [self.broadcast], [self.broadcast]),
            VectorBasicOp(VecOpType.VMUL, [self.x1_add_x2, self.broadcast], [self.x1_add_x2_mul_broadcast]),
            VectorBasicOp(VecOpType.CONV_BF162F32, [self.input_gamma], [self.ub_gamma]),
            VectorBasicOp(VecOpType.CONV_F322BF16, [self.x1_add_x2_mul_broadcast], [self.tmp_x]),
            VectorBasicOp(VecOpType.CONV_BF162F32, [self.tmp_x], [self.x1_add_x2_mul_broadcast]),
            VectorBasicOp(VecOpType.VMUL, [self.x1_add_x2_mul_broadcast, self.input_gamma],
                          [self.x1_add_x2_mul_broadcast]),
            VectorBasicOp(VecOpType.CONV_F322BF16, [self.x1_add_x2_mul_broadcast], [self.out]),
        ]

    def _initialize_operations_fp32(self) -> None:
        """
        初始化VectorBasicOp操作列表
        """
        self.add_rms_norm_op = [
            VectorBasicOp(VecOpType.VADD, [self.input_x1, self.input_x2], [self.x1_add_x2, self.out],
                          pipe_barrier=False),
            VectorBasicOp(VecOpType.VMUL_SELF, [self.x1_add_x2, self.x1_add_x2], [self.x_square]),
            VectorBasicOp(VecOpType.VMULS, [self.x_square], [self.x_square_per_dim]),
            VectorBasicOp(VecOpType.MOVEV, [self.x_square_per_dim], [self.x_square_per_dim]),
            VectorBasicOp(VecOpType.VADD, [self.vadd_1, self.vadd_1], [self.vadd_1]),
            VectorBasicOp(VecOpType.VADD, [self.vadd_2, self.vadd_2], [self.vadd_2]),
            VectorBasicOp(VecOpType.VCADD, [self.vadd_2], [self.reduce_sum_result]),
            VectorBasicOp(VecOpType.VADDS, [self.reduce_sum_result], [self.reduce_sum_add_eps]),
            VectorBasicOp(VecOpType.VSQRT, [self.reduce_sum_add_eps], [self.sqrt_result]),
            VectorBasicOp(VecOpType.VDIV, [self.sqrt_result], [self.rstd, self.rstd_gm]),
            VectorBasicOp(VecOpType.VBRCB, [self.rstd], [self.broadcast]),
            VectorBasicOp(VecOpType.VCOPY, [self.broadcast], [self.broadcast]),
            VectorBasicOp(VecOpType.VMUL, [self.x1_add_x2, self.broadcast], [self.x1_add_x2_mul_broadcast]),
            VectorBasicOp(VecOpType.VMUL, [self.x1_add_x2_mul_broadcast, self.input_gamma], [self.out]),
        ]

    def time_predict(
            self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel
    ) -> dict[ResultKey, float]:
        rows = 1
        for i in range(len(shapes[0]) - 1):
            rows *= shapes[0][i]
        cols = shapes[0][-1]
        # 使用日志记录器记录信息
        logger.info("rows = %s", rows)
        logger.info("cols = %s", cols)

        section = Section(
            0,
            CoreType.AIV,
            rows,
            0,
            cols,
            tiling_param[0],
            self.input_precision,
            self.output_precision,
        )
        tiling = CatlassTiling()
        input_tiles, output_tiles = tiling.generate_tiles(section)
        logger.info("len(input_tiles) = %s", len(input_tiles))
        for tile in input_tiles:
            tile.fused_op = self.add_rms_norm_op
            shape_dict = {
                self.row: tile.rows,
                self.col: tile.cols,
                self.col_half: tile.cols // 2,
            }
            tile.shape_dict = shape_dict

        aiv_pipe = AIVPipeline(aicore, tiling_param[0])

        core_set = {tile.core for tile in input_tiles}
        size_by_core = {
            core: sum([t.size for t in input_tiles if t.core == core])
            for core in core_set
        }
        max_size_core = max(size_by_core.items(), key=lambda x: x[1])[0]
        input_tiles_new = [tile for tile in input_tiles if tile.core == max_size_core]
        pipe_ana_config = [(CoreUnit.AIV_MTE2, CoreUnit.VEC)]
        ret = aiv_pipe.calculate_time(input_tiles_new, output_tiles, PipeAnaConfig(pipe_ana_config))
        if rows == 1:
            ret[ResultKey.CORE_TIME] *= 0.25
        elif rows <= tiling_param[0].m1:
            ret[ResultKey.CORE_TIME] *= 1.9
        return ret