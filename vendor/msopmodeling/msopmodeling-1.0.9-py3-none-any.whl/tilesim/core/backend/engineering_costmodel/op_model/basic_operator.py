# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

import abc
import math
from dataclasses import dataclass

from core.common.entity import ResultKey, CoreType, DType
from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam


@dataclass
class NormalSeqLen:
    mean: float
    std: float
    min_len: int = 1
    max_len: int = None


def task_divide(tiling_param: TilingParam, raw_task: int):
    task_num = raw_task
    if tiling_param.k0 == 0:
        task_num = raw_task * 2
    core_num = tiling_param.w * tiling_param.h
    task_single_core = task_num
    if task_num < core_num:
        core_num = task_num
        task_single_core = 1
    else:
        task_single_core = math.ceil(task_num / core_num)
        core_num = 1

    tiling_param.w = core_num
    tiling_param.h = 1
    tiling_param.core_num = core_num * tiling_param.d
    return task_single_core


class BasicOperatorModel(abc.ABC):

    def __init__(
            self,
            op_name,
            op_type: CoreType,
            input_precision: DType,
            output_precision: DType,
    ):
        self._op_name = op_name
        self._op_type = op_type
        self._input_precision = input_precision
        self._output_precision = output_precision

    @property
    def op_name(self):
        return self._op_name

    @property
    def op_type(self):
        return self._op_type

    @property
    def input_precision(self):
        return self._input_precision

    @property
    def output_precision(self):
        return self._output_precision

    @abc.abstractmethod
    def time_predict(
            self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel
    ) -> dict[ResultKey, float]:
        """
        算子预测耗时
        :param aicore           对应到各芯片的costmodel
        :param shapes           算子输入的形状
        :param tiling_param     tiling配置
        :return:         包含各项指标的计算结果
        """
        pass