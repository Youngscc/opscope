# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import copy
import math

from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.common.entity import DType, CoreType, ResultKey
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.op_model.matmul import Matmul
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel
from core.common.log_format import logging

# 创建一个日志记录器
logger = logging.getLogger(__name__)


class BatchMatmul(BasicOperatorModel):
    def __init__(self, input_precision: DType, output_precision: DType, use_avg_core=True, **kwargs):
        super().__init__("BatchMatmulV2", CoreType.AIC, input_precision, output_precision)
        self.section_list = None
        self.use_avg_core = use_avg_core
        self.scalar = 4.7

    def _parse_shapes(self, shapes: list):
        b0, b1 = 1, 1
        if len(shapes[0]) == 2:
            m, k = shapes[0]
        elif len(shapes[0]) == 3:
            b0, m, k = shapes[0]
        elif len(shapes[0]) == 4:
            b0, b1, m, k = shapes[0]
        else:
            raise ValueError("BatchMatmul input 0 dim must be 2, 3 or 4")

        if len(shapes[1]) == 2:
            if shapes[1][0] != k:
                raise ValueError("k dim not match")
            k, n = shapes[1]
        elif len(shapes[1]) == 3:
            if shapes[1][1] != k:
                raise ValueError("k dim not match")
            if len(shapes[0]) == 4 and shapes[1][0] != b1:
                raise ValueError("b1 dim not match")
            b1, k, n = shapes[1]
        else:
            raise ValueError("BatchMatmul input 1 dim must be 2 or 3")

        batch_num = b0 * b1

        return batch_num, m, k, n

    def time_predict(self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel) -> dict[
        ResultKey, float]:
        """
        BatchMatmul算子
        :param shapes:   A[b0, b1, m, k], B[b1, k, n]，其中b0和b1可省略
        :param tiling_param: [cube_tiling]
        :param aicore:
        :return:
        """
        batch_num, m, k, n = self._parse_shapes(shapes)

        # batch 分核
        tiling = copy.copy(tiling_param[0])
        if batch_num >= tiling.core_num:
            # 单核计算的batch数量
            batch_per_core = math.ceil(batch_num / tiling.core_num)
            batch_num = batch_per_core
            tiling.core_num = 1
            tiling.w = 1
            tiling.h = 1
        else:
            # 单个batch有多少核
            core_per_batch = tiling.core_num // batch_num
            batch_num = 1
            tiling.core_num = core_per_batch
            tiling.w = core_per_batch
            tiling.h = 1

        matmul = Matmul(self.input_precision, self.output_precision)
        res = matmul.time_predict([[m, k], [k, n]], tiling_param, aicore)

        for k in ResultKey.time_keys():
            if k in res:
                res[k] *= batch_num
        res[ResultKey.CORE_TIME] += self.scalar
        res[ResultKey.AIC_TIME] += self.scalar
        return res