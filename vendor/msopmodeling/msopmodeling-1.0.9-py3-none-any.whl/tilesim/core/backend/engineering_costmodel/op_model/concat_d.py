# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.common.entity import (
    CoreType,
    VecOpType,
    DType,
    ResultKey,
    Section,
    TensorData,
    MemLoc
)
from core.backend.engineering_costmodel.core.pipeline.aiv_pipeline import AIVPipeline
from core.backend.engineering_costmodel.core.tiling_and_core_split.catlass_tiling import CatlassTiling
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.core.vector_op import VectorBasicOp
from core.common.log_format import logging
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel
from core.config.arc_spec import load_arc_config

# 创建一个日志记录器
logger = logging.getLogger(__name__)


def get_concat_dim(shapes: list):
    concat_dim = None
    sum_concat_dim = None
    n = len(shapes[0])
    # 遍历每个位置 index
    for index in range(n):
        # 获取所有 shapes[i][v] 的值
        values = [shape[index] for shape in shapes[:-1]]  # 不包括最后一个子列表

        # 检查其他 shapes[i][v] 是否都相等
        # 检查 shapes[-1][dim_index] 是否是其他 shapes[i][v] 之和
        if shapes[-1][index] == sum(values):
            concat_dim = index  # 返回满足条件的 dim_index
            sum_concat_dim = shapes[-1][index]

    if concat_dim is None:
        concat_dim = 0
        sum_concat_dim = len(shapes[0])
        logger.warning("No valid concatenation dimension found, use default value 0 instead")
    return concat_dim, sum_concat_dim


class ConcatDModel(BasicOperatorModel):
    def __init__(self, input_precision: DType, output_precision: DType, **kwargs):
        """
        初始化ConcatDModel类
        """
        super().__init__("ConcatDModel", CoreType.AIV, input_precision, output_precision)
        self.row, self.col = 'row', 'col'
        self.concat_d_op = []
        self.scalar_time = 12

    def _initialize_operations(self) -> None:
        """
        初始化VectorBasicOp操作列表

        """
        self.input_x = TensorData("input_x", DType.FP32, [self.row, self.col], MemLoc.GM)

        self.out = TensorData("out", DType.FP32, [self.row, self.col], MemLoc.GM)

        self.concat_d_op.append(VectorBasicOp(VecOpType.VCOPY, [self.input_x], [self.out]))

    def time_predict(
            self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel
    ) -> dict[ResultKey, float]:
        concat_dim, sum_concat_dim = get_concat_dim(shapes)
        rows = 1
        last_index = len(shapes[0]) - 1

        global_input_tiles, global_output_tiles = [], []
        # 非shape最后维度concat
        if concat_dim != last_index:
            for j in range(len(shapes) - 1):
                rows = 1
                for i in range(last_index):
                    rows *= shapes[j][i]
                cols = shapes[j][-1]

                # 使用日志记录器记录信息
                logger.info("rows = %s", rows)
                logger.info("cols = %s", cols)

                section = Section(0, CoreType.AIV, rows, 0, cols, tiling_param[0], self.input_precision,
                                  self.output_precision,
                                  )
                tiling = CatlassTiling()
                input_tiles, output_tiles = tiling.generate_tiles(section)
                global_input_tiles.extend(input_tiles)
                global_output_tiles.extend(output_tiles)
                logger.info("len(input_tiles) = %s", len(input_tiles))

                self._initialize_operations()

                for tile in input_tiles:
                    tile.fused_op = self.concat_d_op
                    shape_dict = {
                        self.row: tile.rows,
                        self.col: tile.cols,
                    }
                    tile.shape_dict = shape_dict
        else:
            for i in range(last_index):
                rows *= shapes[0][i]
            cols = shapes[0][-1]

            # 使用日志记录器记录信息
            logger.info("rows = %s", rows)
            logger.info("cols = %s", cols)

            for _ in range(len(shapes) - 1):
                input_tiles, output_tiles = self._process_case_2(shapes, tiling_param, rows, cols)
                global_input_tiles.extend(input_tiles)
                global_output_tiles.extend(output_tiles)

        aiv_pipe = AIVPipeline(aicore, tiling_param[0])

        core_set = {tile.core for tile in global_input_tiles}
        size_by_core = {
            core: sum([t.size for t in global_input_tiles if t.core == core])
            for core in core_set
        }
        max_size_core = max(size_by_core.items(), key=lambda x: x[1])[0]
        input_tiles_new = [tile for tile in global_input_tiles if tile.core == max_size_core]
        ret = aiv_pipe.calculate_time(input_tiles_new, global_output_tiles)
        ret[ResultKey.CORE_TIME] = max(ret[ResultKey.CORE_TIME], self.scalar_time)
        return ret

    def _process_case_2(self, shapes, tiling_param, rows, cols):
        self._initialize_operations()
        section = Section(0, CoreType.AIV, rows, 0, cols, tiling_param[0], self.input_precision,
                          self.output_precision,
                          )
        tiling = CatlassTiling()
        input_tiles, output_tiles = tiling.generate_tiles(section)
        logger.info("len(input_tiles) = %s", len(input_tiles))

        for tile in input_tiles:
            tile.fused_op = self.concat_d_op
            shape_dict = {
                self.row: tile.rows,
                self.col: tile.cols
            }
            tile.shape_dict = shape_dict
        return input_tiles, output_tiles


if __name__ == "__main__":
    arc_config = load_arc_config('../../../config/arc_config/910B1/910B1.yaml')

    # 示例 shapes = [[2049,7168],[2049,7168],[2049,7168],[2049,7168],[2049,7168],
    # 示例 shapes = [[1,1,280,64],[1,1,280,64],[1,1,560,64]]
    shapes = [[1, 1, 280, 64], [1, 1, 280, 64], [1, 1, 280, 128]]
    # 示例 shapes = [[16392, 16, 128], [16392, 16, 64], [16392, 16, 192]]
    concat_dim, _ = get_concat_dim(shapes)
    last_index = len(shapes[0]) - 1

    # 非shape最后维度concat
    if concat_dim != last_index:
        sum_elements = 0
        for i in range(len(shapes) - 1):
            shape_elements = 1
            for j in range(len(shapes[i])):
                shape_elements *= shapes[i][j]
            sum_elements += shape_elements

        logger.info("sum_elements: %s", sum_elements)
        # tiling，row和col都是8的倍数附近值
        approximate_elements = sum_elements // 48
        tile_row = 128
        tile_col = 64
        while approximate_elements > 192 * 64:
            approximate_elements = approximate_elements // 2
        logger.info("approximate_elements: %s", approximate_elements)
        for i in range(1, 192 * 4 + 1):
            row = 16 * i
            for j in range(1, 192 * 4 + 1):
                col = 16 * j
                if row * col >= approximate_elements and (
                        (row - 1) * col <= approximate_elements or row * (col - 1) <= approximate_elements):
                    tile_row = row
                    tile_col = col

        logger.info("tile_row: %s, tile_col: %s", tile_row, tile_col)
        tiling_param = TilingParam(0, 0, 0, tile_row, tile_row, 0, 0, 48, 1, swizzle_offset=1, swizzle_direction=0)
    else:
        tiling_param = TilingParam(0, 0, 0, 192, 64, 0, 0, 48, 1, swizzle_offset=1, swizzle_direction=0)

    concat_d = ConcatDModel(input_precision=DType.FP32, output_precision=DType.FP32)
    res = concat_d.time_predict(shapes, [tiling_param], AICoreCostModel(arc_config))
    for k, v in res.items():
        logger.info("test_concat_D, %s : %s", k, v)