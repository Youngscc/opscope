# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from math import sqrt

from tqdm import tqdm

from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.common.entity import DType, ResultKey
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.op_model.matmul import Matmul as MatmulOp


def NCDHW_to_NDC1HWC0(shape, C0=8):
    N, C, D, H, W = shape
    C1 = (C + C0 - 1) // C0
    return [N, D, C1, H, W, C0]


def NCDHW_to_FRACTAL_Z(shape, C0=8, N0=16):
    c_out, c_in, k_d, k_h, k_w = shape
    N1 = (c_out + N0 - 1) // N0
    C1HW = (k_h * k_w * k_d * c_in + C0 - 1) // C0
    return [C1HW, N1, N0, C0]


def infer_pad(ni: int, no: int, nk: int):
    p = no + nk - 1 - ni
    return [p - p // 2, p // 2]


CONV3_INFER_KERNEL_SIZE = {
    1: (1, 1, 1),
    2: (2, 1, 1),
    3: (3, 1, 1),
    4: (1, 2, 2),
    8: (2, 2, 2),
    12: (3, 2, 2),
    18: (2, 3, 3),
    27: (3, 3, 3),
}


def get_conv3d_input(x: list, w: list, y: list, b: list | None = None):
    n, di, ci1, hi, wi, ci0 = x
    z1, cz1, cz0, z0 = w
    no, do, co1, ho, wo, co0 = y
    ci = ci0 * ci1
    co = min(b[0], co0 * co1, cz0 * cz1) if b is not None else min(co0 * co1, cz0 * cz1)
    dhw_k = z0 * z1 // ci
    inferred_dhw_k = CONV3_INFER_KERNEL_SIZE.get(dhw_k)
    if inferred_dhw_k:
        dk, hk, wk = inferred_dhw_k
    else:
        dk = di
        hk = int(sqrt(dhw_k // di))
        wk = hk
    if dk * hk * wk != dhw_k:
        raise ValueError(f"Dimension mismatch: {(n, ci, di, hi, wi)}, {w}, {b}, {(n, co, do, ho, wo)}")

    return [
        [
            [n, ci, di, hi, wi],
            [co, ci, dk, hk, wk],
            b,
        ],
        [
            [n, co, do, ho, wo],
        ],
    ]


class NaiveConv3D(MatmulOp):
    def __init__(
            self,
            input_precision: DType,
            output_precision: DType,
            **kwargs
    ) -> None:
        super().__init__(input_precision, output_precision)
        self._op_name = "Conv3DV2"
        self.batch = 1

    def _validate_and_convert_shapes(self, shapes: list[list, list]) -> tuple:
        """验证并转换输入形状"""
        if len(shapes[0][0]) == 6:
            # NDC1HWC0 format - should be converted to NCDHW
            if len(shapes[1][0]) != 6:
                raise ValueError("Expected length of shapes[1][0] is 6, but got {}".format(len(shapes[1][0])))

            if len(shapes[0][1]) != 4:
                raise ValueError("Expected length of shapes[0][1] is 4, but got {}".format(len(shapes[0][1])))
            shapes = get_conv3d_input(
                shapes[0][0],
                shapes[0][1],
                shapes[1][0],
                shapes[0][2] if len(shapes[0]) > 2 else None,
            )
        return shapes

    def _extract_shapes(self, shapes: list[list, list]) -> tuple:
        """提取输入和输出形状"""
        input_shapes, output_shapes = shapes
        if len(input_shapes) == 2:
            fmap_shape, filter_shape = input_shapes
            bias_shape = [0]
        elif len(input_shapes) == 3:
            fmap_shape, filter_shape, bias_shape = input_shapes
        else:
            msg = "len(input) == 2 or 3"
            raise ValueError(msg)

        if len(output_shapes) != 1:
            raise ValueError(
                "Expected length of output_shapes is 1, "
                "but got {}".format(len(output_shapes))
            )
        output_shape = output_shapes[0]

        return fmap_shape, filter_shape, bias_shape, output_shape

    def _validate_shape_dimensions(self, fmap_shape: list, filter_shape: list, output_shape: list):
        """验证形状维度"""
        if len(fmap_shape) != 5:
            raise ValueError(
                "Expected length of fmap_shape is 5, "
                "but got {}".format(len(fmap_shape))
            )

        if len(filter_shape) != 5:
            raise ValueError(
                "Expected length of filter_shape is 5, "
                "but got {}".format(len(filter_shape))
            )

        if len(output_shape) != 5:
            raise ValueError(
                "Expected length of output_shape is 5, "
                "but got {}".format(len(output_shape))
            )

    def _validate_shape_consistency(self, fmap_shape: list, filter_shape: list, output_shape: list):
        """验证形状一致性"""
        batch_in, c_in, d_in, h_in, w_in = fmap_shape
        c_out, c_in_filter, k_d, k_h, k_w = filter_shape
        batch_out, c_out_out, d_out, h_out, w_out = output_shape

        if c_in_filter != c_in:
            raise ValueError(
                "c_in_filter should be equal to c_in, "
                "but got {} and {}".format(c_in_filter, c_in)
            )

        if batch_in != batch_out:
            raise ValueError(
                "batch_in should be equal to batch_out, "
                "but got {} and {}".format(batch_in, batch_out)
            )

    def _calculate_matmul_dimensions(self, fmap_shape: list, filter_shape: list, output_shape: list) -> tuple:
        """计算矩阵乘法的维度"""
        batch_in, c_in, d_in, h_in, w_in = fmap_shape
        c_out, c_in_filter, k_d, k_h, k_w = filter_shape
        batch_out, c_out_out, d_out, h_out, w_out = output_shape

        k = c_in * k_d * k_h * k_w
        m = d_out * h_out * w_out
        n = c_out
        bias = c_out_out if len(fmap_shape) > 2 else 0

        self.batch = batch_in

        return m, k, n, bias

    def _apply_batch_multiplier(self, mm_res: dict) -> dict:
        """应用批次乘数"""
        for k in mm_res:
            if k != ResultKey.L2_MISS_RATE:
                mm_res[k] *= self.batch
        return mm_res

    def _process_bias(self, bias: int, mm_res: dict) -> dict:
        """处理偏置"""
        if bias:
            ...  # NEXT -- implement bias here
        return mm_res

    def time_predict(
            self,
            shapes: list[list, list],
            tiling_param: list[TilingParam],
            aicore: AICoreCostModel,
    ) -> dict[ResultKey, float]:
        """
        Naive time prediction considering
        conv3d = im2col + matmul
        and im2col time = 0
        """
        # 验证并转换形状
        shapes = self._validate_and_convert_shapes(shapes)

        # 提取形状
        fmap_shape, filter_shape, bias_shape, output_shape = self._extract_shapes(shapes)

        # 验证形状维度
        self._validate_shape_dimensions(fmap_shape, filter_shape, output_shape)

        # 验证形状一致性
        self._validate_shape_consistency(fmap_shape, filter_shape, output_shape)

        # 计算矩阵乘法维度
        m, k, n, bias = self._calculate_matmul_dimensions(fmap_shape, filter_shape, output_shape)

        # 调用父类矩阵乘法预测
        mm_res = super().time_predict(
            shapes=[[m, k], [k, n]],
            tiling_param=tiling_param,
            aicore=aicore,
        )

        # 应用批次乘数
        mm_res = self._apply_batch_multiplier(mm_res)

        # 处理偏置
        mm_res = self._process_bias(bias, mm_res)

        return mm_res


if __name__ == "__main__":
    import argparse
    import json

    import pandas as pd

    from core.config.arc_spec import load_arc_config


    def write_to_csv_with_pandas(
            outputs: dict[str, object], filename: str = "output_3d.csv"
    ):
        data = []
        for key, result in outputs.items():
            row = {"Shape": key}
            row.update(result)
            data.append(row)

        df = pd.DataFrame(data)
        df.to_csv(filename, index=False, encoding="utf-8")


    parser = argparse.ArgumentParser(description="算子性能预测")
    parser.add_argument(
        "--npu_spec",
        nargs="?",
        type=str,
        help="芯片配置参数",
        default="../api/npu_spec_config/910B1_FP32.json",
    )
    parser.add_argument("--precision", type=str, default="fp32")
    parser.add_argument(
        "--tiling_calculator_output", type=str, default="outputs3d.json"
    )

    args = parser.parse_args()
    if args.precision in ["fp32", "float32"]:
        args.precision = DType.FP32
    elif args.precision in ["fp16", "float16"]:
        args.precision = DType.FP16

    with open(args.tiling_calculator_output) as f:
        conv3d_inputs = json.load(f)

    outputs = {}

    for inp in tqdm(conv3d_inputs):
        base_k = int(32 / args.precision.value[0])
        tiling_data = inp["tilingData"]
        m0 = tiling_data["conv3dApiTiling"]["mL0"]
        n0 = tiling_data["conv3dApiTiling"]["nL0"]
        k0 = tiling_data["conv3dApiTiling"]["kL0"]
        m1 = tiling_data["conv3dApiTiling"]["mAL1"]
        n1 = n0 * tiling_data["conv3dApiTiling"]["mAL1DivmL0"]  # NEXT -- not sure
        k1 = tiling_data["conv3dApiTiling"]["kAL1"]
        batch_dim = tiling_data["conv3dRunInfo"]["batchDim"]
        d_dim = tiling_data["conv3dRunInfo"]["doDim"]
        group_dim = tiling_data["conv3dRunInfo"]["groupDim"]
        m_dim = tiling_data["conv3dRunInfo"]["mDim"]
        n_dim = tiling_data["conv3dRunInfo"]["nDim"]

        w_dim = batch_dim * d_dim * m_dim * group_dim
        h_dim = n_dim

        tiling_param = TilingParam(
            m0=m0,
            n0=n0,
            k0=k0,
            m1=m1,
            n1=n1,
            k1a=k1,
            k1b=k1,
            w=w_dim,
            h=h_dim,
            d=1,
            align_tiles=1,
        )
        arc_config = load_arc_config('910B1')
        cost_model = AICoreCostModel(arc_config, fixpipe_calculate=0, pure_fp32=0)

        batch = tiling_data["conv3dRunInfo"]["batch"]
        c_in = tiling_data["conv3dRunInfo"]["cin"]
        c_out = tiling_data["conv3dRunInfo"]["cout"]
        d_in = tiling_data["conv3dRunInfo"]["din"]
        d_out = tiling_data["conv3dRunInfo"]["dout"]
        h_in = tiling_data["conv3dRunInfo"]["hin"]
        h_out = tiling_data["conv3dRunInfo"]["hout"]
        w_in = tiling_data["conv3dRunInfo"]["win"]
        w_out = tiling_data["conv3dRunInfo"]["wout"]
        kd = tiling_data["conv3dRunInfo"]["kd"]
        kh = tiling_data["conv3dRunInfo"]["kh"]
        kw = tiling_data["conv3dRunInfo"]["kw"]

        shapes = [
            [
                NCDHW_to_NDC1HWC0([batch, c_in, d_in, h_in, w_in]),
                NCDHW_to_FRACTAL_Z([c_out, c_in, kd, kh, kw]),
                [c_out],
            ],
            [
                NCDHW_to_NDC1HWC0([batch, c_out, d_out, h_out, w_out]),
            ],
        ]

        output = NaiveConv3D(args.precision, args.precision).time_predict(
            shapes=shapes,
            tiling_param=[tiling_param],
            aicore=cost_model,
        )

        key = (
            f"{batch} {c_in} {d_in} {h_in} {w_in} "
            f"{c_out} {c_in} {kd} {kh} {kw} "
            f"{batch} {c_out} {d_out} {h_out} {w_out}"
        )
        outputs[key] = {d.value[1]: v for d, v in output.items()}

    write_to_csv_with_pandas(outputs)