# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.common.entity import (
    CoreType,
    VecOpType,
    DType,
    ResultKey,
    Section,
    TensorData,
    MemLoc,
)
from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.backend.engineering_costmodel.core.pipeline.aiv_pipeline import AIVPipeline
from core.backend.engineering_costmodel.core.tiling_and_core_split.catlass_tiling import CatlassTiling
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.core.vector_op import VectorBasicOp
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel
from core.common.log_format import logging

# 创建一个日志记录器
logger = logging.getLogger(__name__)


class DynamicQuant(BasicOperatorModel):
    def __init__(self, input_precision: DType, output_precision: DType, **kwargs):
        super().__init__(
            "DynamicQuant", CoreType.AIV, input_precision, output_precision
        )
        self.section_list = None

        input_dtype = self.input_precision
        if input_dtype == DType.BF16:
            input_dtype = DType.FP16

        row, col = "row", "col"
        self.row = row
        self.col = col
        input_x = TensorData("input_x", input_dtype, [row, col], MemLoc.GM)
        conv_float_x = TensorData(
            "conv_float_x", DType.FP32, [row, col], MemLoc.UB
        )
        half_x = TensorData("half_x", DType.FP16, [row, col], MemLoc.UB)
        abs_res = TensorData("abs_res", DType.FP16, [row, col], MemLoc.UB)
        max_res = TensorData("max_res", DType.FP16, [row, col], MemLoc.UB)
        vcg_max_req = TensorData(
            "vcg_max_req", DType.FP16, [row, 128], MemLoc.UB
        )
        vcg_max_res = TensorData(
            "vcg_max_res", DType.FP16, [row, col], MemLoc.UB
        )
        conv_float_res = TensorData(
            "conv_float_res", DType.FP32, [row, col], MemLoc.UB
        )
        div_res = TensorData("div_res", DType.FP32, [row, col], MemLoc.UB)
        muls_res = TensorData("muls_res", DType.FP32, [row, col], MemLoc.UB)
        conv_int32 = TensorData(
            "conv_int32", DType.INT32, [row, col], MemLoc.UB
        )
        conv_fp16 = TensorData(
            "conv_fp16", DType.FP16, [row, col], MemLoc.UB
        )
        y_out = TensorData("y_out", DType.INT8, [row, col], MemLoc.GM)
        # 1个float值，最小搬了32
        scale_out = TensorData("scale_out", DType.FP32, [row, 8], MemLoc.GM)

        self.dynamic_quant_op = [
            VectorBasicOp(
                VecOpType.CONV_F162F32, [input_x], [conv_float_x], pipe_barrier=False
            ),
            VectorBasicOp(VecOpType.VABS, [half_x], [abs_res], pipe_barrier=False),
            VectorBasicOp(VecOpType.VMAX, [abs_res], [max_res]),
            VectorBasicOp(VecOpType.VCGMAX, [vcg_max_req], [vcg_max_res]),
            VectorBasicOp(VecOpType.CONV_F162F32, [vcg_max_res], [conv_float_res]),
            VectorBasicOp(VecOpType.VDIV, [conv_float_res], [scale_out]),
            VectorBasicOp(VecOpType.VMULS, [div_res], [muls_res]),
            VectorBasicOp(VecOpType.CONV_F322S32R, [muls_res], [conv_int32]),
            VectorBasicOp(VecOpType.CONV_DEQ, [conv_int32], [conv_fp16]),
            VectorBasicOp(VecOpType.CONV_F162S8R, [conv_fp16], [y_out]),
        ]

    def time_predict(
            self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel
    ) -> dict[ResultKey, float]:
        rows = shapes[0][0]
        cols = shapes[0][1]
        section = Section(
            0,
            CoreType.AIV,
            rows,
            0,
            cols,
            tiling_param[0],
            self.input_precision,
            self.output_precision,
        )
        tiling = CatlassTiling()
        input_tiles, output_tiles = tiling.generate_tiles(section)

        for tile in input_tiles:
            tile.fused_op = self.dynamic_quant_op
            shape_dict = {self.row: tile.rows, self.col: tile.cols}
            tile.shape_dict = shape_dict
            logger.info("section.bias is %s, tile.rows is %s, tile.cols is %s", section.bias, tile.rows, tile.cols)

        aiv_pipeline = AIVPipeline(aicore, tiling_param[0])
        core_set = {tile.core for tile in input_tiles}
        size_by_core = {
            core: sum([t.size for t in input_tiles if t.core == core])
            for core in core_set
        }
        max_size_core = max(size_by_core.items(), key=lambda x: x[1])[0]
        input_tiles = [tile for tile in input_tiles if tile.core == max_size_core]
        ret = aiv_pipeline.calculate_time(input_tiles, output_tiles)
        scalar_time = 4
        ret[ResultKey.CORE_TIME] += scalar_time
        return ret