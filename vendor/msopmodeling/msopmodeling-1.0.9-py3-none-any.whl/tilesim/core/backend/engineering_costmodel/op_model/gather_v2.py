# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

import math
from core.common.entity import ResultKey, CoreType
from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel
from core.common.log_format import logging
from core.common.entity import DType, MemLoc

# --- 日志记录器 ---
logger = logging.getLogger("gather_v2")

# --- 常量定义 ---
UB_SIZE_BYTES = 192 * 1024  # 192 KB
L2_SIZE_BYTES = 192 * 1024 * 1024


# --- 辅助函数 ---
def _parse_shapes(self_shape, index_shape, dim):
    """解析输入形状和维度"""
    try:
        self_dims = self_shape
        index_dims = index_shape
        gather_dim = int(dim)
        return self_dims, index_dims, gather_dim
    except (ValueError, AttributeError):
        return None, None, None


def _calculate_output_shape(self_dims, index_dims, gather_dim):
    """计算输出形状 - 按照C++代码的逻辑实现"""
    # 1. 拼接 index_dims 和 self_dims 的非 gather_dim 维度
    output_shape = index_dims.copy()  # 第一步：将index_dims复制到output_shape

    # 第二步：遍历self_dims，将除了gather_dim位置以外的所有维度追加到output_shape
    for i, dim in enumerate(self_dims):
        if i != 0:
            output_shape.append(dim)

    # 2. 打印返回值（可选，如果需要调试信息）
    logger.debug(f"Computed outShape: {output_shape}")

    return output_shape


class GatherV2Model(BasicOperatorModel):
    def __init__(self, input_precision: DType, output_precision: DType, block_dim, **kwargs):
        """
        初始化GatherV2Model类
        """
        super().__init__("GatherV2Model", CoreType.AIV, input_precision, output_precision)
        # next:从数据类型去找对应的size
        self.data_type_size = 2 if input_precision == DType.BF16 else 4
        self.block_dim = block_dim

    # --- 主预测函数 ---
    def time_predict(
            self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel
    ) -> dict[ResultKey, float]:
        """
        预测Gather算子的MTE2和MTE3时间
        """
        self.arc_config = aicore.arc_config
        self_shape = shapes[0]
        index_shape = shapes[1]
        dim = shapes[2][0] if len(shapes) > 2 else 0
        self_dims, index_dims, gather_dim = _parse_shapes(self_shape, index_shape, dim)
        if self_dims is None:
            return {
                ResultKey.CORE_TIME: 0,
                ResultKey.AIV_TIME: 0,
                ResultKey.VEC_TIME: 0,
                ResultKey.MTE2_TIME_AIV: "Invalid input parameters",
                ResultKey.MTE3_TIME: "Invalid input parameters",
                ResultKey.L2_MISS_RATE: 0,
            }

        output_shape = _calculate_output_shape(self_dims, index_dims, gather_dim)

        self_total_bytes, inner_bytes, core_inner_shape = self._get_bytes_and_case(self_shape, index_shape,
                                                                                   output_shape)

        mte2_bw_def, _ = self.arc_config.lookup_bw(MemLoc.GM, MemLoc.UB, self.block_dim)
        mte3_bw_def, _ = self.arc_config.lookup_bw(MemLoc.UB, MemLoc.GM, self.block_dim)

        eff_mte2, eff_mte3 = self._get_efficiency_scoring_v2(self_shape, index_shape, self_total_bytes,
                                                             core_inner_shape, inner_bytes)

        mte2_time = inner_bytes / (mte2_bw_def * eff_mte2)
        mte3_time = inner_bytes / (mte3_bw_def * eff_mte3)

        return {
            ResultKey.CORE_TIME: mte2_time + mte3_time + 3,
            ResultKey.AIV_TIME: 0,
            ResultKey.VEC_TIME: 0,
            ResultKey.MTE2_TIME_AIV: mte2_time,
            ResultKey.MTE3_TIME: mte3_time,
            ResultKey.L2_MISS_RATE: 0,
        }

    def _get_bytes_and_case(self, self_dims, index_dims, output_shape):
        """解析搬运的数据量并对场景分类"""
        total_elements = 1
        for dim in output_shape:
            total_elements *= int(dim)
        mte3_total_bytes = total_elements * self.data_type_size
        mte3_bytes_per_core = mte3_total_bytes / self.block_dim

        #
        self_total_elements = 1
        for d in self_dims:
            self_total_elements *= int(d)

        self_total_bytes = self_total_elements * self.data_type_size
        # 解析每个核上面内层循环任务的数据量
        core_inner_shape, inner_loop_bytes = self._parse_core_layout(self_dims, self.block_dim)

        return self_total_bytes, mte3_bytes_per_core, core_inner_shape

    def _get_efficiency_origin(self, direction, case_tag):
        """
        根据搬运方向和场景标签返回带宽折算系数 (0.0 ~ 1.0)
        """
        # MTE2 (GM -> UB) 的折算系数
        mte2_eff_map = {
            "large_aligned": 0.85,  # 大块对齐，效率高
            "small_input": 0.95,  # 整个输入在UB，几乎是缓存速度
            "flat_fit": 0.75,  # 二维且适配UB
            "single_output": 0.25,
            "multi_output": 0.20,  # 输出shape大，UB装不下
            "default": 0.50  # 离散访存或未对齐，效率低
        }

        # MTE3 (UB -> GM) 的折算系数
        mte3_eff_map = {
            "large_aligned": 0.80,
            "small_input": 0.80,
            "flat_fit": 0.80,
            "single_output": 0.25,
            "multi_output": 0.20,
            "default": 0.60
        }

        if direction == "MTE2":
            return mte2_eff_map.get(case_tag, 1)
        else:
            return mte3_eff_map.get(case_tag, 1)

    def _calculate_score_mte2(self, self_dims, index_dims, self_total_bytes, last_dim, inner_bytes):

        score_mte2 = 1.0

        # 1. 对齐得分
        byte_offset = last_dim * self.data_type_size
        alignment_penalties = [(128, 0.1), (64, 0.2), (32, 0.3)]
        for align, penalty in alignment_penalties:
            if byte_offset % align != 0:
                score_mte2 -= penalty
                break

        # 2. 缓存红利
        if self_total_bytes <= L2_SIZE_BYTES:
            score_mte2 += 0.10

        # 3. self shape 评分 (使用 .get() 修复报错)
        dim0_align = (self_dims[0] % 64 == 0)
        dim1_align = (self_dims[1] % 64 == 0)
        shape_score_map = {
            (True, True): 0.2,
            (False, False): -0.4,
            (True, False): -0.3,
            (False, True): -0.3
        }
        # 使用 .get() 并提供默认值 0
        score_mte2 += shape_score_map.get((dim0_align, dim1_align), 0)

        # 4. index shape 评分
        max_idx = max(index_dims[0], index_dims[-1])
        if index_dims[0] == 1 and index_dims[1] == 1:
            pass  # 保持 1.0 不变
        else:
            thresholds = [(4096, 0.4), (2048, 0.3), (1024, 0.2), (128, 0.05)]
            for limit, penalty in thresholds:
                if max_idx > limit or (limit == 128 and max_idx >= 128):
                    score_mte2 -= penalty
                    break

        if index_dims[0] % 1024 != 0 and index_dims[0] != 1:
            score_mte2 -= 0.05
        if len(index_dims) >= 2:
            score_mte2 -= 0.05

        # 5. 小包带宽评分 (使用 .get() 修复报错)
        if inner_bytes < 256:
            pkg_map = {64: 0.02, 128: 0.03, 256: 0.04}
            # 这里的逻辑建议改为寻找第一个大于 inner_bytes 的阈值
            for limit in sorted(pkg_map.keys()):
                if inner_bytes < limit:
                    # 获取该阈值对应的分值
                    score_mte2 = pkg_map.get(limit, score_mte2)
                    break

        # 6. 多核访存扣分
        if self.block_dim in [47, 48] and inner_bytes > 16 * 1024:
            score_mte2 /= 2

        return score_mte2

    def _calculate_score_mte3(self, core_shape, last_dim, inner_bytes):
        """
        专门计算 MTE3 (数据写回) 的效率评分
        """
        score_mte3 = 1.0

        # 写入非对齐时的额外损耗
        if (last_dim * self.data_type_size) % 32 != 0:
            score_mte3 -= 0.1

        # mte3搬出矩阵与32倍数亲和评分
        if core_shape[0] % 32 == 0 and core_shape[1] % 32 == 0:
            score_mte3 = 1
        elif core_shape[0] % 32 != 0 and core_shape[1] % 32 != 0:
            score_mte3 -= 0.35
        else:  # core_shape[0] % 32 != 0 or core_shape[1] % 32 != 0
            score_mte3 -= 0.3

        # 写回数据量很低造成带宽损失
        if inner_bytes < 64:
            score_mte3 = 0.0020 if self.block_dim == 1 else 0.025
        elif inner_bytes < 128:
            score_mte3 = 0.035
        elif inner_bytes < 256:
            score_mte3 = 0.18

        return score_mte3

    def _get_efficiency_scoring_v2(self, self_dims, index_dims, self_total_bytes, core_shape, inner_bytes):
        """
        内部解析场景并输出 MTE2 和 MTE3 的双向效率值
        """
        last_dim = core_shape[-1]

        # 调用子函数获取原始分
        score_mte2 = self._calculate_score_mte2(self_dims, index_dims, self_total_bytes, last_dim, inner_bytes)
        score_mte3 = self._calculate_score_mte3(core_shape, last_dim, inner_bytes)

        # 边界保护与最终系数计算
        eff_mte2 = max(0.001, min(1.0, score_mte2))
        eff_mte3 = max(0.001, min(1.0, score_mte3))

        return eff_mte2 * 0.25, eff_mte3 * 0.25

    def _parse_core_layout(self, self_dims, block_dim):
        """
        根据自右向左亲和原则，推导单核分到的逻辑形状
        返回：core_local_shape (list), inner_loop_bytes (int)
        """
        total_elements = 1
        for d in self_dims:
            total_elements *= int(d)

        # 每个核分到的理论元素数
        per_core_elements = math.ceil(total_elements / block_dim)

        # 自右向左重构 shape
        # 假设内层维度尽量保持完整，直到元素量耗尽
        core_local_shape = []
        remaining_elements = per_core_elements

        # 从最内层开始遍历
        for d in reversed(self_dims):
            if remaining_elements >= d:
                core_local_shape.insert(0, d)
                remaining_elements /= d
            else:
                # 如果当前维度被切开了，记录残余份数
                core_local_shape.insert(0, max(1, int(remaining_elements)))
                remaining_elements = 1  # 任务已分配完

        inner_loop_bytes = per_core_elements * self.data_type_size
        return core_local_shape, inner_loop_bytes