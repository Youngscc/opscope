# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.common.entity import (
    CoreType,
    VecOpType,
    DType,
    ResultKey,
    Section,
    TensorData,
    MemLoc,
)
from core.backend.engineering_costmodel.core.pipeline.aiv_pipeline import AIVPipeline
from core.backend.engineering_costmodel.core.tiling_and_core_split.catlass_tiling import CatlassTiling
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.core.vector_op import VectorBasicOp
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel
from core.common.log_format import logging

# 创建一个日志记录器
logger = logging.getLogger(__name__)


class GeluModel(BasicOperatorModel):
    def __init__(self, input_precision: DType, output_precision: DType, **kwargs):
        super().__init__(
            "aclnnGelu_Gelu_Gelu", CoreType.AIV, input_precision, output_precision
        )
        self.section_list = None
        row, col = "row", "col"
        input_x1 = TensorData("input_x", DType.FP32, [row, col], MemLoc.GM)
        input_x2 = TensorData("input_x", DType.FP32, [row, col], MemLoc.UB)
        x_square = TensorData("x_square", DType.FP32, [row, col], MemLoc.UB)
        x_cube = TensorData("x_cube", DType.FP32, [row, col], MemLoc.UB)
        s_mul_x_cube = TensorData(
            "s_mul_x_cube", DType.FP32, [row, col], MemLoc.UB
        )
        add_result = TensorData(
            "add_result", DType.FP32, [row, col], MemLoc.UB
        )
        y = TensorData("y", DType.FP32, [row, col], MemLoc.UB)
        exp_y = TensorData("exp_y", DType.FP32, [row, col], MemLoc.UB)
        s_add_exp_y = TensorData(
            "s_add_exp_y", DType.FP32, [row, col], MemLoc.UB
        )
        out = TensorData("out", DType.FP32, [row, col], MemLoc.GM)

        self.gelu_op = [
            VectorBasicOp(
                VecOpType.VMUL_SELF,
                [input_x1, input_x2],
                [x_square],
                pipe_barrier=False,
            ), # 公式 input_x^2, x_square = input_x^2
            VectorBasicOp(
                VecOpType.VMUL, [x_square, input_x2], [x_cube]
            ),  # 公式 input_x^3, x_cube = x_square * input_x
            VectorBasicOp(VecOpType.VMULS, [x_cube], [s_mul_x_cube]), 
            # 公式 0.044715 * input_x^3, s_mul_x_cube= scalar * x_cube
            VectorBasicOp(
                VecOpType.VADD, [input_x2, s_mul_x_cube], [add_result]
            ),  # 公式 input_x + 0.044715 * input_x^3,
            VectorBasicOp(VecOpType.VMULS, [input_x2, add_result], [y]), 
            # 公式 y = (input_x + 0.044715 * input_x^3) * (-2) * (np.sqrt(2/np.pi)
            VectorBasicOp(VecOpType.VEXP, [y], [exp_y]),  # e(y)
            VectorBasicOp(VecOpType.VADDS, [exp_y], [s_add_exp_y]),  # 公式 1 + e(y)
            VectorBasicOp(
                VecOpType.VDIV, [input_x2, s_add_exp_y], [out]
            ),  # 公式 input_x / (1 + e(y))
        ]

        self.row = row
        self.col = col

    def time_predict(
        self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel
    ) -> dict[ResultKey, float]:
        rows = 1
        for i in range(len(shapes[0]) - 1):
            rows *= shapes[0][i]
        cols = shapes[0][-1]
        logger.info("rows = %s", rows)
        logger.info("cols = %s", cols)

        section = Section(
            0,
            CoreType.AIV,
            rows,
            0,
            cols,
            tiling_param[0],
            self.input_precision,
            self.output_precision,
        )
        tiling = CatlassTiling()
        input_tiles, output_tiles = tiling.generate_tiles(section)
        logger.info("len(input_tiles) = %s", len(input_tiles))
        for tile in input_tiles:
            tile.fused_op = self.gelu_op
            shape_dict = {self.row: tile.rows, self.col: tile.cols}
            tile.shape_dict = shape_dict

        aiv_pipe = AIVPipeline(aicore, tiling_param[0], mte3_hit_rate=1)

        core_set = {tile.core for tile in input_tiles}
        size_by_core = {
            core: sum([t.size for t in input_tiles if t.core == core])
            for core in core_set
        }
        max_size_core = max(size_by_core.items(), key=lambda x: x[1])[0]
        input_tiles_new = [tile for tile in input_tiles if tile.core == max_size_core]

        return aiv_pipe.calculate_time(input_tiles_new, output_tiles)