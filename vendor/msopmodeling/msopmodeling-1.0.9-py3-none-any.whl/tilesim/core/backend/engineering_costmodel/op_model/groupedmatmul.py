# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

import math
import random
import time
from typing import Literal, List

from core.common.entity import (
    CoreType,
    VecOpType,
    DType,
    ResultKey,
    Section,
    TensorData,
    MemLoc,
)
from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.backend.engineering_costmodel.core.pipeline.inter_core_pipeline import InterCorePipeline
from core.backend.engineering_costmodel.core.tiling_and_core_split.catlass_tiling import CatlassTiling
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.core.vector_op import VectorBasicOp
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel
from core.backend.engineering_costmodel.op_model.matmul import matmul_tiling
from core.common.log_format import logging

# 创建一个日志记录器
logger = logging.getLogger(__name__)


def _shape_parse(shapes: list):
    m, k = shapes[0]
    g, kb, n = shapes[1]

    if k != kb:
        g, n, kb = shapes[1]
    if k != kb:
        raise ValueError("k and kb must be equal")

    return g, m, k, n


def get_current_list(group_list, group_list_type, total_len, group_size):
    # 如果没有传入group_list的时候，默认均分
    if group_list is None or len(group_list) == 0:
        g_len = math.ceil(total_len / group_size)
        group_list = []
        for i in range(group_size):
            group_list.append(min(g_len, total_len - sum(group_list)))
        return group_list

    if group_list_type == 0:  # group_list表示累积和
        if not all(x <= y for x, y in zip(group_list, group_list[1:])):
            raise ValueError("group_list_type = 0表示group_list为前缀和数组，因此必须递增")
        return [group_list[0]] + [group_list[i] - group_list[i - 1] for i in range(1, len(group_list))]
    elif group_list_type == 1:  # group_list表示每组大小
        return group_list
    else:
        raise ValueError(f"不支持的group_list_type：{group_list_type}")


# 生成group_list !!!
def generate_group_list(m: int, problem_count: int, mode: Literal['random', 'arithmetic'] = 'random') -> List[int]:
    """
    生成 Group List (矩阵切分点列表)

    Args:
        m (int): 总维度大小 (比如 M 轴总长)
        problem_count (int): 任务数量 (Group 数量)
        mode (str): 生成模式
            - 'random': 随机生成并排序 (模拟不均匀负载)
            - 'arithmetic': 均匀等差数列，最后一项强制为 m (模拟均匀负载)

    Returns:
        List[int]: 排序后的切分点列表
    """
    group_list = []

    if mode == 'random':
        # --- 模式 1: 随机生成 ---
        # 设置随机种子 (可选，如果你希望每次运行都不同)
        random.seed(time.time())
        # 生成 problem_count 个 [0, m] 之间的随机数
        group_list = [random.randint(0, m) for _ in range(problem_count)]
        # 必须排序，因为后续计算差分需要有序列表
        group_list.sort()

    elif mode == 'arithmetic':
        # --- 模式 2: 等差数列 (均匀分布) ---
        # 1. 计算步长 (向上取整)
        # 对应需求: "m/problem_count向上取整"
        step = math.ceil(m / problem_count)

        # 2. 生成前 N-1 项
        # 对应需求: "首项等于差", 数列为 d, 2d, 3d...
        # range(1, problem_count) 会生成 1 到 problem_count-1
        group_list = [step * i for i in range(1, problem_count)]

        # *安全检查*: 如果 m 很小而 problem_count 很大，等差数列可能会超过 m。
        # 为了保证逻辑正确 (groupList 代表累积索引，不能超过总长 m)，这里做一个截断。
        # 如果你的场景保证 m >> problem_count，这行代码通常不会触发变化。
        group_list = [min(x, m) for x in group_list]

        # 3. 最后一项强制为 m
        # 对应需求: "最后一项等于m（最后一项不必是等差数列）"
        group_list.append(m)

    else:
        raise ValueError("Mode must be 'random' or 'arithmetic'")
    print(f'group_list={group_list}')
    return group_list


class GroupedMatmul(BasicOperatorModel):

    def __init__(
            self,
            input_precision: DType,
            output_precision: DType,
            group_type: int = 0,
            group_list_type: int = 1,
            group_list: List[int] = None,
            split_item: int = 0,
            use_avg_core=False,
            layout=None,
            layout_format=None,
            act_type=0,
            **kwargs
    ):
        # 修复：只传递父类需要的参数
        super().__init__(
            "GroupedMatmul", CoreType.MIX, input_precision, output_precision
        )

        # 添加子类特有的属性
        self.section_list = None
        self.groupType = group_type
        self.groupListType = group_list_type
        self.groupListData = group_list
        self.actType = act_type
        self.use_avg_core = use_avg_core
        self.layout = layout
        self.layout_format = layout_format

        row, col = "row", "col"
        mm_result = TensorData("mm_result", DType.FP32, [row, col], MemLoc.L2)
        mm_result_ub = TensorData("mm_result_ub", DType.FP32, [row, col], MemLoc.UB)
        quant_scale = TensorData("quant_scale", DType.FP16, [1, col], MemLoc.GM)
        quant_scale_ub = TensorData("quant_scale_ub", DType.FP32, [1, col], MemLoc.UB)
        input_per_token_scale = TensorData("input_per_token_scale", DType.FP32, [row], MemLoc.GM)
        per_token_scale_broadcast = TensorData("per_token_scale_broadcast", DType.FP32, [row, col], MemLoc.UB)

        out = TensorData("out", DType.FP32, [row, col], MemLoc.GM)

        comb_per_token = [
            VectorBasicOp(VecOpType.VBRCB, [input_per_token_scale], [per_token_scale_broadcast], pipe_barrier=False),
            VectorBasicOp(VecOpType.CONV_BF162F32, [quant_scale], [quant_scale_ub]),
            VectorBasicOp(VecOpType.CONV_S322F32, [mm_result], [mm_result_ub]),
            VectorBasicOp(VecOpType.VADDS, [quant_scale_ub, mm_result_ub], [mm_result_ub]),  # dequant
            VectorBasicOp(VecOpType.VMUL, [mm_result_ub, per_token_scale_broadcast], [mm_result_ub])
        ]

        if self.actType == 1:
            comb_per_token.append(VectorBasicOp(VecOpType.RELU, [mm_result_ub], [mm_result_ub]))

        comb_per_token.append(VectorBasicOp(VecOpType.CONV_F322BF16, [mm_result_ub], [out]))

        self.output_stage = comb_per_token
        self.row = row
        self.col = col

    def get_tiling_strategy(self, input_shapes):
        g, m, k, n = _shape_parse(input_shapes)
        cube_tiling = matmul_tiling(m, k, n, 24, 1, self.input_precision, self.output_precision)
        tiling_param = [
            cube_tiling,
            TilingParam(cube_tiling.m0, cube_tiling.n1, 0, cube_tiling.m1, cube_tiling.n1, 0, 0, 6, 4, 1)
        ]
        return tiling_param

    def __generate_sections_c(self, shapes_list: list[list], tiling_param: list[TilingParam]):
        """
        为每组矩阵维度生成一个 Section。
        :param shapes_list: 矩阵维度列表，格式为 [[M1, K1, N1], [M2, K2, N2], ...]
        :param tiling_param: tiling 参数。
        :return: 返回所有 Section 的列表。
        """
        self.section_list = []
        for shapes in shapes_list:
            m, k, n = shapes
            if m * k * n == 0:
                continue
            tiling = tiling_param[0]
            sec = Section(
                bias=0,
                core_type=CoreType.AIC,
                m=m,
                k=k,
                n=n,
                tiling_param=tiling,
                input_precision=self.input_precision,
                output_precision=self.output_precision
            )
            tile_cnt = math.ceil(m / tiling.m1) * math.ceil(n / tiling.n1)
            sec.tile_round = tile_cnt
            self.section_list.append(sec)

    def __generate_sections_cv(self, shapes_list: list[list], tiling_param: list[TilingParam]):
        """
        为每组矩阵维度生成两个 Section：一个矩阵乘法 Section 和一个向量操作 Section。
        :param shapes_list: 矩阵维度列表，格式为 [[M1, K1, N1], [M2, K2, N2], ...]
        :param tiling_param: tiling 参数列表，包含 cube_tiling_param 和 vec_tiling_param。
        :return: 返回所有 Section 的列表。
        """
        self.section_list = []

        # 假设 tiling_param[0] 是 cube_tiling_param，tiling_param[1] 是 vec_tiling_param
        cube_tiling = tiling_param[0]
        vec_tiling = tiling_param[1]

        for shapes in shapes_list:
            m, k, n = shapes
            if m * k * n == 0:
                continue

            # 生成矩阵乘法 Section
            sec_matmul = Section(
                bias=0,
                core_type=CoreType.AIC,
                m=m,
                k=k,
                n=n,
                tiling_param=cube_tiling,
                input_precision=self.input_precision,
                output_precision=self.output_precision
            )

            # 生成向量操作 Section
            sec_vec = Section(
                bias=1,
                core_type=CoreType.AIV,
                m=m,
                k=0,
                n=n,
                tiling_param=vec_tiling,
                input_precision=self.input_precision,
                output_precision=self.output_precision,
            )

            # 设置向量操作的输入依赖
            sec_vec.input_dependency = {0: 0}

            # 将两个 Section 添加到 section_list
            self.section_list.append(sec_matmul)
            self.section_list.append(sec_vec)

    def __generate_tiles(self, tiling_param: list[TilingParam]):
        """
        为每个 Section 生成 tile。
        :param tiling_param: tiling 参数。
        """
        tiling = CatlassTiling()
        for section in self.section_list:
            tiles = tiling.generate_tiles(section)
            section.input_tiles = tiles[0]
            section.output_tiles = tiles[1]

    def time_predict(
            self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel
    ) -> dict[ResultKey, float]:

        g, m, k, n = _shape_parse(shapes)

        # 根据分组类型确定实际矩阵尺寸
        if self.groupType == 0 and (self.groupListType == 0 or self.groupListType == 1):
            # M轴分组，且groupList是前缀和数组或是分组轴上每组大小
            m_list = get_current_list(self.groupListData, self.groupListType, m, g)
            shapes_list = [[m, k, n] for m in m_list]
        elif self.groupType == 2 and self.groupListType == 0:
            # K轴分组，且groupList是前缀和数组
            k_list = get_current_list(self.groupListData, self.groupListType, k, g)
            shapes_list = [[m, k, n] for k in k_list]
        else:  # 默认不分组
            raise ValueError("Unsupported groupType or groupListType")

        # 检查是否量化路径
        is_quantized = (
                self.input_precision == DType.INT8
        )

        if tiling_param[0].m0 == 0:
            tiling_param = [matmul_tiling(m, k, n, tiling_param[0].core_num, tiling_param[0].d, self.input_precision,
                                          self.output_precision)]

        if is_quantized:
            # 量化路径: Cube+Vector双Section
            self.__generate_sections_cv(shapes_list, tiling_param)
            self.__generate_tiles(tiling_param)
            # 遍历 self.section_list，只处理索引为奇数的 Section（1, 3, 5, 7, ...）
            for i in range(1, len(self.section_list), 2):
                for tile in self.section_list[i].input_tiles:
                    shape_dict = {
                        self.row: tile.rows,
                        self.col: tile.cols
                    }
                    tile.fused_op = self.output_stage
                    tile.shape_dict = shape_dict
        else:
            # 非量化路径: 只生成Cube Section
            self.__generate_sections_c(shapes_list, tiling_param)
            self.__generate_tiles([tiling_param[0]])

        # 并行流水时间计算
        inter_core_pipe = InterCorePipeline(self.section_list, aicore)
        ret = inter_core_pipe.calculate_sections_time(plot_cv_block=True, use_avg_core=self.use_avg_core)
        fix_count = 0  # 用于控制加的scalar开销次数
        for shapes in shapes_list:
            m_i, k_i, n_i = shapes
            if m_i <= 16:
                fix_time = k_i * n_i * 1.38e-6 * self.input_precision.size / 2
                ret[ResultKey.CORE_TIME] += fix_time
                fix_count += 1
                if fix_count >= 2:
                    break
        return ret