# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.common.entity import (
    CoreType,
    VecOpType,
    DType,
    ResultKey,
    Section,
    TensorData,
    MemLoc,
)
from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.backend.engineering_costmodel.core.pipeline.inter_core_pipeline import InterCorePipeline
from core.backend.engineering_costmodel.core.tiling_and_core_split.catlass_tiling import CatlassTiling
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.core.vector_op import VectorBasicOp
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel


class HstuDenseForward(BasicOperatorModel):
    def __init__(
            self,
            x_precision: DType,
            output_precision: DType,
            enable_bias=True,
            **kwargs
    ):
        """
        初始化 HstuDenseForward 模型
        重构后：将张量和融合操作的初始化逻辑分离到独立的方法中
        """
        super().__init__(
            "HstuDenseForward", CoreType.AIV, x_precision, output_precision
        )
        self.x_precision = x_precision
        self.section_list = None
        self.enable_bias = enable_bias
        self.m_dim = "m"
        self.n_dim = "n"

        # --- 重构点：调用私有方法进行初始化 ---
        # 1. 初始化张量
        self._initialize_tensors()
        # 2. 初始化融合操作组合
        self._initialize_comb_operations()
        # ------------------------------------

    def _initialize_tensors(self):
        """私有方法：初始化所有 TensorData 对象"""
        # 使用您提供的张量定义
        m, n = self.m_dim, self.n_dim
        # Note: These tensors are created but not stored as instance attributes
        # as they are only used to define the operations in self.comb.
        # If they need to be accessed later, they should be assigned to self.
        self._input_x = TensorData(
            "input_x", DType.FP32, [m, n], MemLoc.GM
        )  # mask data
        self._input_y = TensorData(
            "input_y", DType.FP32, [m, n], MemLoc.UB
        )  # QK mm result
        self._add_output_x = TensorData(
            "add_output_x", DType.FP32, [m, n], MemLoc.UB
        )
        self._silu_x = TensorData("silu_x", DType.FP32, [m, n], MemLoc.UB)
        self._muls_x = TensorData("muls_x", DType.FP32, [m, n], MemLoc.UB)
        self._out = TensorData("out", DType.FP32, [m, n], MemLoc.UB)
        self._input_mask = TensorData(
            "input_mask", DType.FP32, [m, n], MemLoc.GM
        )

    def _initialize_comb_operations(self):
        """私有方法：根据 enable_bias 标志初始化融合操作组合 self.comb"""
        # 使用您提供的融合操作序列
        # * option :有偏置，add
        # Silu Muls
        # * option （有mask）: mul
        if self.enable_bias:
            self.comb = [
                VectorBasicOp(
                    VecOpType.VADD,
                    [self._input_x, self._input_y],  # 使用内部存储的 TensorData
                    [self._add_output_x],
                    pipe_barrier=False,
                ),
                # tensor a * tensor b
                VectorBasicOp(
                    VecOpType.SILU, [self._add_output_x], [self._silu_x]
                ),  # x/(1+e(-x))
                VectorBasicOp(
                    VecOpType.VMULS, [self._silu_x], [self._muls_x]
                ),  # tensor a * scalar
                VectorBasicOp(
                    VecOpType.VMUL, [self._muls_x, self._input_mask], [self._out]
                ),  # tensor a * tensor b
            ]
        else:
            self.comb = [
                VectorBasicOp(
                    VecOpType.SILU, [self._input_y], [self._silu_x]
                ),  # x/(1+e(-x))
                VectorBasicOp(
                    VecOpType.VMULS, [self._silu_x], [self._muls_x]
                ),  # tensor a * scalar
                VectorBasicOp(
                    VecOpType.VMUL, [self._muls_x, self._input_mask], [self._out]
                ),  # tensor a * tensor b

            ]

    # --- 以下是之前重构的 __generate_sections 及其辅助方法 ---
    def _create_cube_section_qk(self, m, k, n, tiling_params):
        """创建 Cube 计算段, qk matmul"""
        return Section(
            bias=0,
            core_type=CoreType.AIC,
            m=m,
            k=k,
            n=n,
            tiling_param=tiling_params[0],
            input_precision=self.x_precision,
            output_precision=DType.INT32,
        )

    def _create_vector_section(self, m, k, n, tiling_params):
        """创建 Vector 计算段"""
        vector_section = Section(
            bias=1,
            core_type=CoreType.AIV,
            m=m,
            k=k,  # Note: Original code sets k=0, keeping it as is.
            n=n,
            tiling_param=tiling_params[1],
            input_precision=DType.FP32,
            output_precision=self.output_precision,
        )
        vector_section.input_dependency = {0: 0}  # 依赖Cube输出
        return vector_section

    def _create_cube_section_pv(self, m, k, n, tiling_params):
        """创建 cube, score * V"""
        cube_section_pv = Section(
            bias=2,
            core_type=CoreType.AIC,
            m=m,
            k=n,
            n=k,
            tiling_param=tiling_params[1],
            input_precision=self.x_precision,
            output_precision=DType.INT32,
        )
        cube_section_pv.input_dependency = {0: 1}  # 依赖vec输出分数
        return cube_section_pv

    def _create_cube_section_timeV(self, m, k, n, tiling_params):
        """创建 cube_section_timeV (当 has_bias=True 时)"""
        cube_section_timeV = Section(
            bias=3,
            core_type=CoreType.AIC,
            m=m,
            k=n,
            n=k,
            tiling_param=tiling_params[1],
            input_precision=self.x_precision,
            output_precision=DType.INT32,
        )
        cube_section_timeV.input_dependency = {0: 1}  # 依赖vec输出分数
        return cube_section_timeV

    def _create_cube_section_positionV(self, m, k, n, tiling_params):
        """创建 cube_section_positionV (当 has_bias=True 时)"""
        cube_section_positionV = Section(
            bias=4,
            core_type=CoreType.AIC,
            m=m,
            k=n,
            n=k,
            tiling_param=tiling_params[1],
            input_precision=self.x_precision,
            output_precision=DType.INT32,
        )
        cube_section_positionV.input_dependency = {0: 1}  # 依赖vec输出分数
        return cube_section_positionV

    def __generate_sections(self, m, k, n, tiling_params, has_bias=False):
        """
        生成计算段列表
        重构后：将每个 Section 的创建逻辑分离到独立的方法中
        """
        # 1. 创建基础 Sections
        cube_section_qk = self._create_cube_section_qk(m, k, n, tiling_params)
        vector_section = self._create_vector_section(m, k, n, tiling_params)
        cube_section_pv = self._create_cube_section_pv(m, k, n, tiling_params)

        # 2. 根据 has_bias 标志决定是否添加额外的 Sections
        if has_bias:
            cube_section_timeV = self._create_cube_section_timeV(m, k, n, tiling_params)
            cube_section_positionV = self._create_cube_section_positionV(m, k, n, tiling_params)
            return [
                cube_section_qk,
                vector_section,
                cube_section_pv,
                cube_section_timeV,
                cube_section_positionV,
            ]
        else:
            return [cube_section_qk, vector_section, cube_section_pv]

    # --- __generate_sections 及其辅助方法 结束 ---

    def __generate_tiles(self, tiling_params: list[TilingParam]):
        """生成tiles并分配给section"""
        tiling = CatlassTiling()
        for i, section in enumerate(self.section_list):
            if i < len(tiling_params):
                tiles = tiling.generate_tiles(section)
                section.input_tiles = tiles[0]
                section.output_tiles = tiles[1]

    def time_predict(
            self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel
    ) -> dict[ResultKey, float]:
        """预测算子执行时间"""
        s1, b, h = shapes[0]
        s2 = shapes[1][0]
        m, k, n = s1 * b, h, s2

        # 1. 生成计算段
        # 注意：这里原代码传入了 self.enable_bias 作为 has_bias
        self.section_list = self.__generate_sections(m, k, n, tiling_param, self.enable_bias)

        # 2. 生成 Tiles
        self.__generate_tiles(tiling_param)

        # 3. 为Vector段设置融合操作
        # 假设 Vector 段是 section_list[1]
        if len(self.section_list) > 1:
            vector_section = self.section_list[1]
            if vector_section.input_tiles:  # 检查 tiles 是否已生成
                for tile in vector_section.input_tiles:
                    tile.fused_op = self.comb
                    tile.shape_dict = {
                        self.m_dim: tile.rows,
                        self.n_dim: tile.cols,
                    }

        # 4. 计算并返回时间
        pipeline = InterCorePipeline(self.section_list, aicore)
        return pipeline.calculate_sections_time(plot_cv_block=True)