# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.common.entity import DType, CoreType, TensorData, MemLoc, VecOpType, Tile, Section, ResultKey
from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.backend.engineering_costmodel.core.pipeline.inter_core_pipeline import InterCorePipeline
from core.backend.engineering_costmodel.core.tiling_and_core_split.catlass_tiling import CatlassTiling
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.core.vector_op import VectorBasicOp
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel


class LightningIndexer(BasicOperatorModel):

    def __init__(self, input_precision: DType, output_precision: DType, output_shape, layout=None, index_topk=None,
                 kv_len=None, layout_format=None, q_len=None, **kwargs):
        super().__init__('LightningIndexer', CoreType.MIX, input_precision, output_precision)
        self.k = index_topk if index_topk is not None else output_shape[0][-1]
        self.kv_len = kv_len
        self.q_len = q_len
        self.section_list = []
        self.cnt = 0
        self.layout = layout

    @staticmethod
    def __generate_combo_weight_mm(base_g, base_n):
        """
        计算QK_result 和 weight的向量乘
        """
        mm_res_gm_single_row = TensorData("mm_res_gm_single_row", DType.FP32, [1, base_n], MemLoc.GM)
        weight_gm_single_row = TensorData("weight_gm_single_row", DType.FP32, [1, base_n], MemLoc.GM)
        mm2_res_ub_single_row = TensorData("mm2_res_ub_single_row", DType.FP32, [1, base_n], MemLoc.UB)
        mm2_res_ub = TensorData("mm2_res_ub", DType.FP32, [base_g, base_n], MemLoc.UB)

        combo_list = []

        for i in range(base_g):
            # 一个base_g,base_n大小，需要进行base_g次乘法，次次都要pipe, NEXT: 确认是否需要pipe_barrier
            combo_list.append(
                VectorBasicOp(VecOpType.VMULS, [mm_res_gm_single_row, weight_gm_single_row], [mm2_res_ub_single_row]),
            )

        # 更新base_g的reduce sum
        combo_list.append(
            VectorBasicOp(VecOpType.VADD, [mm2_res_ub, mm2_res_ub], [mm2_res_ub]),
        )
        return combo_list

    def __generate_combo(self, max_row_start, max_col_start, tile: Tile, tiling_base_n, top_k, g_param,
                         each_core_process_num):
        """
        根据每个tile的位置，生成不同的计算逻辑
        """
        base_g = tile.rows
        base_n = tile.cols
        s2_index = tile.col_start // tiling_base_n

        mm2_res_ub_div_2 = TensorData("mm2_res_ub", DType.FP32, [base_g // 2, base_n], MemLoc.UB)
        mm2_res_ub_div_4 = TensorData("mm2_res_ub", DType.FP32, [base_g // 4, base_n], MemLoc.UB)
        mm2_res_ub_div_8 = TensorData("mm2_res_ub", DType.FP32, [base_g // 8, base_n], MemLoc.UB)
        mm2_res_ub_div_16 = TensorData("mm2_res_ub", DType.FP32, [base_g // 16, base_n], MemLoc.UB)
        mm2_res_ub_div_32 = TensorData("mm2_res_ub", DType.FP32, [base_g // 32, base_n], MemLoc.UB)
        mm2_reduce_res_ub = TensorData("mm2_reduce_res_ub", DType.FP32, [1, base_n], MemLoc.UB)
        merge_sort_tensor = TensorData("merge_sort_tensor", DType.FP32, [top_k], MemLoc.UB)
        combo_list = []
        # 如果是当前列的最后一个块
        if tile.row_start == max_row_start:
            self.cnt += 1
            for _ in range(each_core_process_num):
                for _ in range(g_param // base_g):
                    # QK_result * weight
                    combo_list.extend(self.__generate_combo_weight_mm(base_g, base_n))
                    # ReduceSum
                    combo_list.extend(
                        [
                            VectorBasicOp(VecOpType.VADD, [mm2_res_ub_div_2, mm2_res_ub_div_2], [mm2_res_ub_div_2]),
                            VectorBasicOp(VecOpType.VADD, [mm2_res_ub_div_4, mm2_res_ub_div_4], [mm2_res_ub_div_4]),
                            VectorBasicOp(VecOpType.VADD, [mm2_res_ub_div_8, mm2_res_ub_div_8], [mm2_res_ub_div_8]),
                            VectorBasicOp(VecOpType.VADD, [mm2_res_ub_div_16, mm2_res_ub_div_16], [mm2_res_ub_div_16]),
                            VectorBasicOp(VecOpType.VADD, [mm2_res_ub_div_32, mm2_res_ub_div_32], [mm2_res_ub_div_32]),
                            VectorBasicOp(VecOpType.VADDS, [mm2_res_ub_div_32], [mm2_res_ub_div_32]),
                        ]
                    )
                    combo_list.append(
                        VectorBasicOp(VecOpType.VADDS, [mm2_reduce_res_ub], [mm2_reduce_res_ub]))

                combo_list.extend(self.__generate_combo_merge_sort(base_n, s2_index, top_k))

        # 如果计算完了，mask+搬出
        if tile.col_start == max_col_start:
            mask_result_gm = TensorData("mask_result_gm", DType.FP16, [top_k], MemLoc.GM)
            combo_list.append(VectorBasicOp(VecOpType.MOVEV, [merge_sort_tensor], [mask_result_gm]))

        return combo_list

    def __generate_combo_merge_sort(self, base_n, s2_index, top_k):
        """生成merge sort相关的运算逻辑"""
        sort_input = TensorData("sort_input", DType.FP32, [1, base_n * 2], MemLoc.UB)
        merge_sort_input = TensorData("merge_sort_input", DType.FP32, [top_k // base_n, base_n * 2], MemLoc.UB)

        combo_list = []
        # T.sort包含一个sort和两个merge_sort
        combo_list.extend([
            VectorBasicOp(VecOpType.VBS32, [sort_input], [sort_input]),
            # NEXT: merge_sort输入总数据量虽然不变，但是列表长度在变化
            VectorBasicOp(VecOpType.VMS4V2, [sort_input], [sort_input]),
            VectorBasicOp(VecOpType.VMS4V2, [sort_input], [sort_input])])

        # 每top_k_merge_times merge sort一次
        top_k_merge_times = top_k // base_n
        if s2_index % top_k_merge_times == top_k_merge_times - 1:
            combo_list.append(VectorBasicOp(VecOpType.VMS4V2, [merge_sort_input], [merge_sort_input]))
            if s2_index == top_k_merge_times - 1:
                combo_list.append(
                    VectorBasicOp(VecOpType.VMS4V2, [merge_sort_input], [merge_sort_input, merge_sort_input]))
        return combo_list

    def __generate_sections(self, tiling_param: list[TilingParam], T, S2, G, N2, D):

        # 合并成大的矩阵乘 = [T*G,D]*[D,S2*N2]
        sec_qk = Section(bias=0,
                         core_type=CoreType.AIC,
                         m=T * G,
                         k=D,
                         n=S2 * N2,
                         tiling_param=tiling_param[0],
                         input_precision=self.input_precision,
                         output_precision=self.output_precision
                         )

        sec_vec = Section(bias=1,
                          core_type=CoreType.AIV,
                          m=T * G,
                          k=0,
                          n=S2 * N2,
                          tiling_param=tiling_param[1],
                          input_precision=self.input_precision,
                          output_precision=self.output_precision)

        self.section_list = [sec_qk, sec_vec]

    def __generate_tiles(self):
        """
        分section生成tile
        """
        tiling = CatlassTiling()
        for section in self.section_list:
            tiles = tiling.generate_tiles(section)
            section.input_tiles = tiles[0]
            section.output_tiles = tiles[1]

    def time_predict(self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel, ) -> dict[
        ResultKey, float]:
        """
        在B维度上分了不同的核
        B S1 S2 G N2 D topK
        """
        # 对于[[4096, 64, 128], [1254, 128, 1, 128], [4096, 64], [2], [2], [2, 64]]这样的输入，
        # 其格式为TND、[block_count, block_size, N2, D]、[T,N1]、B、B、[B, >=maxBlockNumPerSeq]
        # NEXT -- 此处S2取的可能不对
        if self.layout is not None:
            # 常见 'layout': {'input':{'q':['t','n','d'],'weights':['t','n'],'index_kv':['b','s','d']},'output':{'result':['t','k']}
            q_layout = self.layout['input']['q']
            weights_layout = self.layout['input']['weights']
            index_kv_layout = self.layout['input']['index_kv']
            result_layout = self.layout['output']['result']
            B = shapes[2][index_kv_layout.index('b')]
            S1 = shapes[0][q_layout.index('t')] // B
            S2 = self.kv_len
            N1 = shapes[0][q_layout.index('n')]
            N2 = 1
            D = shapes[0][q_layout.index('d')]
        else:
            if len(shapes) != 6:
                raise ValueError("LightningIndexer input size must be 6")
            B = shapes[3][0]
            S1 = self.q_len if self.q_len is not None else shapes[0][0] // B
            S2 = self.kv_len if self.kv_len is not None else shapes[1][0]
            N1 = shapes[0][1]
            N2 = shapes[1][2]
            D = shapes[0][2]
        top_k = self.k
        G = N1 // N2

        base_n = tiling_param[1].n1

        # 实际使用AIC核数为B*N2，AIV核数=AIC核数*2
        self.__generate_sections(tiling_param, S1 * B, S2, G, N2, D)
        self.__generate_tiles()

        vec_tiles = self.section_list[1].input_tiles

        max_row_start = max([t.row_start for t in vec_tiles])
        max_col_start = max([t.col_start for t in vec_tiles])
        vec_each_core_process_num = N2 * S1 // 2

        # 设定calc combo
        for tile in vec_tiles:
            tile.fused_op = self.__generate_combo(max_row_start, max_col_start, tile, base_n, top_k, G,
                                                  vec_each_core_process_num)

        # 计算CV并行时间
        inter_core_pipe = InterCorePipeline(self.section_list, aicore)
        res = inter_core_pipe.calculate_sections_time()

        return res