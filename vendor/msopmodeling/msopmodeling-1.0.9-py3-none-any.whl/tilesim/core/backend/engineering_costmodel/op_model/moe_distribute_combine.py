# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.common.entity import CoreType, VecOpType, DType, ResultKey, Section, TensorData, MemLoc
from core.backend.engineering_costmodel.core.pipeline.aiv_pipeline import AIVPipeline
from core.backend.engineering_costmodel.core.tiling_and_core_split.catlass_tiling import CatlassTiling
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.core.vector_op import VectorBasicOp
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel


class MoeDistributeCombine(BasicOperatorModel):
    def __init__(self, input_precision: DType, output_precision: DType, **kwargs):
        super().__init__("MoeDistributeCombine", CoreType.AIV, input_precision, output_precision)
        # 相比Dispatch算子，Combine去掉了量化操作，交换了卡间通信的发送方和接收方（通信量不变），并且在最后多了Mul和Add操作
        # 对于输入shape [[4096, 4096], [1, 6], [524288], [256], [1, 6], [1]]，格式为[max(tpWorldSize, 1) * A , H],
        # [Bs, K], [A * 128], [epWorldSize * max(tpWorldSize, 1) * localExpertNum], [Bs, K] 和 [Bs]
        # 其中第6个输入若不存在，则说明无TP域通信
        row, col = 'row', 'col'
        input_x1 = TensorData("input_x1", DType.FP16, [row, col], MemLoc.GM)
        output_x1 = TensorData("output_x1", DType.FP16, [row, col], MemLoc.SHM)

        input_x1_ub = TensorData("input_x1_ub", DType.INT8, [row, col], MemLoc.UB)
        x_out = TensorData("x_out", DType.INT8, [row, col], MemLoc.GM)

        comb = [
            VectorBasicOp(VecOpType.NULL_OP, [input_x1], [output_x1], pipe_barrier=False),
            VectorBasicOp(VecOpType.VMUL, [input_x1_ub], [input_x1_ub]),
            VectorBasicOp(VecOpType.VADD, [input_x1_ub], [x_out])  # NEXT -- 每张卡上的token数量不一样，导致这边操作数也不一样
        ]
        self.op = comb
        self.row = row
        self.col = col

    def get_tiling_strategy(self, input_shapes):
        rows = input_shapes[0][1]
        cols = input_shapes[1][1]
        return [TilingParam(0, 0, 0, rows, cols, 0, 0, 1, 48, swizzle_offset=0, swizzle_direction=0)]

    def time_predict(self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel) -> dict[
        ResultKey, float]:
        rows = shapes[0][1]
        cols = shapes[1][1]
        # tiling&分核
        section = Section(0, CoreType.AIV, rows, 0, cols, tiling_param[0], self.input_precision, self.output_precision)
        tiling = CatlassTiling()
        input_tiles, output_tiles = tiling.generate_tiles(section)
        for tile in input_tiles:
            tile.fused_op = self.op
            shape_dict = {
                self.row: tile.rows,
                self.col: tile.cols
            }
            tile.shape_dict = shape_dict
        aiv_pipe = AIVPipeline(aicore, tiling_param[0])
        core_set = {tile.core for tile in input_tiles}
        size_by_core = {core: sum([t.size for t in input_tiles if t.core == core]) for core in core_set}
        max_size_core = max(size_by_core.items(), key=lambda x: x[1])[0]
        input_tiles = [tile for tile in input_tiles if tile.core == max_size_core]
        return aiv_pipe.calculate_time(input_tiles, output_tiles)