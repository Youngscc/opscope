from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.common.entity import CoreType, VecOpType, DType, ResultKey, Section, TensorData, MemLoc
from core.backend.engineering_costmodel.core.pipeline.aiv_pipeline import AIVPipeline
from core.backend.engineering_costmodel.core.tiling_and_core_split.catlass_tiling import CatlassTiling
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.core.vector_op import VectorBasicOp
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel


class MoeDispatchDispatch(BasicOperatorModel):
    def __init__(self, input_precision: DType, output_precision: DType, **kwargs):
        super().__init__("MoeDispatchDispatch", CoreType.AIV, input_precision, output_precision)
        #  910B1有24*2=48个AIV核，入参为[28,7168] [28,8] [28]   token数=28，topk=8,H=7168,

        # 代码流程（数据量：28*（8+1）*7168*2B=3612672B, 等于3.4453125MB
        # 1、Init ，初始化，通信算子内部数据结构初始化
        # 2、AlltoAllDispatch 
        #    2.1（计算）、计算SHM地址、遍历expertIds，计算通信数据在对端SHM的地址偏移
        #    2.2（搬运）、GMtoUB， 将Token数据从GM搬运到UB
        #    2.3（计算）、UB内数据量化FP16→Int8
        #    2.4（搬运）、UBtoSHM， 将Token数据从UB发送到其它NPU卡的SHM（HCCS物理带宽196GB/s）
        # 3、SetStatus
        #    3.1、核间同步， 单NPU卡的AIV核间同步，确保所有核负责的数据都已发送完成  
        #    3.2、写远端flag + count， 通知其它NPU卡Token个数，并设置token传输完成标志
        # 4、WaitDispatch 
        #    4.1、读本地flag + count， 轮询完成标志  
        #    4.2、核间同步， 单NPU卡的AIV核间同步，确保所有NPU卡的完成标志都已收到
        # 5、LocalWindowCopy 
        #    5.1、（计算）计算输出地址， 计算通信数据在输出BUF的地址偏移  
        #    5.2、（搬运）SHMtoGM， 输出Token矩阵，供MoE矩阵计算算子使用
        row, col = 'row', 'col'
        input_x1 = TensorData("input_x1", DType.FP16, [row, col], MemLoc.GM)
        output_x1 = TensorData("output_x1", DType.FP16, [row, col], MemLoc.SHM)
        output_x1_quant = TensorData("output_x1_quant", DType.INT8, [row, col], MemLoc.SHM)

        input_dup_x1 = TensorData("input_dup_x1", DType.INT8, [row, col], MemLoc.UB)
        output_dup = TensorData("output_dup", DType.INT8, [row, col], MemLoc.GM)
        if output_precision == DType.INT8:
            comb = [
                VectorBasicOp(VecOpType.VMULS, [input_x1], [output_x1_quant], pipe_barrier=False),  # 量化操作，可选
            ]
        else:
            comb = [
                VectorBasicOp(VecOpType.NULL_OP, [input_x1], [output_x1], pipe_barrier=False)
            ]
        comb.append(VectorBasicOp(VecOpType.VECTOR_DUP, [input_dup_x1], [output_dup]))
        self.moe_distribute_dispatch = comb
        self.row = row
        self.col = col

    def get_tiling_strategy(self, input_shapes):
        rows = 1
        for i in range(len(input_shapes[0]) - 2):
            rows *= input_shapes[0][i]
        rows *= input_shapes[1][-1]
        cols = input_shapes[0][-1]
        return [TilingParam(0, 0, 0, rows, cols, 0, 0, 1, 48, swizzle_offset=0, swizzle_direction=0)]

    def time_predict(self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel) -> dict[
        ResultKey, float]:
        rows = 1
        for i in range(len(shapes[0]) - 2):
            rows *= shapes[0][i]
        rows *= shapes[1][-1]
        cols = shapes[0][-1]
        # tiling&分核
        section = Section(0, CoreType.AIV, rows, 0, cols, tiling_param[0], self.input_precision, self.output_precision)
        tiling = CatlassTiling()
        input_tiles, output_tiles = tiling.generate_tiles(section)
        for tile in input_tiles:
            tile.fused_op = self.moe_distribute_dispatch
            shape_dict = {
                self.row: tile.rows,
                self.col: tile.cols
            }
            tile.shape_dict = shape_dict
        aiv_pipe = AIVPipeline(aicore, tiling_param[0])
        core_set = {tile.core for tile in input_tiles}
        size_by_core = {core: sum([t.size for t in input_tiles if t.core == core]) for core in core_set}
        max_size_core = max(size_by_core.items(), key=lambda x: x[1])[0]
        input_tiles = [tile for tile in input_tiles if tile.core == max_size_core]
        return aiv_pipe.calculate_time(input_tiles, output_tiles)