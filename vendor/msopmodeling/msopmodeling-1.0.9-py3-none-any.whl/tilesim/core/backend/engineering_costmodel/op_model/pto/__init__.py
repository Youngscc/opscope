import importlib
import importlib.util
from functools import lru_cache
from pathlib import Path

from core.backend.engineering_costmodel.op_model.pto.cce_kernel_ir_compute import compute_kernel_ir


def model_compute_wrapper(func):
    def wrapper(*args, **kwargs):
        res = compute_kernel_ir(func(*args, **kwargs))
        return res

    return wrapper


@lru_cache(maxsize=None)
def map_instr_impl(function_name: str, version: str = 'v220', impl_suffix: bool = True):
    """
    在当前模块的 {version} 子目录下所有 .py 文件中查找名为 function_name 的顶层函数。

    Args:
        function_name: 函数名
        version: 子目录名，如 'v300', 'v220'
        impl_suffix: 是否在函数名后加 "_IMPL"

    Returns:
        cycles

    """
    if impl_suffix:
        target_name = function_name + "_IMPL"
    else:
        target_name = function_name

    # 获取当前模块所在目录
    current_pkg_path = Path(__file__).parent
    version_dir = current_pkg_path / version

    if not version_dir.exists() or not version_dir.is_dir():
        raise NotImplementedError(f"Version directory '{version}' does not exist under {current_pkg_path}")

    # 遍历所有 .py 文件
    for py_file in version_dir.glob("*.py"):

        module_name = f"{__name__}.{version}.{py_file.stem}"

        if (version_dir / "__init__.py").exists():
            submodule = importlib.import_module(module_name)
        else:
            spec = importlib.util.spec_from_file_location(module_name, py_file)
            if spec is None or spec.loader is None:
                continue
            submodule = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(submodule)

        func = getattr(submodule, target_name, None)
        if callable(func):
            return model_compute_wrapper(func)

    raise NotImplementedError(f"Function '{target_name}' is not found in any .py file under '{version}'")


def tadd(version, dst, src0, src1):
    return map_instr_impl("TADD", version)(dst, src0, src1)


def tsub(version, dst, src0, src1):
    return map_instr_impl("TSUB", version)(dst, src0, src1)


def tmul(version, dst, src0, src1):
    return map_instr_impl("TMUL", version)(dst, src0, src1)


def tmin(version, dst, src0, src1):
    return map_instr_impl("TMIN", version)(dst, src0, src1)


def tmax(version, dst, src0, src1):
    return map_instr_impl("TMIN", version)(dst, src0, src1)


def tdiv(version, dst, src0, src1):
    return map_instr_impl("TDIV", version)(dst, src0, src1)


def tmuls(version, dst, src0, src1):
    return map_instr_impl("TMULS", version, impl_suffix=False)(dst, src0, src1)


def tmatmul(version, c_matrix, a_matrix, b_matrix):
    return map_instr_impl("TMATMUL", version)(c_matrix, a_matrix, b_matrix)


def tmatmul_acc(version, c_out_matrix, c_in_matrix, a_matrix, b_matrix):
    return map_instr_impl("TMATMUL_ACC", version)(c_out_matrix, c_in_matrix, a_matrix, b_matrix)


def tmatmul_bias(version, c_matrix, a_matrix, b_matrix, bias_matrix):
    return map_instr_impl("TMATMUL_BIAS", version)(c_matrix, a_matrix, bias_matrix)


def tcvt(version, dst, src, mode):
    return map_instr_impl("TCVT", version)(src, dst, mode)


def trowmax(version, dst, src, tmp):
    return map_instr_impl("TROWMAX", version)(dst, src, tmp)


def tcolmax(version, dst, src, tmp, is_binary):
    return map_instr_impl("TCOLMAX", version)(dst, src, tmp, is_binary)


def trowsum(version, dst, src, tmp):
    return map_instr_impl("TROWSUM", version)(dst, src, tmp)


def trsqrt(version, dst, src):
    return map_instr_impl("TRSQRT", version)(dst, src)


def tsqrt(version, dst, src):
    return map_instr_impl("TSQRT", version)(dst, src)


def texp(version, dst, src):
    return map_instr_impl("TEXP", version)(dst, src)
