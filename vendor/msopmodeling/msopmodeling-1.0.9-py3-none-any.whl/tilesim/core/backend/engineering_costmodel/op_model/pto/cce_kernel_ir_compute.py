import logging
import math
from copy import deepcopy

from core.backend.engineering_costmodel.core.ub_bank_conflict.instruction_visualizer import count_bank_conflict
from core.backend.engineering_costmodel.op_model.pto.cce.v220 import call_cce
from core.frontend.ir.core.ir import KernelIR
from core.frontend.ir.core.ir_logistic import OpIR

logger = logging.getLogger(__name__)


def compute_kernel_ir(kernel_ir: KernelIR):
    op_irs = kernel_ir.ops
    op_irs = auto_mask_inference(op_irs)
    pipeline_segments = []
    temp_pipeline = []
    for op_ir in op_irs:  # split pipeline by pipe_barrier (actually pipe_v)
        if op_ir.level == "cce":
            if op_ir.op_code != "pipe_barrier":
                temp_pipeline.append(op_ir)
            else:
                pipeline_segments.append(temp_pipeline)
                temp_pipeline = []
    if temp_pipeline:
        pipeline_segments.append(temp_pipeline)
    total_cycles = 0

    for pipeline_segment in pipeline_segments:
        total_cycles += compute_cycles_in_segment(pipeline_segment)

    return total_cycles


def auto_mask_inference(pipeline: list):
    class Reg:  # register.
        def __init__(self, max_len: int, bits: int = 0):
            self.max_len = max_len
            self.mask = (1 << max_len) - 1
            self.bits = 0
            self.set(bits)

        def set(self, bits: int) -> None:
            self.bits = bits & self.mask

        def get(self) -> int:
            return self.bits

        def __repr__(self):
            return f"Reg(max_len={self.max_len}, bits=0b{self.bits:0{self.max_len}b})"

    def move_mask(reg, bits):
        reg.set(bits)

    mask_reg0 = Reg(128,
                    -1)  # set_mask relative cce instructions will affect vector cycle (although PIPE_S), but I cant infer how much it affected.
    mask_reg1 = Reg(128, -1)
    move_mask1_op_ir = OpIR(level='cce', op_code="movemask1", inputs=[], outputs=[], config={})
    move_mask2_op_ir = OpIR(level='cce', op_code="movemask2", inputs=[], outputs=[], config={})

    ctrl_56 = 0  # 0:norm 1:counter
    new_pipeline = [move_mask1_op_ir, move_mask2_op_ir]  # set_mask_vector(-1,-1) will execute by default.

    for op_ir in pipeline:
        if op_ir.op_code == "set_mask_norm":
            ctrl_56 = 0
            continue
        elif op_ir.op_code == "set_mask_count":
            ctrl_56 = 1
            continue
        elif op_ir.op_code == "set_vector_mask" or op_ir.op_code == "vmask":  # vmask is the alias of set_vector_mask.
            move_mask(mask_reg0, op_ir.config['cce_args'][0])
            move_mask(mask_reg1, op_ir.config['cce_args'][1])
            new_pipeline.append(deepcopy(move_mask1_op_ir))
            new_pipeline.append(deepcopy(move_mask2_op_ir))
            continue

        if 'repeat' in op_ir.config and ctrl_56 == 1:  # counter mode need to indict the repeat times.

            if mask_reg0.get() + mask_reg1.get() == 0:  # counter mode if mask register is 0, then this cce inst will be regard to nop.
                continue
            if 'dst' not in op_ir.config:
                raise Exception(f"dst should be defined for {op_ir.config}")
            elem_nums = mask_reg0.get() + mask_reg1.get()
            elem_bytes = op_ir.config['dst'].dtype.size
            repeat = math.ceil(elem_nums / (8 * 32 / elem_bytes))
            op_ir.config['repeat'] = repeat

        new_pipeline.append(op_ir)
    return new_pipeline


def compute_cycles_in_segment(pipeline_segment: list[OpIR]):
    bank_params = []
    first_no_mask = 0
    for op_ir in pipeline_segment:
        if op_ir.op_code.startswith("movemask"):
            first_no_mask += 1
        else:
            break
    if first_no_mask != len(pipeline_segment):
        segment_cycles, bank_param = call_cce(pipeline_segment[first_no_mask], pipe_barrier=True)
    else:
        segment_cycles, bank_param = 0, None

    if bank_param:
        bank_params.append(bank_param)
    for op_ir in pipeline_segment[:first_no_mask] + pipeline_segment[first_no_mask + 1:]:
        cce_cycle, bank_param = call_cce(op_ir, pipe_barrier=False)
        logger.debug("[Pipeline Segment] cce_name=%s, cce_args=%s", op_ir.op_code, op_ir.config)
        logger.debug("[Pipeline Segment]   - simulated_cce_cycles=%s", cce_cycle)
        segment_cycles += cce_cycle
        if bank_param:
            bank_params.append(bank_param)
    bnk = 0
    if len(bank_params) != 0:
        bnk = count_bank_conflict(bank_params)
        logger.debug(
            f"[Pipeline Segment] Total:total_cycles=%s simulated_cce_cycles=%s simulated_bnk_cycles=%s",
            bnk + segment_cycles, segment_cycles, bnk)

    return segment_cycles + bnk


if __name__ == '__main__':
    from core.common.entity import DType
    from core.backend.engineering_costmodel.op_model.pto.include.pto_utils import CPTOTile, RoundMode

    dst_64x1 = CPTOTile(
        row=64,
        col=1,
        row_stride=8,
        addr="0x18000",
        dtype=DType.FP32,
    )
    dst_64x64 = CPTOTile(
        row=64,
        col=1,
        row_stride=8,
        addr="0x18000",
        dtype=DType.FP32,
    )
    src0_64x64 = CPTOTile(
        row=64,
        col=64,
        row_stride=8,
        addr="0x0000",
        dtype=DType.FP32,
    )
    src1_64x64 = CPTOTile(
        row=64,
        col=64,
        row_stride=8,
        addr="0x8000",
        dtype=DType.FP32,
    )

    from core.backend.engineering_costmodel.op_model.pto import tadd, tmatmul, trowsum, trowmax, tcvt, tsub, tmul, \
        texp, tmuls, tmin


    def _ut(func, *args):
        res = func('v220', *args)
        print(f'func_name={func.__name__}, cycle={res}')


    _ut(tadd, dst_64x64, src0_64x64, src1_64x64)
    _ut(tsub, dst_64x64, src0_64x64, src1_64x64)
    _ut(tmul, dst_64x64, src0_64x64, src1_64x64)
    _ut(tcvt, dst_64x64, src0_64x64, RoundMode.CAST_ROUND)
    _ut(tmatmul, dst_64x64, src0_64x64, src1_64x64)
    _ut(trowsum, dst_64x1, src0_64x64, src1_64x64)
    _ut(trowmax, dst_64x64, src0_64x64, src1_64x64)
    _ut(texp, dst_64x64, src0_64x64)
    _ut(tmuls, dst_64x64, src0_64x64, 1)
    _ut(tmin, dst_64x64, src0_64x64, src1_64x64)