from core.common.entity import DType, Tile, Section, CoreType
from core.backend.engineering_costmodel.op_model.pto.include.pto_utils import CPointer


class PTOTile(Tile):
    def __init__(self, row, col, precision: DType, addr):
        section = Section(
            None,
            CoreType.AIV,
            row, 0, col, None,
            precision, precision
        )
        super().__init__(
            section,
            None, 0, 0,
            row, col,
            None, precision,
            None, None, None
        )
        self.addr = addr
        self.precision = precision

    def get_block_ptr(self):
        return CPointer(self.addr, self.precision)

    def __eq__(self, other):
        if not isinstance(other, PTOTile):
            return False
        return (self.addr == other.addr and
                self.rows == other.rows and
                self.cols == other.cols and
                self.precision == other.precision)

    def __hash__(self):
        hash_keys = [
            self.addr,
            self.precision,
            self.rows,
            self.cols,
        ]
        k = ""
        for key in hash_keys:
            k += f"_{str(key)}"
        return hash(self.addr)