from core.common.entity import DType

int64_t = DType.INT64
int32_t = DType.INT32
int16_t = DType.INT16
int8_t = DType.INT8
uint8_t = DType.UINT8
bfloat16_t = DType.BF16
half = DType.FP16


def is_same(a, b):
    class WrappedBool:
        def __init__(self, bool_value):
            self.value = bool_value

    if isinstance(a, DType):
        if isinstance(b, DType):
            return WrappedBool(a == b)
        elif b == float:
            return WrappedBool(a == DType.FP32)
        elif b == int:
            return WrappedBool(a == DType.INT32)
        else:
            raise NotImplementedError(f"type {type(b)} is not supported in std.is_same(a,b).value")
    else:
        if isinstance(b, DType):
            return is_same(b, a)
        else:
            return WrappedBool(isinstance(a, type(b)))
