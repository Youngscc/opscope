import core.backend.engineering_costmodel.op_model.pto.include.std as std
from core.backend.engineering_costmodel.op_model.pto.include.bisheng_utils import PIPE_V
from core.backend.engineering_costmodel.op_model.pto.include.c_utils import sizeof
from core.backend.engineering_costmodel.op_model.pto.include.pto_const import REPEAT_MAX, REPEAT_STRIDE_MAX, \
    REPEAT_BYTE, BLOCK_BYTE_SIZE
from core.backend.engineering_costmodel.op_model.pto.include.pto_utils import __cce_get_tile_ptr, SetContinuousMask
from core.backend.engineering_costmodel.op_model.pto.include.std import int32_t, int16_t, half
from core.frontend.ir.core.ir import KernelIR
from core.frontend.ir.core.ir_logistic import OpIR


def SDIV(DataType, dst, src0, src1, repeat, dst_block_stride, src_block_stride, dst_repeat_stride, src_repeat_stride,
         kernel_ir):
    if std.is_same(DataType, int32_t).value:
        kernel_ir.add_op(OpIR(level='cce', op_code='vector_dup', inputs=[src1, repeat], outputs=[dst],
                              config={'dst': dst, 'src': src1, 'repeat': repeat, 'dstBlockStride': dst_block_stride,
                                      'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'srcRepeatStride': src_repeat_stride}))
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s322f32', inputs=[dst, repeat], outputs=[dst],
                              config={'dst': dst, 'src': dst, 'repeat': repeat, 'dstBlockStride': dst_block_stride,
                                      'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'srcRepeatStride': src_repeat_stride}))
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s322f32', inputs=[src0, repeat], outputs=[src0],
                              config={'dst': src0, 'src': src0, 'repeat': repeat, 'dstBlockStride': dst_block_stride,
                                      'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'srcRepeatStride': src_repeat_stride}))
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vdiv', inputs=[dst, src0], outputs=[dst],
                              config={'dst': dst, 'src0': dst, 'src1': src0, 'repeat': repeat,
                                      'dstBlockStride': dst_block_stride, 'src0BlockStride': src_block_stride,
                                      'src1BlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'src0RepeatStride': src_repeat_stride, 'src1RepeatStride': src_repeat_stride}))
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322s32z', inputs=[dst, repeat], outputs=[dst],
                              config={'dst': dst, 'src': dst, 'repeat': repeat, 'dstBlockStride': dst_block_stride,
                                      'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'srcRepeatStride': src_repeat_stride}))
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
    elif std.is_same(DataType, int16_t).value:
        kernel_ir.add_op(OpIR(level='cce', op_code='vector_dup', inputs=[src1, repeat], outputs=[dst],
                              config={'dst': dst, 'src': src1, 'repeat': repeat, 'dstBlockStride': dst_block_stride,
                                      'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'srcRepeatStride': src_repeat_stride}))
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s162f16', inputs=[dst, repeat], outputs=[dst],
                              config={'dst': dst, 'src': dst, 'repeat': repeat, 'dstBlockStride': dst_block_stride,
                                      'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'srcRepeatStride': src_repeat_stride}))
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s162f16', inputs=[src0, repeat], outputs=[src0],
                              config={'dst': src0, 'src': src0, 'repeat': repeat, 'dstBlockStride': dst_block_stride,
                                      'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'srcRepeatStride': src_repeat_stride}))
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vdiv', inputs=[dst, src0], outputs=[dst],
                              config={'dst': dst, 'src0': dst, 'src1': src0, 'repeat': repeat,
                                      'dstBlockStride': dst_block_stride, 'src0BlockStride': src_block_stride,
                                      'src1BlockStride': dst_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'src0RepeatStride': src_repeat_stride, 'src1RepeatStride': dst_repeat_stride}))
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162s16z', inputs=[dst, repeat], outputs=[dst],
                              config={'dst': dst, 'src': dst, 'repeat': repeat, 'dstBlockStride': dst_block_stride,
                                      'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'srcRepeatStride': src_repeat_stride}))
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
    elif std.is_same(DataType, float).value:
        kernel_ir.add_op(OpIR(level='cce', op_code='vector_dup', inputs=[src1, repeat], outputs=[dst],
                              config={'dst': dst, 'src': src1, 'repeat': repeat, 'dstBlockStride': dst_block_stride,
                                      'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'srcRepeatStride': src_repeat_stride}))
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vdiv', inputs=[dst, src0], outputs=[dst],
                              config={'dst': dst, 'src0': dst, 'src1': src0, 'repeat': repeat,
                                      'dstBlockStride': dst_block_stride, 'src0BlockStride': src_block_stride,
                                      'src1BlockStride': dst_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'src0RepeatStride': src_repeat_stride, 'src1RepeatStride': dst_repeat_stride}))
    elif std.is_same(DataType, half).value:
        kernel_ir.add_op(OpIR(level='cce', op_code='vector_dup', inputs=[src1, repeat], outputs=[dst],
                              config={'dst': dst, 'src': src1, 'repeat': repeat, 'dstBlockStride': dst_block_stride,
                                      'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'srcRepeatStride': src_repeat_stride}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vdiv', inputs=[dst, src0], outputs=[dst],
                              config={'dst': dst, 'src0': dst, 'src1': src0, 'repeat': repeat,
                                      'dstBlockStride': dst_block_stride, 'src0BlockStride': src_block_stride,
                                      'src1BlockStride': dst_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'src0RepeatStride': src_repeat_stride, 'src1RepeatStride': dst_repeat_stride}))


def DIVS(DataType, dst, src0, src1, repeat, dst_block_stride, src_block_stride, dst_repeat_stride, src_repeat_stride,
         kernel_ir):
    divider = src1
    if divider != 0:
        divider = 1.0 / divider
    else:
        divider = 1.0 / 0.0
    if std.is_same(DataType, int32_t).value:
        kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s322f32', inputs=[src0, repeat], outputs=[dst],
                              config={'dst': dst, 'src': src0, 'repeat': repeat, 'dstBlockStride': dst_block_stride,
                                      'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'srcRepeatStride': src_repeat_stride}))
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vmuls', inputs=[dst, divider], outputs=[dst],
                              config={'dst': dst, 'src': dst, 'a': divider, 'repeat': repeat,
                                      'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                      'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322s32z', inputs=[dst, repeat], outputs=[dst],
                              config={'dst': dst, 'src': dst, 'repeat': repeat, 'dstBlockStride': dst_block_stride,
                                      'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'srcRepeatStride': src_repeat_stride}))
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
    elif std.is_same(DataType, int16_t).value:
        kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s162f16', inputs=[src0, repeat], outputs=[dst],
                              config={'dst': dst, 'src': src0, 'repeat': repeat, 'dstBlockStride': dst_block_stride,
                                      'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'srcRepeatStride': src_repeat_stride}))
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vmuls', inputs=[dst, divider], outputs=[dst],
                              config={'dst': dst, 'src': dst, 'a': divider, 'repeat': repeat,
                                      'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                      'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162s16z', inputs=[dst, repeat], outputs=[dst],
                              config={'dst': dst, 'src': dst, 'repeat': repeat, 'dstBlockStride': dst_block_stride,
                                      'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'srcRepeatStride': src_repeat_stride}))
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
    elif std.is_same(DataType, half).value:
        kernel_ir.add_op(OpIR(level='cce', op_code='vector_dup', inputs=[src1, repeat], outputs=[dst],
                              config={'dst': dst, 'src': src1, 'repeat': repeat, 'dstBlockStride': dst_block_stride,
                                      'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'srcRepeatStride': src_repeat_stride}))
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vdiv', inputs=[src0, dst], outputs=[dst],
                              config={'dst': dst, 'src0': src0, 'src1': dst, 'repeat': repeat,
                                      'dstBlockStride': dst_block_stride, 'src0BlockStride': src_block_stride,
                                      'src1BlockStride': dst_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'src0RepeatStride': src_repeat_stride, 'src1RepeatStride': dst_repeat_stride}))
    else:
        kernel_ir.add_op(OpIR(level='cce', op_code='vmuls', inputs=[src0, divider], outputs=[dst],
                              config={'dst': dst, 'src': src0, 'a': divider, 'repeat': repeat,
                                      'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                      'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))


def MULS(dst, src0, src1, repeat, dst_block_stride, src_block_stride, dst_repeat_stride, src_repeat_stride, kernel_ir):
    DataType = dst
    kernel_ir.add_op(OpIR(level='cce', op_code='vmuls', inputs=[src0, src1], outputs=[dst],
                          config={'dst': dst, 'src': src0, 'a': src1, 'repeat': repeat,
                                  'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                  'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))


def ADDS(DataType, dst, src0, src1, repeat, dst_block_stride, src_block_stride, dst_repeat_stride, src_repeat_stride,
         kernel_ir):
    kernel_ir.add_op(OpIR(level='cce', op_code='vadds', inputs=[src0, src1], outputs=[dst],
                          config={'dst': dst, 'src': src0, 'a': src1, 'repeat': repeat,
                                  'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                  'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))


def TBinScalar(TileData, elements_per_repeat, block_size_elem, stride, Func, dst, src0, src1, current_func,
               num_repeat_per_line, num_remain_per_line, valid_row, kernel_ir):
    dst_ptr = __cce_get_tile_ptr(dst)
    src0_ptr = __cce_get_tile_ptr(src0)
    if num_repeat_per_line > 0:
        num_loop = num_repeat_per_line // REPEAT_MAX
        remain_after_loop = num_repeat_per_line % REPEAT_MAX
        i = 0
        while i < valid_row:
            if num_loop:
                j = 0
                while j < num_loop:
                    current_func(dst_ptr + i * stride + j * elements_per_repeat * REPEAT_MAX,
                                 src0_ptr + i * stride + j * elements_per_repeat * REPEAT_MAX, src1, REPEAT_MAX, 1, 1,
                                 8, 8, kernel_ir)
                    j += 1
            if remain_after_loop:
                current_func(dst_ptr + i * stride + num_loop * elements_per_repeat * REPEAT_MAX,
                             src0_ptr + i * stride + num_loop * elements_per_repeat * REPEAT_MAX, src1,
                             remain_after_loop, 1, 1, 8, 8, kernel_ir)
            i += 1
    dst_ptr += num_repeat_per_line * elements_per_repeat
    src0_ptr += num_repeat_per_line * elements_per_repeat
    if num_remain_per_line:
        num_loop = valid_row // REPEAT_MAX
        remain_after_loop = valid_row % REPEAT_MAX
        stride_over_flag = stride // block_size_elem > REPEAT_STRIDE_MAX
        SetContinuousMask(num_remain_per_line)
        if num_loop:
            i = 0
            while i < num_loop:
                if stride_over_flag:
                    j = 0
                    while j < REPEAT_MAX:
                        current_func(dst_ptr + i * REPEAT_MAX * stride + j * stride,
                                     src0_ptr + i * REPEAT_MAX * stride + j * stride, src1, 1, 1, 1, 1, 1, kernel_ir)
                        j += 1
                else:
                    current_func(dst_ptr + i * REPEAT_MAX * stride, src0_ptr + i * REPEAT_MAX * stride, src1,
                                 REPEAT_MAX, 1, 1, stride // block_size_elem, stride // block_size_elem, kernel_ir)
                i += 1
        if remain_after_loop:
            if stride_over_flag:
                j = 0
                while j < remain_after_loop:
                    current_func(dst_ptr + num_loop * REPEAT_MAX * stride + j * stride,
                                 src0_ptr + num_loop * REPEAT_MAX * stride + j * stride, src1, 1, 1, 1, 1, 1, kernel_ir)
                    j += 1
            else:
                current_func(dst_ptr + num_loop * REPEAT_MAX * stride, src0_ptr + num_loop * REPEAT_MAX * stride, src1,
                             remain_after_loop, 1, 1, stride // block_size_elem, stride // block_size_elem, kernel_ir)
        kernel_ir.add_op(OpIR(level='cce', op_code='vmask', inputs=[], outputs=[], config={'cce_args': [-1, -1]}))


def TDIVS(dst, src0, scalar, kernel_ir):
    TileData = dst
    block_size_elem = BLOCK_BYTE_SIZE // sizeof(TileData.DType)
    elements_per_repeat = REPEAT_BYTE // sizeof(TileData.DType)
    num_repeat_per_line = dst.GetValidCol() // elements_per_repeat
    num_remain_per_line = dst.GetValidCol() % elements_per_repeat
    stride = TileData.RowStride
    valid_row = dst.GetValidRow()
    func_ptr = DIVS
    TBinScalar(TileData, elements_per_repeat, block_size_elem, stride, func_ptr, dst.data(), src0.data(), scalar, DIVS,
               num_repeat_per_line, num_remain_per_line, valid_row, kernel_ir)


def TADDS(dst, src0, scalar, kernel_ir):
    TileData = dst
    block_size_elem = BLOCK_BYTE_SIZE // sizeof(TileData.DType)
    elements_per_repeat = REPEAT_BYTE // sizeof(TileData.DType)
    num_repeat_per_line = dst.GetValidCol() // elements_per_repeat
    num_remain_per_line = dst.GetValidCol() % elements_per_repeat
    stride = TileData.RowStride
    valid_row = dst.GetValidRow()
    func_ptr = ADDS
    TBinScalar(TileData, elements_per_repeat, block_size_elem, stride, func_ptr, dst.data(), src0.data(), scalar, ADDS,
               num_repeat_per_line, num_remain_per_line, valid_row, kernel_ir)


def TMULS(dst, src0, scalar):
    kernel_ir = KernelIR('pto_tmuls')
    TileData = dst
    block_size_elem = BLOCK_BYTE_SIZE // sizeof(TileData.DType)
    elements_per_repeat = REPEAT_BYTE // sizeof(TileData.DType)
    num_repeat_per_line = dst.GetValidCol() // elements_per_repeat
    num_remain_per_line = dst.GetValidCol() % elements_per_repeat
    stride = TileData.RowStride
    valid_row = dst.GetValidRow()
    func_ptr = MULS
    TBinScalar(TileData, elements_per_repeat, block_size_elem, stride, func_ptr, dst.data(), src0.data(), scalar, MULS,
               num_repeat_per_line, num_remain_per_line, valid_row, kernel_ir)
    return kernel_ir