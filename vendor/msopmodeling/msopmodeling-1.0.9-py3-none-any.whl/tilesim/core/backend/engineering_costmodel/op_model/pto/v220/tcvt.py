from core.backend.engineering_costmodel.op_model.pto.include import std
from core.backend.engineering_costmodel.op_model.pto.include.bisheng_utils import PIPE_V
from core.backend.engineering_costmodel.op_model.pto.include.c_utils import sizeof
from core.backend.engineering_costmodel.op_model.pto.include.pto_const import REPEAT_MAX, REPEAT_BYTE, \
    BLOCK_BYTE_SIZE, BLOCK_MAX_PER_REPEAT
from core.backend.engineering_costmodel.op_model.pto.include.pto_utils import __cce_get_tile_ptr, \
    SetContinuousMask, RoundMode
from core.backend.engineering_costmodel.op_model.pto.include.std import half, int32_t, int64_t, int16_t, \
    bfloat16_t, uint8_t, int8_t
from core.frontend.ir.core.ir import KernelIR
from core.frontend.ir.core.ir_logistic import OpIR


def GenCastCall(TileDataD, TileDataS, dst, src, repeat_num, mode, dst_block_stride, src_block_stride, dst_repeat_stride,
                src_repeat_stride, kernel_ir):
    if std.is_same(TileDataD.DType, half).value and std.is_same(TileDataS.DType, float).value:
        generated_switch_break_flag = True
        if generated_switch_break_flag and mode == RoundMode.CAST_RINT:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322f16r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_ROUND:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322f16a', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_FLOOR:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322f16f', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_CEIL:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322f16c', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_TRUNC:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322f16z', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_ODD:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322f16o', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_NONE:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322f16', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322f16r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
    elif std.is_same(TileDataD.DType, float).value and std.is_same(TileDataS.DType, float).value:
        generated_switch_break_flag = True
        if generated_switch_break_flag and mode == RoundMode.CAST_RINT:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322f32r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_ROUND:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322f32a', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_FLOOR:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322f32f', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_CEIL:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322f32c', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_TRUNC:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322f32z', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322f32r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
    elif std.is_same(TileDataD.DType, int64_t).value and std.is_same(TileDataS.DType, float).value:
        generated_switch_break_flag = True
        if generated_switch_break_flag and mode == RoundMode.CAST_RINT:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322s64r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_ROUND:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322s64a', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_FLOOR:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322s64f', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_CEIL:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322s64c', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_TRUNC:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322s64z', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322s64r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
    elif std.is_same(TileDataD.DType, int32_t).value and std.is_same(TileDataS.DType, float).value:
        generated_switch_break_flag = True
        if generated_switch_break_flag and mode == RoundMode.CAST_RINT:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322s32r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_ROUND:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322s32a', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_FLOOR:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322s32f', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_CEIL:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322s32c', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_TRUNC:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322s32z', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322s32r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
    elif std.is_same(TileDataD.DType, int16_t).value and std.is_same(TileDataS.DType, float).value:
        generated_switch_break_flag = True
        if generated_switch_break_flag and mode == RoundMode.CAST_RINT:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322s16r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_ROUND:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322s16a', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_FLOOR:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322s16f', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_CEIL:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322s16c', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_TRUNC:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322s16z', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322s16r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
    elif std.is_same(TileDataD.DType, bfloat16_t).value and std.is_same(TileDataS.DType, float).value:
        generated_switch_break_flag = True
        if generated_switch_break_flag and mode == RoundMode.CAST_RINT:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322bf16r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_ROUND:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322bf16a', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_FLOOR:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322bf16f', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_CEIL:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322bf16c', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_TRUNC:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322bf16z', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f322bf16r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
    elif std.is_same(TileDataD.DType, float).value and std.is_same(TileDataS.DType, half).value:
        kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162f32', inputs=[src, repeat_num], outputs=[dst],
                              config={'dst': dst, 'src': src, 'repeat': repeat_num, 'dstBlockStride': dst_block_stride,
                                      'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'srcRepeatStride': src_repeat_stride}))
    elif std.is_same(TileDataD.DType, int32_t).value and std.is_same(TileDataS.DType, half).value:
        generated_switch_break_flag = True
        if generated_switch_break_flag and mode == RoundMode.CAST_RINT:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162s32r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_ROUND:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162s32a', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_FLOOR:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162s32f', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_CEIL:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162s32c', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_TRUNC:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162s32z', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162s32r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
    elif std.is_same(TileDataD.DType, int16_t).value and std.is_same(TileDataS.DType, half).value:
        generated_switch_break_flag = True
        if generated_switch_break_flag and mode == RoundMode.CAST_RINT:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162s16r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_ROUND:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162s16a', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_FLOOR:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162s16f', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_CEIL:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162s16c', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_TRUNC:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162s16z', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162s16r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
    elif std.is_same(TileDataD.DType, int8_t).value and std.is_same(TileDataS.DType, half).value:
        generated_switch_break_flag = True
        if generated_switch_break_flag and mode == RoundMode.CAST_RINT:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162s8r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_ROUND:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162s8a', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_FLOOR:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162s8f', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_CEIL:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162s8c', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_TRUNC:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162s8z', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_NONE:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162s8', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162s8r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
    elif std.is_same(TileDataD.DType, uint8_t).value and std.is_same(TileDataS.DType, half).value:
        generated_switch_break_flag = True
        if generated_switch_break_flag and mode == RoundMode.CAST_RINT:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162u8r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_ROUND:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162u8a', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_FLOOR:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162u8f', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_CEIL:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162u8c', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_TRUNC:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162u8z', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_NONE:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162u8', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_f162u8r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
    elif std.is_same(TileDataD.DType, float).value and std.is_same(TileDataS.DType, bfloat16_t).value:
        kernel_ir.add_op(OpIR(level='cce', op_code='vconv_bf162f32', inputs=[src, repeat_num], outputs=[dst],
                              config={'dst': dst, 'src': src, 'repeat': repeat_num, 'dstBlockStride': dst_block_stride,
                                      'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'srcRepeatStride': src_repeat_stride}))
    elif std.is_same(TileDataD.DType, int32_t).value and std.is_same(TileDataS.DType, bfloat16_t).value:
        generated_switch_break_flag = True
        if generated_switch_break_flag and mode == RoundMode.CAST_RINT:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_bf162s32r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_ROUND:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_bf162s32a', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_FLOOR:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_bf162s32f', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_CEIL:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_bf162s32c', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_TRUNC:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_bf162s32z', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_NONE:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_bf162s32', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_bf162s32r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
    elif std.is_same(TileDataD.DType, half).value and std.is_same(TileDataS.DType, uint8_t).value:
        kernel_ir.add_op(OpIR(level='cce', op_code='vconv_u82f16', inputs=[src, repeat_num], outputs=[dst],
                              config={'dst': dst, 'src': src, 'repeat': repeat_num, 'dstBlockStride': dst_block_stride,
                                      'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'srcRepeatStride': src_repeat_stride}))
    elif std.is_same(TileDataD.DType, half).value and std.is_same(TileDataS.DType, int8_t).value:
        kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s82f16', inputs=[src, repeat_num], outputs=[dst],
                              config={'dst': dst, 'src': src, 'repeat': repeat_num, 'dstBlockStride': dst_block_stride,
                                      'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'srcRepeatStride': src_repeat_stride}))
    elif std.is_same(TileDataD.DType, float).value and std.is_same(TileDataS.DType, int16_t).value:
        kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s162f32', inputs=[src, repeat_num], outputs=[dst],
                              config={'dst': dst, 'src': src, 'repeat': repeat_num, 'dstBlockStride': dst_block_stride,
                                      'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'srcRepeatStride': src_repeat_stride}))
    elif std.is_same(TileDataD.DType, half).value and std.is_same(TileDataS.DType, int16_t).value:
        generated_switch_break_flag = True
        if generated_switch_break_flag and mode == RoundMode.CAST_RINT:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s162f16r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_ROUND:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s162f16a', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_FLOOR:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s162f16f', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_CEIL:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s162f16c', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_TRUNC:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s162f16z', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_NONE:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s162f16', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s162f16r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
    elif std.is_same(TileDataD.DType, float).value and std.is_same(TileDataS.DType, int32_t).value:
        generated_switch_break_flag = True
        if generated_switch_break_flag and mode == RoundMode.CAST_RINT:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s322f32r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_ROUND:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s322f32a', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_FLOOR:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s322f32f', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_CEIL:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s322f32c', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_TRUNC:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s322f32z', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_NONE:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s322f32', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s322f32r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
    elif std.is_same(TileDataD.DType, int64_t).value and std.is_same(TileDataS.DType, int32_t).value:
        kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s322s64', inputs=[src, repeat_num], outputs=[dst],
                              config={'dst': dst, 'src': src, 'repeat': repeat_num, 'dstBlockStride': dst_block_stride,
                                      'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'srcRepeatStride': src_repeat_stride}))
    elif std.is_same(TileDataD.DType, int16_t).value and std.is_same(TileDataS.DType, int32_t).value:
        kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s322s16', inputs=[src, repeat_num], outputs=[dst],
                              config={'dst': dst, 'src': src, 'repeat': repeat_num, 'dstBlockStride': dst_block_stride,
                                      'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'srcRepeatStride': src_repeat_stride}))
    elif std.is_same(TileDataD.DType, half).value and std.is_same(TileDataS.DType, int32_t).value:
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vconv_deq', inputs=[src, repeat_num], outputs=[dst],
                              config={'dst': dst, 'src': src, 'repeat': repeat_num, 'dstBlockStride': dst_block_stride,
                                      'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'srcRepeatStride': src_repeat_stride}))
    elif std.is_same(TileDataD.DType, float).value and std.is_same(TileDataS.DType, int64_t).value:
        generated_switch_break_flag = True
        if generated_switch_break_flag and mode == RoundMode.CAST_RINT:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s642f32r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_ROUND:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s642f32a', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_FLOOR:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s642f32f', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_CEIL:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s642f32c', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag and mode == RoundMode.CAST_TRUNC:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s642f32z', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
            generated_switch_break_flag = False
        if generated_switch_break_flag:
            kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s642f32r', inputs=[src, repeat_num], outputs=[dst],
                                  config={'dst': dst, 'src': src, 'repeat': repeat_num,
                                          'dstBlockStride': dst_block_stride, 'srcBlockStride': src_block_stride,
                                          'dstRepeatStride': dst_repeat_stride, 'srcRepeatStride': src_repeat_stride}))
    elif std.is_same(TileDataD.DType, int32_t).value and std.is_same(TileDataS.DType, int64_t).value:
        kernel_ir.add_op(OpIR(level='cce', op_code='vconv_s642s32', inputs=[src, repeat_num], outputs=[dst],
                              config={'dst': dst, 'src': src, 'repeat': repeat_num, 'dstBlockStride': dst_block_stride,
                                      'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                      'srcRepeatStride': src_repeat_stride}))


def TCvt(TileDataD, TileDataS, SS, DS, dst, src, mode, num_repeat_per_line, num_remain_per_line, valid_row,
         elements_per_repeat, dst_repeat_stride, src_repeat_stride, kernel_ir):
    dst_ptr = __cce_get_tile_ptr(dst)
    src_ptr = __cce_get_tile_ptr(src)
    dst_nelem_per_block = BLOCK_BYTE_SIZE // sizeof(TileDataD.DType)
    src_nelem_per_block = BLOCK_BYTE_SIZE // sizeof(TileDataS.DType)
    if num_repeat_per_line > 0:
        num_loop = num_repeat_per_line // REPEAT_MAX
        remain_after_loop = num_repeat_per_line % REPEAT_MAX
        i = 0
        while i < valid_row:
            if num_loop:
                j = 0
                while j < num_loop:
                    GenCastCall(TileDataD, TileDataS, dst_ptr + i * DS + j * elements_per_repeat * REPEAT_MAX,
                                src_ptr + i * SS + j * elements_per_repeat * REPEAT_MAX, REPEAT_MAX, mode, 1, 1,
                                dst_repeat_stride, src_repeat_stride, kernel_ir)
                    j += 1
            if remain_after_loop:
                GenCastCall(TileDataD, TileDataS, dst_ptr + i * DS + num_loop * elements_per_repeat * REPEAT_MAX,
                            src_ptr + i * SS + num_loop * elements_per_repeat * REPEAT_MAX, remain_after_loop, mode, 1,
                            1, dst_repeat_stride, src_repeat_stride, kernel_ir)
            i += 1
    dst_ptr += num_repeat_per_line * elements_per_repeat
    src_ptr += num_repeat_per_line * elements_per_repeat
    if num_remain_per_line:
        num_loop = valid_row // REPEAT_MAX
        remain_after_loop = valid_row % REPEAT_MAX
        SetContinuousMask(num_remain_per_line)
        if num_loop:
            j = 0
            while j < num_loop:
                GenCastCall(TileDataD, TileDataS, dst_ptr + j * DS * REPEAT_MAX, src_ptr + j * SS * REPEAT_MAX,
                            REPEAT_MAX, mode, 1, 1, DS // dst_nelem_per_block, SS // src_nelem_per_block, kernel_ir)
                j += 1
        if remain_after_loop:
            GenCastCall(TileDataD, TileDataS, dst_ptr + num_loop * DS * REPEAT_MAX,
                        src_ptr + num_loop * SS * REPEAT_MAX, remain_after_loop, mode, 1, 1, DS // dst_nelem_per_block,
                        SS // src_nelem_per_block, kernel_ir)
        kernel_ir.add_op(OpIR(level='cce', op_code='vmask', inputs=[], outputs=[], config={'cce_args': [-1, -1]}))


def TCVT_IMPL(dst, src, mode):
    TileDataD = dst
    TileDataS = src
    kernel_ir = KernelIR('pto_tcvt')
    repeat_width = max(sizeof(TileDataD.DType), sizeof(TileDataS.DType))
    dst_repeat_stride = BLOCK_MAX_PER_REPEAT if repeat_width == sizeof(
        TileDataD.DType) else BLOCK_MAX_PER_REPEAT // sizeof(TileDataS.DType) * sizeof(TileDataD.DType)
    src_repeat_stride = BLOCK_MAX_PER_REPEAT if repeat_width == sizeof(
        TileDataS.DType) else BLOCK_MAX_PER_REPEAT // sizeof(TileDataD.DType) * sizeof(TileDataS.DType)
    elements_per_repeat = REPEAT_BYTE // repeat_width
    num_repeat_per_line = dst.GetValidCol() // elements_per_repeat
    num_remain_per_line = dst.GetValidCol() % elements_per_repeat
    SS = TileDataS.RowStride
    DS = TileDataD.RowStride
    valid_row = dst.GetValidRow()
    TCvt(TileDataD, TileDataS, SS, DS, dst.data(), src.data(), mode, num_repeat_per_line, num_remain_per_line,
         valid_row, elements_per_repeat, dst_repeat_stride, src_repeat_stride, kernel_ir)
    return kernel_ir