from core.backend.engineering_costmodel.op_model.pto.include.bisheng_utils import PIPE_V, ONLY_VALUE
from core.backend.engineering_costmodel.op_model.pto.include.c_utils import sizeof
from core.backend.engineering_costmodel.op_model.pto.include.pto_const import REPEAT_MAX, REPEAT_BYTE, \
    BLOCK_BYTE_SIZE, BLOCK_MAX_PER_REPEAT
from core.backend.engineering_costmodel.op_model.pto.include.pto_utils import __cce_get_tile_ptr, \
    SetContinuousMask
from core.frontend.ir.core.ir import KernelIR
from core.frontend.ir.core.ir_logistic import OpIR


def VcmaxByMode(T, cnt_mode_en, cols, dst_repeat_stride, src_repeat_stride, n_elem_per_repeat, dst, src, repeat_times,
                kernel_ir):
    if dst_repeat_stride > 65535 or src_repeat_stride > 65535:
        i = 0
        while i < repeat_times:
            kernel_ir.add_op(
                OpIR(level='cce', op_code='vcmax', inputs=[src + i * cols], outputs=[dst + i * dst_repeat_stride],
                     config={'dst': dst + i * dst_repeat_stride, 'src': src + i * cols, 'repeat': 1,
                             'srcBlockStride': 0, 'dstRepeatStride': 1, 'srcRepeatStride': 0, 'Order_t': ONLY_VALUE}))
            i += 1
    elif cnt_mode_en:
        kernel_ir.add_op(OpIR(level='cce', op_code='set_mask_count', inputs=[], outputs=[], config={}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vmask', inputs=[], outputs=[],
                              config={'cce_args': [0, repeat_times * n_elem_per_repeat]}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vcmax', inputs=[src], outputs=[dst],
                              config={'dst': dst, 'src': src, 'repeat': 0, 'srcBlockStride': dst_repeat_stride,
                                      'dstRepeatStride': 1, 'srcRepeatStride': src_repeat_stride,
                                      'Order_t': ONLY_VALUE}))
        kernel_ir.add_op(OpIR(level='cce', op_code='set_mask_norm', inputs=[], outputs=[], config={}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vmask', inputs=[], outputs=[], config={'cce_args': [-1, -1]}))
    else:
        kernel_ir.add_op(OpIR(level='cce', op_code='vcmax', inputs=[src], outputs=[dst],
                              config={'dst': dst, 'src': src, 'repeat': repeat_times,
                                      'srcBlockStride': dst_repeat_stride, 'dstRepeatStride': 1,
                                      'srcRepeatStride': src_repeat_stride, 'Order_t': ONLY_VALUE}))


def VmaxByMode(T, cnt_mode_en, dst_cols, src0_cols, src1_cols, dst_repeat_stride, src0_repeat_stride,
               src1_repeat_stride, n_elem_per_repeat, dst, src0, src1, repeat_times, kernel_ir):
    if (dst_repeat_stride > REPEAT_MAX or src0_repeat_stride > REPEAT_MAX) or src1_repeat_stride > REPEAT_MAX:
        i = 0
        while i < repeat_times:
            kernel_ir.add_op(OpIR(level='cce', op_code='vmax', inputs=[src0 + i * src0_cols, src1 + i * src1_cols],
                                  outputs=[dst + i * dst_cols],
                                  config={'dst': dst + i * dst_cols, 'src0': src0 + i * src0_cols,
                                          'src1': src1 + i * src1_cols, 'repeat': 1, 'dstBlockStride': 1,
                                          'src0BlockStride': 1, 'src1BlockStride': 1, 'dstRepeatStride': 0,
                                          'src0RepeatStride': 0, 'src1RepeatStride': 0}))
            i += 1
    elif cnt_mode_en:
        kernel_ir.add_op(OpIR(level='cce', op_code='set_mask_count', inputs=[], outputs=[], config={}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vmask', inputs=[], outputs=[],
                              config={'cce_args': [0, repeat_times * n_elem_per_repeat]}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vmax', inputs=[src0, src1], outputs=[dst],
                              config={'dst': dst, 'src0': src0, 'src1': src1, 'repeat': 0, 'dstBlockStride': 1,
                                      'src0BlockStride': 1, 'src1BlockStride': 1, 'dstRepeatStride': dst_repeat_stride,
                                      'src0RepeatStride': src0_repeat_stride, 'src1RepeatStride': src1_repeat_stride}))
        kernel_ir.add_op(OpIR(level='cce', op_code='set_mask_norm', inputs=[], outputs=[], config={}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vmask', inputs=[], outputs=[], config={'cce_args': [-1, -1]}))
    else:
        kernel_ir.add_op(OpIR(level='cce', op_code='vmax', inputs=[src0, src1], outputs=[dst],
                              config={'dst': dst, 'src0': src0, 'src1': src1, 'repeat': repeat_times,
                                      'dstBlockStride': 1, 'src0BlockStride': 1, 'src1BlockStride': 1,
                                      'dstRepeatStride': dst_repeat_stride, 'src0RepeatStride': src0_repeat_stride,
                                      'src1RepeatStride': src1_repeat_stride}))


def TRowMax(T, TileDataOut, TileDataIn, TileDataTmp, n_elem_per_repeat, dst_repeat_stride, src_repeat_stride,
            tmp_repeat_stride, dst_data, src_data, tmp_data, valid_col, valid_row, kernel_ir):
    dst = __cce_get_tile_ptr(dst_data)
    src = __cce_get_tile_ptr(src_data)
    tmp = __cce_get_tile_ptr(tmp_data)
    src_repeat_per_row = valid_col // n_elem_per_repeat
    remain = valid_col % n_elem_per_repeat
    row_repeat_times = valid_row // REPEAT_MAX
    repeat_times = 0
    dst_p = dst
    src_p = src
    tmp_p = tmp
    if valid_col == n_elem_per_repeat:
        VcmaxByMode(T, True, TileDataIn.Cols, dst_repeat_stride, src_repeat_stride, n_elem_per_repeat, dst, src,
                    valid_row, kernel_ir)
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
        return
    if valid_col < n_elem_per_repeat:
        SetContinuousMask(remain)
        repeat_times = valid_row % REPEAT_MAX if row_repeat_times == 0 else REPEAT_MAX
        VcmaxByMode(T, False, TileDataIn.Cols, dst_repeat_stride, src_repeat_stride, n_elem_per_repeat, dst_p, src_p,
                    repeat_times, kernel_ir)
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
        row_repeat_times -= 1
        dst_p += repeat_times * TileDataOut.Cols
        src_p += repeat_times * TileDataIn.Cols
        tmp_p += repeat_times * TileDataTmp.Cols
        while row_repeat_times >= 0:
            repeat_times = valid_row % REPEAT_MAX if row_repeat_times == 0 else REPEAT_MAX
            VcmaxByMode(T, False, TileDataIn.Cols, dst_repeat_stride, src_repeat_stride, n_elem_per_repeat, dst_p,
                        src_p, repeat_times, kernel_ir)
            kernel_ir.add_op(
                OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
            row_repeat_times -= 1
            dst_p += repeat_times * TileDataOut.Cols
            src_p += repeat_times * TileDataIn.Cols
            tmp_p += repeat_times * TileDataTmp.Cols
        kernel_ir.add_op(OpIR(level='cce', op_code='vmask', inputs=[], outputs=[], config={'cce_args': [-1, -1]}))
        return
    if (
            tmp_repeat_stride >= BLOCK_MAX_PER_REPEAT and src_repeat_stride >= BLOCK_MAX_PER_REPEAT) and valid_col < 2 * n_elem_per_repeat:
        kernel_ir.add_op(OpIR(level='cce', op_code='copy_ubuf_to_ubuf', inputs=[src_p], outputs=[tmp_p],
                              config={'dst': tmp_p, 'src': src_p, 'sid': 0, 'nBurst': valid_row,
                                      'lenBurst': BLOCK_MAX_PER_REPEAT,
                                      'srcGap': src_repeat_stride - BLOCK_MAX_PER_REPEAT,
                                      'dstGap': tmp_repeat_stride - BLOCK_MAX_PER_REPEAT}))
    else:
        VmaxByMode(T, True, TileDataTmp.Cols, TileDataIn.Cols, TileDataIn.Cols, tmp_repeat_stride, src_repeat_stride,
                   src_repeat_stride, n_elem_per_repeat, tmp_p, src_p, src_p + n_elem_per_repeat, valid_row, kernel_ir)
    kernel_ir.add_op(OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
    i = 2
    while i < src_repeat_per_row:
        VmaxByMode(T, True, TileDataTmp.Cols, TileDataIn.Cols, TileDataTmp.Cols, tmp_repeat_stride, src_repeat_stride,
                   tmp_repeat_stride, n_elem_per_repeat, tmp_p, src_p + i * n_elem_per_repeat, tmp_p, valid_row,
                   kernel_ir)
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
        i += 1
    if remain > 0:
        SetContinuousMask(remain)
        VmaxByMode(T, False, TileDataTmp.Cols, TileDataIn.Cols, TileDataTmp.Cols, tmp_repeat_stride, src_repeat_stride,
                   tmp_repeat_stride, n_elem_per_repeat, tmp_p, src_p + src_repeat_per_row * n_elem_per_repeat, tmp_p,
                   valid_row, kernel_ir)
        kernel_ir.add_op(OpIR(level='cce', op_code='vmask', inputs=[], outputs=[], config={'cce_args': [-1, -1]}))
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
    VcmaxByMode(T, True, TileDataTmp.Cols, dst_repeat_stride, tmp_repeat_stride, n_elem_per_repeat, dst_p, tmp_p,
                valid_row, kernel_ir)
    kernel_ir.add_op(OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))


def TROWMAX_IMPL(dst, src, tmp):
    TileDataOut, TileDataIn, TileDataTmp = dst, src, tmp
    kernel_ir = KernelIR('pto_trowmax')
    T = TileDataIn.DType
    src_valid_col = src.GetValidCol()
    src_valid_row = src.GetValidRow()
    dst_valid_col = dst.GetValidCol()
    dst_valid_row = dst.GetValidRow()
    n_elem_per_block = BLOCK_BYTE_SIZE // sizeof(T)
    n_elem_per_repeat = REPEAT_BYTE // sizeof(T)
    dst_repeat_stride = TileDataOut.Cols
    src_repeat_stride = TileDataIn.Cols // n_elem_per_block
    tmp_repeat_stride = TileDataTmp.Cols // n_elem_per_block
    if ((src_valid_row == 0 or src_valid_col == 0) or dst_valid_col == 0) or dst_valid_row == 0:
        return
    TRowMax(T, TileDataOut, TileDataIn, TileDataTmp, n_elem_per_repeat, dst_repeat_stride, src_repeat_stride,
            tmp_repeat_stride, dst.data(), src.data(), tmp.data(), src_valid_col, src_valid_row, kernel_ir)
    return kernel_ir