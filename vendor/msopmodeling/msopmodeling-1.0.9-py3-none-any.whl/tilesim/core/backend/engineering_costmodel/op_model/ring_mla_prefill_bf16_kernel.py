# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.common.entity import DType, CoreType, ResultKey
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.op_model.fused_infer_attention import FlashAttentionInner, Layout
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel


class RINGMLAPrefillBF16Kernel(BasicOperatorModel):

    def __init__(self,
                 input_precision: DType,
                 output_precision: DType,
                 layout: str = "RINGMLA_TND",
                 param: list = None,
                 triu: bool = True,
                 **kwargs
                 ):
        super().__init__("RINGMLAPrefillBF16Kernel", CoreType.MIX, input_precision, output_precision)
        self.fa = FlashAttentionInner(
            input_precision=input_precision,
            output_precision=output_precision,
            layout=layout,
            param=param,
            triu=triu
        )
        self.layout = Layout(layout)

    def time_predict(
            self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel
    ) -> dict[ResultKey, float]:
        res = self.fa.time_predict(shapes, tiling_param, aicore)
        return res