# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.common.entity import (
    CoreType,
    VecOpType,
    DType,
    ResultKey,
    Section,
    TensorData,
    MemLoc,
)
from core.backend.engineering_costmodel.core.pipeline.aiv_pipeline import AIVPipeline
from core.backend.engineering_costmodel.core.tiling_and_core_split.catlass_tiling import CatlassTiling
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.core.vector_op import VectorBasicOp
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel


class SoftmaxFlashV2Model(BasicOperatorModel):

    def __init__(self, input_precision: DType, output_precision: DType, **kwargs):
        super().__init__(
            "SoftmaxFlashV2", CoreType.AIV, input_precision, output_precision
        )
        s1, s2, d1, d2 = "s1", "s2", "d1", "d2"

        s_tile = TensorData("s_tile", DType.FP32, [s1, s2], MemLoc.GM)
        row_max = TensorData("row_max", DType.FP32, [s1, 1], MemLoc.UB)
        m1 = TensorData("m1", DType.FP32, [s1, 8], MemLoc.UB)
        s_sub_m1_r = TensorData(
            "s_sub_m1_r", DType.FP32, [s1, s2], MemLoc.UB
        )
        p_tile = TensorData("p_tile", DType.FP32, [s1, s2], MemLoc.GM)
        row_exp_sum = TensorData(
            "row_exp_sum", DType.FP32, [s1, 1], MemLoc.UB
        )
        l1 = TensorData("l1", DType.FP32, [s1, 8], MemLoc.UB)
        v_tile = TensorData("v_tile", DType.FP32, [s2, d2], MemLoc.GM)
        o_tile_ub = TensorData("o_tile_ub", DType.FP32, [s1, d2], MemLoc.UB)
        o_tile_gm = TensorData("o_tile_gm", DType.FP32, [s1, d2], MemLoc.GM)
        exp_max = TensorData("exp_max", DType.FP32, [s1, 8], MemLoc.UB)

        combo1 = [
            VectorBasicOp(VecOpType.VCGMAX, [s_tile], [row_max], pipe_barrier=False),
            VectorBasicOp(VecOpType.BRCB, [row_max], [m1]),
            VectorBasicOp(VecOpType.VSUB, [m1, s_tile], [s_sub_m1_r]),
            VectorBasicOp(VecOpType.VEXP, [s_sub_m1_r], [p_tile]),
            VectorBasicOp(VecOpType.VCGADD, [p_tile], [row_exp_sum]),
            VectorBasicOp(VecOpType.BRCB, [row_exp_sum], [l1]),
        ]

        combo2 = [
            VectorBasicOp(VecOpType.VCGMAX, [s_tile], [row_max], pipe_barrier=False),
            VectorBasicOp(VecOpType.BRCB, [row_max], [m1]),
            VectorBasicOp(VecOpType.VMAX, [m1, m1], [m1]),
            VectorBasicOp(VecOpType.VSUB, [m1, m1], [m1]),
            VectorBasicOp(VecOpType.VEXP, [m1], [exp_max]),
            VectorBasicOp(VecOpType.VMUL, [l1, exp_max], [l1]),
            VectorBasicOp(VecOpType.VSUB, [m1, s_tile], [s_sub_m1_r]),
            VectorBasicOp(VecOpType.VEXP, [s_sub_m1_r], [p_tile]),
            VectorBasicOp(VecOpType.VCGADD, [p_tile], [row_exp_sum]),
            VectorBasicOp(VecOpType.BRCB, [row_exp_sum], [l1]),
            VectorBasicOp(VecOpType.VADD, [l1, l1], [l1]),
            # update部分，FA中，属于Vec的计算，流程图中橙色
            VectorBasicOp(VecOpType.VMUL, [o_tile_ub, exp_max], [o_tile_ub]),
            VectorBasicOp(VecOpType.VADD, [o_tile_ub, o_tile_ub], [o_tile_ub]),
        ]

        # combo3多一个输出到GM的div流程
        combo3 = combo2 + [
            VectorBasicOp(VecOpType.VDIV, [o_tile_ub, o_tile_ub], [o_tile_gm])
        ]

        self.s1, self.s2, self.d1, self.d2 = s1, s2, d1, d2
        self.stages = [combo1, combo2, combo3]

    def time_predict(
        self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel
    ) -> dict[ResultKey, float]:
        s = 1
        for shape in shapes[0][:-1]:
            s *= shape
        d = shapes[0][-1]

        stage_1 = self.stages[0]
        stage_2 = self.stages[1]
        stage_3 = self.stages[2]

        section = Section(
            0,
            CoreType.AIV,
            s,
            0,
            d,
            tiling_param[0],
            self.input_precision,
            self.output_precision,
        )
        tiling = CatlassTiling()
        input_tiles, output_tiles = tiling.generate_tiles(section)

        col_max = max([tile.col_start for tile in input_tiles])

        # 每一行第一个softmax计算，按照 stage_1 计算
        for tile in input_tiles:
            shape_dict = {
                self.s1: tile.rows,
                self.s2: tile.rows,
                self.d1: tile.cols,
                self.d2: tile.cols,
            }
            tile.shape_dict = shape_dict
            if tile.col_start == 0:
                tile.fused_op = stage_1
            elif tile.col_start < col_max:
                tile.fused_op = stage_2
            else:
                tile.fused_op = stage_3

        aiv_pipe = AIVPipeline(aicore, tiling_param[0])

        core_set = {tile.core for tile in input_tiles}
        size_by_core = {
            core: sum([t.size for t in input_tiles if t.core == core])
            for core in core_set
        }
        max_size_core = max(size_by_core.items(), key=lambda x: x[1])[0]
        input_tiles = [tile for tile in input_tiles if tile.core == max_size_core]

        return aiv_pipe.calculate_time(input_tiles, output_tiles)