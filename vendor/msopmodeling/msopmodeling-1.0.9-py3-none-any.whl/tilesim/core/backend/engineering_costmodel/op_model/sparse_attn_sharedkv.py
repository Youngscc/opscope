# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.common.entity import DType, ResultKey
from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.op_model.sparse_flash_attention import SparseFlashAttention
from core.common.log_format import logging

logger = logging.getLogger(__name__)


class SparseAttnSharedkv(SparseFlashAttention):
    def __init__(self, input_precision: DType, output_precision: DType, layout=None, layout_format=None, tail_dim=None,
                 seqused_kv_cmp_window=None, seqused_kv=None, ori_win_left=None, cmp_ratio=None, **kwargs):
        super().__init__(input_precision, output_precision)
        self.layout = layout
        self.layout_format = layout_format
        self.tail_dim = tail_dim
        self.seqused_kv_cmp_window = seqused_kv_cmp_window
        self.seqused_kv = seqused_kv
        self.ori_win_left = ori_win_left
        self.cmp_ratio = cmp_ratio
        if layout is not None and tail_dim is None:
            raise ValueError("SparseAttnSharedkv should have tail_dim param when layout is not None")

    def __parse_shapes(self, shapes: list):
        if self.layout is not None:
            # shape如下：input: [[1, 1, 64, 512], [1, 1159, 512], [1, 1, 128]], output: [[1, 1, 64, 512]]
            # 额外入参如下：{'tail_dim': 64, 'layout': {'input': {'q_up': ['b', 's', 'n', 'd'], 'kv_cache': ['b', 't', 'd'],
            # 以及 'topk_ids': ['b', 's', 'w']}, 'output': {'result': ['b', 's', 'n', 'd']}}, 'layout_format': 'zhanlu'}
            input_layout = self.layout.get('input')
            q_layout = input_layout['q_up']
            kv_layout = input_layout['kv_cache']
            topk_ids_layout = input_layout['topk_ids']
            self.batch = shapes[0][q_layout.index('b')]
            self.seq_len = shapes[0][q_layout.index('s')]
            self.seq_len_kv = shapes[1][kv_layout.index('t')]
            self.heads = shapes[0][q_layout.index('n')]
            self.heads_kv = 1
            self.kv_group = self.heads // self.heads_kv
            self.dim = shapes[0][q_layout.index('d')]
            self.top_k = self.seq_len_kv  # 此处seq_len_kv即为window+compress的结果，是实际处理的token数量
        else:
            # 对于输入shape [[1, 64, 512], [2069, 128, 1, 512], [17, 128, 1, 512], [1, 512], [1, 512], [2], [1], [64], [1024]]
            # 或者 [[1, 64, 512], [2069, 128, 1, 512], [518, 128, 1, 512], [1, 1, 512], [1, 512], [1, 512], [2], [1], [64], [1024]]
            # 第一个输入Q为TND，第二个输入KV为[block_num, block_size, N2, D]
            # 后续输入中，batch取倒数第3个shape的值，tail_dim取倒数第二个shape的值，top_k取最后一个shape的值
            # NEXT -- shape含义目前没有明确资料参考，后续需要确认清楚
            if len(shapes) < 5:
                raise ValueError("SparseAttnSharedkv input size must larger then 5")
            self.batch = shapes[-3][0]
            self.seq_len = shapes[0][0] // self.batch
            self.seq_len_kv = self.seqused_kv_cmp_window if self.seqused_kv_cmp_window is not None else shapes[1][0]
            self.heads = shapes[0][1]
            self.heads_kv = shapes[1][2]
            self.kv_group = self.heads // self.heads_kv
            self.dim = shapes[0][2]
            self.tail_dim = shapes[-2][-1]
            self.top_k = shapes[-1][-1]

    def time_predict(self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel, sfa_shape=True) -> \
            dict[ResultKey, float]:
        self.__parse_shapes(shapes)
        return super().time_predict(shapes, tiling_param, aicore, False)