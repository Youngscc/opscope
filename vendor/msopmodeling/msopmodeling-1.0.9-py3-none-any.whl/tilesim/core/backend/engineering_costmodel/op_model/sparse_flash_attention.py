# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math

from core.common.entity import DType, CoreType, TensorData, MemLoc, VecOpType, Section, ResultKey
from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.backend.engineering_costmodel.core.pipeline.inter_core_pipeline import InterCorePipeline
from core.backend.engineering_costmodel.core.tiling_and_core_split.catlass_tiling import CatlassTiling
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.core.vector_op import VectorBasicOp
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel
from core.common.log_format import logging

logger = logging.getLogger(__name__)


class SparseFlashAttention(BasicOperatorModel):

    def __init__(self, input_precision: DType, output_precision: DType, **kwargs):
        super().__init__("SparseFlashAttention", CoreType.MIX, input_precision, output_precision)
        self.section_list: list[Section] = []
        self.heads, self.dim, self.tail_dim, self.top_k, self.kv_group, self.batch, self.seq_len, self.seq_len_kv = [
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0]

        if input_precision == DType.FP8:
            self.input_precision_aiv = DType.FP16
            self.output_precision_aiv = DType.FP16
        else:
            self.input_precision_aiv = DType.FP32
            self.output_precision_aiv = DType.FP32

        self.total_dim = 'total_dim'
        self.v_block = 32
        self.bi = 'bi'
        self.d = 'd'

    def __generate_fused_op_vec_1(self, half_bi):
        bi = half_bi * 2

        multi_token_num = 1
        trans_kv_dim = TensorData("trans_kv_dim", DType.FP16, [self.dim * multi_token_num], MemLoc.GM)
        trans_kv_dim_ub = TensorData("trans_kv_dim_ub", DType.FP16, [self.dim * multi_token_num], MemLoc.UB)
        trans_kv_dim_tail = TensorData("trans_kv_dim_tail", DType.FP16, [self.tail_dim * multi_token_num],
                                       MemLoc.GM)
        trans_kv_dim_tail_ub = TensorData("trans_kv_dim_tail_ub", DType.FP16, [self.tail_dim * multi_token_num],
                                          MemLoc.UB)
        trans_indices = TensorData("trans_indices", DType.FP32, [bi], MemLoc.GM)
        trans_indices_ub = TensorData("trans_indices_ub", DType.FP32, [bi], MemLoc.UB)
        trans_out_ub = TensorData("trans_out_ub", DType.FP16, [bi, self.dim], MemLoc.UB)
        trans_out_gm = TensorData("trans_out_gm", DType.FP16, [bi, self.dim], MemLoc.GM)

        combo_index = [VectorBasicOp(VecOpType.NULL_OP, [trans_indices], [trans_indices_ub], pipe_barrier=False)]

        for i in range(half_bi // multi_token_num):
            combo_index.extend([
                VectorBasicOp(VecOpType.NULL_OP, [trans_kv_dim], [trans_kv_dim_ub], pipe_barrier=False),
                VectorBasicOp(VecOpType.NULL_OP, [trans_kv_dim_tail], [trans_kv_dim_tail_ub], pipe_barrier=False),
            ]
            )

        combo_index.extend([
            VectorBasicOp(VecOpType.NULL_OP, [trans_out_ub], [trans_out_gm], pipe_barrier=False)
        ]
        )

        return combo_index

    def __generate_fused_op_vec_2(self):
        s_tile_gm = TensorData("s_tile_gm", DType.FP32, [self.v_block, self.bi], MemLoc.GM)
        s_tile_ub = TensorData("s_tile_ub", DType.FP32, [self.v_block, self.bi], MemLoc.UB)
        s_tile_fp16 = TensorData("s_tile_gm_fp16", DType.FP16, [self.v_block, self.bi], MemLoc.UB)
        s_tile_sub_ub = TensorData("s_tile_sub_ub", DType.FP32, [self.bi], MemLoc.UB)
        reduce_result_ub = TensorData("reduce_result_ub", DType.FP32, [self.v_block], MemLoc.UB)

        combo_softmax = []

        combo_softmax.extend([
            VectorBasicOp(VecOpType.VADD, [s_tile_gm, s_tile_ub], [s_tile_ub]),
            VectorBasicOp(VecOpType.VMULS, [s_tile_ub], [s_tile_ub]),
            VectorBasicOp(VecOpType.VCGMAX, [s_tile_ub], [s_tile_ub]),
            VectorBasicOp(VecOpType.VMAX, [reduce_result_ub], [reduce_result_ub]),
            VectorBasicOp(VecOpType.VSUB, [reduce_result_ub], [reduce_result_ub]),
            VectorBasicOp(VecOpType.VEXP, [reduce_result_ub], [reduce_result_ub]),

        ])

        for i in range(self.v_block):
            combo_softmax.append(VectorBasicOp(VecOpType.VADDS, [s_tile_sub_ub], [s_tile_sub_ub]))

        combo_softmax.extend([
            VectorBasicOp(VecOpType.VEXP, [s_tile_ub], [s_tile_ub]),
            VectorBasicOp(VecOpType.VCADD, [s_tile_ub], [s_tile_ub]),
            VectorBasicOp(VecOpType.VMUL, [reduce_result_ub], [reduce_result_ub]),
            VectorBasicOp(VecOpType.VADD, [reduce_result_ub], [reduce_result_ub]),
        ])

        for i in range(self.v_block):
            combo_softmax.append(VectorBasicOp(VecOpType.VMULS, [s_tile_sub_ub], [s_tile_sub_ub]))

        combo_softmax.append(VectorBasicOp(VecOpType.CONV_F322F16, [s_tile_ub], [s_tile_fp16]))
        return combo_softmax

    def __generate_fused_op_vec_3(self, last_col: bool):
        p_tile_gm = TensorData("p_tile_gm", DType.FP32, [self.v_block, self.d], MemLoc.GM)
        p_tile_ub = TensorData("p_tile_ub", DType.FP32, [self.v_block, self.d], MemLoc.UB)
        o_per_head_ub = TensorData("o_per_head_ub", DType.FP32, [self.d], MemLoc.UB)

        combo_softmax = [
            VectorBasicOp(VecOpType.VADD, [p_tile_gm, p_tile_ub], [p_tile_ub], pipe_barrier=False),
        ]

        if last_col:
            for i in range(self.v_block):
                combo_softmax.append(
                    VectorBasicOp(VecOpType.VDIV, [o_per_head_ub, o_per_head_ub], [o_per_head_ub])
                )
        return combo_softmax

    def __set_tile_round(self, tile_round):
        for sec in self.section_list:
            sec.tile_round = tile_round

    def __generate_sections(self, tiling_param: list[TilingParam]):
        # 一次搬运 v_block*d
        sec_transfer_kv = Section(bias=0, core_type=CoreType.AIV,
                                  m=self.top_k,
                                  k=0,
                                  n=self.dim + self.tail_dim,
                                  tiling_param=tiling_param[0],
                                  input_precision=self.input_precision_aiv, output_precision=self.output_precision_aiv)

        # 一次计算 block_m * block_n ===> 需要 block_n / v_block 次搬运 ==》 大概率block_m = 1
        sec_qk = Section(bias=1, core_type=CoreType.AIC,
                         m=self.heads // 2,
                         k=self.dim,
                         n=self.top_k,
                         tiling_param=tiling_param[1],
                         input_precision=self.input_precision, output_precision=self.output_precision,
                         copy_out=False)
        sec_qk.input_dependency = {1: '0_-1'}

        # 一次计算 block_m * block_n ===> 需要 block_n / v_block 次搬运 ==》 大概率block_m = 1
        sec_qk_tail = Section(bias=2, core_type=CoreType.AIC,
                              m=self.heads // 2,
                              k=self.tail_dim,
                              n=self.top_k,
                              tiling_param=tiling_param[2],
                              input_precision=self.input_precision, output_precision=self.output_precision)
        sec_qk_tail.input_dependency = {1: '0_-1'}

        # 一次计算 v_block * block_i 大小 ===> 需要 block_m / v_block * block_i / block_n 次
        sec_softmax_1 = Section(bias=3, core_type=CoreType.AIV,
                                m=self.heads // 2,
                                k=0,
                                n=self.top_k,
                                tiling_param=tiling_param[3],
                                input_precision=self.input_precision_aiv, output_precision=self.output_precision_aiv)
        sec_softmax_1.input_dependency = {0: '2_-1'}

        sec_pv = Section(bias=4, core_type=CoreType.AIC,
                         m=self.heads // 2,
                         k=self.top_k,
                         n=self.dim,
                         tiling_param=tiling_param[4],
                         input_precision=self.input_precision, output_precision=self.output_precision,
                         single_tile_output=True, transpose={1})
        sec_pv.input_dependency = {0: '3_-1', 1: '0_-1'}

        sec_softmax_2 = Section(bias=5, core_type=CoreType.AIV,
                                m=self.heads // 2,
                                k=0,
                                n=self.dim,
                                tiling_param=tiling_param[5],
                                input_precision=self.input_precision_aiv, output_precision=self.output_precision_aiv)
        sec_softmax_1.input_dependency = {0: '4_-1'}

        self.section_list = [sec_transfer_kv, sec_qk, sec_qk_tail, sec_softmax_1, sec_pv, sec_softmax_2]

    def __generate_tiles(self):
        """
        分section生成tile
        """
        tiling = CatlassTiling()
        for section in self.section_list:
            tiles = tiling.generate_tiles(section, single_tile_output=section.single_tile_output)
            logger.debug(f'{section.bias} - {len(tiles[0])}, {len(tiles[1])}')
            section.input_tiles = tiles[0]
            section.output_tiles = tiles[1]

    def __next_power_of_2(self, n):
        if n <= 0:
            return 1  # 如果 n <= 0，返回最小的 2 的幂，即 1
        if (n & (n - 1)) == 0:
            return n  # 如果 n 本身就是 2 的幂，直接返回
            # 否则，找到下一个 2 的幂
        power = 1
        while power < n:
            power <<= 1  # 左移一位，相当于乘以 2
        return power

    def get_tiling_strategy(self, shapes: list) -> list[TilingParam]:
        d = shapes[0][2]
        tail_d = shapes[-2][-1]

        h_per_block = 64
        v_block = 32
        bi = 256
        block_num = 20

        vec_parallel_config = [False]
        cube_parallel_config = [False, False, False]
        tiling_param = [
            # 搬运kv
            TilingParam(0, 0, 0, bi // 2, d + tail_d, 0, 0, block_num * 2, 1, swizzle_offset=1, swizzle_direction=0,
                        parallel_config=vec_parallel_config),
            # qk乘
            TilingParam(h_per_block, bi, d, h_per_block, bi, d, d, block_num, 1, swizzle_offset=1, swizzle_direction=0,
                        parallel_config=cube_parallel_config),
            # qk tail
            TilingParam(h_per_block, bi, tail_d, h_per_block, bi, tail_d, tail_d, block_num, 1, swizzle_offset=1,
                        swizzle_direction=0, parallel_config=cube_parallel_config),
            # softmax
            TilingParam(0, 0, 0, v_block, bi, 0, 0, block_num * 2, 1, swizzle_offset=1, swizzle_direction=0,
                        parallel_config=vec_parallel_config),
            # pv乘
            TilingParam(h_per_block, d, bi, h_per_block, d, bi, bi, block_num, 1, swizzle_offset=1,
                        swizzle_direction=0, parallel_config=cube_parallel_config),
            # update
            TilingParam(0, 0, 0, v_block, d, 0, 0, block_num * 2, 1, swizzle_offset=1, swizzle_direction=0,
                        parallel_config=vec_parallel_config),
        ]
        return tiling_param

    def __parse_shapes(self, shapes: list):
        # 对于输入shape [[4096, 16, 512], [1254, 128, 1, 512], [1254, 128, 1, 512], [4096, 1, 2048], [2, 64], [2], [2], [4096, 16, 64], [1254, 128, 1, 64]]
        # 上述输入中，Q为TND，KV为[block_num, block_size, N2, D]
        # 后续输入分别为：sparse_indices格式[T, N2, sparse_size(即top_k)]，block_table格式[B, >=maxBlockNumPerSeq]，
        # actual_seq_lengths_query格式[B]，actual_seq_lengths_kv格式[B]，
        # query_rope格式[T,N,tail_dim]，key_rope格式[block_num, block_size, N2, tail_dim]
        # NEXT -- 此处seq_len_kv取的可能不对
        if len(shapes) != 9:
            raise ValueError("SparseFlashAttention input size must be 9")
        self.batch = shapes[5][0]
        self.seq_len = shapes[0][0] // self.batch
        self.seq_len_kv = shapes[1][0]
        self.heads = shapes[0][1]
        self.heads_kv = shapes[1][2]
        self.kv_group = self.heads // self.heads_kv
        self.dim = shapes[0][2]
        self.tail_dim = shapes[7][-1]
        self.top_k = shapes[3][-1]

    def time_predict(self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel, sfa_shape=True) -> \
    dict[ResultKey, float]:
        """源于tilelang实现的SFA的建模，启用了CV并行、Double buffer、最优tiling、连续搬出、同步优化，并且去掉了tilelang中对分核的特殊处理"""
        if sfa_shape:
            self.__parse_shapes(shapes)
        self.v_block = tiling_param[3].m1

        block_num = tiling_param[1].w * tiling_param[1].h
        task = self.batch * self.seq_len * 2
        if task > block_num:
            task = math.ceil(task / block_num)
        else:
            task = 1

        self.__generate_sections(tiling_param)
        self.__set_tile_round(tile_round=1)
        self.__generate_tiles()

        sec_transfer = self.section_list[0]
        sec_softmax = self.section_list[3]
        sec_update = self.section_list[5]

        last_col = max([t.col_start for t in sec_update.input_tiles])

        combo_softmax = self.__generate_fused_op_vec_2()
        combo_update = self.__generate_fused_op_vec_3(False)
        combo_update_last = self.__generate_fused_op_vec_3(True)

        combo_index_dict = {}

        for tile in sec_transfer.input_tiles:
            if tile.rows not in combo_index_dict.keys():
                combo_transfer = self.__generate_fused_op_vec_1(tile.rows)
                combo_index_dict[tile.rows] = combo_transfer
            tile.fused_op = combo_index_dict[tile.rows]

        for tile in sec_softmax.input_tiles:
            tile.fused_op = combo_softmax
            tile.shape_dict = {
                self.v_block: tile.rows,
                self.bi: tile.cols
            }

        for tile in sec_update.input_tiles:
            tile.shape_dict = {
                self.v_block: tile.rows,
                self.d: tile.cols
            }
            if tile.col_start == last_col:
                tile.fused_op = combo_update_last
            else:
                tile.fused_op = combo_update

        # 计算CV并行时间
        inter_core_pipe = InterCorePipeline(self.section_list, aicore)
        res = inter_core_pipe.calculate_sections_time()
        if self.seq_len == 1:
            res[ResultKey.CORE_TIME] += 60

        for k, v in res.items():
            if k in ResultKey.time_keys():
                res[k] *= task
            logger.info(f'{k}:{res[k]:.2f}(total_time); {v:.2f}(single_task_time)')
        return res