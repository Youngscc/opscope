# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.backend.backend_entity.backend_entity import VarEntity
from core.backend.backend_entity.backend_logistic import SubTaskEntity, TaskEntity
from core.backend.backend_entity.backend_math import RangeEntity
from core.backend.backend_entity.ir_to_entity import BackendEntity
from core.backend.engineering_costmodel.optim.optim import Optim
from core.common.backend_config import BackendConfig
from core.common.entity import CoreType


class OptimBySeqImpl(Optim):

    def __init__(self, backend_config: BackendConfig, backend_entity: BackendEntity):
        super().__init__(backend_config, backend_entity)
        self.total_sub_task_list: list[SubTaskEntity] = []
        self.idx_dict = {}

        # 临时变量
        self.block_dim = 0
        self.max_block_dim = 0
        # 分核的index配置信息，k-index名称， v-index
        self.core_split_idx = {}
        # index的stride信息，k-index名称， v-stride
        self.index_stride = {}
        # index是否开启swizzle方向， k-index名称， v-T/F
        self.index_swizzle_dir = {}
        # index的遍历顺序
        self.indices_seq = []

    def _expand_task_indices(self, indices: list[VarEntity], task: TaskEntity, indices_dict: dict[str, int]):
        idx = indices[0]
        if not isinstance(idx.value, RangeEntity):
            raise ValueError(f"task {task.name} indices is not supported")

        range_value = idx.value.eval(self.backend_entity.eval_ctx)
        left_indices = indices[1:]

        for i in range(range_value.start, range_value.end, range_value.step):
            new_indices_dict = indices_dict.copy()
            new_indices_dict[idx.name] = i
            if len(left_indices) > 0:
                self._expand_task_indices(left_indices, task, new_indices_dict)
            else:
                sub_task_idx = self.idx_dict.get(task.name, 0)
                sub_task_idx += 1
                sub_task = SubTaskEntity(
                    root_task_name=task.name,
                    index=sub_task_idx,
                    core_idx=self.block_dim,
                    root_task=task,
                    indices=new_indices_dict
                )
                self.total_sub_task_list.append(sub_task)
                self.idx_dict[task.name] = sub_task_idx
            self._update_block_dim(idx.name)

    def _init_task_expander(self, task_entity: TaskEntity):
        task_index_config = self.optim_config.task_index_config.get(task_entity.name, [])
        self.core_split_idx = {c.index_name: c for c in task_index_config}
        self.index_stride = {c.index_name: c.split_core_stride for c in task_index_config}
        self.index_swizzle_dir = {c.index_name: True for c in task_index_config}
        self.indices_seq = [c.index_name for c in sorted(task_index_config, key=lambda x: (x.seq_num, x.index_name))]
        self.block_dim = 0
        core_type = task_entity.core_type
        if core_type == CoreType.AIC or core_type == CoreType.MIX:
            self.max_block_dim = self.backend_config.aic_core_num
        elif core_type == CoreType.AIV:
            self.max_block_dim = self.backend_config.aiv_core_num
        else:
            raise ValueError(f"core type {core_type} is not supported in seq impl")

    def _update_block_dim(self, idx_name: str):
        idx_name_pure = idx_name.split('_')[0]
        if idx_name_pure in self.core_split_idx:
            stride = self.index_stride[idx_name_pure]
            stride -= 1
            if stride == 0:
                self.block_dim += 1
                if self.block_dim == self.max_block_dim:
                    self.block_dim = 0
                stride = self.core_split_idx[idx_name_pure].split_core_stride

            self.index_stride[idx_name_pure] = stride

    def _generate_sub_task(self, tuning_candidate: dict[str, Any]) -> list[SubTaskEntity]:

        for task_entity in self.backend_entity.task_dict.values():
            idx = 0
            task_indices = task_entity.indices
            if task_indices is None:
                sub_task = SubTaskEntity(
                    root_task_name=task_entity.name,
                    index=idx,
                    core_idx=0,
                    root_task=task_entity
                )
                self.total_sub_task_list.append(sub_task)
            else:
                self._init_task_expander(task_entity)
                self._expand_task_indices(task_indices, task_entity, {})
        return self.total_sub_task_list