# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.backend.backend_entity.ir_to_entity import BackendEntity
from core.common.backend_config import BackendConfig, OptimType
from core.backend.engineering_costmodel.optim.adaptor_optim.adaptor_optim_bypass import OptimAdaptorImpl
from core.backend.engineering_costmodel.optim.general_optim.general_optim_by_seq import OptimBySeqImpl
from core.backend.engineering_costmodel.optim.matmul_optim.optim_swizzle import OptimMatMulImpl
from core.pipeline.basic_operator import OperatorResult


def optim_dispatch(backend_input: BackendConfig, backend_entity: BackendEntity) -> OperatorResult:
    optim_type = backend_input.optim_config.optim_method
    if optim_type == OptimType.MATMUL_OPTIM:
        optim = OptimMatMulImpl(backend_input, backend_entity)
    elif optim_type == OptimType.ADAPTOR_BYPASS_OPTIM:
        optim = OptimAdaptorImpl(backend_input, backend_entity)
    elif optim_type == OptimType.GENERAL_BY_SEQ_OPTIM:
        optim = OptimBySeqImpl(backend_input, backend_entity)
    else:
        raise ValueError(f'Unsupported optim type: {optim_type}')

    return optim()