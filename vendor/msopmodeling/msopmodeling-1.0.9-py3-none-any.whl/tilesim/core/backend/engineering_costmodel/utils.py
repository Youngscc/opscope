# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math
from typing import Optional, List

import numpy as np


def binocular_op_shape_parse(input_shape: list[list[int]]) -> list[int]:
    """双目运算指令的shape处理"""
    if len(input_shape) == 2:
        src1, src2 = input_shape
        if src1 == src2:
            ret_shape = src1
        else:
            src1_size = math.prod(src1)
            src2_size = math.prod(src2)
            ret_shape = src1 if src1_size > src2_size else src2
    elif len(input_shape) == 1:
        ret_shape = input_shape[0]
    else:
        return [1, 1]  # 空输入代表两个标量，按照1维处理

    # 高维到二维的展开
    rows = math.prod(ret_shape[:-1]) if len(ret_shape) > 1 else 1
    cols = ret_shape[-1]
    return [rows, cols]


def generate_sequence_lengths_truncated(
        num_sequences: int,
        mean: float,
        std: float,
        min_length: int = 1,
        max_length: int = None,
        seed: Optional[int] = 1
) -> List[int]:
    """
    使用截断正态分布生成序列长度（确保采样值在范围内，而非简单裁剪）

    Args:
        num_sequences: 需要生成的序列数量
        mean: 正态分布的均值
        std: 正态分布的标准差
        min_length: 序列最小长度
        max_length: 序列最大长度
        seed: 随机种子

    Returns:
        List[int]: 序列长度列表
    """
    from scipy.stats import truncnorm

    if seed is not None:
        np.random.seed(seed)

    if max_length is None:
        max_length = mean + 6 * std  # 默认上限

    # 计算截断正态分布的参数
    a = (min_length - mean) / std
    b = (max_length - mean) / std

    # 从截断正态分布采样
    lengths = truncnorm.rvs(a, b, loc=mean, scale=std, size=num_sequences)

    # 四舍五入转为整数
    lengths = np.round(lengths).astype(int)

    # 确保边界（处理四舍五入后可能的边界问题）
    lengths = np.clip(lengths, min_length, max_length)

    return lengths.tolist()