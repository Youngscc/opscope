import math
from dataclasses import dataclass, field

from core.backend.backend_entity.backend_logistic import OpEntity, LogisticEntity
from core.backend.backend_entity.backend_math import EvalCtxEntity
from core.backend.theoretical_costmodel.evaluation.theo_evaluation import TheoEvaluation
from core.backend.tile_op_costmodel import tile_op_dispatch
from core.backend.tile_op_costmodel.tile_op_backend_entity import TileOpEntity, TileEntity, TileOpContext
from core.common.tile_op_enum import TileOpCode, TileOpType
from core.common.backend_config import BackendConfig, FitParamKey
from core.common.entity import MemLoc, CoreUnit, CoreType, OpLevel
from core.config.arc_spec import load_arc_config
from core.pipeline.basic_operator import OperatorResult


@dataclass
class CoreUnitPipe:
    pipe_manager: dict[CoreUnit, float] = field(default_factory=dict)

    def get_pipe(self, comp: CoreUnit) -> float:
        return self.pipe_manager.get(comp, 0)

    def update_pipe(self, comp: CoreUnit, duration: float):
        self.pipe_manager[comp] = self.pipe_manager.get(comp, 0) + duration


@dataclass
class CacheStorage:
    cache_manager: dict[MemLoc, set] = field(default_factory=dict)
    tensor_recent_store: dict[str, MemLoc] = field(default_factory=dict)

    def mov_in(self, tensors: TileEntity | list[TileEntity], mem_loc: MemLoc):
        cache_set = self.cache_manager.get(mem_loc, set())

        tensor_list = []
        if not isinstance(tensors, list):
            tensor_list.append(tensors)
        else:
            tensor_list = tensors

        for tensor in tensor_list:
            cache_set.add(tensor.magic)
            self.tensor_recent_store[tensor.magic] = mem_loc

        self.cache_manager[mem_loc] = cache_set

    def in_cache(self, tensor: TileEntity, mem_loc: MemLoc) -> bool:
        if mem_loc in self.cache_manager.keys():
            if tensor.magic in self.cache_manager[mem_loc]:
                return True
        return False

    def get_store_cache(self, tensor: TileEntity) -> MemLoc:
        return self.tensor_recent_store.get(tensor.magic, tensor.buffer_type)


def _get_op_core_type(op: OpEntity) -> CoreType:
    if op.op_code in [TileOpCode.CONV2D, TileOpCode.CONV3D, TileOpCode.GEMM]:
        return CoreType.AIC

    if op.op_code == TileOpCode.STORE:
        raise NotImplementedError("store op not in any core")

    return CoreType.AIV


class OptimalPipelineModel(TheoEvaluation):

    def __init__(self, backend_config: BackendConfig, eval_ctx: EvalCtxEntity):
        super().__init__(backend_config, eval_ctx)
        self.arc_config = load_arc_config(backend_config.accelerator)
        self._fit_coeff()

        self.data_transfer = {}
        self.core_unit_pipe = CoreUnitPipe()
        self.cache_storage = CacheStorage()

        self.aiv_core = self.arc_config.core_config.vec_core_num
        self.aic_core = self.arc_config.core_config.cube_core_num

        self.store_tensor = set()

        if backend_config.aic_core_num is not None and backend_config.aiv_core_num > 0:
            self.aiv_core = backend_config.aiv_core_num

        if backend_config.aic_core_num is not None and backend_config.aiv_core_num > 0:
            self.aic_core = backend_config.aic_core_num

        self.ub_2_out, _ = self.arc_config.lookup_bw(MemLoc.UB, MemLoc.L2, self.aiv_core)
        self.l2_2_ub, _ = self.arc_config.lookup_bw(MemLoc.L2, MemLoc.UB, self.aiv_core)
        self.out_2_ub, _ = self.arc_config.lookup_bw(MemLoc.GM, MemLoc.UB, self.aiv_core)
        self.l0c_2_out, _ = self.arc_config.lookup_bw(MemLoc.L0C, MemLoc.L2, self.aic_core)

    def _fit_coeff(self):
        self.arc_config.clock_freq *= self.eval_config.fit_param[FitParamKey.COMP_COEFF]
        self.arc_config.set_bw_coeff(self.eval_config.fit_param[FitParamKey.BW_COEFF])

    def _convert_to_tile_op(self, op: OpEntity) -> TileOpEntity:
        inputs = [TileEntity.from_op_entity(tensor) for tensor in op.inputs]
        outputs = [TileEntity.from_op_entity(tensor) for tensor in op.outputs]
        op_code = op.op_code

        core_num = self.aiv_core
        if op_code in [TileOpCode.CONV2D, TileOpCode.CONV3D, TileOpCode.GEMM]:
            core_num = self.aic_core

        context = TileOpContext(
            arc_config=self.arc_config,
            core_num=core_num,
            barrier=False,
            enable_small_pkt_bw=False
        )

        return TileOpEntity(
            magic=op.op_code.name,
            i_operand=inputs,
            o_operand=outputs,
            context=context,
            opcode=op_code
        )

    def _calc_copy_time(self, tensor: TileEntity, src_mem: MemLoc, dst_mem: MemLoc) -> float:
        """获取搬运时间"""

        if self.cache_storage.in_cache(tensor, dst_mem):
            return 0

        if src_mem == MemLoc.GM and dst_mem == MemLoc.UB:
            bw = self.out_2_ub
        elif src_mem == MemLoc.L2 and dst_mem == MemLoc.UB:
            bw = self.l2_2_ub
        elif src_mem == MemLoc.UB and dst_mem == MemLoc.L2:
            bw = self.ub_2_out
        elif src_mem == MemLoc.L0C and dst_mem == MemLoc.L2:
            bw = self.l0c_2_out
        else:
            raise NotImplementedError(f"{src_mem} -> {dst_mem} copy time not implemented")

        data_size = math.prod(tensor.shape) * tensor.data_type_str.size
        tm = data_size / bw / self.aiv_core
        self.cache_storage.mov_in(tensor, dst_mem)
        path = MemLoc.path_name(src_mem, dst_mem)
        total_data = self.data_transfer.get(path, 0) + data_size
        self.data_transfer[path] = total_data

        return tm

    def _process_copy_out(self, tensor: TileEntity):
        """处理需要输出结果（搬出到GM）的张量"""
        store_cache = self.cache_storage.get_store_cache(tensor)
        if store_cache == MemLoc.L2:
            return
        copy_out_time = self._calc_copy_time(tensor, store_cache, MemLoc.L2)
        if store_cache == MemLoc.UB:
            core_unit = CoreUnit.AIV_MTE3
        elif store_cache == MemLoc.L0C:
            core_unit = CoreUnit.AIC_FIXPIPE
        else:
            raise NotImplementedError(f"copy out from {store_cache} not implemented")

        self.core_unit_pipe.update_pipe(core_unit, copy_out_time)

    def _process_gemm(self, op: TileOpEntity):
        l2_tensors = [t for t in op.i_operand if self.cache_storage.in_cache(t, MemLoc.L2)]
        for t in l2_tensors:
            t.buffer_type = MemLoc.L2

        # 理论极限性能，version标记为-1
        op_duration = tile_op_dispatch(op, TileOpType.PLAIN, version=-1)

        self.core_unit_pipe.update_pipe(CoreUnit.CUBE, op_duration.unit_latency[CoreUnit.CUBE])
        self.core_unit_pipe.update_pipe(CoreUnit.AIC_MTE2, op_duration.unit_latency[CoreUnit.AIC_MTE2])

        for k, v in op_duration.data_transfer.items():
            path = MemLoc.path_name(k)
            self.data_transfer[path] = self.data_transfer.get(path, 0) + v

        # 更新L2的张量
        self.cache_storage.mov_in(op.i_operand, MemLoc.L2)
        self.cache_storage.mov_in(op.o_operand, MemLoc.L0C)

    def _process_conv(self, op: TileOpEntity):
        raise NotImplementedError("conv op not implemented")

    def _process_vec_op(self, op: TileOpEntity):
        """处理vector类型的指令"""
        # 计算 vec op 的搬入时间
        copy_from_l2 = []
        copy_from_gm = []

        for input_tensor in op.i_operand:
            if self.cache_storage.in_cache(input_tensor, MemLoc.UB):
                continue

            if self.cache_storage.in_cache(input_tensor, MemLoc.L2):
                copy_from_l2.append(input_tensor)
            else:
                copy_from_gm.append(input_tensor)
        copy_in_time = sum([self._calc_copy_time(tensor, MemLoc.GM, MemLoc.UB) for tensor in copy_from_gm])
        copy_in_time += sum([self._calc_copy_time(tensor, MemLoc.L2, MemLoc.UB) for tensor in copy_from_l2])
        self.core_unit_pipe.update_pipe(CoreUnit.AIV_MTE2, copy_in_time)

        # 计算时间
        op_duration = tile_op_dispatch(op, TileOpType.PLAIN)
        vec_time = op_duration.latency / self.aiv_core
        self.core_unit_pipe.update_pipe(CoreUnit.VEC, vec_time)

        # 更新UB上存的张量
        self.cache_storage.mov_in(op.o_operand, MemLoc.UB)

    def _process_op(self, event: OpEntity):
        op = self._convert_to_tile_op(event)

        if op.opcode == TileOpCode.GEMM:
            self._process_gemm(op)
        elif op.opcode in [TileOpCode.CONV2D, TileOpCode.CONV3D]:
            self._process_conv(op)
        elif op.opcode in [TileOpCode.STORE, TileOpCode.LOAD]:
            # load可以通过张量位置判断得到，不需要处理
            pass
        else:
            self._process_vec_op(op)

        for tensor in op.o_operand:
            if tensor.magic in self.store_tensor:
                self._process_copy_out(tensor)

    def _find_store_tensor(self, op_list: list[OpEntity]):
        output_tensors = {}
        intput_tensors = {}
        for op in op_list:

            # store一定要搬出，拦截后不做处理
            if op.op_code == TileOpCode.STORE:
                self.store_tensor.add(op.outputs[0].name)
                continue

            core_type = _get_op_core_type(op)
            for tensor in op.inputs:
                tensor_set = intput_tensors.get(core_type, set())
                tensor_set.add(tensor.name)
                intput_tensors[core_type] = tensor_set
            for tensor in op.outputs:
                tensor_set = output_tensors.get(core_type, set())
                tensor_set.add(tensor.name)
                output_tensors[core_type] = tensor_set

        # AIC中输出，AIV中输入
        c_output = output_tensors.get(CoreType.AIC, set())
        v_input = intput_tensors.get(CoreType.AIV, set())
        self.store_tensor.update(c_output & v_input)
        # AIV中输出，AIC中输入
        c_input = intput_tensors.get(CoreType.AIC, set())
        v_output = output_tensors.get(CoreType.AIV, set())
        self.store_tensor.update(c_input & v_output)

    def _expand(self, ori_op_list: list[LogisticEntity]) -> list[OpEntity]:
        op_list = []
        for op in ori_op_list:
            op_list.extend(op.expand(self.eval_ctx))
        return op_list

    def eval(self, op_list: list[LogisticEntity]) -> OperatorResult:
        expanded_op_list = self._expand(op_list)
        self._find_store_tensor(expanded_op_list)

        for op in expanded_op_list:
            if op.level == OpLevel.TILE_OP:
                raise NotImplementedError("Not support tile op in theo model")
            elif op.level == OpLevel.HOST_OP:
                continue
            self._process_op(op)

        aic_time = max(self.core_unit_pipe.get_pipe(CoreUnit.CUBE), max(self.core_unit_pipe.get_pipe(CoreUnit.AIC_MTE2), self.core_unit_pipe.get_pipe(CoreUnit.AIC_FIXPIPE)))
        aiv_time = max(self.core_unit_pipe.get_pipe(CoreUnit.VEC), self.core_unit_pipe.get_pipe(CoreUnit.AIV_MTE2) + self.core_unit_pipe.get_pipe(CoreUnit.AIV_MTE3))

        core_time = max(aic_time, aiv_time)

        ret = OperatorResult(
            latency=core_time,
            aic_time=aic_time,
            aic_cube_time=self.core_unit_pipe.get_pipe(CoreUnit.CUBE),
            aic_mte2_time=self.core_unit_pipe.get_pipe(CoreUnit.AIC_MTE2),
            aic_fixpipe_time=self.core_unit_pipe.get_pipe(CoreUnit.AIC_FIXPIPE),
            aiv_time=aiv_time,
            aiv_vec_time=self.core_unit_pipe.get_pipe(CoreUnit.VEC),
            aiv_mte2_time=self.core_unit_pipe.get_pipe(CoreUnit.AIV_MTE2),
            aiv_mte3_time=self.core_unit_pipe.get_pipe(CoreUnit.AIV_MTE3),
            data_transfer=self.data_transfer
        )

        return ret
