from core.common.entity import DType, MemLoc, MemType
from core.backend.theoretical_costmodel.basic_stage_roofline.basic_cost_api import ModelLevel
from core.config.arc_spec import ArcConfig


def _parse_input(shapes: list[list[int]]):
    m, ka = shapes[0]
    n, kb = shapes[1]

    if ka != kb:
        kb, n = shapes[1]
    if ka != kb:
        raise ValueError("k dimension should be equal")
    return m, ka, n


class MinAccessCubeRoofline:

    def __init__(self, arc_spec: ArcConfig):
        self.db = 1
        self.arc_spec = arc_spec

    def __calc_min_access_through_k(self, stick_tile_size: float, moving_tile_size: float, stick_tile: float,
                                    moving_tile: float, k_tile: float, buffer_size: float) \
            -> tuple[float, float, float]:
        """
        贯穿K轴情况下的最小访存求取
        :param stick_tile_size:     常驻的矩阵基本块大小
        :param moving_tile_size:    移动的矩阵基本块大小
        :param stick_tile:          常驻轴切分块数
        :param moving_tile:         移动轴切分块数
        :param k_tile:              K轴切分块数
        :param buffer_size:         缓存大小
        :return:                    最小访存量
        """
        stick_total_k = stick_tile_size * k_tile + self.db * moving_tile_size

        # 如果能够存下一整个K轴
        if buffer_size > stick_total_k:
            # 额外常驻多少个移动块
            x = (buffer_size - stick_total_k) // moving_tile_size + 1
            if x > k_tile * moving_tile:
                x = k_tile * moving_tile
            # M轴切块数量 * K轴切块数量 * A矩阵大小 + M轴切块数量 * （N轴切块数量 * K轴切块数量 - x） * B矩阵大小 + x * B矩阵大小
            stick_size = stick_tile * k_tile * stick_tile_size
            moving_size = stick_tile * (moving_tile * k_tile - x) * moving_tile_size + x * moving_tile_size
        else:
            # 没办法常驻一整个K轴，那么多出来的空间，尽量多常驻几个常驻矩阵tile
            x = (buffer_size - self.db * moving_tile_size - self.db * stick_tile_size) // stick_tile_size
            if x > k_tile:
                raise ValueError(f"x = {x} should <= k_tile {k_tile}")
            stick_size = moving_tile * stick_tile * (k_tile - x) * stick_tile_size
            moving_size = x * stick_tile_size * stick_tile + stick_tile * moving_tile * k_tile * moving_tile_size

        return stick_size + moving_size, stick_size, moving_size

    @staticmethod
    def __calc_min_access_without_k(stick_tile_size: float, moving_tile_size: float, stick_tile: float,
                                    moving_tile: float, k_tile: float, buffer_size: float) \
            -> tuple[float, float, float]:
        """
        不贯穿K轴的情况下的最小访存求取
        :param stick_tile_size:     常驻的矩阵基本块大小
        :param moving_tile_size:    移动的矩阵基本块大小
        :param stick_tile:          常驻轴切分块数
        :param moving_tile:         移动轴切分块数
        :param k_tile:              K轴切分块数
        :param buffer_size:         缓存大小
        :return:                    最小访存量
        """
        x = (buffer_size - stick_tile_size) // moving_tile_size - 2
        if x > k_tile:
            x = k_tile
        stick_size = stick_tile * k_tile * stick_tile_size
        moving_size = moving_tile * (stick_tile * k_tile - x) * moving_tile_size + x * moving_tile * moving_tile_size
        return stick_size + moving_size, stick_size, moving_size

    def __get_bw(self, src_mem: MemLoc, dst_mem: MemLoc, y, x, d_size, core_num):
        """
        获取小包带宽
        Args:
            src_mem:    起点
            dst_mem:    终点
            y:          矩阵的行数
            x:          矩阵的列数
            d_size:     数据精度大小
            core_num:    核数

        Returns:

        """
        pkt_size = y * d_size if x == 1 else x * d_size
        bw, _ = self.arc_spec.lookup_bw(src_mem, dst_mem, core_num, pkt_size)
        return bw

    def __get_min_access(self, direction, a_size, b_size, m_tile, n_tile, k_tile, buffer_size):
        # 贯穿M轴（常驻A矩阵）
        if direction == 0:
            min_access, min_a, min_b = self.__calc_min_access_without_k(stick_tile_size=a_size,
                                                                        moving_tile_size=b_size,
                                                                        stick_tile=m_tile,
                                                                        moving_tile=n_tile,
                                                                        k_tile=k_tile,
                                                                        buffer_size=buffer_size)

        # 贯穿N轴（常驻B矩阵）
        elif direction == 1:
            min_access, min_b, min_a = self.__calc_min_access_without_k(stick_tile_size=b_size,
                                                                        moving_tile_size=a_size,
                                                                        stick_tile=n_tile,
                                                                        moving_tile=m_tile,
                                                                        k_tile=k_tile,
                                                                        buffer_size=buffer_size)

        # 贯穿K轴（常驻A）
        elif direction == 2:
            min_access, min_a, min_b = self.__calc_min_access_through_k(stick_tile_size=a_size,
                                                                        moving_tile_size=b_size,
                                                                        stick_tile=m_tile,
                                                                        moving_tile=n_tile,
                                                                        k_tile=k_tile,
                                                                        buffer_size=buffer_size)

        # 贯穿K轴（常驻B）
        elif direction == 3:
            min_access, min_b, min_a = self.__calc_min_access_through_k(stick_tile_size=b_size,
                                                                        moving_tile_size=a_size,
                                                                        stick_tile=n_tile,
                                                                        moving_tile=m_tile,
                                                                        k_tile=k_tile,
                                                                        buffer_size=buffer_size)
        else:
            raise ValueError("direction should be 0,1,2,3")

        return min_access, min_a, min_b

    def _tiling_decode(self, tiling, m, k, n) -> list:
        split_m, split_n, split_k = True, True, False
        if len(tiling) == 3:
            tm, tn, tk = tiling
            self.db = 2
        elif len(tiling) == 4:
            tm, tn, tk, self.db = tiling
        elif len(tiling) == 6:
            tm, tn, tk, split_m, split_n, split_k = tiling
        elif len(tiling) == 7:
            tm, tn, tk, self.db, split_m, split_n, split_k = tiling
        else:
            raise ValueError("tiling must be [m,n,k] or [m,n,k,db] or [split_m,split_n,split_k]")

        tm, tn, tk = min(tm, m), min(tn, n), min(tk, k)
        return [tm, tn, tk, split_m, split_n, split_k]

    def predict(self,
                shapes: list[list[int]],
                input_dtype: DType,
                output_dtype: DType,
                tiling: list[float],
                model_level: ModelLevel = ModelLevel.MODEL_L3,
                block_dim: int = None,
                **kwargs) -> tuple[float, float, float, float]:
        """
        采用snowCat的基础模型求解最小访存下的时间
        Args:
            shapes:         [m,k][k,n] or [m,k][n,k]，均支持
            input_dtype:    输入的张量数据格式
            output_dtype:   输出张量的数据格式（暂时没有用到），NEXT 测试不同输出数据格式对于时间是否影响
            tiling:         tiling的设置，支持 len = 3,4,6,7 四种长度，各种长度代表的含义见源码
            model_level:    lv3：不考虑小包。 lv2：考虑小包
            block_dim:      核数，不填写则默认满核
            **kwargs:
        Returns:
        """
        m, k, n = _parse_input(shapes)
        tm, tn, tk, split_m, split_n, split_k = self._tiling_decode(tiling, m, k, n)

        # 默认满核
        if block_dim is None:
            block_dim = self.arc_spec.core_config.cube_core_num

        tiling_direction = kwargs.get('tiling_direction')

        src_mem: MemLoc = kwargs.get('src_mem')
        dst_mem: MemLoc = kwargs.get('dst_mem')
        mid_buffer_name: MemLoc = kwargs.get('mid_buffer')
        m_tile, n_tile, k_tile = (m + tm - 1) // tm, (n + tn - 1) // tn, (k + tk - 1) // tk
        a_size, b_size = tm * tk * input_dtype.size, tn * tk * input_dtype.size

        # 分核数量
        tile_can_be_split = (m_tile if split_m else 1) * (n_tile if split_n else 1) * (k_tile if split_k else 1)
        actual_core_num = min(tile_can_be_split, block_dim)

        mid_buffer = self.arc_spec.lookup_cache_size(mid_buffer_name)
        mid_buffer_size = mid_buffer[1]
        # 核内cache用需要乘以核数表示总容量
        if mid_buffer[0] == MemType.LOCAL_MEM:
            mid_buffer_size *= actual_core_num
        min_access, min_a, min_b = self.__get_min_access(tiling_direction, a_size, b_size, m_tile, n_tile, k_tile, mid_buffer_size)
        repeat_cycles = self.arc_spec.cube_config.cube_repeat_cycles[input_dtype]
        cube_shape = self.arc_spec.cube_config.cube_throughput[input_dtype]
        freq = self.arc_spec.clock_freq

        # 计算时间
        tile_computing_time = (((tm + cube_shape[0] - 1) // cube_shape[0]) * (
                (tk + cube_shape[1] - 1) // cube_shape[1]) * ((tn + cube_shape[2] - 1) // cube_shape[2])) / freq * repeat_cycles

        # lv3，不考虑小包搬运影响
        if model_level == ModelLevel.MODEL_L3:
            bw, _ = self.arc_spec.lookup_bw(src_mem, dst_mem, actual_core_num)
            # 如果不是总带宽，则需要*实际用到的核数来修正
            if self.arc_spec.lookup_cache_type(src_mem) == MemType.LOCAL_MEM or self.arc_spec.lookup_cache_type(
                    dst_mem) == MemType.LOCAL_MEM:
                bw *= actual_core_num
            tile_move_time = (a_size + b_size) / bw
            memory_time = min_access / bw
        else:
            bw_a = self.__get_bw(src_mem, dst_mem, tm, tk, input_dtype.size, actual_core_num)
            bw_b = self.__get_bw(src_mem, dst_mem, tk, tn, input_dtype.size, actual_core_num)
            memory_time = min_a / bw_a + min_b / bw_b
            tile_move_time = a_size / bw_a + b_size / bw_b

        tile_cnt = m_tile * n_tile * k_tile
        compute_time = tile_computing_time * tile_cnt / actual_core_num

        core_time = memory_time + compute_time if self.db == 1 else max(memory_time - tile_move_time, compute_time) + tile_move_time

        return core_time, compute_time, memory_time, min_access
