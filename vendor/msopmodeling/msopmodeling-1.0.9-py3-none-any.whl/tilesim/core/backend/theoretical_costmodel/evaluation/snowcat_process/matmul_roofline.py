from core.backend.theoretical_costmodel.basic_stage_roofline.basic_cost_api import ModelLevel
from core.backend.theoretical_costmodel.evaluation.snowcat_process.cube_roofline_by_min_access import \
    MinAccessCubeRoofline
from core.common.entity import DType, MemLoc, MemType
from core.common.log_format import logging
from core.config.arc_spec import ArcConfig

logger = logging.getLogger(__name__)


class MatmulRoofline:

    def __init__(self,
                 input_shapes: list[list[int]],
                 input_d_type: DType,
                 output_d_type: DType,
                 arc_config: ArcConfig,
                 block_dim: int = None,
                 model_level: ModelLevel = ModelLevel.MODEL_L3):
        self.model_level = model_level
        m, ka = input_shapes[0]
        n, kb = input_shapes[1]
        if ka != kb:
            kb, n = input_shapes[1]

        if ka != kb:
            raise ValueError("input shape not match")

        self.m = m
        self.n = n
        self.k = ka
        self.input_d_type = input_d_type
        self.output_d_type = output_d_type
        self.arc_config = arc_config
        l1_cache = self.arc_config.lookup_cache_size(MemLoc.L1)
        if l1_cache[0] != MemType.LOCAL_MEM:
            raise ValueError("L1 cache size not in local memory")
        l1_cache_size = l1_cache[1]
        self.l1_cache_element_cnt = l1_cache_size / self.input_d_type.size
        self.block_dim = block_dim if block_dim is not None else self.arc_config.core_config.cube_core_num

    def tiling_valid(self, tiling: list[float]) -> bool:
        tm, tn, tk, db, *_ = tiling

        q_size = tm * tk * db
        k_size = tn * tk * db

        if q_size + k_size > self.l1_cache_element_cnt:
            return False
        return True

    def get_tiling_range(self, step: float) -> list[tuple[float, float]]:
        min_dim = step

        m_min = min(step, self.m)
        n_min = min(min_dim, self.n)

        q_min_size = m_min * step
        k_min_size = n_min * step

        m_max = min(self.m, int((self.l1_cache_element_cnt - k_min_size) / step / 2))
        n_max = min(self.n, int((self.l1_cache_element_cnt - q_min_size) / step / 2))
        k_max = min(self.k, int(self.l1_cache_element_cnt / step))

        range_list = [
            # m,n,k大小
            (m_min, m_max),
            (n_min, n_max),
            (step, k_max),

            # 是否开启DB
            (1, 2),

            # 是否进行M、N、K轴分核
            (0, 1),
            (0, 1),
            (0, 1)
        ]
        return range_list

    def _calc_roofline(self, tiling, src_mem, dst_mem):
        kwargs = {
            "tiling_direction": 2,
            "src_mem": src_mem,
            "dst_mem": dst_mem,
            "mid_buffer": dst_mem,
        }

        cube_roofline = MinAccessCubeRoofline(self.arc_config)
        res_roofline_matmul_gm_l2 = cube_roofline.predict(
            shapes=[[self.m, self.k], [self.k, self.n]],
            input_dtype=self.input_d_type,
            output_dtype=self.output_d_type,
            tiling=tiling,
            model_level=self.model_level,
            block_dim=self.block_dim,
            **kwargs
        )
        return res_roofline_matmul_gm_l2

    def get_roofline(self, tiling: list[float]) -> list[float]:
        # 判断是否满足约束
        if not self.tiling_valid(tiling):
            return [float('inf')]

        # L2-->L1-->计算核
        res_roofline_matmul_l2_l1 = self._calc_roofline(tiling, MemLoc.L2, MemLoc.L1)

        cube_core_time = res_roofline_matmul_l2_l1[0]
        cube_time = res_roofline_matmul_l2_l1[1]
        gm_l2_time = 0
        l2_l1_time = res_roofline_matmul_l2_l1[2]
        l2_l1_data_size = res_roofline_matmul_l2_l1[3]
        gm_l2_data_size = 0

        # GM-->L2-->计算核
        try:

            res_roofline_matmul_gm_l2 = self._calc_roofline(tiling, MemLoc.GM, MemLoc.L2)

            # 两段取瓶颈
            res_roofline_matmul = res_roofline_matmul_l2_l1 if res_roofline_matmul_l2_l1[0] > res_roofline_matmul_gm_l2[
                0] else res_roofline_matmul_gm_l2
            cube_core_time = res_roofline_matmul[0]
            cube_time = res_roofline_matmul[1]
            l2_l1_time = res_roofline_matmul_l2_l1[2]
            gm_l2_time = res_roofline_matmul_gm_l2[2]
            gm_l2_data_size = res_roofline_matmul_gm_l2[3]
        except KeyError as e:
            # 可能不存在GM——L2的通路
            logger.warning("KeyError: %s", e)
        return [cube_core_time, cube_time, gm_l2_time, l2_l1_time, gm_l2_data_size, l2_l1_data_size]
