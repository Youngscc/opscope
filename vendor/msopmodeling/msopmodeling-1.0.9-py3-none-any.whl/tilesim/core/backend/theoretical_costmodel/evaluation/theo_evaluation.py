# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from abc import ABC, abstractmethod
from copy import copy

from core.backend.backend_entity.backend_logistic import OpEntity
from core.backend.backend_entity.backend_math import EvalCtxEntity
from core.common.backend_config import BackendConfig
from core.pipeline.basic_operator import OperatorResult


class TheoEvaluation(ABC):

    def __init__(self, backend_config: BackendConfig, eval_ctx: EvalCtxEntity):
        self.backend_config = copy(backend_config)
        self.eval_ctx = copy(eval_ctx)
        self.trace = []
        self.eval_config = self.backend_config.eval_config

    @abstractmethod
    def eval(self, op_list: list[OpEntity]) -> OperatorResult:
        pass
