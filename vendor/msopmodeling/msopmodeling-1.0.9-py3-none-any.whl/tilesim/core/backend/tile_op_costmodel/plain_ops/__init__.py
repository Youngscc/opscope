# pypto_ops/__init__.py
# 每新增一个文件，在这里加一行，或者写个脚本自动扫描
import pkgutil
import importlib

# 自动import所有.py文件
for m in pkgutil.iter_modules(__path__):
    if not m.ispkg:
        importlib.import_module(f"{__name__}.{m.name}")