# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math

from core.backend.theoretical_costmodel.evaluation.snowcat_process.matmul_roofline import MatmulRoofline
from core.backend.theoretical_costmodel.optimizer_algo.ga_optimizer import Optimizer
from core.backend.tile_op_costmodel.tile_op_backend_entity import TileOpEntity, TileOpLatency, TileEntity
from core.backend.tile_op_costmodel.tile_op_registry import tile_op_handler
from core.common import MemLoc
from core.common.entity import CoreUnit
from core.common.tile_op_enum import TileOpCode, TileOpType


def _calculate_best_k0(cube_m, cube_n):
    best_k0 = 32
    tile_limit_size = 32 * 1024
    if cube_m * 256 * 2 <= tile_limit_size and cube_n * 256 * 2 <= tile_limit_size:
        best_k0 = 256
    elif cube_m * 128 * 2 <= tile_limit_size and cube_n * 128 * 2 <= tile_limit_size:
        best_k0 = 128
    elif cube_m * 64 * 2 <= tile_limit_size and cube_n * 64 * 2 <= tile_limit_size:
        best_k0 = 64

    return best_k0


@tile_op_handler(opcode=TileOpCode.GEMM, op_type=TileOpType.PLAIN, version=1)
def plain_gemm_based_on_l1_pipe(tile_op: TileOpEntity) -> TileOpLatency:
    if tile_op.opcode != TileOpCode.GEMM:
        raise Exception(f"not support opcode {tile_op.opcode.name}")

    # 提取左右矩阵，并校验
    lef_tile: TileEntity = tile_op.i_operand[0]
    right_tile: TileEntity = tile_op.i_operand[1]
    # NEXT -- 输入数据位置和精度类型可能不一样
    if lef_tile.buffer_type != MemLoc.L1 or right_tile.buffer_type != MemLoc.L1:
        raise Exception("gemm input should in L1")

    if lef_tile.data_type_str != right_tile.data_type_str:
        raise Exception("gemm input data type should be the same")

    # 提取基础大小（L1 tiling size）
    d_type = lef_tile.data_type_str
    m, k = lef_tile.shape
    kb, n = right_tile.shape
    if kb != k:
        n, kb = right_tile.shape

    if kb != k:
        raise Exception("gemm input shape should be the same")

    arc_config = tile_op.context.arc_config

    k0 = _calculate_best_k0(m, n)
    size_a0 = m * k0 * d_type.size
    size_b0 = k0 * n * d_type.size

    # 计算搬运时间
    l0a_bw, is_small_pkt_a = arc_config.lookup_bw(MemLoc.L1, MemLoc.L0A, pkt_size=size_a0 if tile_op.context.enable_small_pkt_bw else -1)
    l0b_bw, is_small_pkt_b = arc_config.lookup_bw(MemLoc.L1, MemLoc.L0B, pkt_size=size_b0 if tile_op.context.enable_small_pkt_bw else -1)
    copy_time = m * k * d_type.size / l0a_bw + n * k * d_type.size / l0b_bw

    # 计算计算时间
    basic_m, basic_k, basic_n = arc_config.cube_config.cube_throughput.get(d_type)
    repeat_cycles = arc_config.cube_config.cube_repeat_cycles.get(d_type)
    repeats = math.ceil(m / basic_m) * math.ceil(k / basic_k) * math.ceil(n / basic_n)
    compute_time = repeats * repeat_cycles / arc_config.clock_freq

    # 计算首块搬运时间
    first_tile_copy_time = size_a0 / l0a_bw + size_b0 / l0b_bw

    latency = max(copy_time - first_tile_copy_time, compute_time) + first_tile_copy_time

    data_transfer = {
        (MemLoc.L1, MemLoc.L0A): m * k * d_type.size,
        (MemLoc.L1, MemLoc.L0B): k * n * d_type.size,
    }
    small_pkt_transfer = {}
    if is_small_pkt_a:
        small_pkt_transfer[(MemLoc.L1, MemLoc.L0A)] = m * k * d_type.size
    if is_small_pkt_b:
        small_pkt_transfer[(MemLoc.L1, MemLoc.L0B)] = k * n * d_type.size
    cycles = int(latency * arc_config.clock_freq)
    return TileOpLatency(
        latency=latency,
        unit_latency={CoreUnit.CUBE: compute_time, CoreUnit.AIC_MTE1: copy_time},
        data_transfer=data_transfer,
        cycles=cycles,
        small_pkt_transfer=small_pkt_transfer
    )


_OPTIM_ITER_NUM = 100


def _call_matmul_snowcat(tile_op: TileOpEntity, m, k, n, a_matrix, b_matrix):
    matmul = MatmulRoofline(
        input_shapes=[[m, k], [k, n]],
        input_d_type=a_matrix.data_type_str,
        output_d_type=b_matrix.data_type_str,
        arc_config=tile_op.context.arc_config,
        block_dim=tile_op.context.core_num,
    )
    step = 32 / a_matrix.data_type_str.size
    param_range = matmul.get_tiling_range(step)

    optimize = Optimizer(
        value_func=matmul.get_roofline,
        params_range=param_range,
        step=[step],
        iter_num=_OPTIM_ITER_NUM
    )
    optimize.set_constraint(matmul.tiling_valid)
    best_tiling, _ = optimize.optimize()
    core_time, cube_time, gm_time, l2_time, gm_l2_data_size, l2_l1_data_size = matmul.get_roofline(best_tiling)

    data_transfer = {
        (MemLoc.GM, MemLoc.L2): gm_l2_data_size,
        (MemLoc.L2, MemLoc.L1): l2_l1_data_size,
    }

    if a_matrix.buffer_type == MemLoc.L2:
        copy_time = l2_time
    else:
        copy_time = max(gm_time, l2_time)

    return core_time, cube_time, copy_time, data_transfer


@tile_op_handler(opcode=TileOpCode.GEMM, op_type=TileOpType.PLAIN, version=-1)
def plain_gemm_based_on_snowcat(tile_op: TileOpEntity) -> TileOpLatency:
    if tile_op.opcode != TileOpCode.GEMM:
        raise Exception(f"not support opcode {tile_op.opcode.name}")

    if len(tile_op.i_operand) != 2:
        raise Exception("gemm should have 2 input operand")

    if len(tile_op.o_operand) != 1:
        raise Exception("gemm should have 1 output operand")

    a_matrix, b_matrix = tile_op.i_operand
    c_matrix = tile_op.o_operand[0]

    ma, ka = a_matrix.shape
    kb, nb = b_matrix.shape
    mc, nc = c_matrix.shape

    if ka != kb:
        nb, kb = b_matrix.shape

    if ka != kb or ma != mc or nb != nc:
        raise Exception("gemm input shape not match")

    m, k, n = ma, ka, nb
    core_time, cube_time, copy_time, data_transfer = _call_matmul_snowcat(tile_op, m, k, n, a_matrix, b_matrix)

    cycles = int(core_time * tile_op.context.arc_config.clock_freq)

    return TileOpLatency(
        latency=core_time,
        unit_latency={
            CoreUnit.CUBE: cube_time,
            CoreUnit.AIC_MTE2: copy_time,
        },
        data_transfer=data_transfer,
        cycles=cycles
    )


@tile_op_handler(opcode=TileOpCode.MMAD, op_type=TileOpType.PLAIN, version=1)
def plain_mmad(tile_op: TileOpEntity) -> TileOpLatency:
    lef_tile: TileEntity = tile_op.i_operand[0]
    right_tile: TileEntity = tile_op.i_operand[1]
    # NEXT -- 输入数据位置和精度类型可能不一样
    if lef_tile.buffer_type != MemLoc.L0A or right_tile.buffer_type != MemLoc.L0B:
        raise Exception("mmad input should in L0")

    if lef_tile.data_type_str != right_tile.data_type_str:
        raise Exception("mmad input data type should be the same")

    # 提取基础大小（L1 tiling size）
    d_type = lef_tile.data_type_str
    m, k = lef_tile.shape
    kb, n = right_tile.shape
    if kb != k:
        n, kb = right_tile.shape

    if kb != k:
        raise Exception("mmad input shape should be the same")

    arc_config = tile_op.context.arc_config

    # 计算计算时间
    basic_m, basic_k, basic_n = arc_config.cube_config.cube_throughput.get(d_type)
    repeat_cycles = arc_config.cube_config.cube_repeat_cycles.get(d_type)
    repeats = math.ceil(m / basic_m) * math.ceil(k / basic_k) * math.ceil(n / basic_n)
    cycles = int(repeats * repeat_cycles)
    compute_time = cycles / arc_config.clock_freq
    return TileOpLatency(latency=compute_time, unit_latency={CoreUnit.CUBE: compute_time}, cycles=cycles)