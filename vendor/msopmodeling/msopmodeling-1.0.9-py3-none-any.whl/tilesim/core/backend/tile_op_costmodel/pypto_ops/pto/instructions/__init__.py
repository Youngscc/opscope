import pkgutil
import importlib

# 自动import所有.py文件
for m in pkgutil.iter_modules(__path__):
    if not m.ispkg:
        importlib.import_module(f"{__name__}.{m.name}")