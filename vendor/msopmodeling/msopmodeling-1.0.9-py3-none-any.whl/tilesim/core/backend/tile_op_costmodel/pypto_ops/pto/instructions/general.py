from ..pto_registry import pto_register


@pto_register("general")
def cost_general(parameters, ctx=None):
    return 1