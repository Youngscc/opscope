# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from core.common.entity import DType
from core.backend.engineering_costmodel.op_model.pto.entity import PTOTile


class PTOInterface(object):
    def __hash__(self):
        return hash(tuple(
            v for k, v in sorted(self.__dict__.items())
            if not k.startswith('_') and self._is_hashable(v)
        ))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return NotImplemented
        return self.__dict__ == other.__dict__

    @staticmethod
    def _is_hashable(v):
        try:
            hash(v)
            return True
        except TypeError:
            return False


class UnaryInst(PTOInterface):
    """
    TLOAD, TSTORE, TEXP, TCVT
    """
    def __init__(self, dst, src):
        self.dst = dst
        self.src = src


class BinaryInst(PTOInterface):
    """
    TADD,TSUB,TMUL,TMIN,TDIV
    """
    def __init__(self, dst, src0, src1):
        self.dst: PTOTile = dst
        self.src0: PTOTile = src0
        self.src1: PTOTile = src1


class ReduceInst(PTOInterface):
    """
    TROWSUM TROWMAX
    """
    def __init__(self, dst, src, tmp):
        self.dst: PTOTile = dst
        self.src: PTOTile = src
        self.tmp: PTOTile = tmp


class ScaleInst(PTOInterface):
    def __init__(self, dst, src0, scalar):
        self.dst: PTOTile = dst
        self.src0: PTOTile = src0
        self.scalar: DType = scalar


class TMATMUL(PTOInterface):
    def __init__(self, c_matrix, a_matrix, b_matrix):
        self.c_matrix: PTOTile = c_matrix
        self.a_matrix: PTOTile = a_matrix
        self.b_matrix: PTOTile = b_matrix


class TMATMUL_BIAS(PTOInterface):
    def __init__(self, c_matrix, a_matrix, b_matrix, bias_data):
        self.c_matrix: PTOTile = c_matrix
        self.a_matrix: PTOTile = a_matrix
        self.b_matrix: PTOTile = b_matrix
        self.bias_data: PTOTile = bias_data


class TMATMUL_ACC(PTOInterface):
    def __init__(self, c_out_matrix, c_in_matrix, a_matrix, b_matrix):
        self.c_out_matrix: PTOTile = c_out_matrix
        self.c_in_matrix: PTOTile = c_in_matrix
        self.a_matrix: PTOTile = a_matrix
        self.b_matrix: PTOTile = b_matrix