# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Dict, Any
from functools import lru_cache
from core.backend.tile_op_costmodel.pypto_ops.pto.pto_interface import PTOInterface
from core.config.arc_spec import ArcConfig

_PTO_REGISTRY = {}


def pto_register(inst):
    def wrapper(func):
        _PTO_REGISTRY[inst] = func
        return func

    return wrapper


@lru_cache(maxsize=None)
def pto_dispatch(inst: str, pto_params: PTOInterface, *, ctx: Dict[str, Any] = None) -> int:
    func = _PTO_REGISTRY.get(inst) or _PTO_REGISTRY.get("general")
    if func is None:
        raise KeyError(f"No PTO instruction registered for {inst!r} and no fallback 'general'.")
    cycles = int(func(pto_params, ctx=ctx))
    return cycles