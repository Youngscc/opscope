# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from core.backend.tile_op_costmodel.tile_op_backend_entity import TileOpLatency, TileOpEntity
from core.backend.tile_op_costmodel.pypto_ops.pto.pto_registry import pto_dispatch
from core.backend.engineering_costmodel.op_model.pto.entity import PTOTile
from core.backend.tile_op_costmodel.pypto_ops.pto.pto_interface import ScaleInst
from core.backend.tile_op_costmodel.pypto_ops.functions import convert_shapes, get_address, opcode_pto_projection
from core.backend.tile_op_costmodel.tile_op_registry import tile_op_handler, TileOpType
from core.common.entity import CoreUnit
from core.common.tile_op_enum import TileOpCode


def scale(tile_op: TileOpEntity) -> TileOpLatency:
    opcode = tile_op.opcode
    in_tile = tile_op.i_operand[0]
    out_tile = tile_op.o_operand[0]
    shapes = [in_tile.shape, out_tile.shape]
    # 获取地址
    in_addr = get_address(in_tile.offset, in_tile.raw_shape, in_tile.raw_magic, in_tile.start_addr)
    out_addr = get_address(out_tile.offset, out_tile.raw_shape, out_tile.raw_magic, out_tile.start_addr)
    # 维度转换
    new_shapes, repeat = convert_shapes(shapes, out_tile.data_type_str.size)
    cycles = 0

    src = PTOTile(new_shapes[0][0], new_shapes[0][1], out_tile.data_type_str, in_addr)
    dest = PTOTile(new_shapes[1][0], new_shapes[1][1], out_tile.data_type_str, out_addr)
    pto_inst = opcode_pto_projection(opcode.value)
    repeat_times = max(repeat)
    for _ in range(repeat_times):
        # 调用该tile op对应的pto instruction
        cycles += pto_dispatch(pto_inst, ScaleInst(dest, src, out_tile.data_type_str))
    latency = cycles / tile_op.context.arc_config.clock_freq
    return TileOpLatency(latency=latency, unit_latency={CoreUnit.VEC: latency}, cycles=cycles)


@tile_op_handler(opcode=[TileOpCode.ADDS, TileOpCode.SUBS, TileOpCode.MULS, TileOpCode.DIVS, 
                TileOpCode.MAXS, TileOpCode.MINS], op_type=TileOpType.PyPTO)
def scale_costmodel(tile_op: TileOpEntity) -> TileOpLatency:
    return scale(tile_op)