# TileOp Costmodel使用和实现

## 1. 实现

### 1.1 增加TileOpCode & TileOpType 枚举值

TileOpCode：表示的是TileOp的名字，不同平台（PyPTO、TBE、TileLang等）尽量保持命名统一，尽量复用目前已有的TileOpCode。如遇到命名风格不同的，可以通过接口的str转换处理，后续接口实现会说明。
TileOpType：表示的TileOp Costmodel的实现方式，比如PyPTO实现的TADD和TileLang的T.Add二者性能肯定不同，所以对应到后端调用的Costmodel也不同。这里TileOpType就是为了做此区分。此外，可能会存在Costmodel的迭代，该枚举变量同样可以作为Version Tag使用。当需要实现的TileOp Costmodel是一个新的平台/新的Version时，需要补充该Enum变量范围。

### 1.2 TileOp Costmodel的实现
TileOp的实现使用 @tile_op_handler 修饰器修饰，需要传入 opcode\op_type\version，其中 opcode\op_type 定义如上， version为可选参数，默认为1。
version为int类型，表示相同的不同版本，定义tile_op costmodel的时候，可以不输入，默认为0
调用tile_op costmodel的时候，如果不指定具体的version，会使用version最大的版本
version的作用主要用于同一平台不同的版本，导致部分的tile op性能有差异

**需要注意，TileOp的函数实现，输入格式规定为TileOpEntity，输出格式为TileOpLatency，且一定要在函数上显式的声明**

如后续需要补充额外的输入信息，**在TileOpEntity中进行属性扩充，不要直接修改Costmodel实现入参的内容**

具体的案例可以参照：
backend_costmodel.tile_op_costmodel.pypto_ops.binary.pypto_add

## 2. 调用

### 2.1 基础入口

后端costmodel的调用入口为：
backend_costmodel.tile_op_costmodel.tile_op_registry.tile_op_dispatch

### 2.2 对外接口
**1） 对于PyPTO实现的TileOp**
无论是C++还是Python，统一从 api.tile_op_api.tile_op_costmodel.tile_op_latency_predict_pypto 入口调用。
该入口区分了 接口类 TileOpDTO\TileDTO 和 后端实体类 TileOpEntity\TileEntity， **注意二者不要混用**

**2) 对于其他方式实现的（如TileLang）TileOp**
需要扩展接口，可能需要重新实现接口类，并和后端实体类进行转换。
设计原则只要满足 **接口实体类与对方需求\接口需求完全匹配，通过转换得到后端实体类** 即可


*TODO PTO Inst的统一入口还没有实现，后续完善*