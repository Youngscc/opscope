# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from dataclasses import dataclass, field

from core.backend.backend_entity.backend_entity import TensorEntity
from core.common.entity import DType, MemLoc, CoreUnit
from core.common.tile_op_enum import TileOpCode
from core.config.arc_spec import ArcConfig


@dataclass
class TileEntity:
    # tile唯一标识
    magic: int | str
    # tile的数据精度格式
    data_type_str: DType
    # tile所处位置
    buffer_type: MemLoc
    # tile的形状（仅允许二维）
    shape: list[int]
    # tile相较于原始Tensor的位置
    offset: list[int] = None
    # 原始global tensor的唯一标识
    raw_magic: int | str = None
    # 原始global tensor的shape
    raw_shape: list[int] = None
    # 地址信息：十进制地址，默认0x0
    start_addr: int = 0

    @staticmethod
    def from_op_entity(tensor: TensorEntity) -> 'TileEntity':
        return TileEntity(
            magic=tensor.name,
            data_type_str=tensor.dtype,
            buffer_type=tensor.mem_loc,
            shape=tensor.shape,
            offset=tensor.offset,
            raw_magic=tensor.raw_name,
            raw_shape=tensor.raw_shape
        )

    def __eq__(self, other):
        if not isinstance(other, TileEntity):
            return False
        return (self.data_type_str == other.data_type_str and
                self.buffer_type == other.buffer_type and
                tuple(self.shape) == tuple(other.shape))

    def __hash__(self):
        return hash((self.data_type_str, self.buffer_type, tuple(self.shape)))


@dataclass
class TileOpContext:
    # 微架构平台
    arc_config: ArcConfig
    # 实际用到的核数
    core_num: int
    # 是否需要barrier
    barrier: bool
    # 是否开启小包搬运的带宽系数拟合
    enable_small_pkt_bw: bool

    def __eq__(self, other):
        if not isinstance(other, TileOpContext):
            return False
        return (self.arc_config.spec_name == other.arc_config.spec_name and
                self.core_num == other.core_num and
                self.barrier == other.barrier and
                self.enable_small_pkt_bw == other.enable_small_pkt_bw)

    def __hash__(self):
        return hash((self.arc_config.spec_name, self.core_num, self.barrier, self.enable_small_pkt_bw))


@dataclass
class TileOpEntity:
    # tileOp的唯一标识
    magic: int | str
    # tileOp的类型
    opcode: TileOpCode
    # tileOp的输入operand
    i_operand: list[TileEntity]
    # tileOp的输出operand
    o_operand: list[TileEntity]
    # 建模用到的额外入参
    context: TileOpContext = None

    def __eq__(self, other):
        if not isinstance(other, TileOpEntity):
            return False
        return (self.opcode == other.opcode and
                tuple(self.i_operand) == tuple(other.i_operand) and
                tuple(self.o_operand) == tuple(other.o_operand) and
                self.context == other.context)

    def __hash__(self):
        return hash((self.opcode, tuple(self.i_operand), tuple(self.o_operand), self.context))


@dataclass
class TileOpLatency:
    # tileOp花费的时间，单位： us
    latency: float
    cycles: float
    # 组件时间
    unit_latency: dict[CoreUnit, float]
    # 各数据通路的搬运数据量： {(src_mem, dst_mem): data_vol}
    data_transfer: dict[tuple[MemLoc, MemLoc], float] = field(default_factory=dict)
    # 小包搬运数据量： {(src_mem, dst_mem): data_vol}
    small_pkt_transfer: dict[tuple[MemLoc, MemLoc], float] = field(default_factory=dict)