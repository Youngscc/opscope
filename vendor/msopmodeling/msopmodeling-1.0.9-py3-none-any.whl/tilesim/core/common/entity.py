# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from dataclasses import dataclass, field
from enum import Enum
from typing import Set

from fontTools.ufoLib.utils import deprecated

from core.common.log_format import logging

# 创建一个日志记录器
logger = logging.getLogger(__name__)

GB_TO_B = 1024 * 1024 * 1024


class CoreType(Enum):
    AIC = (0, "AIC")
    AIV = (1, "AIV")
    MIX = (2, "MIX")
    CPU = (3, "CPU")

    def __init__(self, order, desc):
        self.order = order
        self.desc = desc


class CoreUnit(Enum):
    CUBE = ("cube", CoreType.AIC)
    VEC = ("vec", CoreType.AIV)
    AIC_MTE1 = ("aic_mte1", CoreType.AIC)
    AIC_MTE2 = ("aic_mte2", CoreType.AIC)
    AIC_MTE3 = ("aic_mte3", CoreType.AIC)
    AIC_FIXPIPE = ("aic_fixpipe", CoreType.AIC)
    AIC_SCALAR = ("aic_scalar", CoreType.AIC)
    AIV_MTE2 = ("aiv_mte2", CoreType.AIV)
    AIV_MTE3 = ("aiv_mte3", CoreType.AIV)
    AIV_SCALAR = ("aiv_scalar", CoreType.AIV)
    HOST = ("host", CoreType.CPU)

    def __init__(self, desc: str, core_type: CoreType):
        self.desc = desc
        self.core_type = core_type

    @staticmethod
    def from_str(core_unit_str):
        for unit in CoreUnit:
            if unit.desc == core_unit_str:
                return unit
        raise ValueError(f"Unsupported CoreUnit: ")


class OpLevel(Enum):
    TENSOR_OP = 'TensorOp'
    TILE_OP = 'TileOp'
    HOST_OP = 'HostOp'

    @staticmethod
    def from_str(op_level_str):
        for op_level in OpLevel:
            if op_level.value == op_level_str:
                return op_level
        raise ValueError(f"Unsupported OpLevel: {op_level_str}")


class MemLoc(Enum):
    GM = "GM"
    SRAM = "SRAM"
    UB = "UB"
    L1 = "L1"
    L0A = "L0A"
    L0B = "L0B"
    L0C = "L0C"
    L2 = "L2"
    SHM = "SHM"

    @staticmethod
    def from_str(mem_loc_str):
        for mem_loc in MemLoc:
            if mem_loc.value == mem_loc_str:
                return mem_loc
        raise ValueError(f"Invalid mem_loc string: {mem_loc_str}")

    @staticmethod
    def path_name(*args) -> str:
        """支持输入 tuple(src_mem, dst_mem)/ list[src_mem, dst_mem]/ src_mem, dst_mem， 所有mem都可以是MemLoc或str"""

        if len(args) == 1:
            src_mem, dst_mem = args[0]
        elif len(args) == 2:
            src_mem, dst_mem = args
        else:
            raise ValueError("path_name() takes 1 or 2 arguments")

        src_name = src_mem.name if isinstance(src_mem, MemLoc) else src_mem.upper()
        dst_name = dst_mem.name if isinstance(dst_mem, MemLoc) else dst_mem.upper()
        return f"{src_name}_2_{dst_name}"


class MemType(Enum):
    LOCAL_MEM = "local_mem"
    SHARE_MEM = "share_mem"

    @staticmethod
    def from_str(mem_type_str):
        for mem_type in MemType:
            if mem_type.value == mem_type_str:
                return mem_type
        raise ValueError(f"Invalid mem_type string: {mem_type_str}")


class CycleType(Enum):
    COMPUTING_CYCLES = "computing_cycles"
    HEAD_CYCLES = "head_cycles"
    INTERVAL_CYCLES = "interval_cycles"


@deprecated("新版工程可达完善后弃用")
class DirectionType(Enum):
    Z = "Z"
    N = "N"

    def __init__(self, desc):
        self.desc = desc

    @staticmethod
    def from_str(direction_str):
        if direction_str == "Z":
            return DirectionType.Z
        elif direction_str == "N":
            return DirectionType.N
        else:
            return None  # 添加默认返回值


class BackendType(Enum):
    ENG = "eng"
    THEO = "theo"
    ENG_CLASSIC = "eng_classic"

    @staticmethod
    def from_str(backend_type: str):
        if backend_type is None:
            raise ValueError("backend_type is None, please choose \'eng\' or \'theo\'")
        if backend_type.lower() == "eng":
            return BackendType.ENG
        elif backend_type.lower() == "theo":
            return BackendType.THEO
        elif backend_type.lower() == "eng_classic":
            return BackendType.ENG_CLASSIC
        else:
            raise ValueError(f"不支持的CostModel后端类型: {backend_type}")


class OpState(Enum):
    DYNAMIC = "dynamic"
    STATIC = "static"

    @staticmethod
    def from_str(backend_type: str):
        if backend_type.lower() == "dynamic":
            return OpState.DYNAMIC
        elif backend_type.lower() == "static":
            return OpState.STATIC
        else:
            raise ValueError(f"不支持的OpState类型: {backend_type}")


class OpType(Enum):
    MatMul = ({"MatMul", "MatMulV3", "MatMulV2"}, CoreType.AIC)
    Conv2D = ({"Conv2d", "Conv2D"}, CoreType.AIC)
    RmsNorm = ({"RmsNorm"}, CoreType.AIV)
    AddRmsNorm = ({"AddRmsNorm"}, CoreType.AIV)
    LayerNorm = ({"LayerNorm", "LayerNormV2", "LayerNormV3", "LayerNormV4"}, CoreType.AIV)
    GroupedMatmul = ({"GroupedMatmul", "GroupedMatMulKernel"}, CoreType.AIC)
    Gelu = ({"Gelu"}, CoreType.AIV)
    ClipByValueV2 = ({"ClipByValueV2"}, CoreType.AIV)
    Add = ({"Add", "AddInplace"}, CoreType.AIV)
    Div = ({"Div"}, CoreType.AIV)
    Log = ({"Log"}, CoreType.AIV)
    Mul = ({"Mul"}, CoreType.AIV)
    Muls = ({"Muls"}, CoreType.AIV)
    Swish = ({"Swish", "Silu"}, CoreType.AIV)
    Abs = ({"Abs"}, CoreType.AIV)
    Max = ({"Max"}, CoreType.AIV)
    Min = ({"Min"}, CoreType.AIV)
    Relu = ({"Relu"}, CoreType.AIV)
    Sqrt = ({"Sqrt"}, CoreType.AIV)
    AddMM = ({"AddMM"}, CoreType.MIX)
    QuantBatchMatmulV3 = ({"QuantBatchMatmulV3"}, CoreType.MIX)
    HstuDenseForwardFuxi = ({"HstuDenseForwardFuxi", "Hstu", "HstuDenseForward"}, CoreType.MIX)
    AscendQuantV2 = ({"AscendQuantV2"}, CoreType.AIV)
    DynamicQuant = ({"DynamicQuant"}, CoreType.AIV)
    Cumsum = ({"Cumsum"}, CoreType.AIV)
    Equal = ({"Equal"}, CoreType.AIV)
    BatchMatMul = ({"BatchMatMul", "BatchMatMulV2"}, CoreType.AIC)
    FlashAttention = ({"FlashAttention", "FlashAttentionScore"}, CoreType.MIX)
    FlashAttentionGrad = ({"FlashAttentionGrad", "FlashAttentionScoreGrad"}, CoreType.MIX)
    FusedInferAttentionScore = ({"FusedInferAttentionScore"}, CoreType.MIX)
    UnpadFlashAttentionMlaBF16NdKernel = (
        {"UnpadFlashAttentionMlaBF16NdKernel", "UnpadFlashAttentionBF16NdKernel"}, CoreType.MIX)
    MoeDistributeDispatchV2 = ({"MoeDistributeDispatchV2"}, CoreType.AIV)
    MoeDistributeCombineV2 = ({"MoeDistributeCombineV2"}, CoreType.AIV)
    ConcatD = ({"ConcatD"}, CoreType.AIV)
    TritonOp = ({"TTIR"}, CoreType.AIV)  # NEXT -- TritonOp暂时只有AIV类型的算子
    HIVM = ({"HIVM"}, CoreType.MIX)
    TopKV2 = ({"TopKV2", "TopK"}, CoreType.AIV)
    MoeGatingTopK = ({"MoeGatingTopK", "FusedCastAddTopkDivKernel"}, CoreType.AIV)
    MultiHeadLatentAttention = ({"MultiHeadLatentAttention", "MLAKernel"}, CoreType.MIX)
    RINGMLAPrefillBF16Kernel = ({"RINGMLAPrefillBF16Kernel"}, CoreType.MIX)
    ReduceSum = ({"ReduceSum"}, CoreType.AIV)
    GreaterEqual = ({"GreaterEqual", "Greater"}, CoreType.AIV)
    Slice = ({"Slice", "SliceV2", "SliceAiCore"}, CoreType.AIV)
    ReduceMax = ({"ReduceMax"}, CoreType.AIV)
    ReduceMin = ({"ReduceMin"}, CoreType.AIV)
    Softmax = ({"Softmax", "SoftmaxV2"}, CoreType.AIV)
    Gather = ({"Gather", "GatherV2", "GatherV3"}, CoreType.AIV)
    PageAttention = ({"PagedAttentionMaskNdKernel"}, CoreType.MIX)
    SelectV2 = ({"SelectV2"}, CoreType.AIV)
    Triu = ({"Triu"}, CoreType.AIV)
    PTO_FA = ({"PTO_FA"}, CoreType.MIX)
    LightningIndexer = ({"LightningIndexer"}, CoreType.MIX)
    SparseFlashAttention = ({"SparseFlashAttention"}, CoreType.MIX)
    SparseAttnSharedkv = ({"SparseAttnSharedkv"}, CoreType.MIX)
    TransposeBatchMatMul = ({"TransposeBatchMatMul"}, CoreType.AIC)
    Index = ({"Index"}, CoreType.AIV)
    Transpose = ({"Transpose"}, CoreType.AIV)
    Cast = ({"Cast", "DtypeCast"}, CoreType.AIV)
    Compressor = ({"Compressor"}, CoreType.MIX)
    HcPre = ({"HcPre"}, CoreType.MIX)
    HcPreTriton = ({"HcPreTriton"}, CoreType.MIX)
    HcPostTriton = ({"HcPostTriton"}, CoreType.AIV)
    HcTilelang = ({"HcTilelang"}, CoreType.MIX)
    HcUnfused = ({"HcUnfused"}, CoreType.MIX)
    MropeGolden = ({"MropeGolden"}, CoreType.MIX)
    MatMulMrope = ({"MatMulMrope"}, CoreType.MIX)
    ViewCopy = ({"ViewCopy", "Copy", "CopyInplace"}, CoreType.AIV)
    ScatterNdUpdate = ({"ScatterNdUpdate"}, CoreType.AIV)
    FloorDiv = ({"FloorDiv"}, CoreType.CPU)
    PadV3 = ({"PadV3"}, CoreType.CPU)
    ScatterElements = ({"ScatterElements"}, CoreType.CPU)
    SparseAttnSharedkvMetadata = ({"SparseAttnSharedkvMetadata"}, CoreType.CPU)
    DequantSwigluQuant = ({"DequantSwigluQuant"}, CoreType.AIV)
    RotaryPositionEmbedding = ({"RotaryPositionEmbedding"}, CoreType.AIV)
    HcPreInvRms = ({"HcPreInvRms"}, CoreType.AIV)
    HcPreSinkhorn = ({"HcPreSinkhorn"}, CoreType.AIV)
    Swiglu = ({"Swiglu"}, CoreType.AIV)
    Sigmoid = ({"Sigmoid"}, CoreType.AIV)

    def __init__(self, desc, core_type):
        self.desc = desc
        self.core_type = core_type

    @staticmethod
    def from_str(op_type_str: str):
        for op_type in OpType:
            if op_type_str.lower() in {s.lower() for s in op_type.desc}:
                return op_type

        raise ValueError(f"don't support {op_type_str} now")


@deprecated("新版工程可达完善后弃用")
class ResultKey(Enum):
    CORE_TIME = (0, "Duration(us)", {CoreType.AIC, CoreType.AIV})
    AIC_TIME = (1, "aicore_time(us)", {CoreType.AIC})
    AIV_TIME = (2, "aiv_time(us)", {CoreType.AIV})
    CUBE_TIME = (3, "aic_mac_time(us)", {CoreType.AIC})
    VEC_TIME = (4, "aiv_vec_time(us)", {CoreType.AIV})
    MTE1_TIME = (5, "aic_mte1_time(us)", {CoreType.AIC})
    MTE2_TIME_AIC = (6, "aic_mte2_time(us)", {CoreType.AIC})
    MTE2_TIME_AIV = (7, "aiv_mte2_time(us)", {CoreType.AIV})
    MTE3_TIME = (8, "aiv_mte3_time(us)", {CoreType.AIV})
    FIXPIPE_TIME = (9, "aic_fixpipe_time(us)", {CoreType.AIC})
    L2_MISS_RATE = (10, "l2_miss_rate", {CoreType.AIC, CoreType.AIV})
    AIC_TOTAL_MKN = (11, "aic_total_mkn", {CoreType.AIC})
    AIV_TOTAL_CYCLES = (12, "aiv_total_cycles", {CoreType.AIV})
    L1_CACHE = (13, "L1_cache(KB)", {CoreType.AIC})
    L0A_CACHE = (14, "L0A_cache(KB)", {CoreType.AIC})
    L0B_CACHE = (15, "L0B_cache(KB)", {CoreType.AIC})
    L0C_CACHE = (16, "L0C_cache(KB)", {CoreType.AIC})
    L2_CACHE = (17, "L2_cache(KB)", {CoreType.AIC, CoreType.AIV})
    UB_CACHE = (18, "UB_cache(KB)", {CoreType.AIV})

    def __init__(self, order, desc, core_type_set):
        self.order = order
        self.desc = desc
        self.core_type_set = core_type_set

    def __str__(self):
        return self.desc

    @staticmethod
    def dict_to_list(result_dict):
        # 按照key的order排序，并放入dict中
        result_list = []
        for key in sorted(result_dict.keys(), key=lambda x: x.order):
            result_list.append(result_dict[key])
        return result_list

    @staticmethod
    def key_list(core_type: CoreType = None):
        key_list = []
        for key in sorted(ResultKey, key=lambda x: x.order):
            if core_type is None or core_type in key.core_type_set:
                key_list.append(key.desc)
        return key_list

    @staticmethod
    def print(result_dict):
        for key in sorted(result_dict.keys(), key=lambda x: x.order):
            logger.info("ResultKey.print, %s : %s", key.desc, result_dict[key])

    @staticmethod
    def time_keys():
        return [
            ResultKey.CORE_TIME,
            ResultKey.AIC_TIME,
            ResultKey.AIV_TIME,
            ResultKey.CUBE_TIME,
            ResultKey.VEC_TIME,
            ResultKey.MTE1_TIME,
            ResultKey.MTE2_TIME_AIC,
            ResultKey.MTE2_TIME_AIV,
            ResultKey.MTE3_TIME,
            ResultKey.FIXPIPE_TIME,
        ]


@deprecated("新版工程可达完善后弃用")
class OutputType(Enum):
    """
    输入与输出的形状关系
    EQUAL：  与输出相同形状-AIV核使用
    TO_ONE： 仅输出一个数据-AIV核使用
    MN：     矩阵乘类，输出由输入的两个轴构成-AIC核使用
    """

    EQUAL = 0
    TO_ONE = 1
    MN = 2


class VecOpType(Enum):
    VMUL = "VMUL"
    VMAX = "VMAX"
    VMAXS = "MAXS"
    VEXP = "VEXP"
    VSUB = "VSUB"
    VSUBS = "VSUBS"
    VABS = "VABS"
    VMINS = "VMINS"
    VCGMAX = "VCGMAX"
    BRCB = "BRCB"
    VCOPY = "VCOPY"
    VCGADD = "VCGADD"
    VSEL = "VSEL"
    CMPV_EQ = "CMPV_EQ"
    CONV_F162S8R = "CONV_F162S8R"
    VECTOR_DUP = "VECTOR_DUP"
    VADD = "VADD"
    VMULS = "VMULS"
    VADDS = "VADDS"
    VDIV = "VDIV"
    VDIVS = "VDIVS"
    VBRCB = "VBRCB"
    VCADD = "VCADD"
    MOVEV = "MOVEV"
    VSQRT = "VSQRT"
    VMUL_SELF = "VMUL_SELF"
    CONV_F322S32R = "CONV_F322S32R"
    CONV_DEQ = "CONV_DEQ"
    CONV_BF162F32 = "CONV_BF162F32"
    CONV_S322F32 = "CONV_S322F32"
    CONV_F322BF16 = "CONV_F322BF16"
    RELU = "RELU"
    CONV_F162F32 = "CONV_F162F32"
    LOG = "LOG"
    CONV_F322F16 = "CONV_F322F16"
    AXPY = "AXPY"
    SILU = 'SILU'
    CMPV_GE = 'CMPV_GE'
    VREDUCEV2 = 'VREDUCEV2'
    NULL_OP = "NULL_OP"
    VCMPV_NE = "VCMPV_NE"
    VCMPV_GE = "VCMPV_GE"
    VMIN = "VMIN"
    CMPY = "CMPY"
    VCGMIN = "VCGMIN"
    VTRANS = "VTRANS"
    VBS32 = 'VBS32'
    VMS4V2 = 'VMS4V2'
    VCMAX = "VCMAX"
    VCONV = "VCONV"
    MOVEMASK1 = "MOVEMASK1"
    MOVEMASK2 = "MOVEMASK2"

    def __init__(self, desc, vec_op_depend_on=0):
        """
        vector基础操作
        :param desc:                算子名称
        :param vec_op_depend_on:    当前操作的操作计算取决于哪个输入的计算数量，< 0表示取决于输出矩阵， >= 0表示取决于输入矩阵
        """
        self.desc = desc
        self.vec_op_depend_on = vec_op_depend_on

    def __str__(self):
        return self.desc

    @staticmethod
    def from_str(vec_op_type_str: str):
        for vec_op_type in VecOpType:
            if vec_op_type_str.upper() in vec_op_type.desc:
                return vec_op_type

        raise ValueError(f"don't support {vec_op_type_str} now")


class DType(Enum):
    FP16 = (2, "FP16")
    FP8 = (1, "FP8")
    INT8 = (1, "INT8")
    FP32 = (4, "FP32")
    HF32 = (4, "HF32")
    BF16 = (2, "BF16")
    INT32 = (4, "INT32")
    INT16 = (2, "INT16")
    UINT64 = (8, "UINT64")
    INT64 = (8, "INT64")
    UNDEFINED = (0, "UNDEFINED")  # 数据类型UNDEFINED的情况对应的输入shape为空
    BOOL = (1, "BOOL")
    UINT8 = (1, "UINT8")

    def __init__(self, size, desc):
        self.size = size
        self.desc = desc

    @staticmethod
    def from_str(precision_str):
        if precision_str in {"FLOAT16", "FP16"}:
            return DType.FP16
        elif precision_str in {"FLOAT32", "FLOAT", "FP32", ""}:  # 默认值
            return DType.FP32
        elif precision_str in {"FP8", "FLOAT8_E4M3FN", "FLOAT8"}:
            return DType.FP8
        elif precision_str == "INT8":
            return DType.INT8
        elif precision_str == "BOOL":
            return DType.BOOL
        elif precision_str in {"BF16", "DT_BF16", "BFLOAT16"}:
            return DType.BF16
        elif precision_str == "INT32":
            return DType.INT32
        elif precision_str == "UINT64":
            return DType.UINT64
        elif precision_str == "INT64":
            return DType.INT64
        elif precision_str == "UINT8":
            return DType.UINT8
        elif precision_str == "HF32":
            return DType.HF32
        elif precision_str in {"DT_UNDEFINED", "UNDEFINED"}:
            return DType.UNDEFINED
        else:
            raise ValueError(
                f"precision {precision_str} is not supported"
            )


@deprecated("新版工程可达完善后弃用")
@dataclass
class Operator:
    # 算子输入shape入参，各自解析，比如 fa 而言，[128,15000] 128-head dim, 15000-seq len
    shape: list[list[int]]
    # 算子input的精度，各自解析，比如 fa 而言，[FP16]，所有入参都是FP16格式
    input_precision: list[DType]
    # 算子输出精度，如果是单个输出，则是1维
    output_precision: list[DType]
    # 算子名称
    op_name: str
    # 使用核数
    block_dim: int
    output_shape: list[int] = None


@deprecated("新版工程可达完善后弃用")
class TensorData:
    def __init__(
            self, tensor_id: str, precision: DType, shape: list, location: MemLoc
    ):
        """
        计算流程中的张量表示
        :param tensor_id:   张量名称，唯一识别，相同的tensorId是同一个tensor
        :param precision:   张量的数据精度
        :param shape:       张量的各维度数据大小
        :param location:    张量所存cache位置
        """
        self.tensor_id = tensor_id
        self.precision = precision
        self.shape = shape
        self.location = location


@deprecated("新版工程可达完善后弃用")
class Cube:
    TILE_L0_ID = 0

    def __init__(self, m, k, n, precision: DType):
        """
        L0 层的tile块
        """
        Cube.TILE_L0_ID += 1
        self.id = Cube.TILE_L0_ID
        self.m = m
        self.k = k
        self.n = n
        self.precision = precision


@deprecated("新版工程可达完善后弃用")
class Section:

    def __init__(
            self,
            bias,
            core_type: CoreType,
            m,
            k,
            n,
            tiling_param,
            input_precision: DType,
            output_precision: DType,
            single_tile_output: bool = False,
            transpose=None,
            copy_out=True
    ):
        self.bias = bias
        self.core_type = core_type
        self.m = m
        self.k = k
        self.n = n
        self.tiling_param = tiling_param
        self.input_precision = input_precision
        self.output_precision = output_precision
        self.input_tiles = []
        self.output_tiles = []

        # section所属的第几个CV并行块（取值范围是 0~n，n表示所有section可以分成几个CV并行块）
        self.group_idx = 0
        # 当前section属于CV并行块中的第几个（一般只有 0，1两个取值）
        self.block_idx = 0

        self.tile_round = 1

        # section的输入依赖关系，格式为 this.section.input_bias : dependency.section.bias
        self.input_dependency = {}
        self.single_tile_output = single_tile_output
        self.transpose = transpose
        self.copy_out = copy_out


class Tile:
    # 新版工程可达完善后弃用
    TILE_ID = 0

    def __init__(
            self,
            section: Section,
            core,
            row_start,
            col_start,
            rows,
            cols,
            idx_in_section,
            precision: DType,
            input_bias,
            depth=0,
            depth_start=0,
            shape_dict: dict[str, float] = None,
            op_name="",
    ):
        """
        L1层/UB层的tile块。
        注意！！！对于AIC核的tiling，这里默认是转置了的，也就是说。对于A矩阵（左矩阵）rows = m，cols = k，而对于B矩阵（右矩阵）rows = n，cols = k
        Args:
            section:            算子的第几个AICore阶段
            core:               分到第几个核上
            row_start:          tile行开始的idx
            col_start:          tile列开始的idx
            rows:               tile包含多少行
            cols:               tile包含多少列
            idx_in_section:     在section中，第几个运算
            precision:          精度
            input_bias:         第几个输入的tile，-1表示输出的tile
        """
        Tile.TILE_ID += 1
        self.id = Tile.TILE_ID
        self.input_bias = input_bias
        self.op_name = op_name

        # 分核、L1层搬运相关，L0层tiling没有
        self.section = section
        self.core = core
        self.core_type = section.core_type
        self.idx_in_section = idx_in_section

        # vv融合的算子，如果像softmax这种，不同的tile计算方式不同，则按照不同融合算子设置
        self.fused_op = None

        # tile的基本参数
        if not (
                int(row_start) - row_start == 0
                and int(col_start) - col_start == 0
                and int(rows) - rows == 0
                and int(cols) - cols == 0
        ):
            raise ValueError("tile start must be int")
        self.row_start = int(row_start)
        self.col_start = int(col_start)
        self.rows = int(rows)
        self.cols = int(cols)
        self.depth_start = depth_start
        self.depth = depth
        self.size = rows * cols
        self.precision = precision

        # 是否命中L1
        self.l1_hit = 0

        # 是否命中L2 cache
        self.l2_hit = 0
        self.batch_idx = 0
        self.idx_in_batch = idx_in_section
        self.loop_idx = 0
        self.round_idx = 0

        # 设定唯一标识，相同的表示为同一个tile
        self.tile_name = (
            f"{self.section.bias}_"
            f"{self.input_bias}_"
            f"{self.row_start}_"
            f"{self.col_start}_"
            f"{self.rows}_"
            f"{self.cols}"
        )
        # 如果当前输入是之前某个section的输出，则需要以前一个section的输出来命名
        if section.input_dependency != {} and self.input_bias in section.input_dependency.keys():
            pre_section_bias = section.input_dependency[self.input_bias]
            if section.transpose is not None and self.input_bias in section.transpose:
                self.tile_name = f"{pre_section_bias}_{-1}_{self.col_start}_{self.row_start}_{self.cols}_{self.rows}"
            else:
                self.tile_name = f"{pre_section_bias}_{-1}_{self.row_start}_{self.col_start}_{self.rows}_{self.cols}"

        self.shape_dict = None

    def to_list(self):
        return [
            self.id,
            self.core,
            self.row_start,
            self.col_start,
            self.depth_start,
            self.rows,
            self.cols,
            self.depth,
            self.idx_in_section,
            self.precision.value[0],
            self.input_bias,
            self.l1_hit,
            self.l2_hit,
        ]

    @staticmethod
    def get_col_name():
        return [
            "tile_id",
            "core",
            "row_start",
            "col_start",
            "depth_start",
            "rows",
            "cols",
            "depth",
            "idx_in_section",
            "precision",
            "input_bias",
            "l1_hit",
            "l2_hit",
        ]

    def split_l0(self, tiling_param) -> list[tuple[int, int]]:
        """
        L1层的tile切割成L0层tile之后的尺寸和数量
        Args:
            tiling_param:   tiling设置

        Returns:            1. tile数量。 2. tile的尺寸-[rows,cols]

        """
        row_split = 0
        col_split = 0
        # 如果是左矩阵，则 row = m
        if self.input_bias == 0:
            row_split = tiling_param.m0
            col_split = tiling_param.k0

        # 如果是右矩阵，则 row = n
        elif self.input_bias == 1:
            row_split = tiling_param.n0
            col_split = tiling_param.k0
        else:
            raise ValueError(f"input bias must be 0 or 1, but get {self.input_bias}")

        # 普遍意义上来讲，可能存在三种尾块：行\列+尾块\非尾块 共计四种组合，除了 行列都是非尾块的情况，其他三种都属于尾块。但实际大多数情况，从L1-->L0时，m\n轴不切分，所以大概率指挥出现k轴的尾块
        former_col = self.cols // col_split
        tail_col = self.cols % col_split
        former_row = self.rows // row_split
        tail_row = self.rows % row_split

        l0_tiles = []
        for _ in range(0, former_row):
            for _ in range(0, former_col):
                l0_tiles.append((row_split, col_split))

        if tail_col != 0:
            for _ in range(0, former_row):
                l0_tiles.append((row_split, tail_col))

        if tail_row != 0:
            for _ in range(0, former_col):
                l0_tiles.append((tail_row, col_split))

        if tail_row != 0 and tail_col != 0:
            l0_tiles.append((tail_row, tail_col))

        return l0_tiles

    def __get_tensor_elements(self, tensor: TensorData) -> float:
        element_cnt = 1
        for dim in tensor.shape:
            if isinstance(dim, str):
                element_cnt *= self.shape_dict[dim]
            else:
                element_cnt *= dim
        return element_cnt

    def get_op_element_cnt(
            self,
    ) -> tuple[
        dict[int, float], dict[MemLoc, list[float]], dict[MemLoc, list[float]]
    ]:
        ele_cnt_dict = {}
        input_shape_dict = {}
        output_shape_dict = {}
        for op in self.fused_op:
            op_depend_on = op.op_type.vec_op_depend_on
            tensor = (
                op.inputs[op_depend_on]
                if op_depend_on >= 0
                else op.outputs[-1 - op_depend_on]
            )
            ele_cnt_dict[op.id] = self.__get_tensor_elements(tensor)

            for input_tensor in op.inputs:
                tensor_size = (
                        input_tensor.precision.size
                        * self.__get_tensor_elements(input_tensor)
                )
                if input_tensor.location not in input_shape_dict.keys():
                    input_shape_dict[input_tensor.location] = [tensor_size]
                else:
                    input_shape_dict[input_tensor.location].append(tensor_size)

            for output_tensor in op.outputs:
                tensor_size = (
                        output_tensor.precision.size
                        * self.__get_tensor_elements(output_tensor)
                )
                if output_tensor.location not in output_shape_dict.keys():
                    output_shape_dict[output_tensor.location] = [tensor_size]
                else:
                    output_shape_dict[output_tensor.location].append(tensor_size)

        return ele_cnt_dict, input_shape_dict, output_shape_dict


@deprecated("新版工程可达完善后弃用")
class Block:

    def __init__(self, key: tuple, input_tiles: list[Tile], output_tiles: list[Tile]):
        """
        CV并行快中的C块/V块
        """
        self.core_type = CoreType(key[0])

        # 一个loop，表示的是一个数据，从头到尾，完整的计算完了所有的section
        self.loop_idx = key[1]
        self.round_idx = key[2]
        self.block_idx = key[3]
        self.batch_idx = key[4]

        self.input_tiles = input_tiles
        self.output_tiles = output_tiles

        self.time = {}
        self.section = input_tiles[0].section

        # 记录什么时候开始的计算
        self.time_start = 0

    def to_list(self):
        return [
            self.core_type,
            self.loop_idx,
            self.round_idx,
            self.block_idx,
            self.batch_idx,
            self.time.get(ResultKey.CORE_TIME, None),  # 使用dict.get()方法获取值，并设置默认值为None
            self.section.bias,
            self.time_start,
            len(self.input_tiles),
            len(self.output_tiles),
        ]


@deprecated("新版工程可达完善后弃用")
@dataclass
class PipeAnaConfig:
    # 不可并行的组件配置
    un_parallel_components: Set[tuple] = field(default_factory=set)

    def __init__(self, un_parallel_components: list[tuple] = None):
        if un_parallel_components is None:
            self.un_parallel_components = set()
        else:
            self.un_parallel_components = set(un_parallel_components)