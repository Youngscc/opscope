# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
"""
Shared SSA definitions

This module contains definitions shared between frontend and backend
to avoid circular imports. Both PhiFuncIR and PhiFuncEntity should
derive from or map to these definitions.
"""

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

# Forward declarations to avoid circular imports
if TYPE_CHECKING:
    pass


@dataclass(frozen=True)
class PhiScopeReferrer:
    """
    Represents a mapping from a scope ID to the variable version
    that is active when that scope is taken.
    """
    scope_id: str
    referred_name: str


@dataclass
class PhiFunction:
    """
    Base definition of a Phi function for SSA form.

    A Phi function merges different versions of a variable from
    different control flow paths into a single version at a join point.
    """
    id: str
    result_name: str
    referred_name: list[str]
    scope_referrers: dict[str, str] = field(default_factory=dict)