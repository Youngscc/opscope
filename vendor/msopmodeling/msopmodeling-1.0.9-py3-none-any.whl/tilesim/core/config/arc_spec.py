# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

import csv
import os
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

import yaml

from core.backend.bandwidth_costmodel.npu.npu_type import NPUBandwidth
from core.common.entity import VecOpType, MemLoc, DType, CycleType, MemType
from core.common.entity import logging

# 创建一个日志记录器
logger = logging.getLogger(__name__)


def get_absolute_path(relative_path, base_dir):
    """将相对于base_dir的路径转换为绝对路径"""
    return os.path.abspath(os.path.join(base_dir, os.path.expanduser(relative_path)))


class BandwidthMode(Enum):
    NORMAL = 'normal'


@dataclass
class CacheConfig:
    cache_name: MemLoc
    cache_size: float

    def __post_init__(self):
        # 转换KB-->B
        self.cache_size *= 1024


@dataclass
class CoreConfig:
    # AIC核数
    cube_core_num: int
    # AIV核数
    vec_core_num: int
    # CV是否是绑定的，如果是绑定的，则1C2V为一个group
    cv_bind: bool


@dataclass
class CubeConfig:
    cube_throughput: dict[DType, tuple[int, int, int]]
    cube_repeat_cycles: dict[DType, float]

    def __post_init__(self):
        cube_repeat_cycles_dict = {}
        for key, value in self.cube_repeat_cycles.items():
            cube_repeat_cycles_dict[DType.from_str(key)] = value
        self.cube_repeat_cycles = cube_repeat_cycles_dict

        cube_throughput_dict = {}
        if isinstance(self.cube_throughput, dict):
            for key, value in self.cube_throughput.items():
                cube_throughput_dict[DType.from_str(key)] = value
        elif isinstance(self.cube_throughput, list):
            m, k, n = self.cube_throughput
            for d_type in self.cube_repeat_cycles.keys():
                k_d = k / d_type.size
                cube_throughput_dict[d_type] = (m, k_d, n)
        self.cube_throughput = cube_throughput_dict


@dataclass
class VecConfig:
    vec_size_single_repeat: dict[DType, float]

    def __post_init__(self):
        tmp_dict = {}
        if isinstance(self.vec_size_single_repeat, (int or float)):
            for key in DType:
                tmp_dict[key] = self.vec_size_single_repeat
        elif isinstance(self.vec_size_single_repeat, dict):
            for key, value in self.vec_size_single_repeat.items():
                tmp_dict[DType.from_str(key)] = value
        else:
            raise ValueError("vec_size_single_repeat should be float/int or dict")
        self.vec_size_single_repeat = tmp_dict


@dataclass
class BandwidthConfig:
    src_mem: MemLoc
    dst_mem: MemLoc
    # -1 表示带宽与核数、包大小无关
    core_num: int = -1
    pkt_size: int = -1
    mode: BandwidthMode = BandwidthMode.NORMAL
    bw: float = 0.0

    def __post_init__(self):
        self.src_mem = MemLoc.from_str(self.src_mem)
        self.dst_mem = MemLoc.from_str(self.dst_mem)
        self.core_num = int(self.core_num)
        self.pkt_size = int(self.pkt_size)
        self.mode = BandwidthMode(self.mode)
        self.bw = float(self.bw)
        # 转换为GB/s-->B/us
        self.bw = self.bw * 1024 * 1024 * 1024 / 1e6


@dataclass
class VecIntrinsics:
    intrinsic: VecOpType
    d_type: DType
    computing_cycles: int
    head_cycles: int
    interval_cycles: int

    def __post_init__(self):
        self.intrinsic = VecOpType(self.intrinsic)
        self.d_type = DType.from_str(self.d_type)
        self.computing_cycles = int(self.computing_cycles)
        self.head_cycles = int(self.head_cycles)
        self.interval_cycles = int(self.interval_cycles)

    def get_cycle(self, cycle_type: CycleType) -> int:
        if cycle_type == CycleType.COMPUTING_CYCLES:
            return self.computing_cycles
        elif cycle_type == CycleType.HEAD_CYCLES:
            return self.head_cycles
        elif cycle_type == CycleType.INTERVAL_CYCLES:
            return self.interval_cycles
        else:
            raise ValueError(f"Cycle type {cycle_type} is not supported in class VecIntrinsics")


@dataclass
class ArcConfig:
    spec_name: str
    clock_freq: float  # 单位：MHz

    core_config: CoreConfig
    cube_config: CubeConfig
    vec_config: VecConfig
    bandwidth: str  # csv路径
    vec_intrinsics: str  # csv路径
    vec_no_bank_conflict_intrinsics: str = None
    local_mem: dict[MemLoc, float] = None
    share_mem: dict[MemLoc, float] = None
    pkt_param: dict[str, tuple[int, int]] = None

    bandwidth_dict: dict[tuple[MemLoc, MemLoc, int, int, BandwidthMode], BandwidthConfig] = None
    vec_intrinsics_dict: dict[tuple[VecOpType, DType], VecIntrinsics] = None
    vec_no_bank_conflict_intrinsics_dict: dict[tuple[VecOpType, DType], VecIntrinsics] = None
    npu: NPUBandwidth = None

    # 带宽系数
    __bw_coeff = 1.0

    def set_bw_coeff(self, coeff):
        self.__bw_coeff = coeff
        logger.warning(f"Bandwidth coefficient is set to {coeff}")

    def __post_init__(self):
        """对于非简单数据类型的属性进行后处理"""
        # KB 转换成 B
        cache_dict = {}
        for key, value in self.local_mem.items():
            cache_dict[MemLoc(key)] = value * 1024
        self.local_mem = cache_dict

        cache_dict = {}
        for key, value in self.share_mem.items():
            cache_dict[MemLoc(key)] = value * 1024
        self.share_mem = cache_dict
        self.core_config = CoreConfig(**self.core_config)
        self.cube_config = CubeConfig(**self.cube_config)
        self.vec_config = VecConfig(**self.vec_config)

        with open(self.bandwidth, mode='r', encoding='utf-8') as file:
            csv_dict_reader = csv.DictReader(file)
            for row in csv_dict_reader:
                bw = BandwidthConfig(bw=row.pop('bandwidth(GB/s)'), **row)
                if self.bandwidth_dict is None:
                    self.bandwidth_dict = {}
                self.bandwidth_dict[(bw.src_mem, bw.dst_mem, bw.core_num, bw.pkt_size, bw.mode)] = bw

        with open(self.vec_intrinsics, mode='r', encoding='utf-8') as file:
            csv_dict_reader = csv.DictReader(file)
            for row in csv_dict_reader:
                vec_intri = VecIntrinsics(**row)
                if self.vec_intrinsics_dict is None:
                    self.vec_intrinsics_dict = {}
                self.vec_intrinsics_dict[VecOpType(vec_intri.intrinsic), DType(vec_intri.d_type)] = vec_intri

        if self.vec_no_bank_conflict_intrinsics is not None:
            with open(self.vec_no_bank_conflict_intrinsics, mode='r', encoding='utf-8') as file:
                csv_dict_reader = csv.DictReader(file)
                for row in csv_dict_reader:
                    vec_no_bank_conflict_intri = VecIntrinsics(**row)
                    if self.vec_no_bank_conflict_intrinsics_dict is None:
                        self.vec_no_bank_conflict_intrinsics_dict = {}
                    self.vec_no_bank_conflict_intrinsics_dict[VecOpType(vec_no_bank_conflict_intri.intrinsic),
                                        DType(vec_no_bank_conflict_intri.d_type)] = vec_no_bank_conflict_intri

    def lookup_cache_type(self, mem_loc: MemLoc) -> MemType:
        """
        lookup memory type of mem_loc
        Args:
            mem_loc: cache name

        Returns:
            MemType.INTRA_CORE or MemType.INTER_CORE
        """
        if mem_loc in self.local_mem.keys():
            return MemType.LOCAL_MEM
        elif mem_loc in self.share_mem.keys():
            return MemType.SHARE_MEM

        raise KeyError(f"Do not have {mem_loc} config")

    def lookup_cache_size(self, mem_loc: MemLoc) -> tuple[MemType, float]:
        """
        lookup cache size and return cache size & mem type (intra/inter core)
        Args:
            mem_loc: cache name

        Returns:
            cache size on single core - mem type = intra core
            total cache size  - mem type = inter core
        """
        if mem_loc in self.local_mem.keys():
            return MemType.LOCAL_MEM, self.local_mem[mem_loc]
        elif mem_loc in self.share_mem.keys():
            return MemType.SHARE_MEM, self.share_mem[mem_loc]
        elif mem_loc == MemLoc.GM:
            return MemType.SHARE_MEM, float('inf')

        raise KeyError(f"Do not have {mem_loc} config")

    def lookup_bw(self, src_mem: MemLoc, dst_mem: MemLoc, core_num: int = -1,
                  pkt_size: int = -1, mode: BandwidthMode = BandwidthMode.NORMAL) -> tuple[float, bool]:
        """Look up bandwidth based on configuration parameters.

        Args:
            src_mem: Source memory location
            dst_mem: Destination memory location
            core_num: Number of cores (-1 means core-independent)
            pkt_size(Byte): Packet size (-1 means size-independent)
            mode: Bandwidth mode

        Returns:
            A tuple of (bandwidth, is_small_pkt):
            - bandwidth: The bandwidth in B/us/single core
            - is_small_pkt: Whether this is a small packet transfer
        """
        # NEXT -- key中的pkt_size目前只能是-1，因为现在pkt_size只支持拟合不支持查表
        is_small_pkt = False

        key = (src_mem, dst_mem, core_num, -1, mode)
        if key in self.bandwidth_dict:
            ret = self.bandwidth_dict[key].bw
        else:
            default_key = (src_mem, dst_mem, -1, -1, mode)
            if default_key in self.bandwidth_dict:  # 核数无关的默认值
                logger.warning(f"Bandwidth param {key} not in {self.bandwidth}, use default with core_num -1")
                ret = self.bandwidth_dict[default_key].bw
            else:
                raise KeyError(f"Bandwidth param {key} not in {self.bandwidth}")

        if self.pkt_param is not None and pkt_size != -1:
            size_mapping = {64: "64B", 128: "128B", 256: "256B"}
            pkt_desc = "big_pkt"
            for threshold, desc in size_mapping.items():
                if pkt_size < threshold:
                    pkt_desc = desc
                    break
            if pkt_desc != "big_pkt":
                is_small_pkt = True
                a, b = self.pkt_param[pkt_desc]
                pkt_size_gb = pkt_size / (1024 ** 3)
                ret = b / (a * b + pkt_size_gb) * (1024 ** 3) / 1e6  # GB/s-->B/us

        ret *= self.__bw_coeff
        return ret, is_small_pkt

    def lookup_vec_cycle(self, vec_intrinsic_type: VecOpType, dtype: DType, cycle_type: CycleType) -> int:
        key = (vec_intrinsic_type, dtype)
        if key in self.vec_intrinsics_dict:
            return self.vec_intrinsics_dict[key].get_cycle(cycle_type)
        default_key = (vec_intrinsic_type, DType.FP32)
        if default_key not in self.vec_intrinsics_dict:
            raise KeyError(f"Vec intrinsic param {key} not in {self.vec_intrinsics}")
        logger.warning(f"Vec intrinsic param {key} not in {self.vec_intrinsics}, use default")
        return self.vec_intrinsics_dict[default_key].get_cycle(cycle_type)

    def lookup_vec_no_bank_conflict_cycle(self, vec_intrinsic_type: VecOpType, dtype: DType, cycle_type: CycleType) -> int:
        key = (vec_intrinsic_type, dtype)
        if key in self.vec_no_bank_conflict_intrinsics_dict:
            return self.vec_no_bank_conflict_intrinsics_dict[key].get_cycle(cycle_type)
        default_key = (vec_intrinsic_type, DType.FP32)
        if default_key not in self.vec_no_bank_conflict_intrinsics_dict:
            raise KeyError(f"Vec intrinsic param {key} not in {self.vec_intrinsics}")
        logger.warning(f"Vec intrinsic param {key} not in {self.vec_intrinsics}, use default")
        return self.vec_no_bank_conflict_intrinsics_dict[default_key].get_cycle(cycle_type)


def load_arc_config(accelerator):
    config_path = Path(accelerator)
    with open(config_path, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
    config_dir = os.path.dirname(os.path.abspath(config_path))
    if not os.path.exists(data['bandwidth']):
        data['bandwidth'] = get_absolute_path(data['bandwidth'], config_dir)
    if not os.path.exists(data['vec_intrinsics']):
        data['vec_intrinsics'] = get_absolute_path(data['vec_intrinsics'], config_dir)
    if data.get('vec_no_bank_conflict_intrinsics') is not None:
        if not os.path.exists(data['vec_no_bank_conflict_intrinsics']):
            data['vec_no_bank_conflict_intrinsics'] = get_absolute_path(data['vec_no_bank_conflict_intrinsics'], config_dir)

    return ArcConfig(**data)
