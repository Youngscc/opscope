# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
"""
HIVM指令到TileOpCode的映射

HIVM MLIR中使用的指令格式为 hivm.hir.xxx，需要映射到TileOpCode枚举值
"""
from core.common.tile_op_enum import TileOpCode

# HIVM指令到TileOpCode的映射表
HIVM_OP_MAPPING: dict[str, TileOpCode] = {
    # 内存传输指令
    # load: 从GM加载数据到UB (PIPE_MTE2)
    'hivm.hir.load': TileOpCode.COPY,
    # store: 从UB存储数据到GM (PIPE_MTE3)
    'hivm.hir.store': TileOpCode.COPY,
    # copy: UB到UB或UB到L1的数据拷贝
    'hivm.hir.copy': TileOpCode.COPY,
    # fixpipe: L0C到其他内存层级的数据搬运 (PIPE_FIX)
    'hivm.hir.fixpipe': TileOpCode.COPY,
    # nd2nz: 从GM加载数据到L1 (PIPE_MTE2)
    'hivm.hir.nd2nz': TileOpCode.COPY,

    # 矩阵计算指令
    # mmadL1: L1输入的矩阵乘加 (PIPE_MTE1 + PIPE_M)
    # 注意：mmadL1 是宏操作，包含从 L1 到 L0 的搬运，所以映射到 GEMM
    'hivm.hir.mmadL1': TileOpCode.GEMM,
    # batchMmadL1: 批量矩阵乘加
    'hivm.hir.batchMmadL1': TileOpCode.GEMM,
    # matmul: GM输入的矩阵乘
    'hivm.hir.matmul': TileOpCode.GEMM,

    # 向量计算指令 (PIPE_V)
    'hivm.hir.vmul': TileOpCode.MUL,
    'hivm.hir.vadd': TileOpCode.ADD,
    'hivm.hir.vsub': TileOpCode.SUB,
    'hivm.hir.vdiv': TileOpCode.DIV,
    'hivm.hir.vmax': TileOpCode.MAX,
    'hivm.hir.vmin': TileOpCode.MIN,
    'hivm.hir.vexp': TileOpCode.EXP,
    'hivm.hir.vln': TileOpCode.LOG,  # vector log
    'hivm.hir.vsqrt': TileOpCode.SQRT,
    'hivm.hir.vcast': TileOpCode.CAST,
    'hivm.hir.vbrc': TileOpCode.BROADCAST,  # vector broadcast
    'hivm.hir.vabs': TileOpCode.ABS,
    'hivm.hir.vrelu': TileOpCode.RELU,
    'hivm.hir.vrsqrt': TileOpCode.RSQRT,

    # Reduce指令 (PIPE_V)
    # 格式: hivm.hir.vreduce <op> ins(...) outs(...) reduce_dims = [...]
    'hivm.hir.vreduce<max>': TileOpCode.REDUCE_MAX,
    'hivm.hir.vreduce<sum>': TileOpCode.REDUCE_SUM,
    'hivm.hir.vreduce<add>': TileOpCode.REDUCE_SUM,  # add和sum等效
    'hivm.hir.vreduce<min>': TileOpCode.REDUCE_MIN,

    # 同步指令
    # set_flag: 设置同步标志 [set_pipe, wait_pipe, event_id]
    'hivm.hir.set_flag': TileOpCode.BARRIER,
    # wait_flag: 等待同步标志
    'hivm.hir.wait_flag': TileOpCode.BARRIER,
    # pipe_barrier: 流水线屏障 [pipe]
    'hivm.hir.pipe_barrier': TileOpCode.BARRIER,
    # sync_block_set: 块同步设置
    'hivm.hir.sync_block_set': TileOpCode.BARRIER,
    # sync_block_wait: 块同步等待
    'hivm.hir.sync_block_wait': TileOpCode.BARRIER,

    # 其他指令
    'hivm.hir.pointer_cast': None,  # 地址转换，不生成实际操作
    'hivm.hir.set_ffts_base_addr': None,  # 设置FFTS基地址
    'hivm.hir.set_mask_norm': None,  # 设置mask归一化
    'hivm.hir.get_block_idx': None,  # 获取块索引
    'hivm.hir.get_sub_block_idx': None,  # 获取子块索引
}


def hivm_op_to_tileopcode(hivm_op: str) -> TileOpCode | None:
    """
    将HIVM指令字符串转换为TileOpCode枚举值

    Args:
        hivm_op: HIVM指令字符串，如 'hivm.hir.load', 'hivm.hir.mmadL1'

    Returns:
        对应的TileOpCode枚举值，如果指令不需要生成操作则返回None

    Raises:
        ValueError: 如果传入的指令字符串不被支持
    """
    hivm_op_stripped = hivm_op.strip()

    # 检查完整指令（带参数）
    if hivm_op_stripped in HIVM_OP_MAPPING:
        return HIVM_OP_MAPPING[hivm_op_stripped]

    # 提取基础指令名（去除空格和参数）
    base_op = hivm_op_stripped.split()[0] if ' ' in hivm_op_stripped else hivm_op_stripped

    if base_op in HIVM_OP_MAPPING:
        return HIVM_OP_MAPPING[base_op]

    # 特殊处理vreduce指令，格式: hivm.hir.vreduce <op>
    if 'hivm.hir.vreduce' in base_op:
        # 解析reduce类型
        if '<max>' in hivm_op_stripped:
            return TileOpCode.REDUCE_MAX
        elif '<sum>' in hivm_op_stripped or '<add>' in hivm_op_stripped:
            return TileOpCode.REDUCE_SUM
        elif '<min>' in hivm_op_stripped:
            return TileOpCode.REDUCE_MIN

    raise ValueError(f"Unknown HIVM operation: {hivm_op}")


def is_sync_op(hivm_op: str) -> bool:
    """
    判断HIVM指令是否为同步指令

    Args:
        hivm_op: HIVM指令字符串

    Returns:
        如果是同步指令返回True，否则返回False
    """
    sync_ops = {
        'hivm.hir.set_flag',
        'hivm.hir.wait_flag',
        'hivm.hir.pipe_barrier',
        'hivm.hir.sync_block_set',
        'hivm.hir.sync_block_wait',
    }
    base_op = hivm_op.strip().split()[0] if ' ' in hivm_op else hivm_op
    return base_op in sync_ops


def is_memory_op(hivm_op: str) -> bool:
    """
    判断HIVM指令是否为内存操作指令

    Args:
        hivm_op: HIVM指令字符串

    Returns:
        如果是内存操作指令返回True，否则返回False
    """
    memory_ops = {
        'hivm.hir.load',
        'hivm.hir.store',
        'hivm.hir.copy',
        'hivm.hir.fixpipe',
        'hivm.hir.nd2nz',
    }
    base_op = hivm_op.strip().split()[0] if ' ' in hivm_op else hivm_op
    return base_op in memory_ops