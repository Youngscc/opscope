# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
"""
HIVM MLIR解析工具类

提供解析MLIR文本格式的工具函数，包括:
- MemRef类型解析
- scf.for循环解析
- HIVM指令解析
- 函数定义解析
"""
import re
from dataclasses import dataclass
from typing import Optional

from core.common.entity import DType, MemLoc
from core.frontend.adaptor.hivm.hivm_mem_mapping import hivm_mem_to_memloc


@dataclass
class MemRefInfo:
    """MemRef类型信息"""
    shape: list[int | str]  # 维度大小，动态维度用 '?' 或字符串表示
    dtype: DType
    mem_loc: MemLoc
    strides: Optional[list[int]] = None
    offset: Optional[int | str] = None


@dataclass
class ForLoopInfo:
    """scf.for循环信息"""
    iter_var: str  # 迭代变量名
    lower_bound: str  # 下界表达式
    upper_bound: str  # 上界表达式
    step: str  # 步长表达式
    iter_args: list[str]  # 迭代参数
    body_lines: list[str]  # 循环体行
    end_line_idx: int  # 循环结束的行索引


@dataclass
class FuncInfo:
    """函数定义信息"""
    name: str  # 函数名
    args: list[tuple[str, str, dict]]  # (参数名, 类型, 属性)
    attrs: dict  # 函数属性
    core_type: str  # AIC 或 AIV
    body_lines: list[str]  # 函数体行


def parse_dtype(dtype_str: str) -> DType:
    """
    解析数据类型字符串

    Args:
        dtype_str: MLIR数据类型字符串，如 'f16', 'f32', 'i32'

    Returns:
        对应的DType枚举值
    """
    dtype_mapping = {
        'f16': DType.FP16,
        'fp16': DType.FP16,
        'bf16': DType.BF16,
        'f32': DType.FP32,
        'fp32': DType.FP32,
        'hf32': DType.HF32,
        'f8': DType.FP8,
        'fp8': DType.FP8,
        'i8': DType.INT8,
        'i16': DType.INT16,
        'i32': DType.INT32,
        'i64': DType.INT64,
        'ui8': DType.UINT8,
        'ui64': DType.UINT64,
        'bool': DType.BOOL,
    }
    dtype_lower = dtype_str.lower()
    if dtype_lower in dtype_mapping:
        return dtype_mapping[dtype_lower]
    # 默认返回FP32
    return DType.FP32


def _parse_strides_and_offset(memref_str):
    # 解析stride和offset
    strides = None
    offset = None
    strided_match = re.search(r'strided<\[(.+?)\](?:,\s*offset:\s*(\S+))?>', memref_str)
    if strided_match:
        strides_str = strided_match.group(1)
        # 解析strides，处理 '?' 的情况
        strides = []
        for s in strides_str.split(','):
            s = s.strip()
            if s == '?':
                strides.append('?')
            else:
                try:
                    strides.append(int(s))
                except ValueError:
                    strides.append(s)  # 动态stride用字符串表示
        if strided_match.group(2):
            offset_str = strided_match.group(2)
            try:
                offset = int(offset_str)
            except ValueError:
                offset = offset_str  # 动态offset
    return strides, offset


def _parse_memref_shape(parts):
    shape = []
    for part in parts[:-1]:
        part = part.strip()
        if part == '?' or part == '':
            shape.append('?')
        else:
            try:
                shape.append(int(part))
            except ValueError:
                shape.append(part)  # 动态维度用字符串表示
    return shape


def parse_memref(memref_str: str) -> MemRefInfo:
    """
    解析memref类型字符串

    支持格式:
    - memref<64x128xf16, #hivm.address_space<gm>>
    - memref<?xi8, #hivm.address_space<gm>>
    - memref<64x128xf16, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>

    Args:
        memref_str: memref类型字符串

    Returns:
        MemRefInfo对象
    """
    # 提取形状和数据类型部分
    # 需要正确处理嵌套的 <>
    # 找到 memref< 的起始位置
    start = memref_str.find('memref<')
    if start == -1:
        raise ValueError(f"Invalid memref format: {memref_str}")

    # 从 memref< 后面开始，找到匹配的 >
    start += 7  # 跳过 'memref<'
    depth = 1
    i = start
    while i < len(memref_str) and depth > 0:
        if memref_str[i] == '<':
            depth += 1
        elif memref_str[i] == '>':
            depth -= 1
        i += 1

    # 提取 memref<...> 内部的内容
    # 如果 depth == 0，说明找到了匹配的 >，i-1 是 > 的位置
    # 如果 depth > 0，说明没有匹配的 >，取到字符串末尾
    if depth == 0:
        inner_content = memref_str[start:i - 1]
    else:
        inner_content = memref_str[start:]

    # 提取地址空间
    mem_loc = MemLoc.GM  # 默认值
    addr_space_match = re.search(r'#hivm\.address_space<(\w+)>', memref_str)
    if addr_space_match:
        mem_loc = hivm_mem_to_memloc(addr_space_match.group(1))

    # 从 inner_content 中提取形状和数据类型部分
    # 格式: dim1xdim2x...xdtype, ...其他属性...
    # 需要找到第一个不在嵌套<>内的逗号
    shape_dtype_part = inner_content
    depth = 0
    for idx, ch in enumerate(inner_content):
        if ch == '<':
            depth += 1
        elif ch == '>':
            depth -= 1
        elif ch == ',' and depth == 0:
            shape_dtype_part = inner_content[:idx]
            break

    # 解析形状和数据类型
    # 格式: dim1xdim2x...xdtype
    parts = shape_dtype_part.split('x')

    # 最后一部分是数据类型
    dtype_str = parts[-1].strip()
    dtype = parse_dtype(dtype_str)

    # 前面的部分是形状
    shape = _parse_memref_shape(parts)

    # 解析stride和offset
    strides, offset = _parse_strides_and_offset(memref_str)

    return MemRefInfo(
        shape=shape,
        dtype=dtype,
        mem_loc=mem_loc,
        strides=strides,
        offset=offset
    )


def parse_for_loop(lines: list[str], start_idx: int) -> Optional[ForLoopInfo]:
    """
    解析scf.for循环

    格式示例:
    scf.for %arg11 = %6 to %c2048_i32 step %c20_i32 : i32 {
      ...
    }

    或带iter_args:
    scf.for %arg12 = %c0_i32 to %c1024_i32 step %c32_i32 iter_args(%arg13 = %c0_i32, %arg14 = %c0_i32) -> (i32, i32) : i32 {
      ...
    }

    Args:
        lines: MLIR代码行列表
        start_idx: 循环开始的行索引

    Returns:
        ForLoopInfo对象，如果解析失败返回None
    """
    line = lines[start_idx].strip()

    # 匹配scf.for语句
    for_match = re.match(
        r'scf\.for\s+(\S+)\s*=\s*(\S+)\s+to\s+(\S+)\s+step\s+(\S+)',
        line
    )
    if not for_match:
        return None

    iter_var = for_match.group(1)
    lower_bound = for_match.group(2)
    upper_bound = for_match.group(3)
    step = for_match.group(4)

    # 解析iter_args
    iter_args = []
    iter_args_match = re.search(r'iter_args\(([^)]+)\)', line)
    if iter_args_match:
        iter_args_str = iter_args_match.group(1)
        # 解析每个iter_arg
        for arg_pair in iter_args_str.split(','):
            arg_pair = arg_pair.strip()
            if '=' in arg_pair:
                arg_name = arg_pair.split('=')[0].strip()
                iter_args.append(arg_name)

    # 查找循环体
    brace_count = 0
    body_lines = []
    end_idx = start_idx

    for i in range(start_idx, len(lines)):
        current_line = lines[i]
        brace_count += current_line.count('{') - current_line.count('}')

        if i > start_idx:
            body_lines.append(current_line)

        if brace_count == 0 and i > start_idx:
            end_idx = i
            break

    # 移除最后的 '}'
    if body_lines and body_lines[-1].strip().startswith('}'):
        body_lines = body_lines[:-1]

    return ForLoopInfo(
        iter_var=iter_var,
        lower_bound=lower_bound,
        upper_bound=upper_bound,
        step=step,
        iter_args=iter_args,
        body_lines=body_lines,
        end_line_idx=end_idx
    )


def parse_func_def(lines: list[str], start_idx: int) -> Optional[FuncInfo]:
    """
    解析func.func函数定义

    格式示例:
    func.func @_attn_fwd_mix_aic(%arg0: i64 {...}, ...) attributes {...} {

    Args:
        lines: MLIR代码行列表
        start_idx: 函数开始的行索引

    Returns:
        FuncInfo对象，如果解析失败返回None
    """
    line = lines[start_idx].strip()

    # 匹配func.func语句
    func_match = re.match(r'func\.func\s+@(\w+)\s*\(([^)]*)\)', line)
    if not func_match:
        return None

    func_name = func_match.group(1)
    args_str = func_match.group(2)

    # 解析参数
    args = []
    # 简单解析参数列表
    arg_pattern = r'(%\w+):\s*([^,}]+(?:\{[^}]*\})?)'
    for match in re.finditer(arg_pattern, args_str):
        arg_name = match.group(1)
        arg_type = match.group(2).strip()
        args.append((arg_name, arg_type, {}))

    # 解析属性
    attrs = {}
    attrs_match = re.search(r'attributes\s*\{([^}]+)\}', line)
    if attrs_match:
        attrs_str = attrs_match.group(1)
        # 解析关键属性
        if 'AIC' in attrs_str:
            attrs['core_type'] = 'AIC'
        elif 'AIV' in attrs_str:
            attrs['core_type'] = 'AIV'

    # 确定核类型
    core_type = attrs.get('core_type', 'UNKNOWN')
    if 'hivm.func_core_type = #hivm.func_core_type<AIC>' in line:
        core_type = 'AIC'
    elif 'hivm.func_core_type = #hivm.func_core_type<AIV>' in line:
        core_type = 'AIV'

    # 查找函数体
    brace_count = 0
    body_lines = []
    end_idx = start_idx

    for i in range(start_idx, len(lines)):
        current_line = lines[i]
        brace_count += current_line.count('{') - current_line.count('}')

        if i > start_idx:
            body_lines.append(current_line)

        if brace_count == 0 and i > start_idx:
            end_idx = i
            break

    # 移除最后的 '}'
    if body_lines and body_lines[-1].strip().startswith('}'):
        body_lines = body_lines[:-1]

    return FuncInfo(
        name=func_name,
        args=args,
        attrs=attrs,
        core_type=core_type,
        body_lines=body_lines
    )


def extract_hivm_instruction(line: str) -> Optional[tuple[str, str]]:
    """
    从一行MLIR代码中提取HIVM指令

    Args:
        line: MLIR代码行

    Returns:
        (指令名, 完整指令字符串) 元组，如果不是HIVM指令返回None
    """
    line = line.strip()

    # 匹配hivm.hir.xxx指令（使用search因为指令可能不在行首，如 %var = hivm.hir.xxx）
    hivm_match = re.search(r'(hivm\.hir\.\w+(?:\s*<[^>]+>)?)', line)
    if hivm_match:
        op_name = hivm_match.group(1).split()[0] if ' ' in hivm_match.group(1) else hivm_match.group(1)
        # 处理带参数的指令如 vreduce <max>
        if 'vreduce' in op_name and '<' in line:
            reduce_match = re.search(r'vreduce\s*<(\w+)>', line)
            if reduce_match:
                op_name = f'hivm.hir.vreduce<{reduce_match.group(1)}>'
        return (op_name, line)

    return None


def parse_instruction_operands(line: str) -> tuple[list[str], list[str], dict]:
    """
    解析指令的操作数

    格式示例:
    hivm.hir.load ins(%src : memref<...>) outs(%dst : memref<...>)
    hivm.hir.mmadL1 {...} ins(%a, %b, %c : ...) outs(%d : ...)

    Args:
        line: 指令行

    Returns:
        (输入操作数列表, 输出操作数列表, 属性字典)
    """
    inputs = []
    outputs = []
    attrs = {}

    # 解析ins部分
    ins_match = re.search(r'ins\(([^)]+)\)', line)
    if ins_match:
        ins_str = ins_match.group(1)
        # 提取操作数名称
        inputs = re.findall(r'%\w+', ins_str)

    # 解析outs部分
    outs_match = re.search(r'outs\(([^)]+)\)', line)
    if outs_match:
        outs_str = outs_match.group(1)
        outputs = re.findall(r'%\w+', outs_str)

    # 解析属性（花括号内的内容）
    attrs_match = re.search(r'\{([^}]+)\}', line)
    if attrs_match:
        attrs_str = attrs_match.group(1)
        # 简单解析属性
        for attr_pair in attrs_str.split(','):
            if '=' in attr_pair:
                key, value = attr_pair.split('=', 1)
                attrs[key.strip()] = value.strip()

    return inputs, outputs, attrs


def _extract_operand_types(types_part):
    # 提取类型（需要处理嵌套括号）
    types = []
    i = 0
    while i < len(types_part):
        # 跳过空白和逗号
        while i < len(types_part) and types_part[i] in ' ,':
            i += 1
        if i >= len(types_part):
            break

        # 检测类型开始
        if types_part[i:i + 7] == 'memref<':
            depth = 1
            j = i + 7
            while j < len(types_part) and depth > 0:
                if types_part[j] == '<':
                    depth += 1
                elif types_part[j] == '>':
                    depth -= 1
                j += 1
            types.append(types_part[i:j])
            i = j
        elif types_part[i:i + 6] == 'tensor':
            # 处理 tensor<...> 类型
            depth = 1
            j = i + 7
            while j < len(types_part) and depth > 0:
                if types_part[j] == '<':
                    depth += 1
                elif types_part[j] == '>':
                    depth -= 1
                j += 1
            types.append(types_part[i:j])
            i = j
        elif types_part[i] in 'ifb':  # f32, i1, bf16, fp16, etc.
            j = i
            while j < len(types_part) and types_part[j] not in ' ,':
                j += 1
            types.append(types_part[i:j])
            i = j
        elif types_part[i:i + 5] == 'index':
            types.append('index')
            i += 5
        elif types_part[i:i + 2] == 'i1' or types_part[i:i + 2] == 'i8':
            j = i
            while j < len(types_part) and types_part[j] not in ' ,':
                j += 1
            types.append(types_part[i:j])
            i = j
        elif types_part[i] == 'i' or types_part[i] == 'u':
            # i32, i64, u8, etc.
            j = i
            while j < len(types_part) and types_part[j] not in ' ,':
                j += 1
            types.append(types_part[i:j])
            i = j
        else:
            i += 1
    return types


def parse_operand_types(section: str) -> list[tuple[str, str]]:
    """
    解析ins/outs部分中的变量-类型对

    格式示例:
    ins(%var1, %var2 : type1, type2)
    ins(%var1 : type1, %var2 : type2)

    Args:
        section: ins(...)或outs(...)中的内容

    Returns:
        [(变量名, 类型字符串)] 列表
    """
    section = section.strip()

    # 分离变量和类型（以第一个不在嵌套括号内的 : 为分隔符）
    colon_idx = -1
    depth = 0
    for i, c in enumerate(section):
        if c in '<([{':
            depth += 1
        elif c in '>)\\]}':
            depth -= 1
        elif c == ':' and depth == 0:
            colon_idx = i
            break

    if colon_idx == -1:
        # 没有类型信息，只提取变量名
        return [(var, None) for var in re.findall(r'%\w+', section)]

    vars_part = section[:colon_idx].strip()
    types_part = section[colon_idx + 1:].strip()

    # 提取变量名
    var_names = re.findall(r'%\w+', vars_part)

    types = _extract_operand_types(types_part)

    # 配对变量和类型
    result = []
    for idx, var in enumerate(var_names):
        if idx < len(types):
            result.append((var, types[idx]))
        else:
            result.append((var, None))

    return result


def extract_operand_type_pairs(line: str) -> tuple[list[tuple[str, str]], list[tuple[str, str]]]:
    """
    从指令行中提取输入和输出的变量-类型对

    Args:
        line: 指令行

    Returns:
        (输入变量-类型对列表, 输出变量-类型对列表)
    """
    input_pairs = []
    output_pairs = []

    # 解析ins部分
    ins_match = re.search(r'ins\(([^)]+)\)', line)
    if ins_match:
        input_pairs = parse_operand_types(ins_match.group(1))

    # 解析outs部分
    outs_match = re.search(r'outs\(([^)]+)\)', line)
    if outs_match:
        output_pairs = parse_operand_types(outs_match.group(1))

    return input_pairs, output_pairs


def parse_constant(line: str) -> Optional[tuple[str, any, str]]:
    """
    解析arith.constant指令

    格式示例:
    %c3_i64 = arith.constant 3 : i64
    %cst = arith.constant 1.000000e+00 : f32
    %cst_0 = arith.constant 0xFF800000 : f32

    Args:
        line: MLIR代码行

    Returns:
        (变量名, 值, 类型) 元组，如果不是constant指令返回None
    """
    import struct

    line = line.strip()

    const_match = re.match(r'(%[\w-]+)\s*=\s*arith\.constant\s+([-\d]+)\s*:\s*(\w+)', line)
    if const_match:
        var_name = const_match.group(1)
        value_str = const_match.group(2)
        dtype_str = const_match.group(3)

        # 转换值
        if dtype_str.startswith('i') or dtype_str.startswith('u'):
            value = int(value_str)
        elif dtype_str.startswith('f'):
            # 处理十六进制浮点数表示 (如 0xFF800000)
            if value_str.startswith('0x') or value_str.startswith('0X'):
                # 将十六进制转换为整数，然后解释为浮点数
                int_bits = int(value_str, 16)
                if dtype_str == 'f32':
                    value = struct.unpack('!f', struct.pack('!I', int_bits))[0]
                elif dtype_str == 'f16':
                    value = struct.unpack('!e', struct.pack('!H', int_bits))[0]
                else:
                    value = float(int_bits)
            else:
                value = float(value_str)
        elif dtype_str == 'bool':
            value = value_str == 'true'
        else:
            value = value_str

        return (var_name, value, dtype_str)
    elif 'arith.constant true' in line:
        pattern = r'^(%\w+)\s*=\s*.*?(true|false)$'

        # 执行正则匹配
        match = re.match(pattern, line.strip())
        if match:
            var_name = match.group(1)
            value = 1 if match.group(2) == 'true' else 0
            dtype_str = 'bool'
            return (var_name, value, dtype_str)

    return None


def parse_value_assignment(line: str) -> Optional[tuple[str, str]]:
    """
    解析值赋值语句

    格式示例:
    %0 = arith.muli %arg8, %arg9 : i32
    %view = memref.view %arg2[%8][] : ...

    Args:
        line: MLIR代码行

    Returns:
        (变量名, 表达式) 元组，如果不是赋值语句返回None
    """
    line = line.strip()

    assign_match = re.match(r'(%\w+)\s*=\s*(.+)$', line)
    if assign_match:
        var_name = assign_match.group(1)
        expr = assign_match.group(2).strip()
        return (var_name, expr)

    return None


@dataclass
class ArithOpInfo:
    """算术操作信息"""
    op_name: str  # 操作名 (如 'arith.addi', 'arith.muli')
    result_var: str  # 结果变量名
    operands: list[str]  # 操作数变量名列表
    dtype: str  # 数据类型 (如 'i32', 'f32')
    raw_line: str  # 原始行


def parse_arith_operation(line: str) -> Optional[ArithOpInfo]:
    """
    解析arith操作语句

    格式示例:
    %75 = arith.addi %arg13, %c32_i32 : i32
    %0 = arith.muli %arg8, %arg9 : i32
    %56 = arith.addi %arg16, %c32_i32 : i32

    Args:
        line: MLIR代码行

    Returns:
        ArithOpInfo对象，如果不是arith操作返回None
    """
    line = line.strip()

    # 匹配 %var = arith.xxx operand1, operand2, ... : type 格式
    # 注意：操作数可能有多个，用逗号分隔
    pattern = r'(%\w+)\s*=\s*(arith\.\w+)\s+(.+?)\s*:\s*(\w+)'
    match = re.match(pattern, line)
    if not match:
        return None

    result_var = match.group(1)
    op_name = match.group(2)
    operands_str = match.group(3)
    dtype = match.group(4)

    # 提取操作数变量名
    operands = re.findall(r'%\w+', operands_str)

    return ArithOpInfo(
        op_name=op_name,
        result_var=result_var,
        operands=operands,
        dtype=dtype,
        raw_line=line
    )


def get_arith_op_tile_code(op_name: str) -> tuple[str, str]:
    """
    从arith操作名获取对应的指令名和原始操作名

    arith. 开头的操作是 Scalar 操作，在 AIC_S 或 AIV_S 上执行

    Args:
        op_name: arith操作名 (如 'arith.addi', 'arith.muli')

    Returns:
        (指令名, 原始操作名) 元组
        指令名对应 TileOpCode 枚举值
    """
    # 所有 arith 操作都映射到 SCALAR_OP
    # 具体的操作类型保存在 raw_inst_name 中供参考
    arith_ops = [
        'arith.addi', 'arith.addf',
        'arith.muli', 'arith.mulf', 'arith.mulsi',
        'arith.subi', 'arith.subf',
        'arith.divsi', 'arith.divui', 'arith.divf',
        'arith.remsi', 'arith.remui',
        'arith.extsi', 'arith.extui', 'arith.extf',
        'arith.trunci', 'arith.truncf',
        'arith.cmpi', 'arith.cmpf',
        'arith.select',
        'arith.index_cast', 'arith.index_castui',
        'arith.minsi', 'arith.maxsi', 'arith.minf', 'arith.maxf',
        'arith.andi', 'arith.ori', 'arith.xori',
        'arith.shli', 'arith.shrsi', 'arith.shrui',
        'arith.negf',
    ]
    if op_name in arith_ops:
        return ('SCALAR_OP', op_name)
    return ('UNKNOWN', op_name)


@dataclass
class SyncFlagInfo:
    """同步标志指令信息"""
    op_type: str  # 'set_flag', 'wait_flag', 'sync_block_set', 'sync_block_wait', 'pipe_barrier'
    src_pipe: str = ""  # 源流水线
    dst_pipe: str = ""  # 目标流水线
    event_id: str = ""  # 事件ID (可能是变量如 %17 或常量如 EVENT_ID0)
    core_type: str = ""  # 核类型 (CUBE, VECTOR)
    flag: str = ""  # sync_block 的 flag 编号


def parse_sync_flag_instruction(line: str) -> Optional[SyncFlagInfo]:
    """
    解析同步标志指令

    格式示例:
    - hivm.hir.set_flag[<PIPE_M>, <PIPE_MTE1>, <EVENT_ID0>]
    - hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %17]
    - hivm.hir.sync_block_set[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
    - hivm.hir.sync_block_wait[<VECTOR>, <PIPE_FIX>, <PIPE_S>] flag = 1
    - hivm.hir.pipe_barrier[<PIPE_V>]

    Args:
        line: MLIR代码行

    Returns:
        SyncFlagInfo对象，如果不是同步指令返回None
    """
    line = line.strip()

    # 解析 set_flag 和 wait_flag
    # 格式: hivm.hir.set_flag[<PIPE_src>, <PIPE_dst>, <EVENT_ID>] 或 hivm.hir.wait_flag[<PIPE_src>, <PIPE_dst>, %var]
    # 注意第三个参数可能是 <EVENT_ID0> 或 %17
    flag_match = re.match(
        r'hivm\.hir\.(set_flag|wait_flag)\[<(\w+)>,\s*<(\w+)>,\s*(?:<(\w+)>|(%\w+))\]',
        line
    )
    if flag_match:
        event_id = flag_match.group(4) if flag_match.group(4) else flag_match.group(5)
        return SyncFlagInfo(
            op_type=flag_match.group(1),
            src_pipe=flag_match.group(2),
            dst_pipe=flag_match.group(3),
            event_id=event_id
        )

    # 解析 sync_block_set 和 sync_block_wait
    # 格式: hivm.hir.sync_block_set[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
    sync_block_match = re.match(
        r'hivm\.hir\.(sync_block_set|sync_block_wait)\[<(\w+)>,\s*<(\w+)>,\s*<(\w+)>\]\s*flag\s*=\s*(\d+)',
        line
    )
    if sync_block_match:
        return SyncFlagInfo(
            op_type=sync_block_match.group(1),
            core_type=sync_block_match.group(2),
            src_pipe=sync_block_match.group(3),
            dst_pipe=sync_block_match.group(4),
            flag=sync_block_match.group(5)
        )

    # 解析 pipe_barrier
    # 格式: hivm.hir.pipe_barrier[<PIPE_V>] 或 hivm.hir.pipe_barrier[<PIPE_ALL>]
    barrier_match = re.match(
        r'hivm\.hir\.pipe_barrier\[<(\w+)>\]',
        line
    )
    if barrier_match:
        return SyncFlagInfo(
            op_type='pipe_barrier',
            src_pipe=barrier_match.group(1)
        )

    return None