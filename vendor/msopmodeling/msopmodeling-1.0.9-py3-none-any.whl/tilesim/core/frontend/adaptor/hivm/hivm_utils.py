# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
"""
HIVM适配器工具函数
"""
import re
from dataclasses import dataclass
from typing import Optional, Any

from core.common.entity import DType, MemLoc, CoreType
from core.frontend.ir.core.ir_entity import TensorIR
from core.frontend.ir.core.ir_math import ConstExprIR, VarExprIR
from core.pipeline.basic_operator import OperatorExtraParam


@dataclass
class HIVMExtraParam(OperatorExtraParam):
    """HIVM额外参数"""
    hivm_path: str = None  # HIVM MLIR文件路径
    model_level: int = 2  # 模型层级


def get_core_type_from_hivm(func_attrs: dict) -> CoreType:
    """
    从HIVM函数属性中提取核类型

    Args:
        func_attrs: 函数属性字典

    Returns:
        CoreType枚举值
    """
    core_type_str = func_attrs.get('core_type', '').upper()
    if core_type_str == 'AIC':
        return CoreType.AIC
    elif core_type_str == 'AIV':
        return CoreType.AIV
    return CoreType.MIX


def extract_address_space(memref_str: str) -> Optional[str]:
    """
    从memref字符串中提取地址空间

    Args:
        memref_str: memref类型字符串

    Returns:
        地址空间字符串，如 'gm', 'cbuf', 'ub', 'cc'
    """
    match = re.search(r'#hivm\.address_space<(\w+)>', memref_str)
    if match:
        return match.group(1)
    return None


def extract_shape_from_memref(memref_str: str) -> list[int | str]:
    """
    从memref字符串中提取形状

    Args:
        memref_str: memref类型字符串

    Returns:
        形状列表，动态维度用 '?' 表示
    """
    # 提取memref<...>中的内容
    match = re.match(r'memref<([^>]+)>', memref_str)
    if not match:
        # 处理嵌套<>的情况
        match = re.match(r'memref<(.+?)>\s*(?:,|$)', memref_str)

    if not match:
        return []

    shape_dtype = match.group(1)
    parts = shape_dtype.split('x')

    shape = []
    for part in parts[:-1]:  # 最后一部分是dtype
        part = part.strip()
        if part == '?' or part == '':
            shape.append('?')
        else:
            try:
                shape.append(int(part))
            except ValueError:
                shape.append(part)

    return shape


def extract_dtype_from_memref(memref_str: str) -> DType:
    """
    从memref字符串中提取数据类型

    Args:
        memref_str: memref类型字符串

    Returns:
        DType枚举值
    """
    dtype_mapping = {
        'f16': DType.FP16,
        'bf16': DType.BF16,
        'f32': DType.FP32,
        'i8': DType.INT8,
        'i16': DType.INT16,
        'i32': DType.INT32,
        'i64': DType.INT64,
    }

    # 提取最后一个x后面的类型
    match = re.search(r'x(\w+)(?:\s*,|>)', memref_str)
    if match:
        dtype_str = match.group(1).lower()
        return dtype_mapping.get(dtype_str, DType.FP32)

    return DType.FP32


def create_tensor_ir_from_memref(name: str, memref_str: str) -> TensorIR:
    """
    从memref字符串创建TensorIR

    Args:
        name: 张量名称
        memref_str: memref类型字符串

    Returns:
        TensorIR对象
    """
    from core.frontend.adaptor.hivm.hivm_mem_mapping import hivm_mem_to_memloc

    shape = extract_shape_from_memref(memref_str)
    dtype = extract_dtype_from_memref(memref_str)
    addr_space = extract_address_space(memref_str)

    mem_loc = hivm_mem_to_memloc(addr_space) if addr_space else MemLoc.GM

    # 将形状转换为ConstExprIR或VarExprIR
    shape_ir = []
    for dim in shape:
        if isinstance(dim, int):
            shape_ir.append(ConstExprIR(dim))
        elif dim == '?':
            shape_ir.append(VarExprIR(f'{name}_dim_{len(shape_ir)}'))
        else:
            shape_ir.append(VarExprIR(str(dim)))

    return TensorIR(name, shape_ir, dtype, mem_loc)


def is_mix_mode(func_attrs: dict) -> bool:
    """
    判断是否为Mix模式

    Args:
        func_attrs: 函数属性字典

    Returns:
        如果是Mix模式返回True
    """
    return func_attrs.get('mix_mode', '') == 'mix' or 'hivm.part_of_mix' in str(func_attrs)


def clean_mlir_line(line: str) -> str:
    """
    清理MLIR行，移除注释和多余空白

    Args:
        line: MLIR代码行

    Returns:
        清理后的代码行
    """
    # 移除注释
    if '//' in line:
        line = line.split('//')[0]
    return line.strip()


def parse_pipeline_flags(line: str) -> dict:
    """
    解析流水线标志信息

    Args:
        line: 包含PIPE_xxx标志的指令行

    Returns:
        标志信息字典
    """
    flags = {}

    # 匹配 <PIPE_xxx>
    pipe_matches = re.findall(r'<(PIPE_\w+)>', line)
    if pipe_matches:
        flags['pipes'] = pipe_matches

    # 匹配 <EVENT_IDx>
    event_match = re.search(r'<(EVENT_ID\d+)>', line)
    if event_match:
        flags['event_id'] = event_match.group(1)

    # 匹配 <CUBE> 或 <VECTOR>
    core_match = re.search(r'<(CUBE|VECTOR)>', line)
    if core_match:
        flags['core_unit'] = core_match.group(1)

    return flags