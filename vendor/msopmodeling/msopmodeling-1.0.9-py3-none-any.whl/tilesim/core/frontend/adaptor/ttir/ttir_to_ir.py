# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import ast
import re
from typing import List

from core.common.tile_op_enum import TileOpCode
from core.common.backend_config import BackendConfig
from core.backend.theoretical_costmodel.basic_stage_roofline.basic_cost_api import TensorData
from core.common.entity import OpLevel, DType, MemLoc
from core.frontend.dsl.parse.dsl_to_expr_ir import expr_parse
from core.frontend.ir.core.ir_math import RangeIR, ConstExprIR
from ops.theoretical_model.ttir_op.loop_analyzer import create_mlir_loop_calculator
from ops.theoretical_model.ttir_op.ttir_adapter import analyze_mlir_code
from ops.theoretical_model.ttir_op.ttir_utils import init_logger
from core.frontend.ir.core.ir import KernelIR
from core.frontend.ir.core.ir_entity import TensorIR, VarIR
from core.frontend.ir.core.ir_logistic import TaskIR, ForIR, OpIR

logger = init_logger()

ttir_to_tile_op = {
    'arith.addi': TileOpCode.ADD,
    'arith.addf': TileOpCode.ADD,
    'arith.muli': TileOpCode.MUL,
    'arith.cmpi': TileOpCode.NOT_EQUAL,
    'arith.cmpf': TileOpCode.GREATER_EQUAL,
    'arith.select': TileOpCode.SELECT,
    'arith.maxnumf': TileOpCode.MAX,
    'arith.divf': TileOpCode.DIV,
    'math.exp': TileOpCode.EXP,
    'arith.subf': TileOpCode.SUB,
    'tensor.insert_slice': TileOpCode.COPY,
    'tt.reduce_add': TileOpCode.REDUCE_SUM,
    'tt.reduce_max': TileOpCode.REDUCE_MAX,
    'tt.broadcast': TileOpCode.BROADCAST,
    'tt.dot': TileOpCode.GEMM,
    'tt.trans': TileOpCode.TRANSPOSE,
    'arith.mulf': TileOpCode.MUL,
    'arith.truncf': TileOpCode.CAST,
    'math.log2': TileOpCode.LOG
}


class TTIRToIrBuilder:
    def __init__(self, mlir_code: str, param, sim_config):
        self.mlir_code = mlir_code
        self.param = param
        self.sim_config = sim_config
        self.task_id = 0
        self.kernel_ir = KernelIR("TTIR")
        self.all_tensors = {}

    def _is_memloc_coretype_different(self, memloc_1, memloc_2):
        aiv_set = {'UB'}
        aic_set = {'L1', 'L0C'}
        return (memloc_1 in aiv_set and memloc_2 in aic_set) or (memloc_2 in aiv_set and memloc_1 in aic_set)

    def convert_tensor(self, tensor: TensorData) -> TensorIR:
        """将TensorData转换成TensorIR"""
        tensor_shape = [ConstExprIR(shape) for shape in tensor.shape]
        tensor_dtype = DType.from_str(tensor.d_type)
        tensor_mem_loc = MemLoc.from_str(tensor.mem_loc)
        return TensorIR(tensor.name, tensor_shape, tensor_dtype, tensor_mem_loc)

    def _remove_all_tensor_versions(self, tensor_name):
        for k in list(self.all_tensors):
            if (tensor_name + "_") in k:
                self.all_tensors.pop(k)

    def _parse_tensors(self, tensors: List[TensorData], task: TaskIR = None, flush_tensor=False) -> list[TensorIR]:
        """将TensorIR生成，并根据tensor的位置来添加copy操作"""
        if tensors is None:
            return []
        ret = []
        for tensor in tensors:
            tensor_ir = self.convert_tensor(tensor)

            # TTIR会把不同mem_loc上的tensor命名成相同的名称，因此这里需要区分并创建不同的TensorIR
            if tensor.name not in self.all_tensors:
                # 没有遇到过的tensor名称，直接添加
                ret.append(tensor_ir)
                self.all_tensors[tensor.name] = tensor
            else:
                # 遇到过的tensor名称，说明该tensor是前置ttir行的输入或输出
                if flush_tensor:
                    # 当这个tensor是某行的输出tensor或者是load指令，并且之前遇到过这个名称，说明ttir重复创建了新的同名tensor，需要删除之前所有的版本
                    ret.append(tensor_ir)
                    self._remove_all_tensor_versions(tensor.name)
                    self.all_tensors[tensor.name] = tensor
                    continue
                last_same_tensor = self.all_tensors[tensor.name]  # 找到之前的同名tensor
                # ttir中真实tensor信息只在第一次出现的时候定义，因此选取last_same_tensor的信息
                last_tensor_ir = self.convert_tensor(last_same_tensor)
                if tensor.mem_loc == last_same_tensor.mem_loc:
                    ret.append(last_tensor_ir)
                    continue
                new_tensor_name = tensor.name + "_" + tensor.mem_loc
                tensor_ir.name = new_tensor_name
                tensor_ir.shape = [ConstExprIR(shape) for shape in last_same_tensor.shape]
                tensor_ir.dtype = DType.from_str(last_same_tensor.d_type)
                ret.append(tensor_ir)
                if new_tensor_name in self.all_tensors:
                    # new_tensor_name已被创建过，说明已经在对应cache上，不需要额外操作
                    continue

                # 前置ttir行解析的tensor mem_loc不一致，并且new_tensor_name未被创建过，则创建新tensor并添加copy操作
                self.all_tensors[new_tensor_name] = tensor
                if self._is_memloc_coretype_different(tensor.mem_loc,
                                                      last_same_tensor.mem_loc) and '910B' in self.sim_config.accelerator:
                    # 对于A2、A3硬件，aic和aiv之间的搬运没有直接的带宽，需要经过L2，因此搬运两次
                    tensor_name_L2 = tensor.name + "_L2"
                    tensor_data_l2 = TensorData(tensor_name_L2, last_same_tensor.shape, last_same_tensor.d_type, "L2", "")
                    tensor_ir_l2 = self.convert_tensor(tensor_data_l2)
                    self.all_tensors[tensor_name_L2] = tensor_data_l2
                    op_ir_1 = OpIR(OpLevel.TILE_OP, TileOpCode.COPY, [last_tensor_ir], [tensor_ir_l2])
                    op_ir_2 = OpIR(OpLevel.TILE_OP, TileOpCode.COPY, [tensor_ir_l2], [tensor_ir])
                    task.body.append(op_ir_1)
                    task.body.append(op_ir_2)
                else:
                    op_ir = OpIR(OpLevel.TILE_OP, TileOpCode.COPY, [last_tensor_ir], [tensor_ir])
                    task.body.append(op_ir)
        return ret

    def _str_to_expr_ir(self, expr_str: str):
        """
        处理带 %变量 的表达式：
        1. 临时替换 %xxx 为合法 Python 变量（避免 ast.parse 报错）
        2. ast 解析表达式
        3. 自动还原回原始 %xxx 格式
        """
        # 用来存储映射：临时变量名 → 原始 %变量名
        var_mapping = {}
        counter = 0

        # 匹配所有以 % 开头的变量
        def replace_var(match):
            nonlocal counter
            original = match.group(0)
            temp_var = f'tmp_var_{counter}'  # 生成合法临时变量名
            var_mapping[temp_var] = original
            counter += 1
            return temp_var

        processed_str = re.sub(r'%\w+', replace_var, expr_str)
        module = ast.parse(processed_str, mode='eval')
        expr_node = module.body

        class RestoreVisitor(ast.NodeTransformer):
            def visit_Name(self, node):
                if node.id in var_mapping:
                    # 还原为原来的 %xxx 名称
                    node.id = var_mapping[node.id]
                return node

        # 执行还原
        restored_node = RestoreVisitor().visit(expr_node)
        ast.fix_missing_locations(restored_node)
        return expr_parse(restored_node)

    def _add_host_op(self, task: TaskIR, for_range: VarIR):
        """让for循环中的搬入搬出操作关联循环下标，保证搬运不命中L2"""
        # NEXT -- 命中L2的逻辑需要用ttir关联到循环下标，从而算出命中率
        pos_offset = 0
        for i, op_ir in enumerate(task.body[:]):
            if op_ir.op_code == TileOpCode.COPY:
                if op_ir.inputs[0].mem_loc == MemLoc.GM:
                    null_op = OpIR(OpLevel.HOST_OP, TileOpCode.NULL_OP, [for_range], op_ir.inputs)
                    task.body.insert(i + pos_offset, null_op)
                    pos_offset += 1
                elif op_ir.outputs[0].mem_loc == MemLoc.GM:
                    null_op = OpIR(OpLevel.HOST_OP, TileOpCode.NULL_OP, [for_range], op_ir.outputs)
                    task.body.insert(i + pos_offset, null_op)
                    pos_offset += 1

    def _parse_loops(self, task: TaskIR) -> ForIR | TaskIR:
        """解析ttir中的循环，如果成功解析则返回最外层的ForIR，否则返回TaskIR"""
        try:
            calculator = create_mlir_loop_calculator(self.mlir_code, self.sim_config.aiv_core_num)
            all_loops = calculator['formulas']['all_loops']
            if not all_loops:
                return task
            for_ir_dict = {}
            for loop_id, loop in all_loops.items():
                for_range = VarIR(
                    name=loop['variable'],
                    value=RangeIR(
                        start=self._str_to_expr_ir(loop['start_formula']),
                        end=self._str_to_expr_ir(loop['end_formula']),
                        step=self._str_to_expr_ir(loop['step_formula'])
                    ))
                for_ir_dict[loop_id] = ForIR("", range=for_range, body=[])
            for loop_id, for_ir in for_ir_dict.items():
                for_ir.body = [for_ir_dict.get(child_loops) for child_loops in all_loops[loop_id]['child']]
                if for_ir.body:
                    # 如果有子循环，则不处理
                    continue
                self._add_host_op(task, for_ir.range)
                for_ir.body = task.body
                return_value = all_loops[loop_id]['return_value']
                if return_value is None:
                    continue
                yield_data_list = all_loops[loop_id]['yield_data']
                yield_tensor_ir = [self.convert_tensor(self.all_tensors[yield_data]) for yield_data in yield_data_list]
                # NEXT - 对于多返回值的情况需要适配
                return_tensor_ir = TensorIR(return_value, yield_tensor_ir[0].shape, yield_tensor_ir[0].dtype,
                                            yield_tensor_ir[0].mem_loc)
                op_ir = OpIR(OpLevel.TILE_OP, TileOpCode.NULL_OP, yield_tensor_ir, [return_tensor_ir])
                for_ir.body.append(op_ir)
            return for_ir_dict.get(calculator['formulas']['top_level_loops'][0])
        except ValueError as e:
            logger.warning(e)
            logger.warning("循环解析出错，可能导致预测时延异常")
            return task

    def parse_ttir_lines(self):
        inst_event_list = analyze_mlir_code(self.mlir_code)
        task = TaskIR(indices=[], body=[], task_name='ttir_task')
        for inst_event in inst_event_list:
            if 'tt.load' in inst_event.raw_inst_name:
                self._parse_tensors(inst_event.input_tensors, task, flush_tensor=True)
                continue
            elif 'tt.store' in inst_event.raw_inst_name:
                self._parse_tensors(inst_event.input_tensors, task)
                continue
            else:
                op_type = TileOpCode.NULL_OP if '(raw)' in inst_event.inst_name else ttir_to_tile_op.get(
                    inst_event.raw_inst_name, TileOpCode.NULL_OP)
                input_tensors = self._parse_tensors(inst_event.input_tensors, task)
                output_tensors = self._parse_tensors(inst_event.output_tensors, flush_tensor=True)
            op_ir = OpIR(OpLevel.TILE_OP, op_type, input_tensors, output_tensors)
            task.body.append(op_ir)
        loop_contain_task = self._parse_loops(task)
        if isinstance(loop_contain_task, ForIR):
            out_task = TaskIR([], [loop_contain_task], 'ttir_out_task')
        else:
            out_task = loop_contain_task
        self.kernel_ir.add_op(out_task)
        return self.kernel_ir


def build_ir_from_ttir(mlir_code: str, param, backend_config: BackendConfig):
    ir_builder = TTIRToIrBuilder(mlir_code, param, backend_config)
    ret = ir_builder.parse_ttir_lines()
    return ret