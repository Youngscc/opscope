# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from core.frontend.dsl.grammar.task import Task
from core.frontend.dsl.grammar.tensor_op import TensorOp
from core.frontend.dsl.grammar.tile_op import TileOp


class KernelRegistry:
    def __init__(self):
        self.trace = []

        self.kernels = []
        self.TileOp = TileOp(self)
        self.TensorOp = TensorOp(self)
        self.Task = Task

        # ops
        self.min = None
        self.max = None
        self.ceil = None
        self.floor = None
        self.str_con = None

    def record_call(self, opname, outputs, inputs, config=None):
        self.trace.append((opname, outputs, inputs, config))

    def get_trace(self):
        return self.trace

    @staticmethod
    def define_symbol(cnt: int) -> list:
        return [i for i in range(cnt)]


T = KernelRegistry()