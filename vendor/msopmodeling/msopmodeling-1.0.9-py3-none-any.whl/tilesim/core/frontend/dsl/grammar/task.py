# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

class IndexVar:
    def __init__(self, idx):
        self.id = f"idx_{idx}"


class Task:
    def __init__(self, parent, range_input):
        self.parent = parent
        self.range = range_input
        self.indices = None

    def __enter__(self):
        self.indices = [IndexVar(n) for n in range(len(self.range))]
        return self.indices

    def __exit__(self, exc_type, exc, tb):
        pass
