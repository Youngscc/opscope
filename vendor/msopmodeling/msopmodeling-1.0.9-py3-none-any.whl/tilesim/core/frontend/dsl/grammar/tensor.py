# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from core.common.entity import DType, MemLoc


class Tensor:
    def __init__(self, shape: list[int], dtype: DType, mem_loc: MemLoc):
        self.name = None
        self.shape = shape
        self.dtype = dtype
        self.mem_loc = mem_loc

    def view(self, sub_shape: list[int], offset: list[int] = None) -> 'Tensor':
        """
        对张量进行切片操作，返回切片后的张量
        Args:
            sub_shape:  切片后的形状
            offset:     切片的偏移量，可以不填，比如没有确定好原始张量的大小（这个一般是在中间的临时张量）

        Returns:

        """
        actual_shape = sub_shape
        if offset is not None:
            for dim in range(len(sub_shape)):
                actual_shape[dim] = min(self.shape[dim] - offset[dim], sub_shape[dim])
        sub_tensor = Tensor(sub_shape, self.dtype, self.mem_loc)
        return sub_tensor

    def to_str(self):
        return f"Tensor(name={self.name}, shape={self.shape}, dtype={self.dtype}, mem_loc={self.mem_loc})"

    def __repr__(self):
        return f"Tensor(shape={self.shape}, dtype={self.dtype}, mem_loc={self.mem_loc})"