# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import ast
import math

from core.backend.backend_entity.backend_math import ExprOpEnum, ExprFunc
from core.frontend.ir.core.ir_math import ExprIR, ConstExprIR, VarExprIR, OpExprIR, CallExprIR, \
    RangeIR, CompareExprIR, LogicalExprIR


def _op_type_parse(op_node: ast.operator) -> ExprOpEnum:
    """op类型转换"""
    if isinstance(op_node, ast.Add):
        return ExprOpEnum.ADD
    elif isinstance(op_node, ast.Sub):
        return ExprOpEnum.SUB
    elif isinstance(op_node, ast.Mult):
        return ExprOpEnum.MUL
    elif isinstance(op_node, ast.Div):
        return ExprOpEnum.DIV
    elif isinstance(op_node, ast.FloorDiv):
        return ExprOpEnum.FLOORDIV
    elif isinstance(op_node, ast.Mod):
        return ExprOpEnum.MOD
    raise ValueError(f"Unsupported operation: {ast.dump(op_node)}")


def _func_type_parse(func_node: ast.Call) -> ExprFunc:
    """函数类型（min/max/floor/ceil转换）"""
    func = func_node.func
    if isinstance(func, ast.Name):
        func_name = func.id
    elif isinstance(func, ast.Attribute):
        func_name = func.attr
    else:
        raise NotImplementedError("func only support ast.Name or ast.Attribute")
    return ExprFunc.from_str(func_name)


def expr_parse(node: ast.expr) -> ExprIR:
    """表达式转换"""
    if isinstance(node, ast.Constant):
        return ConstExprIR(node.value)
    elif isinstance(node, ast.Name):
        return VarExprIR(node.id)
    elif isinstance(node, ast.BinOp):
        return OpExprIR(_op_type_parse(node.op), expr_parse(node.left), expr_parse(node.right))
    elif isinstance(node, ast.Compare):
        return compare_parse(node)
    elif isinstance(node, ast.UnaryOp):
        # 处理算术一元操作符（如 -1 负号）
        if isinstance(node.op, ast.USub):
            operand_ir = expr_parse(node.operand)
            if isinstance(operand_ir, ConstExprIR):
                return ConstExprIR(-operand_ir.value)
            else:
                # 对于非常量表达式，如 -x，构造 OpExprIR
                return OpExprIR(ExprOpEnum.SUB, ConstExprIR(0), operand_ir)
        elif isinstance(node.op, ast.UAdd):
            # 正号，直接返回 operand
            return expr_parse(node.operand)
        else:
            # 逻辑非等交给 logical_parse
            return logical_parse(node)
    elif isinstance(node, ast.BoolOp):
        return logical_parse(node)
    elif isinstance(node, ast.Call):
        return CallExprIR(_func_type_parse(node), [expr_parse(arg) for arg in node.args])
    raise ValueError(f"Unsupported expression: {ast.dump(node)}")


def range_parse(call: ast.Call) -> RangeIR:
    """解析 Python AST 中的 range(...) 调用为 (start, end, step)"""
    if not isinstance(call.func, ast.Name) or call.func.id != "range":
        raise ValueError(f"parse_range: Not a range() call: {ast.dump(call)}")

    args = call.args
    argc = len(args)

    if argc == 1:
        start = ConstExprIR(0)
        end = expr_parse(args[0])
        step = ConstExprIR(1)

    elif argc == 2:
        start = expr_parse(args[0])
        end = expr_parse(args[1])
        step = ConstExprIR(1)

    elif argc == 3:
        start = expr_parse(args[0])
        end = expr_parse(args[1])
        step = expr_parse(args[2])

    else:
        raise ValueError(f"range() takes 1–3 args, got {argc}")

    range_ir = RangeIR(start, end, step)
    return range_ir


def slice_parse(node: ast.Slice) -> RangeIR:
    start = expr_parse(node.lower) if node.lower else ConstExprIR(0)
    end = expr_parse(node.upper) if node.upper else ConstExprIR(math.inf)
    step = expr_parse(node.step) if node.step else ConstExprIR(1)
    return RangeIR(start, end, step)


def compare_parse(node: ast.Compare) -> CompareExprIR:
    left_ir = expr_parse(node.left)
    for op, comparator in zip(node.ops, node.comparators):
        right_ir = expr_parse(comparator)
        if isinstance(op, ast.Gt):
            cmp_op = ExprOpEnum.GT
        elif isinstance(op, ast.Lt):
            cmp_op = ExprOpEnum.LT
        elif isinstance(op, ast.Eq):
            cmp_op = ExprOpEnum.EQ
        elif isinstance(op, ast.GtE):
            cmp_op = ExprOpEnum.GE
        elif isinstance(op, ast.LtE):
            cmp_op = ExprOpEnum.LE
        elif isinstance(op, ast.NotEq):
            cmp_op = ExprOpEnum.NE
        else:
            raise NotImplementedError(f"不支持的比较运算符: {type(op).__name__}")
        left_ir = CompareExprIR(cmp_op, left_ir, right_ir)
    return left_ir


def logical_parse(node: ast.BoolOp | ast.UnaryOp) -> LogicalExprIR:
    if isinstance(node.op, ast.And):
        op = ExprOpEnum.AND
    elif isinstance(node.op, ast.Or):
        op = ExprOpEnum.OR
    elif isinstance(node.op, ast.Not):
        op = ExprOpEnum.NOT
    else:
        raise NotImplementedError(f"不支持的逻辑运算符: {type(node.op).__name__}")

    if op == ExprOpEnum.NOT:
        operand_ir = expr_parse(node.operand)
        expr_ir = LogicalExprIR(ExprOpEnum.NOT, [operand_ir])
    else:
        values_ir = [expr_parse(v) for v in node.values]
        expr_ir = values_ir[0]
        for sub_ir in values_ir[1:]:
            expr_ir = LogicalExprIR(op, [expr_ir, sub_ir])
    return expr_ir