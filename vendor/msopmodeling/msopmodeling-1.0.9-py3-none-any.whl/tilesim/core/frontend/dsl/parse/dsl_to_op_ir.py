# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import ast
import traceback
import uuid

from core.common.entity import OpLevel
from core.common.tile_op_enum import TileOpCode
from core.frontend.dsl.parse.dsl_to_expr_ir import expr_parse
from core.frontend.dsl.parse.dsl_to_tensor_ir import tensor_parse_inline
from core.frontend.dsl.parse.ssa_env import SSAEnv
from core.frontend.ir.core.ir_entity import EntityIR, TensorIR
from core.frontend.ir.core.ir_logistic import OpIR


def generate_allocate_op(output_obj: EntityIR) -> OpIR:
    op = OpIR(
        level=OpLevel.HOST_OP,
        op_code=TileOpCode.ALLOC,
        inputs=[],
        outputs=[output_obj],
    )
    return op


def generate_view_op(local_tensor: TensorIR, env: SSAEnv) -> OpIR:
    if local_tensor.raw_tensor is None:
        raise ValueError('local tensor should has raw_tensor')
    global_tensor = env.read_var(local_tensor.raw_tensor.origin_name)
    op = OpIR(
        level=OpLevel.HOST_OP,
        op_code=TileOpCode.VIEW,
        inputs=[global_tensor],
        outputs=[local_tensor]
    )
    return op


def _config_value_parse(node: ast.expr):
    """递归解析config中的值，支持基本类型、枚举引用和表达式"""
    if isinstance(node, ast.Constant):
        return node.value
    elif isinstance(node, ast.List):
        return [_config_value_parse(elt) for elt in node.elts]
    elif isinstance(node, ast.Dict):
        return {
            _config_value_parse(k): _config_value_parse(v)
            for k, v in zip(node.keys, node.values)
        }
    elif isinstance(node, ast.Attribute):
        # 处理枚举属性访问，如 CoreUnit.AIC_FIXPIPE，直接返回枚举对象
        return ast.unparse(node)
    elif isinstance(node, ast.Name):
        # 处理变量引用，如 first_tile
        return node.id
    else:
        # 表达式节点，使用 expr_parse 解析
        return expr_parse(node)


def _config_parse(kws: list[ast.keyword]) -> dict:
    config = {}
    # NEXT 根据tileOp的输入/输出个数，将输入输出以外的输入作为config
    for kw in kws:
        if kw.arg == 'config':
            if isinstance(kw.value, ast.Dict):
                config = {
                    _config_value_parse(k): _config_value_parse(v)
                    for k, v in zip(kw.value.keys, kw.value.values)
                }
    return config


def _parse_tensor_in_op(tmp_name: str, node: ast.Call | ast.Name, env: SSAEnv) -> TensorIR:
    if isinstance(node, ast.Name):
        tmp_name = node.id
    return tensor_parse_inline(node, env, tmp_name)


def tensor_op_parse(node: ast.Call, env: SSAEnv) -> OpIR:
    """解析DSL中的OP调用语句"""
    try:
        op_level = OpLevel.from_str(node.func.value.attr)
        op_name = node.func.attr

        if op_level not in [OpLevel.TILE_OP, OpLevel.TENSOR_OP]:
            raise ValueError(f'op_parse error: unsupport op_level: {op_level}')

        op_type = TileOpCode.from_str(op_name)

        # config转换
        config = _config_parse(node.keywords)

        # 输出转换
        outputs = []
        if len(node.args) > 0:
            output = node.args[0]
            outputs = [_parse_tensor_in_op(f'output_inline_def_{uuid.uuid4()}', output, env)]

        # 输入转换
        inputs = [_parse_tensor_in_op(f'input_inline_def_{uuid.uuid4()}', arg, env) for arg in node.args[1:]]

        return OpIR(
            level=op_level,
            op_code=op_type,
            inputs=inputs,
            outputs=outputs,
            config=config
        )
    except Exception as e:
        traceback.print_exc()
        raise ValueError(f"\n解析语句出错: 第 {node.lineno} 行: {ast.unparse(node)}。 报错内容如下: {e}") from e