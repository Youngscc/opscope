# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from core.frontend.ir.core.ir_logistic import PhiFuncIR

from core.frontend.ir.core.ir_entity import EntityIR


# ============================================================
# Data structures
# ============================================================
@dataclass
class Scope:
    """
    A naming scope. Tracks which variables have been *written* in this scope,
    and what their latest versioned name is.

    - var_map: {original_name -> latest versioned name}  (inherited + local writes)
    """
    scope_id: str
    # origin name and latest version ir
    var_map: dict[str, EntityIR] = field(default_factory=dict)
    # origin name and latest version name
    version_map: dict[str, str] = field(default_factory=dict)
    sub_scopes: list[Scope] = field(default_factory=list)

    def lookup(self, name: str) -> EntityIR | None:
        return self.var_map.get(name)

    def bind(self, name: str, versioned: EntityIR):
        self.var_map[name] = versioned
        self.version_map[name] = versioned.name

    def update_var_map(self, version_map: dict[str, str], var_map: dict[str, EntityIR]):
        self.version_map.update(version_map)
        for k, v in version_map.items():
            self.var_map[k] = var_map[v]


# ============================================================
# Main SSA Environment
# ============================================================

def _generate_phi(var_name: str, versions: set[str], scope_referrers: dict[str, str]) -> PhiFuncIR:
    """Generate a PhiFuncIR - lazy import to avoid circular dependency"""
    from core.frontend.ir.core.ir_logistic import PhiFuncIR
    return PhiFuncIR(
        id=uuid.uuid4().__str__(),
        result_name=var_name,
        referred_name=list(versions),
        scope_referrers=scope_referrers,
    )


class SSAEnv:
    """
    Maintains SSA variable versioning during an on-the-fly AST -> IR lowering.

    Key ideas:
      1. A global counter per original variable name ensures unique versions.
      2. A "current scope" (Scope) tracks the latest version of each variable.
      3. On control-flow splits (if branches, loop body), we snapshot the scope
         and restore/merge at join points, emitting phi functions as needed.
    """

    def __init__(self):
        # Global version counter: {"x": 3} means next version of x is x.3
        self._version_counter: dict[str, int] = {}
        self._scope = [Scope(uuid.uuid4().__str__())]
        self.phi_func_list: list[PhiFuncIR] = []

    # ----------------------------------------------------------
    # Version helpers
    # ----------------------------------------------------------

    def _next_version(self, name: str) -> str:
        """Allocate and return the next versioned name for `name`."""
        ver = self._version_counter.get(name, 0)
        self._version_counter[name] = ver + 1
        if ver == 0:
            return name
        return f"{name}.{ver}"

    def _current_version(self, name: str) -> str | None:
        """Return the latest versioned name visible in the current scope."""
        current_scope = self._scope[-1]
        var = current_scope.lookup(name)
        return var.name if var else None

    # ----------------------------------------------------------
    # Public API: read / write / push stack / pop stack
    # ----------------------------------------------------------

    def read_var(self, name: str) -> EntityIR:
        """
        Read a variable. Returns its current versioned name.
        Raises if the variable has never been defined.
        """
        v = None
        for scope in reversed(self._scope):
            v = scope.lookup(name)
            if v is not None:
                break
        if v is None:
            raise NameError(
                f"Variable '{name}' used before definition in current scope"
            )
        return v

    def write_var(self, var: EntityIR):
        """
        Write (define) a variable. Allocates a fresh version, updates scope.
        Returns the new versioned name (e.g. "x.3").
        """
        name = var.origin_name
        versioned = self._next_version(name)
        var.name = versioned
        current_scope = self._scope[-1]
        current_scope.bind(name, var)

    def push_stack(self, scope_id: str | None = None):
        scope_id = scope_id if scope_id else uuid.uuid4().__str__()
        new_scope = Scope(scope_id)
        self._scope[-1].sub_scopes.append(new_scope)
        self._scope.append(new_scope)

    def pop_stack(self) -> Scope | None:
        """
        Pop current stack, merge different version and insert a phi function

        Returns the scope that was popped
        """
        if len(self._scope) <= 1:
            return None

        last_scope = self._scope[-1]
        current_scope = self._scope[-2]
        merged_version_map = {}
        var_entity_map = {}
        activation_map = {}

        # Collect variables from the popped scope
        for k, v in last_scope.version_map.items():
            activation_map[v] = last_scope.scope_id
            merged_version_map[k] = {v}
            var_entity_map.update({v: last_scope.var_map[k]})

        # If there are no sub-scopes, just propagate and return
        if not last_scope.sub_scopes:
            self._scope.pop()
            current_scope.update_var_map(last_scope.version_map, var_entity_map)
            return last_scope

        # Collect versions from sub-scopes
        all_versions = {k: set() for k in merged_version_map.keys()}
        for scope in last_scope.sub_scopes:
            for k, v in scope.version_map.items():
                activation_map[v] = scope.scope_id
                if k in all_versions:
                    all_versions[k].add(v)
                else:
                    all_versions[k] = {v}
                var_entity_map.update({v: scope.var_map[k]})

        # Add last_scope's own versions
        for k, v in last_scope.version_map.items():
            all_versions[k].add(v)

        # Insert phi functions
        final_version_map = {}
        for var_name, versions in all_versions.items():
            if len(versions) == 1:
                # Single version, no phi needed
                final_version_map[var_name] = list(versions)[0]
                continue

            # Multiple versions - need phi function
            scope_referrers = {activation_map[v]: v for v in versions}

            # Get the variable before the merge (from parent scope)
            try:
                var = self.read_var(var_name)
            except NameError:
                # Variable not defined in parent, create a placeholder
                from core.frontend.ir.core.ir_entity import VarIR
                from core.frontend.ir.core.ir_math import ConstExprIR
                var = VarIR(name=var_name, origin_name=var_name, value=ConstExprIR(0))

            # Write a new version for the phi result
            self.write_var(var)
            phi_func = _generate_phi(var.name, versions, scope_referrers)
            self.phi_func_list.append(phi_func)
            final_version_map[var_name] = var.name
            var_entity_map.update({var.name: var})

        self._scope.pop()
        current_scope.update_var_map(final_version_map, var_entity_map)

        return last_scope