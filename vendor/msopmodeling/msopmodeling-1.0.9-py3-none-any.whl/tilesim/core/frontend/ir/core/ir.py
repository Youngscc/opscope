from dataclasses import dataclass, field

from core.frontend.ir.core.ir_logistic import LogisticIR, PhiFuncIR


@dataclass
class KernelIR:
    name: str
    ops: list[LogisticIR] = None
    phi_func_dict: dict[str, list[PhiFuncIR]] = field(default_factory=dict)

    def __post_init__(self):
        if self.ops is None:
            self.ops = []

    def add_op(self, op: LogisticIR | list[LogisticIR]):
        if isinstance(op, LogisticIR):
            self.ops.append(op)
        elif isinstance(op, list):
            self.ops.extend(op)