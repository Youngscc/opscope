# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from abc import ABC, abstractmethod
from dataclasses import dataclass, field

from core.backend.backend_entity.backend_context import PhiFuncEntity
from core.backend.backend_entity.backend_logistic import OpEntity, TaskEntity, ForEntity, IfEntity
from core.common.entity import OpLevel, CoreType
from core.common.tile_op_enum import TileOpCode
from core.frontend.ir.core.ir_entity import EntityIR, VarIR
from core.frontend.ir.core.ir_math import CompareExprIR, LogicalExprIR, ExprIR


def _config_to_entity(config: dict) -> dict:
    """递归转换config中的ExprIR为ExprEntity"""
    if config is None:
        return None
    result = {}
    for k, v in config.items():
        if isinstance(v, ExprIR):
            result[k] = v.to_entity()
        elif isinstance(v, list):
            result[k] = [item.to_entity() if isinstance(item, ExprIR) else item for item in v]
        elif isinstance(v, dict):
            result[k] = _config_to_entity(v)
        else:
            result[k] = v
    return result


# 运算逻辑，低层一定是包装的具体的运算
class LogisticIR(ABC):

    def __init__(self):
        pass

    @abstractmethod
    def to_entity(self):
        pass

    @abstractmethod
    def return_body_ops(self) -> list['OpIR']:
        pass


@dataclass
class PhiFuncIR(LogisticIR):
    id: str
    result_name: str
    referred_name: list[str]
    # key: scope_id, value: referred_name，表示 scope_id 激活 referred_name
    scope_referrers: dict[str, str] = field(default_factory=dict)

    def return_body_ops(self) -> list['OpIR']:
        return []

    def to_entity(self) -> PhiFuncEntity:
        return PhiFuncEntity(
            id=self.id,
            result_name=self.result_name,
            referred_name=self.referred_name,
            scope_referrers=self.scope_referrers
        )


@dataclass
class OpIR(LogisticIR):
    level: OpLevel
    op_code: TileOpCode
    inputs: list[EntityIR]
    outputs: list[EntityIR]
    config: dict = None

    def return_body_ops(self):
        return [self]

    def to_entity(self) -> OpEntity:
        return OpEntity(
            self.level,
            self.op_code,
            [t.to_entity() for t in self.inputs],
            [t.to_entity() for t in self.outputs],
            _config_to_entity(self.config))


@dataclass
class TaskIR(LogisticIR):
    indices: list[VarIR]
    body: list[LogisticIR]
    task_name: str

    def return_body_ops(self):
        ops = []
        for lg in self.body:
            ops.extend(lg.return_body_ops())
        return ops

    def to_entity(self) -> TaskEntity:
        task_entity = TaskEntity(
            name=self.task_name,
            core_type=CoreType.MIX,
            indices=[v.to_entity() for v in self.indices],
            body=[op.to_entity() for op in self.body],
            input_tensors=[],
            output_tensors=[]
        )

        ops = task_entity.get_ops()
        core_set = {op.op_code.get_core_type() for op in ops if op.op_code != TileOpCode.COPY}
        core_set.discard(None)

        if CoreType.AIC in core_set and CoreType.AIV in core_set:
            task_entity.core_type = CoreType.MIX
        elif CoreType.AIC in core_set:
            task_entity.core_type = CoreType.AIC
        elif CoreType.AIV in core_set:
            task_entity.core_type = CoreType.AIV

        return task_entity


@dataclass
class ForIR(LogisticIR):
    scope_id: str
    range: VarIR
    body: list[LogisticIR]

    def return_body_ops(self):
        ops = []
        for lg in self.body:
            ops.extend(lg.return_body_ops())
        return ops

    def to_entity(self) -> ForEntity:
        return ForEntity(
            scope_id=self.scope_id,
            range=self.range.to_entity(),
            body=[op.to_entity() for op in self.body],
        )


@dataclass
class IfIR(LogisticIR):
    cond: CompareExprIR | LogicalExprIR
    if_body: list[LogisticIR]
    else_body: list[LogisticIR] = None
    scope_id: str = None
    if_scope_id: str = None
    else_scope_id: str = None

    def return_body_ops(self):
        ops = []
        body = self.if_body
        if self.else_body is not None:
            body = self.if_body + self.else_body

        for lg in body:
            ops.extend(lg.return_body_ops())

        return ops

    def to_entity(self) -> IfEntity:
        return IfEntity(
            condition=self.cond.to_entity(),
            if_body=[op.to_entity() for op in self.if_body],
            else_body=[op.to_entity() for op in self.else_body] if self.else_body is not None else None,
            scope_id=self.scope_id,
            if_scope_id=self.if_scope_id,
            else_scope_id=self.else_scope_id
        )