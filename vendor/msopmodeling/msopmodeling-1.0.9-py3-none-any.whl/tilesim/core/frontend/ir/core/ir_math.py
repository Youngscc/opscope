# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any

from core.backend.backend_entity.backend_math import ExprOpEnum


# 数学运算相关的IR
class MathIR(ABC):

    def __init__(self):
        pass

    @abstractmethod
    def to_entity(self) -> Any:
        pass


@dataclass
class EvalContext:
    env: dict[str, int | float | bool]


class ExprIR(MathIR, ABC):
    pass


@dataclass
class RangeIR(MathIR):
    start: ExprIR
    end: ExprIR
    step: ExprIR

    def to_entity(self):
        """Lazy import to avoid circular dependency"""
        from core.backend.backend_entity.backend_math import RangeEntity
        return RangeEntity(self.start.to_entity(), self.end.to_entity(), self.step.to_entity())

    def get_shape(self) -> ExprIR:
        shape = OpExprIR(ExprOpEnum.SUB, self.end, self.start)
        return shape


@dataclass(frozen=True)
class ConstExprIR(ExprIR):
    value: int | float | bool

    def to_entity(self):
        """Lazy import to avoid circular dependency"""
        from core.backend.backend_entity.backend_math import ConstExprEntity
        return ConstExprEntity(self.value)


@dataclass(frozen=True)
class VarExprIR(ExprIR):
    name: str

    def to_entity(self):
        """Lazy import to avoid circular dependency"""
        from core.backend.backend_entity.backend_math import VarExprEntity
        return VarExprEntity(self.name)


@dataclass(frozen=True)
class OpExprIR(ExprIR):
    # 支持符号： '+', '-', '*', '/', '//', '%'
    op: Any  # ExprOpEnum - use Any to avoid import
    lhs: ExprIR
    rhs: ExprIR

    def to_entity(self):
        """Lazy import to avoid circular dependency"""
        from core.backend.backend_entity.backend_math import BinaryExprEntity
        return BinaryExprEntity(self.op, self.lhs.to_entity(), self.rhs.to_entity())


@dataclass(frozen=True)
class CompareExprIR(ExprIR):
    op: Any  # ExprOpEnum - use Any to avoid import  # '<', '<=', '>', '=='
    lhs: ExprIR
    rhs: ExprIR

    def to_entity(self):
        """Lazy import to avoid circular dependency"""
        from core.backend.backend_entity.backend_math import CompareExprEntity
        return CompareExprEntity(self.op, self.lhs.to_entity(), self.rhs.to_entity())


@dataclass(frozen=True)
class LogicalExprIR(ExprIR):
    op: Any  # ExprOpEnum - use Any to avoid import  # 'and', 'or', 'not'
    operands: list[ExprIR]

    def to_entity(self):
        """Lazy import to avoid circular dependency"""
        from core.backend.backend_entity.backend_math import LogicalExprEntity
        return LogicalExprEntity(self.op, [op.to_entity() for op in self.operands])


@dataclass(frozen=True)
class CallExprIR(ExprIR):
    func: Any  # ExprFunc - use Any to avoid import  # 'min', 'max', 'floor', 'ceil'
    args: list[ExprIR]

    def to_entity(self):
        """Lazy import to avoid circular dependency"""
        from core.backend.backend_entity.backend_math import CallExprEntity
        return CallExprEntity(self.func, [op.to_entity() for op in self.args])