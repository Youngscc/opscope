# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from abc import ABC, abstractmethod
from dataclasses import dataclass, field, fields
from typing import Any, final

from core.common.backend_config import BackendConfig, FitParamKey, OptimType, EvaluationType, OptimConfig, EvalConfig
from core.common import BackendType
from core.common.entity import DType


@dataclass
class OperatorExtraParam:
    # 是否开启拟合，比如为了覆盖开箱性能，需要按照一定的拟合系数进行时间调整
    enable_fit: bool = False
    # 拟合系数
    fit_param: dict[str, float] = field(default_factory=dict)
    # 工程可达的寻优参数
    tuning_candidates: list[dict[str, Any]] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict):
        field_names = {f.name for f in fields(cls)}
        filtered = {k: v for k, v in data.items() if k in field_names}
        return cls(**filtered)


@dataclass
class OperatorInput:
    accelerator: str
    input_dict: dict = None
    input_shapes: list[list[int]] = None
    output_shapes: list[list[int]] = None
    input_dtypes: list[DType] = None
    output_dtypes: list[DType] = None
    # shape表达的格式，比如BNSD
    layout_format: str = None
    aic_core_num: int = 0
    aiv_core_num: int = 0
    param: OperatorExtraParam = None

    def __post_init__(self):
        if self.param is not None and not issubclass(self.param.__class__, OperatorExtraParam):
            raise ValueError(f'传入额外参数必须是继承至OperatorExtraParam的类')


@dataclass
class OperatorResult:
    latency: float = 0.0
    aic_time: float = 0.0
    aic_cube_time: float = 0.0
    aic_mte2_time: float = 0.0
    aic_mte1_time: float = 0.0
    aic_fixpipe_time: float = 0.0
    aiv_time: float = 0.0
    aiv_vec_time: float = 0.0
    aiv_mte2_time: float = 0.0
    aiv_mte3_time: float = 0.0
    data_transfer: dict = field(default_factory=dict)
    small_pkt_transfer: dict = field(default_factory=dict)
    trace: list = None
    tuning_result: dict = field(default_factory=dict)
    aic_cycles: int = 0
    aiv_cycles: int = 0
    l2_access_rate: float = 0.0

    def append_result(self, op_result: 'OperatorResult'):
        self.latency += op_result.latency
        self.aic_time += op_result.aic_time
        self.aic_cube_time += op_result.aic_cube_time
        self.aic_mte2_time += op_result.aic_mte2_time
        self.aic_mte1_time += op_result.aic_mte1_time
        self.aic_fixpipe_time += op_result.aic_fixpipe_time
        self.aiv_time += op_result.aiv_time
        self.aiv_vec_time += op_result.aiv_vec_time
        self.aiv_mte2_time += op_result.aiv_mte2_time
        self.aiv_mte3_time += op_result.aiv_mte3_time
        data_path_set = set(self.data_transfer.keys()) | set(op_result.data_transfer.keys())
        for path in data_path_set:
            self.data_transfer[path] = self.data_transfer.get(path, 0) + op_result.data_transfer.get(path, 0)
        trace = []
        if self.trace is not None:
            trace.extend(self.trace)
        if op_result.trace is not None:
            trace.extend(op_result.trace)
        tuning_key_set = set(self.tuning_result.keys()) | set(op_result.tuning_result.keys())
        for key in tuning_key_set:
            self.tuning_result[key] = self.tuning_result.get(key, []) + op_result.tuning_result.get(key, [])

    def print_format(self):
        print(f'latency: {self.latency}')
        print(
            f'--aic_time: {self.aic_time}\n'
            f'--aic_cube_time: {self.aic_cube_time}\n'
            f'--aic_mte1_time: {self.aic_mte1_time}\n'
            f'--aic_mte2_time: {self.aic_mte2_time}\n'
            f'--aic_fixpipe_time: {self.aic_fixpipe_time}\n'
            f'--aiv_time: {self.aiv_time}\n'
            f'--aiv_vec_time: {self.aiv_vec_time}\n'
            f'--aiv_mte2_time: {self.aiv_mte2_time}\n'
            f'--aiv_mte3_time: {self.aiv_mte3_time}\n'
        )


@dataclass
class BasicOperator(ABC):
    extra_param_class = OperatorExtraParam
    operator_dsl = None

    @final
    def op_name(self):
        return self.__class__.__name__

    @property
    @abstractmethod
    def backend_type(self) -> BackendType:
        pass

    @property
    @abstractmethod
    def optim_type(self) -> OptimType:
        pass

    @property
    @abstractmethod
    def eval_type(self) -> EvaluationType:
        pass

    @final
    def __init__(self, op_input: OperatorInput):
        self.op_input = op_input

    @abstractmethod
    def _input_check(self):
        pass

    @abstractmethod
    def _dynamic_shape_assign(self) -> dict[str, Any]:
        pass

    def _set_optim_config(self) -> OptimConfig:
        pass

    def _set_eval_config(self) -> EvalConfig:
        param = self.op_input.param
        eval_config = EvalConfig(
            eval_method=self.eval_type,
            fit_param=param.fit_param if param else {}
        )
        return eval_config

    def _post_fit(self, backend_config: BackendConfig, op_result: OperatorResult) -> OperatorResult:
        """拟合的情况下，添加后处理的拟合逻辑"""
        fit_param = backend_config.eval_config.fit_param
        scalar_time = fit_param.get(FitParamKey.SCALAR_TIME, 0)
        latency = max(scalar_time, op_result.latency)
        op_result.latency = latency
        return op_result

    def _adjust_coeff(self, backend_config: BackendConfig):
        """通过设定拟合系数，对不同的系数进行拟合"""
        fit_param = backend_config.eval_config.fit_param

        if FitParamKey.BW_COEFF not in fit_param:
            fit_param[FitParamKey.BW_COEFF] = 1

        if FitParamKey.COMP_COEFF not in fit_param:
            fit_param[FitParamKey.COMP_COEFF] = 1

        if FitParamKey.SCALAR_TIME not in fit_param:
            fit_param[FitParamKey.SCALAR_TIME] = 0

    @abstractmethod
    def run(self) -> OperatorResult:
        pass

    @classmethod
    def op_input_convert(cls, op_input: dict[str, Any]) -> OperatorInput:
        profiling_keys = [
            'input_shapes',
            'output_shapes',
            'input_dtypes',
            'output_dtypes'
        ]
        if 'accelerator' not in op_input:
            raise ValueError(f'op_input must have info: accelerator')
        if 'input_dict' not in op_input:
            for key in profiling_keys:
                if key not in op_input:
                    raise ValueError(f'op_input must have info: {key}')

        if op_input.get('extra_param') is None:
            extra_param = cls.extra_param_class()
        else:
            param_format = cls.extra_param_class
            if issubclass(param_format.__class__, OperatorExtraParam):
                raise ValueError('illegal extra_param format')
            extra_param = param_format.from_dict(op_input.get('extra_param'))
        ret = OperatorInput(
            accelerator=op_input.get('accelerator'),
            layout_format=op_input.get('layout_format', ''),
            aic_core_num=op_input.get('aic_core_num', 0),
            aiv_core_num=op_input.get('aiv_core_num', 0),
            param=extra_param,
        )
        if 'input_dict' in op_input:
            input_dict = {k.lower(): v for k, v in op_input.get('input_dict').items()}  # key全部转为小写
            ret.input_dict = input_dict
        else:
            ret.input_shapes = op_input.get('input_shapes')
            ret.output_shapes = op_input.get('output_shapes')
            ret.input_dtypes = [DType.from_str(d) for d in op_input.get('input_dtypes')]
            ret.output_dtypes = [DType.from_str(d) for d in op_input.get('output_dtypes')]
        return ret
