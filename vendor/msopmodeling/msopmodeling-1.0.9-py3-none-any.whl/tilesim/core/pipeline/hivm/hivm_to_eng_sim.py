# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
"""
HIVM MLIR到工程仿真Pipeline

直接将HIVM MLIR转换为KernelIR，然后执行工程仿真。
"""
from core.backend.backend_entity.ir_to_entity import backend_entity_build
from core.backend.engineering_costmodel.optim.optim_dispatch import optim_dispatch
from core.common.backend_config import BackendConfig
from core.frontend.adaptor.hivm.hivm_to_ir import build_ir_from_hivm
from core.pipeline.basic_operator import OperatorResult
from core.pipeline.tilesim_eng.dsl_to_eng_sim import enable_auto_pipe


def hivm_to_eng_sim(
        mlir: str,
        backend_config: BackendConfig,
        dynamic_shape: dict[str, int] = None,
        param=None
) -> OperatorResult:
    """
    HIVM MLIR到工程仿真的入口函数

    直接将HIVM MLIR解析为KernelIR（无InstEvent中间层），
    然后构建后端实体并执行仿真。

    Args:
        mlir: HIVM MLIR代码字符串
        backend_config: 后端配置
        dynamic_shape: 动态形状参数字典
        param: 额外参数

    Returns:
        OperatorResult对象，包含仿真结果
    """

    ir = build_ir_from_hivm(mlir, param, backend_config)

    # 检查是否存在BARRIER指令，如果存在则禁用自动流水线
    backend_config.eval_config.enable_auto_pipe = enable_auto_pipe(ir.ops)

    backend_entity = backend_entity_build(ir, dynamic_shape)
    output = optim_dispatch(backend_config, backend_entity)

    return output