# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

import ast
import inspect

from core.backend.backend_entity.ir_to_entity import backend_entity_build
from core.common.backend_config import BackendConfig
from core.backend.engineering_costmodel.optim.optim_dispatch import optim_dispatch
from core.common.tile_op_enum import TileOpCode
from core.pipeline.basic_operator import OperatorResult
from core.frontend.dsl.parse.ir_builder_by_dsl import IrBuilder
from core.frontend.ir.core.ir_logistic import LogisticIR


def enable_auto_pipe(lg_list: list[LogisticIR]) -> bool:
    for lg in lg_list:
        ops = lg.return_body_ops()
        for op in ops:
            if op.op_code == TileOpCode.BARRIER:
                return False

    return True


def dsl_to_eng_sim(operator, backend_config: BackendConfig, dynamic_shape: dict[str, int] = None) -> OperatorResult:
    src = inspect.getsource(operator)
    tree = ast.parse(src)

    ir_builder = IrBuilder()
    ir = ir_builder.build(tree, dynamic_shape)
    backend_config.eval_config.enable_auto_pipe = enable_auto_pipe(ir.ops)

    backend_entity = backend_entity_build(ir, dynamic_shape)

    output = optim_dispatch(backend_config, backend_entity)
    return output