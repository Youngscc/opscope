# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from abc import ABC
from typing import final

from core.common import BackendType
from core.common.backend_config import BackendConfig, EvaluationType, OptimType, OptimConfig
from core.pipeline.basic_operator import BasicOperator, OperatorResult
from core.pipeline.tilesim_eng.dsl_to_eng_sim import dsl_to_eng_sim


class EngineeringOperator(BasicOperator, ABC):

    @property
    @final
    def backend_type(self) -> BackendType:
        """所有继承子类不可重写"""
        return BackendType.ENG

    @property
    def optim_type(self) -> OptimType:
        """按需选择不同的分核/tiling方法"""
        return OptimType.GENERAL_BY_SEQ_OPTIM

    @property
    def eval_type(self) -> EvaluationType:
        """可以根据实际各算子需要的方法，写不同的后端， 目前仅支持一种"""
        return EvaluationType.ENG_PIPE_BY_RULE

    def _set_optim_config(self) -> OptimConfig:
        optim_config = OptimConfig(
            optim_method=self.optim_type,
            tuning_candidates=self.op_input.param.tuning_candidates,
        )
        return optim_config

    @final
    def run(self) -> OperatorResult:
        # shape\精度等校验
        self._input_check()

        # 动态shape生成
        dynamic_shape = self._dynamic_shape_assign()

        # 后端配置
        optim_config = self._set_optim_config()
        eval_config = self._set_eval_config()
        backend_config = BackendConfig(
            accelerator=self.op_input.accelerator,
            aic_core_num=self.op_input.aic_core_num,
            aiv_core_num=self.op_input.aiv_core_num,
            layout_format=self.op_input.layout_format,
            eval_config=eval_config,
            optim_config=optim_config
        )
        enable_fit = self.op_input.param is not None and self.op_input.param.enable_fit
        if enable_fit:
            self._adjust_coeff(backend_config)
        eval_config.set_default_fit_param()

        if isinstance(self.operator_dsl, list):
            op_result = None
            for dsl in self.operator_dsl:
                dsl_res = dsl_to_eng_sim(operator=dsl, dynamic_shape=dynamic_shape, backend_config=backend_config)
                if op_result is None:
                    op_result = dsl_res
                else:
                    op_result.append_result(dsl_res)
        else:
            op_result = dsl_to_eng_sim(operator=self.operator_dsl, dynamic_shape=dynamic_shape, backend_config=backend_config)

        # 后处理拟合
        if enable_fit:
            op_result = self._post_fit(backend_config, op_result)
        return op_result