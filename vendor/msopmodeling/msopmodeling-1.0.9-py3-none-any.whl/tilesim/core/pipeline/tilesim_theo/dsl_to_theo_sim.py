# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

import ast
import inspect

from core.backend.backend_entity.ir_to_entity import backend_entity_build
from core.common.backend_config import BackendConfig
from core.backend.theoretical_costmodel.evaluation.theo_evaluation_dispatch import theo_eval_dispatch
from core.frontend.dsl.parse.ir_builder_by_dsl import IrBuilder
from core.pipeline.basic_operator import OperatorResult


def dsl_to_theo_sim(operator, backend_config: BackendConfig, dynamic_shape: dict = None) -> OperatorResult:
    src = inspect.getsource(operator)
    tree = ast.parse(src)

    ir_builder = IrBuilder()
    ir = ir_builder.build(tree, dynamic_shape)
    backend_entity = backend_entity_build(ir, dynamic_shape, False)

    res = theo_eval_dispatch(backend_config, backend_entity.eval_ctx, backend_entity.op_list)
    return res