# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from abc import ABC
from typing import final

from core.common import BackendType
from core.common.backend_config import BackendConfig, EvaluationType, OptimType
from core.pipeline.basic_operator import BasicOperator, OperatorResult
from core.pipeline.tilesim_theo.dsl_to_theo_sim import dsl_to_theo_sim


class TheoreticalOperator(BasicOperator, ABC):

    @property
    @final
    def backend_type(self) -> BackendType:
        """所有继承子类不可重写"""
        return BackendType.THEO

    @property
    @final
    def optim_type(self) -> OptimType:
        """理论极限性能不需要这个函数"""
        return OptimType.ADAPTOR_BYPASS_OPTIM

    @property
    def eval_type(self) -> EvaluationType:
        """可以根据实际各算子需要的方法，写不同的后端， 目前仅支持一种"""
        return EvaluationType.THEO_OPTIMAL_PIPE

    def run(self) -> OperatorResult:
        # shape\精度等校验
        self._input_check()

        # 动态shape生成
        dynamic_shape = self._dynamic_shape_assign()
        if dynamic_shape is None:
            dynamic_shape = {}

        # 后端配置
        eval_config = self._set_eval_config()
        backend_config = BackendConfig(
            accelerator=self.op_input.accelerator,
            aic_core_num=self.op_input.aic_core_num,
            aiv_core_num=self.op_input.aiv_core_num,
            layout_format=self.op_input.layout_format,
            eval_config=eval_config,
        )
        enable_fit = self.op_input.param is not None and self.op_input.param.enable_fit
        if enable_fit:
            self._adjust_coeff(backend_config)
        eval_config.set_default_fit_param()

        if isinstance(self.operator_dsl, list):
            op_result = None
            for dsl in self.operator_dsl:
                dsl_res = dsl_to_theo_sim(operator=dsl, dynamic_shape=dynamic_shape, backend_config=backend_config)
                if op_result is None:
                    op_result = dsl_res
                else:
                    op_result.append_result(dsl_res)
        else:
            op_result = dsl_to_theo_sim(operator=self.operator_dsl, dynamic_shape=dynamic_shape, backend_config=backend_config)

        # 后处理拟合
        if enable_fit:
            op_result = self._post_fit(backend_config, op_result)

        return op_result