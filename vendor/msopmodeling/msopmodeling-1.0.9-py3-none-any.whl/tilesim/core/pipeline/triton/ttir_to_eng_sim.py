# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from core.backend.backend_entity.ir_to_entity import backend_entity_build
from core.backend.engineering_costmodel.optim.optim_dispatch import optim_dispatch
from core.common.backend_config import BackendConfig
from core.frontend.adaptor.ttir.ttir_to_ir import build_ir_from_ttir
from core.pipeline.basic_operator import OperatorResult
from core.pipeline.tilesim_eng.dsl_to_eng_sim import enable_auto_pipe
from ops.theoretical_model.ttir_op.ttir_utils import TTIRExtraParam


def ttir_to_eng_sim(mlir, backend_config: BackendConfig, dynamic_shape: dict[str, int] = None,
                    param: TTIRExtraParam = None) -> OperatorResult:
    ir = build_ir_from_ttir(mlir, param, backend_config)
    backend_config.eval_config.enable_auto_pipe = enable_auto_pipe(ir.ops)

    backend_entity = backend_entity_build(ir, dynamic_shape)

    output = optim_dispatch(backend_config, backend_entity)
    return output