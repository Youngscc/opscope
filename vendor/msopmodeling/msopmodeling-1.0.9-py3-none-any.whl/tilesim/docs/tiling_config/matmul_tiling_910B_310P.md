# MatMul算子tiling策略（910B/310P）

本文档提供MatMul算子在不同情况下的AscendC默认tiling策略，用户可以酌情选择来作为TileSim MatMul类算子的输入，以达到预测性能和AscendC实现的算子实测相近。默认tiling策略来源于算子源码仓：https://gitcode.com/cann/ops-nn。

本文按照策略执行优先级从高到低排列。

## 1 BL1FullloadWithFixpipeTiling（优先级最高）

  - 触发条件:
    - 芯片支持L0C2out
    - N < 256 且 N 不对齐
    - K <= 256
    - N % (256/dtypeSize) != 0
    - 256/dtypeSize % N != 0 (Fixpipe Bound场景)
  - 切分方式:
    - baseN = N对齐到16
    - baseM = 向下对齐到128,由UB和L0C资源决定
    - baseK = 向下对齐到16
    - B矩阵全驻留L1缓存

## 2 AL1FullLoadTiling

  - 触发条件:
    - 芯片支持L0C2out
    - 数据类型为FP32
    - !isATrans && isBTrans
    - M <= 16 && N > 16 && N <= 16*aicNum
    - K >= 4096
    - K对齐到512/dtypeSize
    - AL1大小不超过L1容量限制
  - 切分方式:
    - baseM = 16, baseN = 16, baseK = 256
    - A矩阵全驻留L1缓存
    - 步长: stepM=1, stepN=1, stepKa=K/baseK

## 3 BL1FullLoadTiling

  - 触发条件:
    - 子策略1 (V2 Tiling):
        - FP32类型,isATrans && !isBTrans
      - M范围: [30848, 98048]
      - N = 512, K = 512
      - A、B均为ND格式,无Bias
    - 子策略2: 其他BL1全载场景
  - 切分方式: B矩阵全加载到L1,M和N按Core数切分

## 4 L2CacheTiling

  - 触发条件:
    - 芯片支持L0C2out
    - 总数据量 > L2Ratio * 100MB (避免L2数据置换)
  - 切分方式:
    - 计算mTileBlock和nTileBlock进行L2级分块
    - 每个核处理一个L2块,内部再按baseMN切分

## 5 SingleCoreSplitKTiling

  - 触发条件:
    - 芯片支持L0C2out
    - 不支持L12BtBf16
    - K >= 27392 (SPLIT_K_THRES)
    - 或者满足特殊通道条件: K=1536时的MKN/NKM通道
  - 切分方式:
    - 单核模式下,沿K轴多次迭代
    - nL2TileLength = 3072 (确保L2缓存容下计算)
    - 基本块: MK33或NK33或24
    - 多核处理M、N维度,每个核负责K的一部分

## 6 DeterministicMultiCoreSplitKTiling

  - 触发条件:
    - 不支持L12BtBf16
    - K >= 1000且K <= 4608时的特定场景
    - 或 K >= 27392 的MTE2 Bound场景
    - 或 M,N <= 64且K >= 6144的MN64场景
  - 切分方式:
    - 确定性多核切K,保证输出结果顺序
    - MK顺序: M不分核,N做外层pingpong,K完成分核
    - NK顺序: N不分核,M做外层pingpong,K完成分核

## 7 L2CacheTiling310P

  - 触发条件:
    - 芯片不支持L12BtBf16和L0C2out (310P芯片)
  - 切分方式:
    - mTileBlock = aicNum/2
    - nTileBlock = 2
    - 固定(4,2)或(5,2)的分块模式
