# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import json

from api.operator_api.op_latency_predict import op_latency_predict, save_optimization_hints_csv


def main():
    example_input_path = 'input_example.json'
    example_output_path = 'output_example.json'

    with open(example_input_path, "r", encoding="utf-8") as f:
        op_input_example = json.load(f)

    op_output_dict = {}
    for op_input_data in op_input_example:
        result, optimization_hints = op_latency_predict(op_input_data)
        op_id = f'OP_{len(op_output_dict)}'
        op_output_dict[op_id] = result
        if optimization_hints:
            hints_csv_path = f'optimization_hints_{op_id}.csv'
            save_optimization_hints_csv(optimization_hints, hints_csv_path)
    with open(example_output_path, "w", encoding="utf-8") as f:
        op_output_dict = json.dumps(
            op_output_dict, indent=2, ensure_ascii=False
        )
        f.write(op_output_dict)


if __name__ == '__main__':
    main()
