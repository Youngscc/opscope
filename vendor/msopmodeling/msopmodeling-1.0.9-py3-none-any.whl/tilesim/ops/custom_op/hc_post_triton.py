# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.common import OpType, BackendType, MemLoc, DType
from core.common import op_registry
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

T, HC, D, HC_D, dtype = T.define_symbol(5)


def mhc_post_triton():
    """mhc_post 算子DSL实现,重点关注访存量"""
    # post = post.reshape(-1, post.size(2)) 对B*S=T 进行扁平化，此处略去
    post_in = Tensor(shape=[HC, 1], dtype=DType.FP32, mem_loc=MemLoc.GM)
    x_in = Tensor(shape=[1, D], dtype=DType.FP32, mem_loc=MemLoc.GM)
    term1 = Tensor(shape=[HC, D], dtype=DType.FP32, mem_loc=MemLoc.UB)

    comb_in = Tensor(shape=[HC, 1], dtype=dtype, mem_loc=MemLoc.GM)
    res_in = Tensor(shape=[1, D], dtype=dtype, mem_loc=MemLoc.GM)
    term2 = Tensor(shape=[HC, D], dtype=DType.FP32, mem_loc=MemLoc.UB)
    y = Tensor(shape=[HC, D], dtype=DType.FP32, mem_loc=MemLoc.GM)
    # 考虑T/BLOCK_M通常是能整除的，那么访存量没有冗余,分析T<65535的场景
    for i in range(T):
        T.TensorOp.mul(term1, post_in, x_in)

        for j in range(HC):
            T.TensorOp.mul(term2, comb_in, res_in)  # [4,16384]*[4,16384]
            T.TensorOp.add(term1, term1, term2)

        T.TensorOp.null_op(y, term1)
        T.TensorOp.store(y)  # 8KB*4


@op_registry.register(OpType.HcPostTriton, BackendType.THEO)
class TheoHcPostTriton(TheoreticalOperator):
    operator_dsl = mhc_post_triton

    def _input_check(self):
        pass

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        shape_T = self.op_input.input_shapes[0][0]
        shape_HC = self.op_input.input_shapes[0][1]
        shape_D = self.op_input.input_shapes[0][2]
        dynamic_shape = {
            'T': shape_T,
            'HC': shape_HC,
            'D': shape_D,
            'HC_D': shape_HC * shape_D,
            'dtype': self.op_input.input_dtypes[0],
        }
        return dynamic_shape