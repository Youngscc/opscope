# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.common import OpType, BackendType, MemLoc, DType
from core.common import op_registry
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

T, HC, D, MIX_HC, HC_D, HC_HC, HC_2, dtype, = T.define_symbol(8)


def mhc_pre_triton_extend(
        hc_fn: Tensor(shape=[MIX_HC, HC_D], dtype=dtype, mem_loc=MemLoc.GM),
        hc_scale_: Tensor(shape=[3], dtype=dtype, mem_loc=MemLoc.GM),
        hc_base_: Tensor(shape=[MIX_HC], dtype=dtype, mem_loc=MemLoc.GM),
        y_out: Tensor(shape=[T, D], dtype=dtype, mem_loc=MemLoc.GM)
):
    """x_pre 搬入UB后应该有个vec指令将其处理成x的shape"""
    x = Tensor(shape=[T, HC, D], dtype=dtype, mem_loc=MemLoc.UB)
    x_2d = Tensor(shape=[1, T, HC_D], dtype=dtype, mem_loc=MemLoc.UB)
    x_fp32 = Tensor(shape=[T, HC_D], dtype=DType.FP32, mem_loc=MemLoc.UB)
    x_mean = Tensor(shape=[1, T, 1], dtype=DType.FP32, mem_loc=MemLoc.UB)

    hc_fn_tr = Tensor(shape=[HC_D, MIX_HC], dtype=DType.FP32, mem_loc=MemLoc.UB)
    mm_res = Tensor(shape=[T, MIX_HC], dtype=DType.FP32, mem_loc=MemLoc.UB)
    mixes = Tensor(shape=[T, MIX_HC], dtype=DType.FP32, mem_loc=MemLoc.UB)

    scalar = Tensor(shape=[1], dtype=DType.FP32, mem_loc=MemLoc.UB)
    rms_res = Tensor(shape=[1], dtype=DType.FP32, mem_loc=MemLoc.UB)
    rsqrt = Tensor(shape=[1], dtype=DType.FP32, mem_loc=MemLoc.UB)

    # 对应x = x.unsqueeze(0)
    T.TensorOp.transpose(x, x_2d)  # x = x.flatten(2).float() reshape x
    T.TensorOp.cast(x_fp32, x_2d)  # x_fp32 [1,T,HC_D] 数据类型转化为fp32

    # 计算归一化因子rsqrt
    # 对应rsqrt = torch.rsqrt(x.square().mean(-1, keepdim=True) + self.norm_eps)
    T.TensorOp.mul(x_fp32, x_fp32, x_fp32)  # x.square()
    T.TensorOp.reduce_sum(x_mean, x_fp32, config={
        'reduce_axis': -1, 'keepdim': True
    })
    T.TensorOp.div(x_mean, x_mean, scalar)  # mean
    T.TensorOp.adds(x_mean, x_mean, scalar)  # mean(x^2[-1]) + e
    T.TensorOp.sqrt(rms_res, x_mean)
    # 对应mixes = F.linear(x, hc_fn) * rsqrt
    T.TensorOp.transpose(hc_fn, hc_fn_tr)
    T.TensorOp.gemm(mm_res, x_fp32, hc_fn_tr)  # [T,HC_D]*[HC_D, MIX_HC]=[T, MIX_HC]
    T.TensorOp.div(mm_res, mm_res, rsqrt)

    # 开始sinkhorn_triton流程#
    # 首先mixes会切成三个新矩阵#
    T.TensorOp.transpose(mm_res, mixes)  # mixes = mixes.reshape(-1, (2 + hc_mult) * hc_mult)
    pre = Tensor(shape=[T, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)
    post = Tensor(shape=[T, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)
    comb = Tensor(shape=[T, HC, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)

    T.TensorOp.load(hc_scale_)
    T.TensorOp.load(hc_base_)

    # 处理pre计算，将每块pre子矩阵乘hc_scale注意力，再做sigmoid
    # cur_hc_base = tl.extract_slice(hc_base, [0], [hc_mult], [1])   从hc_base取数据，非访存行为
    hc_pre_mul = Tensor(shape=[T, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)
    cur_hc_base = Tensor(shape=[HC], dtype=DType.FP32, mem_loc=MemLoc.UB)
    # 对应pre = pre * tl.get_element(hc_scale, (0,)) + cur_hc_base
    T.TensorOp.mul(pre, pre, scalar)  # 对应乘scalar
    T.TensorOp.add(hc_pre_mul, pre, cur_hc_base)  # 对应加base

    # 对应pre = tl.sigmoid(pre) + eps
    scalar = Tensor(shape=[1], dtype=DType.FP32, mem_loc=MemLoc.UB)  # -1
    T.TensorOp.muls(hc_pre_mul, hc_pre_mul, scalar)  # -x
    T.TensorOp.exp(hc_pre_mul, hc_pre_mul)  # e^(-x)
    T.TensorOp.add(hc_pre_mul, hc_pre_mul, scalar)  # 1+e^(-x)
    T.TensorOp.div(hc_pre_mul, scalar, hc_pre_mul)  # 1/1+e^(-x)
    T.TensorOp.add(hc_pre_mul, hc_pre_mul, scalar)  # +eps

    T.TensorOp.store(hc_pre_mul)
    # pre 结束，post开始处理

    # post取出来与hc_scale相乘，再加上hc_base对应位置
    cur_post_hc_base = Tensor(shape=[HC], dtype=DType.FP32, mem_loc=MemLoc.UB)
    # 对应post = post * tl.get_element(hc_scale, (1,)) + cur_post_hc_base
    T.TensorOp.muls(post, post, scalar)
    T.TensorOp.add(post, post, cur_post_hc_base)

    # 对应post = 2 * tl.sigmoid(post)
    T.TensorOp.muls(post, post, scalar)  # -x
    T.TensorOp.exp(post, post)  # e^(-x)
    T.TensorOp.add(post, post, scalar)  # 1+e^(-x)
    T.TensorOp.div(post, scalar, post)  # 1/1+e^(-x)
    T.TensorOp.mul(post, post, scalar)  # *2

    T.TensorOp.store(post)
    # post结束，comb开始

    # 对应comb = tl.load(mixes_ptr + offs_comb, mask=mask_d)  # (8,)
    hc_base_comb = Tensor(shape=[MIX_HC], dtype=DType.FP32, mem_loc=MemLoc.UB)
    comb_frag_tmp = Tensor(shape=[32], dtype=DType.FP32, mem_loc=MemLoc.UB)
    # 对应comb_frag = comb * tl.get_element(hc_scale, (2,)) + cur_comb_hc_base
    T.TensorOp.muls(comb, comb, scalar)
    T.TensorOp.add(comb, comb, hc_base_comb)
    # 对应comb_frag_tmp = tl.insert_slice(comb_frag_tmp, comb_frag, (i * 8,), (8,), (1,))
    # comb_frag计算完先乘后加，再slice出comb_tmp，并reshape成[n,hc,2hc]
    # 对应comb_frag_tmp = tl.reshape(comb_frag_tmp, (4, 8))
    comb_tmp = Tensor(shape=[T, HC, HC_2], dtype=DType.FP32, mem_loc=MemLoc.UB)

    # 对comb_tmp进行safe softmax，其中一半数据是-inf，挑出每行最大值并减去，再做exp
    T.TensorOp.exp(comb_tmp, comb_tmp)

    # 行reduce
    row_sum = Tensor(shape=[HC, 1], dtype=DType.FP32, mem_loc=MemLoc.UB)
    # 对应row_sum = tl.sum(comb_frag, axis=1)
    T.TensorOp.reduce_sum(row_sum, comb_tmp, config={
        'reduce_axis': -1, 'keepdim': True
    })
    # 对应comb_frag = comb_frag / row_sum[:, None] + eps
    T.TensorOp.div(comb_tmp, comb_tmp, row_sum)
    T.TensorOp.add(comb_tmp, comb_tmp, scalar)

    # 列reduce
    # 对应col_sum = tl.sum(comb_frag, axis=0)
    col_sum = Tensor(shape=[1, HC_2], dtype=DType.FP32, mem_loc=MemLoc.UB)
    T.TensorOp.reduce_sum(col_sum, comb_tmp, config={
        'reduce_axis': 0, 'keepdim': True
    })
    T.TensorOp.add(col_sum, col_sum, scalar)
    T.TensorOp.div(comb_tmp, comb_tmp, col_sum)

    for i in range(20):
        T.TensorOp.reduce_sum(row_sum, comb_tmp, config={
            'reduce_axis': -1, 'keepdim': True
        })
        T.TensorOp.add(row_sum, row_sum, scalar)
        T.TensorOp.div(comb_tmp, comb_tmp, row_sum)

        T.TensorOp.reduce_sum(col_sum, comb_tmp, config={
            'reduce_axis': 0, 'keepdim': True
        })
        T.TensorOp.add(col_sum, col_sum, scalar)
        T.TensorOp.div(comb_tmp, comb_tmp, col_sum)

    for i in range(HC):
        comb_slice = Tensor(shape=[HC, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)
        T.TensorOp.store(comb_slice)

    # sinkhorn 流程结束
    # 对应pre.unsqueeze(-1)
    pre_unsue = Tensor(shape=[T, HC, 1], dtype=DType.FP32, mem_loc=MemLoc.UB)
    T.TensorOp.transpose(pre, pre_unsue)
    y_tmp = Tensor(shape=[T, T, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)
    y = Tensor(shape=[1, T, D], dtype=DType.BF16, mem_loc=MemLoc.UB)
    T.TensorOp.mul(y_tmp, pre_unsue, x)

    T.TensorOp.reduce_sum(y, y_tmp, config={
        'reduce_axis': 2, 'keepdim': True
    })
    T.TensorOp.store(y)


@op_registry.register(OpType.HcPreTriton, BackendType.THEO)
class TheoHcPreTriton(TheoreticalOperator):
    operator_dsl = mhc_pre_triton_extend

    def _input_check(self):
        pass

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        shape_T = self.op_input.input_shapes[0][0]
        shape_HC = self.op_input.input_shapes[0][1]
        shape_D = self.op_input.input_shapes[0][2]
        dynamic_shape = {
            'T': shape_T,
            'HC': shape_HC,
            'D': shape_D,
            'MIX_HC': (2 + shape_HC) * shape_HC,
            'HC_D': shape_HC * shape_D,
            'HC_HC': shape_HC * shape_HC,
            "HC_2": 2 * shape_HC,
            'dtype': self.op_input.input_dtypes[0],
        }
        return dynamic_shape