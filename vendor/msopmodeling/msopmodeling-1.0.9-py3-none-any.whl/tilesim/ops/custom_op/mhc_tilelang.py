# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.common import OpType, BackendType, MemLoc, DType
from core.common import op_registry
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

N, HC, HC_2, D, HC_D, MIX_HC, dtype = T.define_symbol(7)


def mhc_pre_gemm_sqrsum_tilelang(
        res: Tensor(shape=[N, HC, D], dtype=dtype, mem_loc=MemLoc.GM),
        hc_fn: Tensor(shape=[MIX_HC, HC_D], dtype=dtype, mem_loc=MemLoc.GM),
        hc_scale_: Tensor(shape=[3], dtype=dtype, mem_loc=MemLoc.GM),
        hc_base: Tensor(shape=[MIX_HC], dtype=dtype, mem_loc=MemLoc.GM),
        y_out: Tensor(shape=[N, D], dtype=dtype, mem_loc=MemLoc.GM),
        post_out: Tensor(shape=[N, HC], dtype=dtype, mem_loc=MemLoc.GM),
        comb_out: Tensor(shape=[N, HC, HC], dtype=dtype, mem_loc=MemLoc.GM),
):
    # 创建输入矩阵 UB
    res_flat = Tensor(shape=[N, HC_D], dtype=DType.BF16, mem_loc=MemLoc.UB)
    fn_t = Tensor(shape=[HC_D, MIX_HC], dtype=DType.FP32, mem_loc=MemLoc.UB)
    out_frag = Tensor(shape=[N, MIX_HC], dtype=DType.FP32, mem_loc=MemLoc.UB)
    out_sqrsum = Tensor(shape=[N, 1], dtype=DType.FP32, mem_loc=MemLoc.UB)

    # 创建输出矩阵 GM
    output_sqrsum = Tensor(shape=[N, 1], dtype=DType.FP32, mem_loc=MemLoc.UB)
    output_frag = Tensor(shape=[N, MIX_HC], dtype=DType.FP32, mem_loc=MemLoc.UB)

    T.TensorOp.null_op(res_flat, res)  # 从内存上把数据取到NPU并flat化
    T.TensorOp.null_op(fn_t, hc_fn)  # 从内存上取数据并且转置

    # 创建并行化任务 with T.Kernel(T.ceildiv(num_tokens, token_block)) as px:  其实就是为了并行化gemm过程
    T.TensorOp.gemm(out_frag, res_flat, fn_t)
    T.TensorOp.mul(res_flat, res_flat, res_flat)
    T.TensorOp.reduce_sum(out_sqrsum, res_flat, config={
        'reduce_axis': -1, 'keepdim': True
    })

    T.TensorOp.store(output_sqrsum)
    T.TensorOp.store(output_frag)


def mhc_pre_gemm_fused_tilelang(gemm_out_mul: Tensor(shape=[1, 1, MIX_HC], dtype=DType.FP32, mem_loc=MemLoc.GM),
                                gemm_out_sqrsum: Tensor(shape=[1], dtype=DType.FP32, mem_loc=MemLoc.GM),
                                res: Tensor(shape=[N, HC, D], dtype=DType.BF16, mem_loc=MemLoc.GM),
                                hc_scale: Tensor(shape=[3], dtype=dtype, mem_loc=MemLoc.GM),
                                hc_base: Tensor(shape=[MIX_HC], dtype=dtype, mem_loc=MemLoc.GM),
                                # 输出矩阵创建 GM
                                post_mix: Tensor(shape=[N, HC], dtype=DType.FP32, mem_loc=MemLoc.GM),
                                comb_mix: Tensor(shape=[N, HC, HC], dtype=DType.FP32, mem_loc=MemLoc.GM),
                                layer_input: Tensor(shape=[N, D], dtype=DType.BF16, mem_loc=MemLoc.GM)
                                ):
    hc_scale_in = Tensor(shape=[3], dtype=DType.FP32, mem_loc=MemLoc.UB)
    hc_base_in = Tensor(shape=[MIX_HC], dtype=dtype, mem_loc=MemLoc.UB)
    res_in = Tensor(shape=[N, HC, D], dtype=DType.BF16, mem_loc=MemLoc.UB)

    T.TensorOp.null_op(hc_scale_in, hc_scale)
    T.TensorOp.null_op(hc_base_in, hc_base)
    T.TensorOp.null_op(res_in, res)

    for i in range(N):
        # 输入矩阵至UB
        gemm_in_sqrsum = Tensor(shape=[1], dtype=DType.FP32, mem_loc=MemLoc.GM)
        gemm_in_mul = Tensor(shape=[1, 1, MIX_HC], dtype=DType.FP32, mem_loc=MemLoc.UB)
        scalar = Tensor(shape=[1], dtype=DType.FP32, mem_loc=MemLoc.UB)
        scalar_2 = Tensor(shape=[1], dtype=DType.FP32, mem_loc=MemLoc.UB)
        mixes = Tensor(shape=[MIX_HC], dtype=DType.FP32, mem_loc=MemLoc.UB)

        T.TensorOp.null_op(gemm_in_sqrsum, gemm_out_sqrsum)  # 输入x^2

        T.TensorOp.div(gemm_in_sqrsum, gemm_in_sqrsum, scalar)  # mean（x^2）
        T.TensorOp.adds(gemm_in_sqrsum, gemm_in_sqrsum, scalar)  # mean(x[-1]^2) + e
        T.TensorOp.sqrt(gemm_in_sqrsum, gemm_in_sqrsum)  # (mean(x[-1]^2+exps))^1/2

        T.TensorOp.null_op(gemm_in_mul, gemm_out_mul)  # 输入gemm结果
        T.TensorOp.reduce_sum(mixes, gemm_in_mul, config={
            'reduce_axis': 1, 'keepdim': True
        })
        T.TensorOp.div(mixes, mixes, gemm_in_sqrsum)

        comb = Tensor(shape=[HC, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)
        post = Tensor(shape=[1, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)
        pre = Tensor(shape=[1, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)

        # comb计算
        T.TensorOp.mul(comb, comb, hc_scale_in)
        T.TensorOp.add(comb, comb, hc_base_in)  # COMb=mixes*hc_scale[2]+hc_base[HC]
        # T.TensorOp.sigmod(comb, comb)  #还需要拿去sinkhorn，先不搬出去

        # post计算
        T.TensorOp.mul(post, post, hc_scale_in)
        T.TensorOp.add(post, post, hc_base_in)
        # 对应T.TensorOp.sigmod(post,post)
        T.TensorOp.mul(post, post, scalar_2)  # post =2 *sigmod(mixes*hc_scale[1]+hc_base)
        # post存储
        post_out = Tensor(shape=[1, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)
        T.TensorOp.store(post_out)

        # sinkhorn流程
        # 对应comb = comb.softmax(-1) + eps
        # 对应comb = comb / (comb.sum(-2) + eps)
        # 行reduce_sum 列reduce_sum 执行repeat次（20次）
        comb_out = Tensor(shape=[1, HC, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)
        T.TensorOp.store(comb_out)

        # pre计算
        T.TensorOp.mul(pre, pre, hc_scale_in)
        T.TensorOp.add(pre, pre, hc_base_in)
        # 对应 T.TensorOp.sigmod(pre, pre)
        res_split = Tensor(shape=[1, HC, D], dtype=DType.BF16, mem_loc=MemLoc.UB)
        pre_mul = Tensor(shape=[1, D], dtype=DType.BF16, mem_loc=MemLoc.UB)
        T.TensorOp.mul(pre_mul, pre, res_split)  #
        # pre_mul储存
        T.TensorOp.store(pre_mul)


def mhc_post_tilelang(x: Tensor(shape=[N, HC, D], dtype=DType.BF16, mem_loc=MemLoc.GM),
                      res: Tensor(shape=[N, HC, D], dtype=DType.BF16, mem_loc=MemLoc.GM),
                      post: Tensor(shape=[N, HC], dtype=DType.FP32, mem_loc=MemLoc.GM),
                      comb: Tensor(shape=[N, HC, HC], dtype=DType.FP32, mem_loc=MemLoc.GM),
                      # 输出矩阵创建 GM
                      out: Tensor(shape=[N, HC, D], dtype=DType.FP32, mem_loc=MemLoc.GM)

                      ):
    # 输入矩阵 UB
    x_in = Tensor(shape=[N, HC, D], dtype=DType.BF16, mem_loc=MemLoc.UB)
    res_in = Tensor(shape=[N, HC, D], dtype=DType.BF16, mem_loc=MemLoc.UB)
    post_in = Tensor(shape=[N, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)
    comb_in = Tensor(shape=[N, HC, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)

    T.TensorOp.null_op(x_in, x)
    T.TensorOp.null_op(res_in, res)
    T.TensorOp.null_op(post_in, post)
    T.TensorOp.null_op(comb_in, comb)

    for i in range(N):
        term1 = Tensor(shape=[HC, HC_D], dtype=DType.BF16, mem_loc=MemLoc.UB)
        T.TensorOp.mul(term1, post, x)
        term2 = Tensor(shape=[HC, HC_D], dtype=DType.BF16, mem_loc=MemLoc.UB)
        T.TensorOp.mul(term2, comb, res)
        term3 = Tensor(shape=[HC, HC_D], dtype=DType.BF16, mem_loc=MemLoc.UB)
        T.TensorOp.add(term3, term1, term2)

    out_term = Tensor(shape=[N, HC, D], dtype=DType.BF16, mem_loc=MemLoc.UB)
    T.TensorOp.store(out_term)


@op_registry.register(OpType.HcTilelang, BackendType.THEO)
class TheoHcTilelang(TheoreticalOperator):
    operator_dsl = [mhc_pre_gemm_sqrsum_tilelang, mhc_pre_gemm_fused_tilelang, mhc_post_tilelang]

    def _input_check(self):
        pass

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        shape_T = self.op_input.input_shapes[0][0]
        shape_HC = self.op_input.input_shapes[0][1]
        shape_D = self.op_input.input_shapes[0][2]
        dynamic_shape = {
            'N': shape_T,
            'HC': shape_HC,
            'D': shape_D,
            "MIX_HC": shape_HC * (shape_HC + 2),
            'HC_D': shape_HC * shape_D,
            'dtype': self.op_input.input_dtypes[0],
        }
        return dynamic_shape