# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.common import OpType, BackendType, MemLoc, DType
from core.common import op_registry
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

N, HC, HC_2, D, HC_D, MIX_HC, dtype = T.define_symbol(7)


def mhc_unfused(
        res: Tensor(shape=[N, HC, D], dtype=dtype, mem_loc=MemLoc.GM),
        res_2: Tensor(shape=[N, HC, D], dtype=dtype, mem_loc=MemLoc.GM),
        hc_fn: Tensor(shape=[MIX_HC, HC_D], dtype=dtype, mem_loc=MemLoc.GM),
        hc_scale_: Tensor(shape=[3], dtype=dtype, mem_loc=MemLoc.GM),
        hc_base: Tensor(shape=[MIX_HC], dtype=dtype, mem_loc=MemLoc.GM),
        y_out: Tensor(shape=[N, D], dtype=dtype, mem_loc=MemLoc.GM),
        post_out: Tensor(shape=[N, HC], dtype=dtype, mem_loc=MemLoc.GM),
        comb_out: Tensor(shape=[N, HC, HC], dtype=dtype, mem_loc=MemLoc.GM),
):
    # res搬入UB并flatten
    x = Tensor(shape=[N, HC_D], dtype=dtype, mem_loc=MemLoc.UB)
    T.TensorOp.null_op(x, res)

    # RMSNorm
    x_mean = Tensor(shape=[N, 1], dtype=dtype, mem_loc=MemLoc.UB)
    scalar = Tensor(shape=[1], dtype=dtype, mem_loc=MemLoc.UB)
    rms_res = Tensor(shape=[N, 1], dtype=dtype, mem_loc=MemLoc.UB)

    T.TensorOp.mul(x, x, x)  # x.square()
    T.TensorOp.reduce_sum(x_mean, x, config={
        'reduce_axis': -1, 'keepdim': True
    })
    T.TensorOp.div(x_mean, x_mean, scalar)  # mean
    T.TensorOp.adds(x_mean, x_mean, scalar)  # mean(x^2[-1]) + e
    T.TensorOp.sqrt(rms_res, x_mean)  # (mean(x^2[-1]) + e)^1/2

    T.TensorOp.store(rms_res)  # 缓存 r[N,1]

    # H_Mixed_Linear
    hc_fn_in = Tensor(shape=[HC_D, MIX_HC], dtype=dtype, mem_loc=MemLoc.UB)
    x_2 = Tensor(shape=[N, HC_D], dtype=dtype, mem_loc=MemLoc.UB)
    mm_res = Tensor(shape=[N, MIX_HC], dtype=dtype, mem_loc=MemLoc.UB)
    T.TensorOp.null_op(hc_fn_in, hc_fn)  # 搬入hc_fn
    T.TensorOp.null_op(x_2, res_2)  # 再度搬入 res

    T.TensorOp.gemm(mm_res, x_2, hc_fn)  # [N,HC_D]*[HC_D，MIX_HC]=[N, MIX_HC]
    T.TensorOp.store(mm_res)

    # hadamard product
    gemm_res = Tensor(shape=[N, MIX_HC], dtype=dtype, mem_loc=MemLoc.GM)
    rms_res_load = Tensor(shape=[N, 1], dtype=dtype, mem_loc=MemLoc.GM)
    mixes = Tensor(shape=[N, MIX_HC], dtype=dtype, mem_loc=MemLoc.UB)
    T.TensorOp.div(mixes, gemm_res, rms_res_load)
    T.TensorOp.store(mixes)

    # cal pre
    mixes_pre = Tensor(shape=[N, HC], dtype=dtype, mem_loc=MemLoc.GM)
    scalar = Tensor(shape=[1], dtype=dtype, mem_loc=MemLoc.UB)
    pre = Tensor(shape=[N, HC], dtype=dtype, mem_loc=MemLoc.UB)
    hc_base_pre = Tensor(shape=[HC], dtype=dtype, mem_loc=MemLoc.UB)

    T.TensorOp.null_op(scalar, hc_scale_)  # 从hc_scale提取[0]
    T.TensorOp.null_op(hc_base_pre, hc_base)  # 从hc_base提取第一个[hc]
    T.TensorOp.mul(pre, mixes_pre, scalar)
    T.TensorOp.add(pre, pre, hc_base_pre)
    #补充 T.TensorOp.sigmod(pre,pre)
    T.TensorOp.store(pre)

    # cal post
    mixes_post = Tensor(shape=[N, HC], dtype=dtype, mem_loc=MemLoc.GM)
    scalar = Tensor(shape=[1], dtype=dtype, mem_loc=MemLoc.UB)
    post = Tensor(shape=[N, HC], dtype=dtype, mem_loc=MemLoc.UB)
    hc_base_post = Tensor(shape=[HC], dtype=dtype, mem_loc=MemLoc.UB)

    T.TensorOp.null_op(scalar, hc_scale_)  # 从hc_scale提取[1]
    T.TensorOp.null_op(hc_base_post, hc_base)  # 从hc_base提取第2个[hc]
    T.TensorOp.mul(post, mixes_post, scalar)
    T.TensorOp.add(post, post, hc_base_post)
    #补充 T.TensorOp.sigmod(post, post)
    T.TensorOp.mul(post, post, scalar)  # 2*sigmod(post)
    T.TensorOp.store(post)

    # cal comb
    mixes_comb = Tensor(shape=[N, HC_2], dtype=dtype, mem_loc=MemLoc.GM)
    scalar = Tensor(shape=[1], dtype=dtype, mem_loc=MemLoc.UB)
    row_max = Tensor(shape=[1], dtype=dtype, mem_loc=MemLoc.UB)
    comb = Tensor(shape=[N, HC_2], dtype=dtype, mem_loc=MemLoc.UB)
    hc_base_comb = Tensor(shape=[HC_2], dtype=dtype, mem_loc=MemLoc.UB)

    T.TensorOp.null_op(scalar, hc_scale_)  # 从hc_scale提取[2]
    T.TensorOp.null_op(hc_base_comb, hc_base)  # 从hc_base提取[hc^2]

    T.TensorOp.mul(comb, mixes_comb, scalar)
    T.TensorOp.add(comb, comb, hc_base_comb)
    T.TensorOp.null_op(comb, row_max)  # comb减去行最大值
    T.TensorOp.exp(comb, comb)

    row_sum = Tensor(shape=[N, 1], dtype=dtype, mem_loc=MemLoc.UB)
    exp = Tensor(shape=[1], dtype=dtype, mem_loc=MemLoc.UB)
    T.TensorOp.reduce_sum(row_sum, comb, config={
        'reduce_axis': -1, 'keepdim': True
    })
    # 对应cm[j, k] = cm[j, k] / row_sum[j] + hc_sinkhorn_eps
    T.TensorOp.div(comb, comb, row_sum)
    T.TensorOp.add(comb, comb, exp)

    col_sum = Tensor(shape=[1, HC_2], dtype=dtype, mem_loc=MemLoc.UB)
    T.TensorOp.reduce_sum(col_sum, comb, config={
        'reduce_axis': -2, 'keepdim': True
    })
    # 对应cm[j, k] = cm[j, k] / (col_sum[k] + hc_sinkhorn_eps)
    T.TensorOp.add(col_sum, col_sum, exp)
    T.TensorOp.div(comb, comb, col_sum)

    T.TensorOp.store(comb)
    # sinkhorn流程开始
    for i in range(200):
        comb_red = Tensor(shape=[N, HC_2], dtype=dtype, mem_loc=MemLoc.GM)

        row_sum = Tensor(shape=[N, 1], dtype=dtype, mem_loc=MemLoc.UB)
        col_sum = Tensor(shape=[1, HC_2], dtype=dtype, mem_loc=MemLoc.UB)
        #对应 comb = comb / (comb.sum(-1) + eps）
        T.TensorOp.reduce_sum(row_sum, comb_red, config={
            'reduce_axis': -1, 'keepdim': True
        })
        T.TensorOp.add(row_sum, row_sum, exp)
        T.TensorOp.div(comb, comb, row_sum)
        # 对应comb = comb / (comb.sum(-2) + eps)
        T.TensorOp.reduce_sum(col_sum, comb_red, config={
            'reduce_axis': -2, 'keepdim': True
        })
        T.TensorOp.add(col_sum, col_sum, exp)
        T.TensorOp.div(comb, comb, col_sum)

        T.TensorOp.store(comb)  # 每次sinkhorn的结果写入主存

    # pre和x乘得到 y给到layer层
    pre_2 = Tensor(shape=[N, HC], dtype=dtype, mem_loc=MemLoc.GM)
    x_in = Tensor(shape=[N, HC_D], dtype=dtype, mem_loc=MemLoc.GM)
    y = Tensor(shape=[N, HC_D], dtype=dtype, mem_loc=MemLoc.UB)
    T.TensorOp.mul(y, pre_2, x_in)  # pre_2 boardcast D维度
    T.TensorOp.store(y)

    # 经过layer层 进入post过程
    # y和post乘得到term1
    y_in = Tensor(shape=[N, HC_D], dtype=dtype, mem_loc=MemLoc.GM)
    post_2 = Tensor(shape=[N, HC], dtype=dtype, mem_loc=MemLoc.GM)
    term1 = Tensor(shape=[HC, HC_D], dtype=dtype, mem_loc=MemLoc.UB)
    T.TensorOp.mul(term1, post_2, y_in)

    comb_2 = Tensor(shape=[N, HC_2], dtype=dtype, mem_loc=MemLoc.GM)
    res_new = Tensor(shape=[N, HC_D], dtype=dtype, mem_loc=MemLoc.GM)
    term2 = Tensor(shape=[HC, HC_D], dtype=dtype, mem_loc=MemLoc.UB)
    T.TensorOp.mul(term2, comb_2, res_new)
    T.TensorOp.add(term1, term1, term2)

    T.TensorOp.store(term1)


@op_registry.register(OpType.HcUnfused, BackendType.THEO)
class TheoHcUnfused(TheoreticalOperator):
    operator_dsl = mhc_unfused

    def _input_check(self):
        pass

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        shape_T = self.op_input.input_shapes[0][0]
        shape_HC = self.op_input.input_shapes[0][1]
        shape_D = self.op_input.input_shapes[0][2]
        dynamic_shape = {
            'N': shape_T,
            'HC': shape_HC,
            'D': shape_D,
            'HC_2': shape_HC * shape_HC,
            "MIX_HC": shape_HC * (shape_HC + 2),
            'HC_D': shape_HC * shape_D,
            'dtype': self.op_input.input_dtypes[0],
        }
        return dynamic_shape