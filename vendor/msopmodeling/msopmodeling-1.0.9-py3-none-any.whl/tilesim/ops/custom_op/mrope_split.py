# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.common import OpType, BackendType, MemLoc, DType
from core.common import op_registry
from core.frontend.dsl.grammar.tensor_op import TensorOp
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

S, H, Q_N, K_N, D = T.define_symbol(5)


def mrope_golden(
):
    position = Tensor(shape=[3, S], dtype=DType.INT64, mem_loc=MemLoc.GM)
    p_in = Tensor(shape=[3, S], dtype=DType.INT64, mem_loc=MemLoc.GM)

    k_in = Tensor(shape=[S, D], dtype=DType.BF16, mem_loc=MemLoc.GM)  # D=256
    q_in = Tensor(shape=[S, H], dtype=DType.BF16, mem_loc=MemLoc.GM)  # H=4096
    # Q K 的rms norm
    query = Tensor(shape=[S, H], dtype=DType.BF16, mem_loc=MemLoc.UB)
    key = Tensor(shape=[S, D], dtype=DType.BF16, mem_loc=MemLoc.UB)

    v = Tensor(shape=[S, D], dtype=DType.BF16, mem_loc=MemLoc.GM)
    v_in = Tensor(shape=[S, D], dtype=DType.BF16, mem_loc=MemLoc.UB)

    sincos = Tensor(shape=[32000, 128], dtype=DType.BF16, mem_loc=MemLoc.GM)

    q_gamma = Tensor(shape=[128], dtype=DType.BF16, mem_loc=MemLoc.GM)
    q_gamma_in = Tensor(shape=[128], dtype=DType.BF16, mem_loc=MemLoc.UB)
    k_gamma = Tensor(shape=[128], dtype=DType.BF16, mem_loc=MemLoc.GM)
    k_gamma_in = Tensor(shape=[128], dtype=DType.BF16, mem_loc=MemLoc.UB)

    T.TensorOp.null_op(key, k_in)
    T.TensorOp.null_op(query, q_in)
    T.TensorOp.null_op(position, p_in)
    T.TensorOp.null_op(v, v_in)
    T.TensorOp.null_op(q_gamma, q_gamma_in)
    T.TensorOp.null_op(k_gamma, k_gamma_in)

    # 按照positon 提取旋转坐标量
    cos_sin = Tensor(shape=[3 * S, 128], dtype=DType.BF16, mem_loc=MemLoc.UB)
    T.TensorOp.null_op(cos_sin, sincos)

    cos = Tensor(shape=[3 * S, 64], dtype=DType.BF16, mem_loc=MemLoc.UB)
    sin = Tensor(shape=[3 * S, 64], dtype=DType.BF16, mem_loc=MemLoc.UB)

    # 如果position是2D的，
    # cos reshape 成[3,S,64],从中取第一组数据clone进主存然后把剩下两个矩阵插值进去
    cos_res = Tensor(shape=[S, 64], dtype=DType.BF16, mem_loc=MemLoc.UB)
    sin_res = Tensor(shape=[S, 64], dtype=DType.BF16, mem_loc=MemLoc.UB)
    T.TensorOp.store(cos_res)
    T.TensorOp.store(cos)
    T.TensorOp.store(sin_res)
    T.TensorOp.store(sin)

    cos_unsq = Tensor(shape=[S, 1, 64], dtype=DType.BF16, mem_loc=MemLoc.UB)
    sin_unsq = Tensor(shape=[S, 1, 64], dtype=DType.BF16, mem_loc=MemLoc.UB)

    query_2 = Tensor(shape=[S, 32, 128], dtype=DType.BF16, mem_loc=MemLoc.UB)
    query_rot = Tensor(shape=[S, 32, 128], dtype=DType.BF16, mem_loc=MemLoc.UB)
    query_pass = Tensor(shape=[S, 32, 0], dtype=DType.BF16, mem_loc=MemLoc.UB)

    x1 = Tensor(shape=[S, 32, 64], dtype=DType.BF16, mem_loc=MemLoc.UB)
    x2 = Tensor(shape=[S, 32, 64], dtype=DType.BF16, mem_loc=MemLoc.UB)

    term1 = Tensor(shape=[S, 1, 64], dtype=DType.BF16, mem_loc=MemLoc.UB)
    term2 = Tensor(shape=[S, 1, 64], dtype=DType.BF16, mem_loc=MemLoc.UB)

    o1 = Tensor(shape=[S, 1, 64], dtype=DType.BF16, mem_loc=MemLoc.UB)
    o2 = Tensor(shape=[S, 1, 64], dtype=DType.BF16, mem_loc=MemLoc.UB)
    # 对应o1=x1*cos-x2*sin
    T.TensorOp.mul(term1, x1, cos_unsq)
    T.TensorOp.mul(term2, x2, sin_unsq)
    T.TensorOp.add(o1, term1, term2)
    # 对应o2=x2*cos+x1*sin
    T.TensorOp.mul(term1, x1, sin_unsq)
    T.TensorOp.mul(term2, x2, cos_unsq)
    T.TensorOp.add(o2, term1, term2)
    # o1 o2拼接成完整的query_rot，query_rot和query_pass拼成完整的query
    T.TensorOp.store(query_2)
    # 类似的处理k，最后写回k
    T.TensorOp.store(key)


def mrope_merge(
):
    qkv = Tensor(shape=[S, (D + D + H)], dtype=DType.BF16, mem_loc=MemLoc.GM)
    qkv_in = Tensor(shape=[S, (D + D + H)], dtype=DType.BF16, mem_loc=MemLoc.UB)
    q_gamma = Tensor(shape=[128], dtype=DType.BF16, mem_loc=MemLoc.GM)
    q_gamma_in = Tensor(shape=[128], dtype=DType.BF16, mem_loc=MemLoc.UB)
    k_gamma = Tensor(shape=[128], dtype=DType.BF16, mem_loc=MemLoc.GM)
    k_gamma_in = Tensor(shape=[128], dtype=DType.BF16, mem_loc=MemLoc.UB)
    sincos = Tensor(shape=[32000, 128], dtype=DType.BF16, mem_loc=MemLoc.GM)
    sincos_in = Tensor(shape=[32000, 128], dtype=DType.BF16, mem_loc=MemLoc.UB)

    position = Tensor(shape=[3, S], dtype=DType.INT64, mem_loc=MemLoc.GM)
    position_in = Tensor(shape=[3, S], dtype=DType.INT64, mem_loc=MemLoc.UB)
    # 搬入
    T.TensorOp.null_op(qkv, qkv_in)
    T.TensorOp.null_op(q_gamma, q_gamma_in)
    T.TensorOp.null_op(k_gamma, k_gamma_in)
    T.TensorOp.null_op(sincos, sincos_in)
    T.TensorOp.null_op(position_in, position)
    # 搬出
    query = Tensor(shape=[S, H], dtype=DType.BF16, mem_loc=MemLoc.UB)
    key = Tensor(shape=[S, D], dtype=DType.BF16, mem_loc=MemLoc.UB)

    T.TensorOp.store(query)
    T.TensorOp.store(key)


@op_registry.register(OpType.MropeGolden, BackendType.THEO)
class TheoMropeGolden(TheoreticalOperator):
    operator_dsl = mrope_golden

    def _input_check(self):
        pass

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        dynamic_shape = {
            'S': 200,
            'H': 4096,
            'D': 256,
            'Q_N': 32,
            'K_N': 2,
        }
        return dynamic_shape