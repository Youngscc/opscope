# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.common.backend_config import OptimType, TaskIndexConfig, OptimConfig
from core.common.entity import MemLoc, DType, OpType, BackendType
from core.common.op_registry import op_registry
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor
from core.pipeline.tilesim_eng.eng_operator import EngineeringOperator
from ops.engineering_model.cube_op.tiling_strategy.matmul_tiling import MatMulTilingPredictor

M, N, K, input_dtype, output_dtype, tm, tn, tk1, tk0 = T.define_symbol(9)


def matmul_l0(src1: Tensor(shape=[M, K], dtype=input_dtype, mem_loc=MemLoc.GM),
              src2: Tensor(shape=[K, N], dtype=input_dtype, mem_loc=MemLoc.GM),
              output: Tensor(shape=[M, N], dtype=output_dtype, mem_loc=MemLoc.GM),
              ):
    """matmul算子dsl实现"""
    m_tiles = T.ceil(M / tm)
    n_tiles = T.ceil(N / tn)
    k_tiles = T.ceil(K / tk1)
    k0_tiles = T.ceil(tk1 / tk0)

    with T.Task(name="matmul_l1", range=[m_tiles, n_tiles]) as ([i, j]):
        out_l0c = Tensor(shape=[tm, tn], dtype=output_dtype, mem_loc=MemLoc.L0C)
        src1_tile_l1 = Tensor(shape=[tm, tk1], dtype=input_dtype, mem_loc=MemLoc.L1)

        for k1_idx in range(k_tiles):
            src1_tile_k1 = src1[i * tm:T.min((i + 1) * tm, M), k1_idx * tk1: T.min((k1_idx + 1) * tk1, K)]
            src2_tile_k1 = src2[k1_idx * tk1: T.min((k1_idx + 1) * tk1, K), j * tn:T.min((j + 1) * tn, N)]

            if i == 0:
                T.TileOp.copy(src1_tile_l1, src1_tile_k1)
            src2_tile_l1 = Tensor(shape=[tk1, tn], dtype=input_dtype, mem_loc=MemLoc.L1)
            T.TileOp.copy(src2_tile_l1, src2_tile_k1)

            for k0_idx in range(k0_tiles):
                src1_tile_k0 = src1_tile_l1[0: T.min(tm, M - i * tm), k0_idx * tk0: T.min(tk0 * (k0_idx + 1), K - k1_idx * tk1)]
                src2_tile_k0 = src2_tile_l1[k0_idx * tk0: T.min(tk0 * (k0_idx + 1), K - k1_idx * tk1), 0:T.min(tn, N - j * tn)]

                src1_tile_l0 = Tensor(shape=[tm, tk0], dtype=input_dtype, mem_loc=MemLoc.L0A)
                src2_tile_l0 = Tensor(shape=[tk0, tn], dtype=input_dtype, mem_loc=MemLoc.L0B)
                T.TileOp.copy(src1_tile_l0, src1_tile_k0)
                T.TileOp.copy(src2_tile_l0, src2_tile_k0)

                T.TileOp.mmad(out_l0c, src1_tile_l0, src2_tile_l0)

        output_tile = output[i * tm:T.min((i + 1) * tm, M), j * tn:T.min((j + 1) * tn, N)]
        T.TileOp.copy(output_tile, out_l0c)


@op_registry.register(OpType.MatMul, BackendType.ENG)
class EngMatmulL0(EngineeringOperator):

    @property
    def operator_dsl(self):
        return matmul_l0

    @property
    def optim_type(self) -> OptimType:
        return OptimType.GENERAL_BY_SEQ_OPTIM

    def _input_check(self):
        if self.op_input.input_dict:
            required_dynamic_shape = {'m', 'k', 'n', 'input_dtype', 'output_dtype'}
            for key in required_dynamic_shape:
                if key not in self.op_input.input_dict:
                    raise ValueError(f"[EngOp.{EngMatmulL0.op_name}]: input_dict must have key {key}")
        else:
            input_shapes = self.op_input.input_shapes
            output_shapes = self.op_input.output_shapes

            if len(input_shapes) != 2:
                raise ValueError(f"[EngOp.{EngMatmulL0.op_name}]: inputs len must be 2")
            if len(output_shapes) != 1:
                raise ValueError(f"[EngOp.{EngMatmulL0.op_name}]: outputs len must be 1")
            if input_shapes[0][1] != input_shapes[1][0]:
                raise ValueError(f"[EngOp.{EngMatmulL0.op_name}]: K must be equal")

    def _set_optim_config(self) -> OptimConfig:
        task_index_configs = {
            "matmul_l1": [
                TaskIndexConfig(
                    index_name='i',
                    seq_num=0,
                    split_core_stride=-1,
                    enable_swizzle=False
                ),
                TaskIndexConfig(
                    index_name='j',
                    seq_num=1,
                    split_core_stride=1,
                    enable_swizzle=True
                )
            ]
        }

        optim_config = OptimConfig(
            optim_method=self.optim_type,
            tuning_candidates=self.op_input.param.tuning_candidates,
            task_index_config=task_index_configs
        )
        return optim_config

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        input_dict = self.op_input.input_dict
        if input_dict:
            m = input_dict['m']
            k = input_dict['k']
            n = input_dict['n']
            input_dtype = DType.from_str(input_dict['input_dtype'])
            output_dtype = DType.from_str(input_dict['output_dtype'])
        else:
            input_shapes = self.op_input.input_shapes
            m = input_shapes[0][0]
            k = input_shapes[0][1]
            n = input_shapes[1][1]
            input_dtype = self.op_input.input_dtypes[0]
            output_dtype = self.op_input.output_dtypes[0]
        dynamic_shape = {
            "M": m,
            "K": k,
            "N": n,
            "input_dtype": input_dtype,
            "output_dtype": output_dtype,
        }

        return dynamic_shape


if __name__ == "__main__":
    input_shapes = [[2048, 512], [512, 1024]]
    output_shapes = [[2048, 1024]]
    input_dtypes = [DType.FP16.name, DType.FP16.name]
    output_dtypes = [DType.FP32.name]
    accelerator = "../../../core/config/arc_config/910B1/910B1.yaml"
    core_num = 24

    m = input_shapes[0][0]
    k = input_shapes[0][1]
    n = input_shapes[1][1]
    dtype = DType.from_str(input_dtypes[0])
    predictor = MatMulTilingPredictor(chip=accelerator)

    # 预测tiling策略
    strategy_name, candidate_tuning = predictor.predict_tiling(m, n, k, dtype, False, False)

    op_input = {
        'input_shapes': input_shapes,
        'output_shapes': output_shapes,
        'input_dtypes': input_dtypes,
        'output_dtypes': output_dtypes,
        'accelerator': accelerator,
        'aic_core_num': 24,
        "extra_param": {
            "tuning_candidates": [candidate_tuning],
        }
    }

    op_input_obj = EngMatmulL0.op_input_convert(op_input)
    res = EngMatmulL0(op_input_obj).run()

    res.print_format()
