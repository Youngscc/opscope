# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from typing import Any

from core.pipeline.tilesim_eng.eng_operator import EngineeringOperator
from core.common import MemLoc, DType
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

S0 = 1024
S1 = 1024
N = 1
D = 128
D1 = 128
s0_c = 128
s1_c = 128
s0_v = 64
d_type = DType.FP16
mem_loc = MemLoc.GM
vec_d_type = DType.FP32
preload_num = 4
TMP_UB_OFFSET = 184 * 1024   # UB临时空间起始地址
stride_bytes = 64 * 128 * 4



def pto_flash_attention(
        q: Tensor(shape=[S0, D], dtype=d_type, mem_loc=MemLoc.GM),
        k: Tensor(shape=[S1, D], dtype=d_type, mem_loc=MemLoc.GM),
        v: Tensor(shape=[S1, D1], dtype=d_type, mem_loc=MemLoc.GM),
        output: Tensor(shape=[S0, D1], dtype=d_type, mem_loc=MemLoc.GM),

        # C&V中间结果的tiling大小
        s0_inter=S0+1,
        s1_inter=S1,
):
    """
    pto_flash attention计算dsl
    Args:
        q:
        k:
        v:
        output:
        softmax_type:
        s0_c:
        s1_c:
        s0_v:
        s1_c:
        s0_inter:
        s1_inter:

    Returns:

    """
    # compute_qk  QK矩阵乘
    s0_tiles_cube = T.ceil(S0/s0_c)
    s1_tiles_cube = T.ceil(S1/s1_c)
    s = Tensor(shape=[s0_inter, s1_inter], dtype=DType.FP32, mem_loc=mem_loc)

    # L1&L0C的空间分配
    q_tile_l1 = Tensor(shape=[s0_c, D], dtype=DType.FP16, mem_loc=MemLoc.L1)
    k_tile_l1 = Tensor(shape=[D, s1_c], dtype=DType.FP16, mem_loc=MemLoc.L1)
    s_tile_l0c = Tensor(shape=[s0_c, s1_c], dtype=DType.FP32, mem_loc=MemLoc.L0C)
    with T.Task(range=[s0_tiles_cube, s1_tiles_cube]) as ([i, j]):
        # 需要操作的张量（两种方式都可以表示张量的切片操作，但是第一种必须要指定明确的offset）
        q_tile = q[i * s0_c:T.min((i + 1) * s0_c, S0), :]
        k_tile = k[:, j * s1_c:T.min((j + 1) * s1_c, S1)]
        s_tile = s.view([s0_c, s1_c])

        # TEXTRACT l1 to l0 待实现
        # 核内Q的S0按cube核数切分s0_c常驻L1，核内K的S1再切分s1_c分批次加载到L1
        if j == 0:
            T.TileOp.copy(q_tile_l1, q_tile)
        T.TileOp.copy(k_tile_l1, k_tile)
        T.TileOp.barrier()
        T.TileOp.gemm(s_tile_l0c, q_tile_l1, k_tile_l1)
        T.TileOp.barrier()
        T.TileOp.copy(s_tile, s_tile_l0c)
        T.TileOp.barrier()

    # softmax  compute_p
    s0_tiles_v = T.ceil(S0/s0_v)  # s0_vector = s0_cube / vec_cores = s0_cube / 2
    s1_tiles_v = T.ceil(S1/s1_c)  # s1_vector = s1_cube

    # 中间Global Tensor临时空间分配
    p = Tensor(shape=[s0_inter, s1_inter], dtype=DType.FP16, mem_loc=mem_loc)

    # UB地址分配
    vec_input_buffer_num = 2  # vector input buffer 2
    vec_exp_max_buffer_num = preload_num + 1  # vector exp max buffer 5
    # NEXT stride_bytes = (s0_v * s1_c if s1_c > D1 else s0_v * D1) * DType.FP32.size

    tmp_row_max_broadcast_ub = Tensor(shape=[s0_v, 8], dtype=DType.FP32, mem_loc=MemLoc.UB,
                                      # NEXT start_addr=TMP_UB_OFFSET)
                                      start_addr=188416)
    tmp_row_sub_max_exp_ub = Tensor(shape=[s0_v, s1_c], dtype=DType.FP32, mem_loc=MemLoc.UB,
                                    # NEXT start_addr=stride_bytes * 2 + s0_v * DType.FP32.size * 2)
                                    start_addr=66048)


    # local
    local_max = Tensor(shape=[s0_v, 1], dtype=DType.FP32, mem_loc=MemLoc.UB,
                       # NEXT start_addr=stride_bytes * 2)
                       start_addr=65536)
    local_sum = Tensor(shape=[s0_v, 1], dtype=DType.FP32, mem_loc=MemLoc.UB,
                       # NEXT start_addr=stride_bytes * 2 + s0_v * DType.FP32.size * 2 + s0_v * s1_c * DType.FP32.size)
                       start_addr=98816)

    # global
    global_row_max_ub = Tensor(shape=[s0_v, 1], dtype=DType.FP32, mem_loc=MemLoc.UB,
                               # NEXT start_addr=stride_bytes * 2 + s0_v * DType.FP32.size * 1)
                               start_addr=65792)
    global_row_sum_ub = Tensor(shape=[s0_v, 1], dtype=DType.FP32, mem_loc=MemLoc.UB,
                               # NEXT start_addr=stride_bytes * 2 + s0_v * DType.FP32.size * 3 + s0_v * s1_c * DType.FP32.size)
                               start_addr=99072)

    global_row_max_gm = Tensor(shape=[s0_v, 1], dtype=DType.FP32, mem_loc=mem_loc)
    global_row_sum_gm = Tensor(shape=[s0_v, 1], dtype=DType.FP32, mem_loc=mem_loc)


    with T.Task(range=[s0_tiles_v, s1_tiles_v]) as ([i, j]):
        exp_max_ub = Tensor(shape=[s0_v, 1], dtype=DType.FP32, mem_loc=MemLoc.UB,
                            # NEXT start_addr=stride_bytes * 2 + s0_v * DType.FP32.size * 4 + s0_v * s1_c * DType.FP32.size
                            # NEXT            + s0_v * DType.FP32.size * (j % vec_exp_max_buffer_num))
                            start_addr=99328 + 256 * (j % 5))
        exp_max_gm = Tensor(shape=[s0_v, 1], dtype=DType.FP32, mem_loc=mem_loc)

        s_tile_ub = Tensor(shape=[s0_v, s1_c], dtype=DType.FP32, mem_loc=MemLoc.UB,
                           # NEXT start_addr=stride_bytes * (j % vec_input_buffer_num))
                           start_addr=32768 * (j % 2))
        p_tile_ub = Tensor(shape=[s0_v, s1_c], dtype=DType.FP16, mem_loc=MemLoc.UB,
                           # NEXT start_addr=stride_bytes * 2 + s0_v * DType.FP32.size * 4 + s0_v * s1_c * DType.FP32.size
                           # NEXT            + s0_v * DType.FP32.size * vec_exp_max_buffer_num
                           # NEXT            + s0_v * s1_c * DType.FP16.size  * (j % vec_input_buffer_num))
                           start_addr=100608 + 16384 * (j % 2))

        s_tile = s.view([s0_v, s1_c])
        T.TileOp.copy(s_tile_ub, s_tile)
        T.TileOp.barrier()

        # 每行除第一个tile块外，更新全局row_max
        if j > 0:
            T.TileOp.reduce_max(local_max, s_tile_ub, tmp_row_sub_max_exp_ub, config={'axis': 1})
            T.TileOp.barrier()

            # TRESHAPE
            # TRESHAPE
            T.TileOp.max(local_max, local_max, global_row_max_ub)
            T.TileOp.barrier()

            T.TileOp.sub(exp_max_ub, global_row_max_ub, local_max)
            T.TileOp.barrier()

            T.TileOp.muls(global_row_max_ub, local_max)
            T.TileOp.barrier()

            T.TileOp.broadcast(tmp_row_max_broadcast_ub, local_max)  # TROWEXPANDSUB_IMPL
            # broadcast后是8维，与被减数维度不一致，需在后端考虑其中计算时间差异
            T.TileOp.sub(tmp_row_sub_max_exp_ub, s_tile_ub, tmp_row_max_broadcast_ub)

            T.TileOp.muls(exp_max_ub, exp_max_ub)
            T.TileOp.muls(tmp_row_sub_max_exp_ub, tmp_row_sub_max_exp_ub)
            T.TileOp.exp(exp_max_ub, exp_max_ub)
            # TRESHAPE
            T.TileOp.exp(p_tile_ub, tmp_row_sub_max_exp_ub)
            # TRESHAPE
            # TCVT
            T.TileOp.barrier()

            # TRESHAPE
            T.TileOp.mul(global_row_sum_ub, exp_max_ub, global_row_sum_ub)
            T.TileOp.reduce_sum(local_sum, p_tile_ub, tmp_row_sub_max_exp_ub, config={'axis': 1})
            # TRESHAPE
            T.TileOp.barrier()

            T.TileOp.add(global_row_sum_ub, global_row_sum_ub, local_sum)
            T.TileOp.barrier()
        else:
            T.TileOp.reduce_max(global_row_max_ub, s_tile_ub, tmp_row_sub_max_exp_ub, config={'axis': 1})
            T.TileOp.barrier()

            T.TileOp.broadcast(tmp_row_max_broadcast_ub, global_row_max_ub)  # TROWEXPANDSUB_IMPL
            T.TileOp.sub(tmp_row_sub_max_exp_ub, s_tile_ub, tmp_row_max_broadcast_ub)

            T.TileOp.muls(tmp_row_sub_max_exp_ub, tmp_row_sub_max_exp_ub)  # scale
            T.TileOp.exp(p_tile_ub, tmp_row_sub_max_exp_ub)
            T.TileOp.barrier()

            T.TileOp.reduce_sum(global_row_sum_ub, p_tile_ub, tmp_row_sub_max_exp_ub, config={'axis': 1})
            # TRESHAPE
            # TRESHAPE
            # TCVT
            T.TileOp.barrier()

        # copy data to gm
        p_tile = p.view([s0_v, s1_c])
        T.TileOp.copy(p_tile, p_tile_ub)
        T.TileOp.copy(exp_max_gm, exp_max_ub)
        T.TileOp.copy(global_row_max_gm, global_row_max_ub)
        T.TileOp.copy(global_row_sum_gm, global_row_sum_ub)

        T.TileOp.barrier()

    # compute_pv PV乘 [s0, s1] * [s1, D1]
    # 分配L1/L0C空间
    p_tile_l1 = Tensor(shape=[s0_c, s1_c], dtype=DType.FP16, mem_loc=MemLoc.L1)
    v_tile_l1 = Tensor(shape=[s1_c, D1], dtype=DType.FP16, mem_loc=MemLoc.L1)
    o_tile_l0c = Tensor(shape=[s0_c, D1], dtype=DType.FP32, mem_loc=MemLoc.L0C)
    with T.Task(range=[s0_tiles_cube, s1_tiles_cube]) as ([i, j]):
        T.TileOp.copy(p_tile_l1, p.view([s0_c, s1_c]))
        T.TileOp.copy(v_tile_l1, v[j * s1_c:T.min((j + 1) * s1_c, S1), :])
        T.TileOp.barrier()
        T.TileOp.gemm(o_tile_l0c, p_tile_l1, v_tile_l1)
        T.TileOp.copy(output[i * s0_c:T.min((i + 1) * s0_c, S0), j * s1_c:T.min((j + 1) * s1_c, S1)], o_tile_l0c)
        T.TileOp.barrier()

    # global update compute_gu
    running_o_tile_ub = Tensor(shape=[s0_v, D1], dtype=DType.FP32, mem_loc=MemLoc.UB,
                               # NEXT start_addr=stride_bytes * 2 + s0_v * DType.FP32.size * 4 + s0_v * s1_c * DType.FP32.size
                               # NEXT        + s0_v * DType.FP32.size * vec_exp_max_buffer_num
                               # NEXT        + stride_bytes * vec_input_buffer_num)
                               start_addr=133376)
    o_tile_ub = Tensor(shape=[s0_v, D1], dtype=DType.FP32, mem_loc=MemLoc.UB,
                       # NEXT start_addr=stride_bytes * (j % vec_input_buffer_num))
                       start_addr=32768 * (j % 2))
    with T.Task(range=[s0_tiles_v, s1_tiles_v]) as ([i, j]):
        T.TileOp.copy(o_tile_ub, output[i * s0_v: T.min(i+1*s0_v, S0), :])
        T.TileOp.barrier()

        # 每行除第一个tile块外，更新output
        if j > 0:
            # TROWEXPANDMUL
            T.TileOp.broadcast(tmp_row_max_broadcast_ub, exp_max_ub)
            T.TileOp.mul(o_tile_ub, o_tile_ub, tmp_row_max_broadcast_ub)

            T.TileOp.add(running_o_tile_ub, running_o_tile_ub, o_tile_ub)

            # 每行最后一个tile块，除以分母
            if j == s1_tiles_v - 1:
                # o = o / l （向量 / 标量）
                T.TileOp.broadcast(tmp_row_max_broadcast_ub, global_row_sum_ub)
                T.TileOp.div(running_o_tile_ub, running_o_tile_ub, tmp_row_max_broadcast_ub)
                T.TileOp.copy(output[i * s0_v: T.min(i+1*s0_v, S0), :], running_o_tile_ub)
            T.TileOp.barrier()

