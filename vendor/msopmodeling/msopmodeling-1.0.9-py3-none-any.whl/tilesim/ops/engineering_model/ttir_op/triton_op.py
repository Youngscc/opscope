# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

import pathlib
from abc import ABC
from enum import Enum
from typing import Any, final

from core.common import OpType, BackendType, op_registry
from core.common.backend_config import BackendConfig, OptimConfig, OptimType, FitParamKey
from core.pipeline.basic_operator import BasicOperator
from core.pipeline.triton.ttir_to_eng_sim import ttir_to_eng_sim
from ops.theoretical_model.ttir_op.ttir_utils import TTIRExtraParam


class TTIRModelLevel(Enum):
    # 最极限的模型： 1. 不考虑小包搬运； 2. 不考虑同步带来的额外开销； 3. 流水紧密排布
    level1 = (1,
              {
                  'enable_small_package': False,
                  'enable_pipe_barrier': False,
                  'enable_pipe_babble': False
              }
              )
    # 工程模型： 1. 考虑小包搬运； 2. 考虑同步造成的CCE流水打断； 3. 流水排布考虑张量依赖关系
    level2 = (2,
              {
                  'enable_small_package': True,
                  'enable_pipe_barrier': True,
                  'enable_pipe_babble': True
              }
              )

    def __init__(self, level, config):
        self.level = level
        self.config = config

    @staticmethod
    def from_level(level: int):
        for m in TTIRModelLevel:
            if m.level == level:
                return m
        raise ValueError(f"invalid level: {level}")


@op_registry.register(OpType.TritonOp, BackendType.ENG)
class EngTriton(BasicOperator, ABC):
    extra_param_class = TTIRExtraParam

    @property
    def operator_dsl(self):
        return None

    @property
    def extra_param_format(self):
        return TTIRExtraParam

    def _input_check(self):
        pass

    @property
    @final
    def backend_type(self):
        pass

    @property
    @final
    def optim_type(self) -> OptimType:
        return OptimType.ADAPTOR_BYPASS_OPTIM

    def _set_optim_config(self) -> OptimConfig:
        return OptimConfig(OptimType.ADAPTOR_BYPASS_OPTIM)

    @property
    def eval_type(self):
        pass

    def _adjust_coeff(self, backend_config: BackendConfig):
        enable_fit = self.op_input.param is not None and self.op_input.param.enable_fit
        if not enable_fit:
            return
        fit_param_input = self.op_input.param.fit_param
        if not fit_param_input:
            return
        fit_param = backend_config.eval_config.fit_param

        if FitParamKey.BW_COEFF not in fit_param:
            fit_param[FitParamKey.BW_COEFF] = fit_param_input.get('bw_coeff', 1)

        if FitParamKey.COMP_COEFF not in fit_param:
            fit_param[FitParamKey.COMP_COEFF] = fit_param_input.get('comp_coeff', 1)

        if FitParamKey.SCALAR_TIME not in fit_param:
            fit_param[FitParamKey.SCALAR_TIME] = fit_param_input.get('scalar_time', 0)

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        return self.op_input.input_dict

    def run(self):
        param: TTIRExtraParam = self.op_input.param
        path = pathlib.Path(param.ttir_path)
        if not path.exists():
            raise ValueError(f"ttir path {path} is not exist")
        with open(path, "r") as f:
            mlir = f.read()

        # shape\精度等校验
        self._input_check()

        # 动态shape生成
        dynamic_shape_dict = self._dynamic_shape_assign()

        # 获取ttir后端层级
        config = TTIRModelLevel.from_level(param.model_level)

        # 调用后端
        optim_config = self._set_optim_config()
        eval_config = self._set_eval_config()
        backend_config = BackendConfig(
            accelerator=self.op_input.accelerator,
            aic_core_num=self.op_input.aic_core_num,
            aiv_core_num=self.op_input.aiv_core_num,
            layout_format=self.op_input.layout_format,
            eval_config=eval_config,
            optim_config=optim_config
        )
        enable_fit = self.op_input.param is not None and self.op_input.param.enable_fit
        if enable_fit:
            self._adjust_coeff(backend_config)
        eval_config.set_default_fit_param()
        res = ttir_to_eng_sim(mlir=mlir, dynamic_shape=dynamic_shape_dict, backend_config=backend_config, param=param)
        if enable_fit:
            res = self._post_fit(backend_config, res)
        return res