# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math
from typing import Any

from core.common import OpType, BackendType, MemLoc
from core.common import op_registry
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

dtype, m = T.define_symbol(2)


def theo_abs(src: Tensor(shape=[m], dtype=dtype, mem_loc=MemLoc.GM),
             dst: Tensor(shape=[m], dtype=dtype, mem_loc=MemLoc.GM)):
    """基础vec运算 - ABS"""
    dst_ub = Tensor(shape=[m], dtype=dtype, mem_loc=MemLoc.UB)
    T.TensorOp.abs(dst_ub, src)
    T.TensorOp.store(dst_ub)


@op_registry.register(OpType.Abs, BackendType.THEO)
class TheoAbs(TheoreticalOperator):
    operator_dsl = theo_abs

    def _input_check(self):
        if len(self.op_input.input_shapes) != 1:
            raise ValueError("[TheoOp.abs]: inputs len must be 1")

        if len(self.op_input.input_shapes) != len(self.op_input.output_shapes):
            raise ValueError("[TheoOp.abs]: input len must be equal to output len")

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        dynamic_shape = {
            'm': math.prod(self.op_input.input_shapes[0]),
            'dtype': self.op_input.input_dtypes[0],
        }
        return dynamic_shape