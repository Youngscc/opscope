# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math
from typing import Any

from core.common import OpType, BackendType, MemLoc
from core.common import op_registry
from core.common.backend_config import FitParamKey, BackendConfig
from core.pipeline.basic_operator import OperatorResult
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

m, dtype = T.define_symbol(2)


def add(src1: Tensor(shape=[m], dtype=dtype, mem_loc=MemLoc.GM),
        src2: Tensor(shape=[m], dtype=dtype, mem_loc=MemLoc.GM),
        dst: Tensor(shape=[m], dtype=dtype, mem_loc=MemLoc.GM)):
    """支持维度不对齐的张量加减"""
    dst_ub = Tensor(shape=[m], dtype=dtype, mem_loc=MemLoc.UB)
    T.TensorOp.add(dst_ub, src1, src2)
    T.TensorOp.store(dst_ub)


@op_registry.register(OpType.Add, BackendType.THEO)
class TheoAdd(TheoreticalOperator):

    @property
    def operator_dsl(self):
        return add

    def _input_check(self):
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        if len(input_shapes) == 1:
            input_shapes.append(input_shapes[0])

        if len(input_shapes) > 8:
            raise ValueError("[TheoOp.add]: inputs len must be <= 2")

        if len(output_shapes) != 1:
            raise ValueError("[TheoOp.add]: outputs len must be 1")

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        input_shapes = self.op_input.input_shapes
        total_dimension = math.prod(input_shapes[0])
        dynamic_shape = {
            'm': total_dimension,
            'dtype': self.op_input.input_dtypes[0],
        }

        return dynamic_shape

    def _adjust_coeff(self, backend_config: BackendConfig):
        total_size_per_core = math.prod(self.op_input.input_shapes[0]) / self.op_input.aiv_core_num
        fit_param = backend_config.eval_config.fit_param

        if FitParamKey.BW_COEFF not in fit_param:
            fit_param[FitParamKey.BW_COEFF] = 0.5

        if FitParamKey.COMP_COEFF not in fit_param:
            fit_param[FitParamKey.COMP_COEFF] = 0.8

        if FitParamKey.SCALAR_TIME not in fit_param:
            fit_param[FitParamKey.SCALAR_TIME] = 0.8 * math.ceil(total_size_per_core / 512)

    def _post_fit(self, backend_config: BackendConfig, op_result: OperatorResult) -> OperatorResult:
        elements_cnt = math.prod(self.op_input.input_shapes[0])
        cnt_per_core = elements_cnt / self.op_input.aiv_core_num
        if cnt_per_core < 8192:
            op_result.latency += backend_config.eval_config.fit_param.get(FitParamKey.SCALAR_TIME, 0.0)
        return op_result