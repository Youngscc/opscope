# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math
from typing import Any

from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.common import op_registry
from core.common import OpType, BackendType, DType, MemLoc
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

dtype = DType.FP32
mem_loc = MemLoc.GM
a = 128 * 128
b = 128 * 128
c = 128 * 128


def theo_mul(src1: Tensor(shape=[a], dtype=dtype, mem_loc=mem_loc),
             src2: Tensor(shape=[b], dtype=dtype, mem_loc=mem_loc),
             dst: Tensor(shape=[c], dtype=dtype, mem_loc=mem_loc)):
    """
    支持维度不对齐的张量加减，但仅支持二维，更高纬度的请转换成二维
    """

    src1_brcb = Tensor(shape=[c], dtype=dtype, mem_loc=MemLoc.UB)
    src2_brcb = Tensor(shape=[c], dtype=dtype, mem_loc=MemLoc.UB)
    dst_ub = Tensor(shape=[c], dtype=dtype, mem_loc=MemLoc.UB)

    T.TensorOp.broadcast(src1_brcb, src1)
    T.TensorOp.broadcast(src2_brcb, src2)

    T.TensorOp.mul(dst_ub, src1_brcb, src2_brcb)
    T.TensorOp.store(dst_ub)


@op_registry.register(OpType.Mul, BackendType.THEO)
@op_registry.register(OpType.Muls, BackendType.THEO)
class TheoMul(TheoreticalOperator):
    operator_dsl = theo_mul

    def _input_check(self):
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        if len(input_shapes) == 1:
            input_shapes.append(input_shapes[0])

        if len(input_shapes) > 2:
            raise ValueError("[TheoOp.mul]: inputs len must be <= 2")

        if len(output_shapes) != 1:
            raise ValueError("[TheoOp.mul]: outputs len must be 1")

        for input_shape in input_shapes:
            for i, shape in enumerate(input_shape):
                if shape != output_shapes[0][i] and shape != 1:
                    raise ValueError(f"[TheoOp.mul]: input dim{i} not match output")

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        if len(input_shapes) == 1:
            input_shapes.append([1, 1])
        dynamic_shape = {
            'a': math.prod(input_shapes[0]),
            'b': math.prod(input_shapes[1]),
            'c': math.prod(output_shapes[0]),
            'dtype': self.op_input.input_dtypes[0],
            'mem_loc': MemLoc.GM,
        }
        return dynamic_shape