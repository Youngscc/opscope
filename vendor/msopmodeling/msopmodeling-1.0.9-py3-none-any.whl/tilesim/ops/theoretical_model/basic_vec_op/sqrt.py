# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math
from typing import Any

from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.common import op_registry
from core.common import OpType, BackendType, DType, MemLoc
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

dtype = DType.FP32
mem_loc = MemLoc.GM

m = 128 * 128


def theo_sqrt(src: Tensor(shape=[m], dtype=dtype, mem_loc=mem_loc),
              dst: Tensor(shape=[m], dtype=dtype, mem_loc=mem_loc)):
    """
    基础vec运算 - sqrt
    Args:
            src:    输入tensor
            dst:    输出tensor

    Returns:

    """
    dst_ub = Tensor(shape=[m], dtype=dtype, mem_loc=MemLoc.UB)
    T.TensorOp.sqrt(dst_ub, src)
    T.TensorOp.store(dst_ub)


@op_registry.register(OpType.Sqrt, BackendType.THEO)
class TheoSqrt(TheoreticalOperator):
    operator_dsl = theo_sqrt

    def _input_check(self):
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        if len(input_shapes) != 1:
            raise ValueError("[TheoOp.sqrt]: inputs len must be 1")

        if len(output_shapes) != 1:
            raise ValueError("[TheoOp.sqrt]: outputs len must be 1")

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        dynamic_shape = {
            'm': math.prod(self.op_input.input_shapes[0]),
            'dtype': self.op_input.input_dtypes[0],
            'mem_loc': MemLoc.GM,
        }
        return dynamic_shape