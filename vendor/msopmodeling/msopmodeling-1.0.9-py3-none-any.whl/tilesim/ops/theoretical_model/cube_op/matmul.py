# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.common import OpType, BackendType, MemLoc
from core.common import op_registry
from core.common.backend_config import FitParamKey, BackendConfig
from core.pipeline.basic_operator import OperatorResult
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

m, n, k, d_type = T.define_symbol(4)


def matmul(src1: Tensor(shape=[m, k], dtype=d_type, mem_loc=MemLoc.GM),
           src2: Tensor(shape=[k, n], dtype=d_type, mem_loc=MemLoc.GM),
           output: Tensor(shape=[m, n], dtype=d_type, mem_loc=MemLoc.GM)):
    """matmul算子dsl实现"""
    output_l0c = Tensor(shape=[m, n], dtype=d_type, mem_loc=MemLoc.L0C)
    T.TensorOp.gemm(output_l0c, src1, src2)
    T.TensorOp.store(output_l0c)


@op_registry.register([OpType.MatMul, OpType.AddMM], BackendType.THEO)
class TheoMatMul(TheoreticalOperator):
    operator_dsl = matmul

    def _adjust_coeff(self, backend_config: BackendConfig):
        """通过设定拟合系数，对不同的系数进行拟合"""
        enable_fit = self.op_input.param is not None and self.op_input.param.enable_fit
        if not enable_fit:
            return

        fit_param = backend_config.eval_config.fit_param

        if FitParamKey.BW_COEFF not in fit_param:
            fit_param[FitParamKey.BW_COEFF] = 0.5

        if FitParamKey.COMP_COEFF not in fit_param:
            fit_param[FitParamKey.COMP_COEFF] = 0.8

        if FitParamKey.SCALAR_TIME not in fit_param:
            fit_param[FitParamKey.SCALAR_TIME] = 10

    def _input_check(self):
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        if len(input_shapes) < 2:
            raise ValueError("[TheoOp.matmul]: inputs at least 2 inputs")

        ma_size, ka_size = input_shapes[0]
        kb_size, nb_size = input_shapes[1]
        mc_size, nc_size = output_shapes[0]

        # B矩阵没有转置
        if ka_size != kb_size:
            nb_size, kb_size = input_shapes[1]

        if ma_size != mc_size:
            raise ValueError("[TheoOp.matmul]: m dim do not match")
        if ka_size != kb_size:
            raise ValueError("[TheoOp.matmul]: k dim do not match")
        if nb_size != nc_size:
            raise ValueError("[TheoOp.matmul]: n dim do not match")

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        ma_size, ka_size = input_shapes[0]
        kb_size, nb_size = input_shapes[1]

        # B矩阵没有转置
        if ka_size != kb_size and nb_size == ka_size:
            nb_size, kb_size = input_shapes[1]

        dynamic_shape = {
            'm': ma_size,
            'k': ka_size,
            'n': nb_size,
            'd_type': self.op_input.input_dtypes[0]
        }

        return dynamic_shape

    def _post_fit(self, backend_config: BackendConfig, op_result: OperatorResult) -> OperatorResult:
        rows = self.op_input.input_shapes[0][0]
        if rows < 16:
            op_result.latency += 10
        return op_result