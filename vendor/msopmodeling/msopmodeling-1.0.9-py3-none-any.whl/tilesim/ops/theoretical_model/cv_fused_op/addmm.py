# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.common import op_registry
from core.common import OpType, BackendType, DType, MemLoc
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

m, k, n = [128] * 3
d_type = DType.FP32


def theo_addmm(
        input1: Tensor(shape=[m, k], dtype=d_type, mem_loc=MemLoc.GM),
        input2: Tensor(shape=[k, n], dtype=d_type, mem_loc=MemLoc.GM),
        input_bias: Tensor(shape=[m, n], dtype=d_type, mem_loc=MemLoc.GM),
        output: Tensor(shape=[m, n], dtype=d_type, mem_loc=MemLoc.GM)
):
    """
    addmm DSL 实现
    Args:
        input1:
        input2:
        input_bias:
        output:

    Returns:

    """
    temp_value = Tensor(shape=[m, n], dtype=d_type, mem_loc=MemLoc.UB)
    output_ub = Tensor(shape=[m, n], dtype=d_type, mem_loc=MemLoc.UB)

    T.TensorOp.gemm(temp_value, input1, input2)
    T.TensorOp.add(output_ub, temp_value, input_bias)
    T.TensorOp.store(output_ub)


@op_registry.register(OpType.AddMM, BackendType.THEO)
class TheoAddMm(TheoreticalOperator):
    operator_dsl = theo_addmm

    def _input_check(self):
        """3个输入分别为self、mat1、mat2。计算公式：βself + α(mat1@mat2)"""
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        if len(input_shapes) != 3:
            raise ValueError("[TheoOp.addMm]: inputs len must be 3")

        ma_size, ka_size = input_shapes[1]
        kb_size, nb_size = input_shapes[2]
        mc_size, nc_size = output_shapes[0]

        if ka_size != kb_size:
            nb_size, kb_size = input_shapes[2]

        if ma_size != mc_size:
            raise ValueError("[TheoOp.addMm]: m dim do not match")
        if ka_size != kb_size:
            raise ValueError("[TheoOp.addMm]: k dim do not match")
        if nb_size != nc_size:
            raise ValueError("[TheoOp.addMm]: n dim do not match")

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        ma_size, ka_size = input_shapes[1]
        kb_size, nb_size = input_shapes[2]

        # B矩阵没有转置
        if ka_size != kb_size and nb_size == ka_size:
            nb_size, kb_size = input_shapes[2]

        dynamic_shape = {
            'm': ma_size,
            'k': ka_size,
            'n': nb_size,
            'd_type': self.op_input.input_dtypes[0]
        }
        return dynamic_shape