# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from dataclasses import dataclass
from typing import Any

from core.common import OpType, BackendType, MemLoc, DType
from core.common import op_registry
from core.common.backend_config import BackendConfig, FitParamKey
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor
from core.pipeline.basic_operator import OperatorExtraParam, OperatorInput
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator


@dataclass
class CompressorExtraParam(OperatorExtraParam):
    # 压缩率
    compress_ratio: int = None
    # 是否overlap ： 1/2
    coff: int = None
    # head_dim
    head_dim: int = None
    # 位置编码dim
    rope_dim: int = None
    # 当前decode的长度
    cur_seq_len: int = None


S, H, D, COFF_D, CUTOFF, SC, R, COFF_R, HALF_DR, DR, should_compress, is_prefill = T.define_symbol(12)


# 不包含B轴
def compressor(x: Tensor(shape=[S, H], dtype=DType.FP16, mem_loc=MemLoc.GM),
               W_kv: Tensor(shape=[H, COFF_D], dtype=DType.FP16, mem_loc=MemLoc.GM),
               W_gate: Tensor(shape=[H, COFF_D], dtype=DType.FP16, mem_loc=MemLoc.GM),
               ape: Tensor(shape=[R, COFF_D], dtype=DType.FP32, mem_loc=MemLoc.GM),
               eps: Tensor(shape=[1], dtype=DType.FP32, mem_loc=MemLoc.UB),
               weight: Tensor(shape=[D], dtype=DType.FP32, mem_loc=MemLoc.UB),
               ):
    """FA 算子DSL实现"""
    # 计算 kv = x * w_kv
    kv = Tensor(shape=[S, COFF_D], dtype=DType.FP32, mem_loc=MemLoc.GM)
    T.TensorOp.gemm(kv, x, W_kv)

    # 计算 score = x * w_gate
    score = Tensor(shape=[S, COFF_D], dtype=DType.FP32, mem_loc=MemLoc.GM)
    T.TensorOp.gemm(score, x, W_gate)
    # 计算 score = score + brcb(ape) --> 可能不需要brcb，这里先不写
    T.TensorOp.add(score, score, ape)

    # decode阶段
    if not is_prefill:
        score_cutoff = Tensor(shape=[1, COFF_D], dtype=DType.FP32, mem_loc=MemLoc.GM)
        score_cutoff_ub = Tensor(shape=[1, COFF_D], dtype=DType.FP32, mem_loc=MemLoc.UB)
        kv_cutoff = Tensor(shape=[1, COFF_D], dtype=DType.FP32, mem_loc=MemLoc.GM)
        kv_cutoff_ub = Tensor(shape=[1, COFF_D], dtype=DType.FP32, mem_loc=MemLoc.UB)
        # overlap
        if should_compress and COFF_D != D:
            T.TensorOp.null_op(score_cutoff_ub, score)

    # prefill阶段
    else:
        # 提取阶段部分，这里应该是 R, COFF_D 的shape，后面转换成的 COFF_R, D，为了方便shape统一，先转换成下面的格式了
        score_cutoff = Tensor(shape=[SC, COFF_R, D], dtype=DType.FP32, mem_loc=MemLoc.GM)
        score_cutoff_ub = Tensor(shape=[SC, COFF_R, D], dtype=DType.FP32, mem_loc=MemLoc.UB)
        kv_cutoff = Tensor(shape=[SC, COFF_R, D], dtype=DType.FP32, mem_loc=MemLoc.GM)
        kv_cutoff_ub = Tensor(shape=[SC, COFF_R, D], dtype=DType.FP32, mem_loc=MemLoc.UB)
        # overlap_transfer
        if COFF_D == D:
            T.TensorOp.null_op(kv_cutoff_ub, kv_cutoff)
            T.TensorOp.null_op(score_cutoff_ub, score_cutoff)

    if is_prefill or should_compress:
        # softmax的计算
        reduce_score = Tensor(shape=[SC, 1, D], dtype=DType.FP32, mem_loc=MemLoc.UB)
        T.TensorOp.reduce_max(reduce_score, score_cutoff)
        score_brcb = Tensor(shape=[SC, COFF_R, D], dtype=DType.FP32, mem_loc=MemLoc.UB)
        T.TensorOp.broadcast(score_brcb, reduce_score)
        T.TensorOp.sub(score_cutoff_ub, score_cutoff_ub, score_brcb)
        T.TensorOp.exp(score_cutoff_ub, score_cutoff_ub)
        T.TensorOp.reduce_sum(reduce_score, score_cutoff_ub)
        T.TensorOp.broadcast(score_brcb, reduce_score)
        T.TensorOp.div(score_cutoff_ub, score_cutoff_ub, score_brcb)

    if should_compress:
        # score_cutoff * kv_cutoff的计算
        T.TensorOp.mul(kv_cutoff_ub, kv_cutoff, score_cutoff)
        # 按照coff*r轴求和
        kv_reduce = Tensor(shape=[SC, D], dtype=DType.FP32, mem_loc=MemLoc.UB)
        T.TensorOp.reduce_sum(kv_reduce, kv_cutoff_ub)

        # rms norm计算
        T.TensorOp.mul(kv_reduce, kv_reduce, kv_reduce)
        kv_d_reduce = Tensor(shape=[SC, 1], dtype=DType.FP32, mem_loc=MemLoc.UB)
        T.TensorOp.reduce_sum(kv_d_reduce, kv_reduce)
        one_div_n = Tensor(shape=[1], dtype=DType.FP32, mem_loc=MemLoc.UB)
        T.TensorOp.muls(kv_d_reduce, kv_d_reduce, one_div_n)
        T.TensorOp.adds(kv_d_reduce, kv_d_reduce, eps)

        T.TensorOp.sqrt(kv_d_reduce, kv_d_reduce)
        ones = Tensor(shape=[1], dtype=DType.FP32, mem_loc=MemLoc.UB)
        T.TensorOp.div(kv_d_reduce, ones, kv_d_reduce)
        denominator = Tensor(shape=[SC, D], dtype=DType.FP32, mem_loc=MemLoc.UB)
        T.TensorOp.broadcast(denominator, kv_d_reduce)

        T.TensorOp.mul(kv_reduce, denominator, kv_reduce)
        T.TensorOp.mul(kv_reduce, kv_reduce, weight)

        # apply_rope计算
        kv_real = Tensor(shape=[SC, HALF_DR], dtype=DType.FP32, mem_loc=MemLoc.UB)
        kv_imag = Tensor(shape=[SC, HALF_DR], dtype=DType.FP32, mem_loc=MemLoc.UB)
        freq_sin = Tensor(shape=[SC, HALF_DR], dtype=DType.FP32, mem_loc=MemLoc.GM)
        freq_cos = Tensor(shape=[SC, HALF_DR], dtype=DType.FP32, mem_loc=MemLoc.GM)
        out_real = Tensor(shape=[SC, HALF_DR], dtype=DType.FP32, mem_loc=MemLoc.UB)
        out_imag = Tensor(shape=[SC, HALF_DR], dtype=DType.FP32, mem_loc=MemLoc.UB)
        out_tmp = Tensor(shape=[SC, HALF_DR], dtype=DType.FP32, mem_loc=MemLoc.UB)

        T.TensorOp.mul(out_real, kv_real, freq_cos)
        T.TensorOp.mul(out_tmp, kv_imag, freq_sin)
        T.TensorOp.sub(out_real, out_real, out_tmp)

        T.TensorOp.mul(out_imag, kv_real, freq_sin)
        T.TensorOp.mul(out_tmp, kv_imag, freq_cos)
        T.TensorOp.add(out_imag, out_imag, out_tmp)

        T.TensorOp.store(kv_reduce)

    T.TensorOp.store(kv_cutoff_ub)
    T.TensorOp.store(score_cutoff_ub)


def _parse_shape_zhanlu_format(op_input: OperatorInput) -> dict:
    extra_param: CompressorExtraParam = op_input.param
    r = extra_param.compress_ratio
    coff = extra_param.coff
    d = extra_param.head_dim
    dr = extra_param.rope_dim
    cur_seq_len = extra_param.cur_seq_len
    b, s, h = op_input.input_shapes[0]
    sc = (cur_seq_len + 1) // r
    should_comp = (cur_seq_len + 1) % r == 0

    dynamic_shape = {
        'S': s * b,
        'H': h,
        'COFF_D': coff * d,
        'CUTOFF': sc * r,
        'COFF_R': coff * r,
        'D': d,
        'R': r,
        'HALF_DR': dr // 2,
        'DR': dr,
        'SC': sc,
        'should_compress': should_comp,
        'is_prefill': s > 1
    }
    return dynamic_shape


def _parse_shape_prof_format(op_input: OperatorInput) -> dict:
    input_x, w_kv, w_gate, kv_state, score_state = op_input.input_shapes[:5]
    if len(op_input.output_shapes) == 3:
        comp_kv, _, _ = op_input.output_shapes
    else:
        comp_kv = None
    if len(input_x) == 2:
        s = 1
        b, h = input_x
    else:
        b, s, h = input_x

    coff_d, _ = w_kv
    mbs, coff_r, _ = kv_state

    extra_param: CompressorExtraParam = op_input.param

    if extra_param.coff is not None:
        r = 4 if extra_param.coff == 2 else 128
        coff = extra_param.coff
    elif extra_param.compress_ratio is not None:
        r = extra_param.compress_ratio
        coff = 2 if r == 4 else 1
    else:
        raise ValueError('compressor param must contain coff or cmp_ratio')
    d = coff_d / coff
    sc = coff_r
    dr = 64

    should_comp = comp_kv is None or len(comp_kv) == 0

    dynamic_shape = {
        'S': s * b,
        'H': h,
        'COFF_D': coff_d,
        'CUTOFF': sc * r,
        'COFF_R': coff_r,
        'D': d,
        'R': r,
        'HALF_DR': dr // 2,
        'DR': dr,
        'SC': sc,
        'should_compress': should_comp,
        'is_prefill': s > 1
    }
    return dynamic_shape


@op_registry.register(OpType.Compressor, BackendType.THEO)
class TheoCompressor(TheoreticalOperator):
    operator_dsl = compressor
    extra_param_class = CompressorExtraParam

    def _input_check(self):
        pass

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        shape_format = self.op_input.layout_format
        if shape_format == 'prof':
            dynamic_shape = _parse_shape_prof_format(self.op_input)
        else:
            dynamic_shape = _parse_shape_zhanlu_format(self.op_input)
        return dynamic_shape

    def _adjust_coeff(self, backend_config: BackendConfig):
        fit_param = backend_config.eval_config.fit_param

        if FitParamKey.BW_COEFF not in fit_param:
            fit_param[FitParamKey.BW_COEFF] = 0.03
        if FitParamKey.COMP_COEFF not in fit_param:
            fit_param[FitParamKey.COMP_COEFF] = 0.3

        if FitParamKey.SCALAR_TIME not in fit_param:
            fit_param[FitParamKey.SCALAR_TIME] = 0