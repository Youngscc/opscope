# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.common import OpType, BackendType, MemLoc
from core.common import op_registry
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

S1, S2, D1, D2, dtype = T.define_symbol(5)


def flash_attention(q: Tensor(shape=[S1, D1], dtype=dtype, mem_loc=MemLoc.GM),
                    k: Tensor(shape=[D1, S2], dtype=dtype, mem_loc=MemLoc.GM),
                    v: Tensor(shape=[S2, D2], dtype=dtype, mem_loc=MemLoc.GM),
                    out: Tensor(shape=[S1, D2], dtype=dtype, mem_loc=MemLoc.GM)
                    ):
    """FA 算子DSL实现"""
    qk_l0c = Tensor(shape=[S1, S2], dtype=dtype, mem_loc=MemLoc.L0C)
    qk_ub = Tensor(shape=[S1, S2], dtype=dtype, mem_loc=MemLoc.UB)
    reduce_result = Tensor(shape=[S1, 1], dtype=dtype, mem_loc=MemLoc.UB)
    out_l0c = Tensor(shape=[S1, D2], dtype=dtype, mem_loc=MemLoc.L0C)

    T.TensorOp.gemm(qk_l0c, q, k)
    T.TensorOp.mul(qk_ub, qk_l0c, qk_l0c)
    T.TensorOp.reduce_max(reduce_result, qk_ub)
    T.TensorOp.broadcast(qk_ub, reduce_result)
    T.TensorOp.sub(qk_ub, qk_ub, qk_ub)
    T.TensorOp.exp(qk_ub, qk_ub)
    T.TensorOp.reduce_sum(reduce_result, qk_ub)
    T.TensorOp.broadcast(qk_ub, reduce_result)
    T.TensorOp.div(qk_ub, qk_ub, qk_ub)
    T.TensorOp.gemm(out_l0c, qk_ub, v)
    T.TensorOp.store(out_l0c)


@op_registry.register(OpType.FlashAttention, BackendType.THEO)
class TheoFlashAttention(TheoreticalOperator):
    operator_dsl = flash_attention

    def _input_check(self):
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes

        if len(input_shapes) != 3:
            raise ValueError(f"[TheoOp.{TheoFlashAttention.op_name}]: inputs len must be 3")
        if len(output_shapes) != 1:
            raise ValueError(f"[TheoOp.{TheoFlashAttention.op_name}]: outputs len must be 1")

        # S1轴相等
        if input_shapes[0][0] != output_shapes[0][0]:
            raise ValueError(f"[TheoOp.{TheoFlashAttention.op_name}]: S1 must be equal")

        # S2轴相等
        if input_shapes[1][1] != input_shapes[2][0]:
            raise ValueError(f"[TheoOp.{TheoFlashAttention.op_name}]: S2 must be equal")

        # D1轴相等
        if input_shapes[0][1] != input_shapes[1][0]:
            raise ValueError(f"[TheoOp.{TheoFlashAttention.op_name}]: D1 must be equal")

        # D2轴相等
        if input_shapes[2][1] != output_shapes[0][1]:
            raise ValueError(f"[TheoOp.{TheoFlashAttention.op_name}]: D2 must be equal")

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        dynamic_shape = {
            'S1': self.op_input.input_shapes[0][0],
            'S2': self.op_input.input_shapes[1][1],
            'D1': self.op_input.input_shapes[0][1],
            'D2': self.op_input.input_shapes[2][1],
            'dtype': self.op_input.input_dtypes[0],
        }
        return dynamic_shape