# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.common import OpType, BackendType, DType, MemLoc
from core.common import op_registry
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

S1, S2, D1, D2 = 1024, 1024, 128, 80

dtype = DType.FP16
mem_loc = MemLoc.GM


def flash_attention_grad(dy: Tensor(shape=[S1, D2], dtype=dtype, mem_loc=mem_loc),
                         attn: Tensor(shape=[S1, D2], dtype=dtype, mem_loc=mem_loc),
                         q: Tensor(shape=[S1, D1], dtype=dtype, mem_loc=mem_loc),
                         k: Tensor(shape=[D1, S2], dtype=dtype, mem_loc=mem_loc),
                         v: Tensor(shape=[D2, S2], dtype=dtype, mem_loc=mem_loc),
                         ):
    """FA 算子DSL实现"""
    # NEXT - 部分写法有问题，需要校验

    # 1） dpt = dy * V
    dpt = Tensor(shape=[S1, S2], dtype=DType.FP32, mem_loc=mem_loc)
    T.TensorOp.gemm(dpt, dy, v)

    # 2） softmax grad stage
    attn_fp32 = Tensor(shape=[S1, D2], dtype=DType.FP32, mem_loc=mem_loc)
    attn_sum = Tensor(shape=[S1, 1], dtype=DType.FP32, mem_loc=mem_loc)
    T.TensorOp.cast(attn_fp32, attn)
    T.TensorOp.mul(attn_fp32, attn_fp32, attn_fp32)
    T.TensorOp.reduce_sum(attn_sum, attn_fp32, config={'reduce_axis': 1})
    T.TensorOp.broadcast(attn_fp32, attn_sum)

    # 3） qk = q * k
    qk = Tensor(shape=[S1, S2], dtype=DType.FP32, mem_loc=mem_loc)
    T.TensorOp.gemm(qk, q, k)

    # 4） softmax
    ds = Tensor(shape=[S1, S2], dtype=DType.FP16, mem_loc=mem_loc)
    T.TensorOp.sub(qk, qk, qk)
    T.TensorOp.exp(qk, qk)
    T.TensorOp.div(qk, qk, qk)
    T.TensorOp.sub(qk, qk, qk)
    T.TensorOp.mul(qk, qk, qk)
    T.TensorOp.cast(ds, qk)

    # 5） dq = ds*k
    dq = Tensor(shape=[S1, D1], dtype=DType.FP32, mem_loc=mem_loc)
    T.TensorOp.gemm(dq, ds, k)

    # 6） sum dq
    dq_sum = Tensor(shape=[S1, D1], dtype=DType.FP16, mem_loc=mem_loc)
    T.TensorOp.muls(dq, dq)
    T.TensorOp.cast(dq_sum, dq)

    # 7） dk = ds*q
    dk = Tensor(shape=[S2, D1], dtype=DType.FP32, mem_loc=mem_loc)
    T.TensorOp.gemm(dk, ds, q)

    # 8） sum dk
    dk_sum = Tensor(shape=[S2, D1], dtype=DType.FP16, mem_loc=mem_loc)
    T.TensorOp.muls(dk, dk)
    T.TensorOp.cast(dk_sum, dk)

    # 9） dv = p * dy
    dv = Tensor(shape=[S2, D2], dtype=DType.FP32, mem_loc=mem_loc)
    T.TensorOp.gemm(dv, ds, dy)

    # 10） sum dv
    dv_sum = Tensor(shape=[S2, D2], dtype=DType.FP16, mem_loc=mem_loc)
    T.TensorOp.cast(dv_sum, dv)

    T.TensorOp.store(dv_sum)


@op_registry.register(OpType.FlashAttentionGrad, BackendType.THEO)
class TheoFlashAttentionGrad(TheoreticalOperator):
    operator_dsl = flash_attention_grad

    def _input_check(self):
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes

        q, k, v = input_shapes
        out = output_shapes[0]
        if q[1] != k[0] or k[1] != v[0]:
            raise ValueError("input shape D not match")
        if q[0] != out[0]:
            raise ValueError("input shape S1 not match")
        if k[1] != v[0]:
            raise ValueError("input shape S2 not match")

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        dynamic_shape = {
            'S1': self.op_input.input_shapes[0][0],
            'S2': self.op_input.input_shapes[1][1],
            'D1': self.op_input.input_shapes[0][1],
            'D2': self.op_input.input_shapes[2][1],
            'dtype': self.op_input.input_dtypes[0],
            'mem_loc': MemLoc.GM,
        }
        return dynamic_shape


