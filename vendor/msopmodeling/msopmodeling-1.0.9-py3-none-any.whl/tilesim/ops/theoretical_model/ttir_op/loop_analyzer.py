import logging
import math
import re
from typing import Dict, Any, Union, List, Set, Optional
from collections import defaultdict
from ops.theoretical_model.ttir_op.ttir_utils import init_logger, set_log_level

logger = init_logger()


class MLIRLoopFormula:
    """表示MLIR循环次数的公式，可调用对象"""

    def __init__(self, formula_str: str, constant_value: Optional[int] = None):
        """
        初始化循环公式
        
        Args:
            formula_str: 公式字符串
            constant_value: 如果是常数，直接存储常数值
        """
        self.formula_str = formula_str
        self.constant_value = constant_value
        self.is_constant = constant_value is not None

    def __call__(self, **kwargs) -> int:
        """调用公式，传入参数，返回循环次数"""
        if self.is_constant:
            return self.constant_value

        # 将参数名从arg0, arg1等转换为%arg0, %arg1
        arg_dict = {}
        for key, value in kwargs.items():
            if key.startswith('arg'):
                arg_dict[f'%{key}'] = value
            elif key.startswith('%'):
                arg_dict[key] = value

        # 替换公式中的参数，使用正则表达式避免部分替换
        formula = self.formula_str
        for arg_name, arg_value in arg_dict.items():
            # 使用正则表达式确保只替换完整的变量名
            pattern = r'(?<!\w)' + re.escape(arg_name) + r'(?!\w)'
            formula = re.sub(pattern, str(arg_value), formula)

        # 计算表达式
        try:
            def min_func(a, b):
                return min(a, b)

            def max_func(a, b):
                return max(a, b)

            # 使用安全的eval
            result = eval(formula, {"__builtins__": {}}, {"min": min_func, "max": max_func})
            return int(result)
        except Exception as e:
            raise ValueError(f"计算公式时出错: {formula}, 错误: {e}") from e

    def __str__(self) -> str:
        """返回公式字符串表示"""
        if self.is_constant:
            return str(self.constant_value)
        return self.formula_str

    def __repr__(self) -> str:
        """返回repr表示"""
        if self.is_constant:
            return f"MLIRLoopFormula(constant={self.constant_value})"
        return f"MLIRLoopFormula(formula='{self.formula_str}')"


class MLIRLoopAnalyzerWithLambda:
    def __init__(self, mlir_code: str, core_num: int):
        self.mlir_code = mlir_code
        self.core_num = core_num
        self.lines = mlir_code.strip().split('\n')
        self.constants: Dict[str, int] = {}
        self.variables: Dict[str, Dict[str, Any]] = {}
        self.loop_info: List[Dict[str, Any]] = []
        self.function_args: Set[str] = set()
        self.program_id_vars: Set[str] = set()
        self.num_programs_vars: Set[str] = set()
        self.nesting_tree = defaultdict(list)

    def parse_function_definition(self):
        """解析函数定义和参数"""
        for line in self.lines:
            line = line.strip()
            if not line:
                continue

            # 匹配函数定义
            func_pattern = r'tt\.func.*@\w+\((.*?)\)'
            match = re.search(func_pattern, line)
            if match:
                args_part = match.group(1)
                # 提取所有%argX参数
                args = re.findall(r'(%\w+)(?=:)', args_part)
                self.function_args = set(args)
                break

    def parse_constants_and_variables(self):
        """解析常量和变量定义"""
        for i, line in enumerate(self.lines):
            line = line.strip()
            if not line:
                continue

            # 改进的整数常量解析模式
            # 匹配: %c1535_i32 = arith.constant 1535 : i32 loc(#loc1)
            int_const_pattern = r'^(\%\w+)\s*=\s*arith\.constant\s+(-?\d+)(?:\s*:\s*\w+)?(?:\s*loc\([^)]*\))?\s*$'
            match = re.search(int_const_pattern, line)
            if match:
                const_name = match.group(1)
                const_value_str = match.group(2)
                # 确保是纯数字
                if const_value_str.strip().lstrip('-').isdigit():
                    const_value = int(const_value_str)
                    self.constants[const_name] = const_value
                    continue

            # 尝试匹配没有位置信息的常量定义
            int_const_pattern2 = r'^(\%\w+)\s*=\s*arith\.constant\s+(-?\d+)(?:\s*:\s*\w+)?\s*$'
            match = re.search(int_const_pattern2, line)
            if match and match.group(1) not in self.constants:
                const_name = match.group(1)
                const_value_str = match.group(2)
                if const_value_str.strip().lstrip('-').isdigit():
                    const_value = int(const_value_str)
                    self.constants[const_name] = const_value
                    continue

    def parse_variables(self):
        """解析变量定义和计算"""
        for i, line in enumerate(self.lines):
            line = line.strip()
            if not line or 'arith.constant' in line or '=' not in line:
                continue

            # 匹配变量定义
            var_pattern = r'^\s*(\%\w+)\s*=\s*([^:]+)(?::\s*(.+))?'
            match = re.search(var_pattern, line)
            if not match:
                continue
            var_name = match.group(1)
            expr_part = match.group(2).strip()
            type_part = match.group(3).strip() if match.group(3) else ""

            # 跳过包含loc的行
            if 'loc(' in expr_part and '#' in expr_part:
                continue

            # 提取操作符
            op_match = re.search(r'^([a-zA-Z.]+)', expr_part)
            op = op_match.group(1) if op_match else "unknown"

            # 提取操作数
            operands = []
            for operand in re.findall(r'\%\w+', expr_part):
                if operand.startswith('%') and operand not in operands:
                    operands.append(operand)

            # 检查是否是tt.get_program_id
            if 'tt.get_program_id' in expr_part:
                self.program_id_vars.add(var_name)
                op = 'tt.get_program_id'

            # 检查是否是tt.get_num_programs
            if 'tt.get_num_programs' in expr_part:
                self.num_programs_vars.add(var_name)
                op = 'tt.get_num_programs'

            self.variables[var_name] = {
                'expression': expr_part,
                'type': type_part,
                'operator': op,
                'operands': operands
            }

    def _find_matching_right_brace(self, index):
        """输入左括号对应的行号，返回对应的右括号行，行号从0开始计数"""
        # 行号合法性校验
        line_num = len(self.lines)
        start_line = index
        if start_line < 0 or start_line >= line_num:
            return None

        # 校验当前行是否包含左括号
        current_line = self.lines[start_line].strip()
        if '{' not in current_line:
            return None

        brace_count = 0
        for idx in range(start_line, line_num):
            line_content = self.lines[idx]
            for char in line_content:
                if char == '{':
                    brace_count += 1
                elif char == '}':
                    brace_count -= 1

            if brace_count == 0:
                return idx
        return None

    def add_loop_children(self):
        """
        为每个loop字典添加'child'键，值为子节点variable组成的列表

        Args:
            loop_list: 包含所有loop实例的列表，每个loop需有'start_line'和'parent'键

        Returns:
            list[dict]: 补充了'child'键的loop列表
        """
        # 步骤1：构建父节点 -> 子节点variable的映射字典
        parent_to_children = {}
        for loop in self.loop_info:
            parent_lines = loop.get('parent')
            current_loop_line = loop.get('start_line')
            if current_loop_line is None:
                continue

            # 仅处理有父节点的子节点
            for parent_line in parent_lines:
                if parent_line is not None:
                    parent_to_children.setdefault(parent_line, []).append(current_loop_line)

        # 步骤2：为每个loop添加child字段
        for loop in self.loop_info:
            current_loop_line = loop.get('start_line')
            # 无子女则赋值为空列表
            loop['child'] = parent_to_children.get(current_loop_line, [])

    def analyze_loop_structure(self):
        """分析循环结构，识别嵌套关系"""
        loop_stack = []  # 用于跟踪循环嵌套
        depth = 0

        for i, line in enumerate(self.lines):
            line = line.strip()

            # 检查是否是循环开始
            if 'scf.for' in line:
                depth += 1
                # 解析循环定义
                loop_pattern = r'scf\.for\s+(%\w+)\s*=\s*(%\w+)\s+to\s+(%\w+)\s+step\s+(%\w+)'
                match = re.search(loop_pattern, line)

                if not match:
                    continue
                loop_var = match.group(1)
                start_expr = match.group(2)
                end_expr = match.group(3)
                step_expr = match.group(4)
                end_line = self._find_matching_right_brace(i)

                # 确定父循环
                parent_loop = [loop['start_line'] for loop in loop_stack]
                return_value = re.findall(r'%[\w]+', line)[0] if line.startswith('%') else None
                yield_data = re.findall(r'%[\w]+', self.lines[end_line - 1]) if return_value else None

                loop_data = {
                    'variable': loop_var,
                    'return_value': return_value,
                    'yield_data': yield_data,
                    'start_expr': start_expr,
                    'end_expr': end_expr,
                    'step_expr': step_expr,
                    'start_line': i,
                    'end_line': end_line,
                    'depth': depth,
                    'parent': parent_loop
                }

                # 添加到循环列表
                self.loop_info.append(loop_data)

                # 更新嵌套树
                for loop in parent_loop:
                    self.nesting_tree[loop].append(i)

                # 添加到循环栈
                loop_stack.append(loop_data)

            # 检查是否离开当前循环
            while loop_stack and i > loop_stack[-1]['end_line']:
                loop_stack.pop()
                depth -= 1
        self.add_loop_children()

    def evaluate_expression(self, expr: str) -> Union[int, str]:
        """计算表达式的值，如果能计算则返回整数，否则返回表达式字符串"""
        # 如果是常量
        if expr in self.constants:
            return self.constants[expr]

        # 如果是数字
        if expr.lstrip('-').isdigit():
            return int(expr)

        # 如果是输入参数
        if expr in self.function_args:
            return expr

        # 如果是变量
        if expr in self.variables:
            var_info = self.variables[expr]
            op = var_info['operator']
            operands = var_info['operands']

            # 处理程序ID变量
            if expr in self.program_id_vars:
                return 0

            if expr in self.num_programs_vars:
                return self.core_num

            if not operands:
                return expr

            # 计算操作数的值
            op_values = []
            for operand in operands:
                op_value = self.evaluate_expression(operand)
                op_values.append(op_value)

            # 如果所有操作数都是整数，尝试计算
            all_ints = all(isinstance(v, int) for v in op_values)
            if all_ints:
                op_handlers = {
                    'arith.muli': lambda x: x[0] * x[1],
                    'arith.addi': lambda x: x[0] + x[1],
                    'arith.subi': lambda x: x[0] - x[1],
                    'arith.divsi': lambda x: x[0] // x[1] if x[1] != 0 else None,
                    'arith.remsi': lambda x: x[0] % x[1] if x[1] != 0 else None,
                    'arith.minsi': lambda x: min(x[0], x[1]),
                    'arith.maxsi': lambda x: max(x[0], x[1]),
                    'arith.extsi': lambda x: x[0],  # 符号扩展，值不变
                    'arith.extui': lambda x: x[0],  # 零扩展，值不变
                }
                handler = op_handlers.get(op)
                if handler is not None and len(op_values) >= 2 and handler(op_values) is not None:
                    return handler(op_values)
        return expr

    def get_expression_formula(self, expr: str, visited: Set[str] = None) -> str:
        """获取表达式的计算公式"""
        if visited is None:
            visited = set()

        if expr in visited:
            return expr

        visited.add(expr)

        # 先尝试计算表达式的值
        evaluated = self.evaluate_expression(expr)
        if isinstance(evaluated, int):
            return str(evaluated)

        # 如果是输入参数
        if expr in self.function_args:
            return expr

        # 如果是变量
        if expr in self.variables:
            var_info = self.variables[expr]
            op = var_info['operator']
            operands = var_info['operands']

            # 处理程序ID变量
            if expr in self.program_id_vars:
                return '0'

            if expr in self.num_programs_vars:
                return str(self.core_num)

            if not operands:
                return '0'

            # 获取操作数的公式
            operand_formulas = []
            for operand in operands:
                if operand in visited:
                    operand_formulas.append(operand)
                else:
                    operand_formula = self.get_expression_formula(operand, visited.copy())
                    operand_formulas.append(operand_formula)

            # 根据操作符构建公式
            formula_handlers = {
                'arith.muli': lambda x: f"({operand_formulas[0]} * {operand_formulas[1]})",
                'arith.addi': lambda x: f"({operand_formulas[0]} + {operand_formulas[1]})",
                'arith.subi': lambda x: f"({operand_formulas[0]} - {operand_formulas[1]})",
                'arith.divsi': lambda x: f"(({operand_formulas[0]}) // {operand_formulas[1]})",
                'arith.remsi': lambda x: f"(({operand_formulas[0]}) % {operand_formulas[1]})",
                'arith.minsi': lambda x: f"min({operand_formulas[0]}, {operand_formulas[1]})",
                'arith.maxsi': lambda x: f"max({operand_formulas[0]}, {operand_formulas[1]})",
                'arith.extsi': lambda x: operand_formulas[0],  # 符号扩展，公式不变
                'arith.extui': lambda x: operand_formulas[0],  # 零扩展，公式不变
            }
            handler = formula_handlers.get(op)
            if handler is not None and len(operand_formulas) >= 2:
                return handler(operand_formulas)
        return expr

    def _simplify_parentheses(self, match):
        inner = match.group(1)
        # 检查inner是否已经包含运算符，如果是则保留一层括号
        if re.search(r'[+\-*/]', inner):
            return f'({inner})'
        else:
            return inner

    def _simplify_pattern(self, formula: str) -> str:
        """简化pattern"""
        # 记录简化次数，避免无限递归
        max_iterations = 10
        iteration = 0

        while iteration < max_iterations:
            iteration += 1
            # 1. 简化常量计算，搜索如下7种pattern：[0 * expr, expr * 0, 0 + expr, expr + 0, expr - 0, 0 // expr, expr // 1]
            pattern_replace_pairs = [(r'\(0\s*\*\s*([^)]+?)\)', r'0'),
                                     (r'\(([^)]+?)\s*\*\s*0\)', r'0'),
                                     (r'\(0\s*\+\s*([^)]+?)\)', r'\1'),
                                     (r'\(([^)]+?)\s*\+\s*0\)', r'\1'),
                                     (r'\(([^)]+?)\s*-\s*0\)', r'\1'),
                                     (r'\(0\s*//\s*([^)]+?)\)', r'0'),
                                     (r'\(([^)]+?)\s*//\s*1\)', r'\1')]
            changed = False
            for (pattern, replace) in pattern_replace_pairs:
                if re.search(pattern, formula):
                    formula = re.sub(pattern, replace, formula)
                    changed = True
                    break
            if changed:
                continue

            # 2. 简化 (expr - 0 + 1 - 1) // 1
            # 这个模式需要特别小心，避免数字连接
            pattern = r'\(([^()]+?)\s*-\s*0\s*\+\s*1\s*-\s*1\)\s*//\s*1'
            if re.search(pattern, formula):
                new_formula = re.sub(pattern, lambda m: m.group(1), formula)
                if new_formula != formula:
                    formula = new_formula
                    continue

            # 3. 简化嵌套括号
            # 处理 ((expr)) 变成 (expr) 的情况
            pattern = r'\(\(([^()]+)\)\)'
            if re.search(pattern, formula):
                new_formula = re.sub(pattern, self._simplify_parentheses, formula)
                if new_formula != formula:
                    formula = new_formula
                    continue

            # 4. 简化 (expr) // 1
            pattern = r'\(([^()]+)\)\s*//\s*1(?!\d)'
            if re.search(pattern, formula):
                new_formula = re.sub(pattern, r'\1', formula)
                if new_formula != formula:
                    formula = new_formula
                    continue

            # 5. 简化 0 + expr
            pattern = r'0\s*\+\s*\(([^()]+)\)'
            if re.search(pattern, formula):
                new_formula = re.sub(pattern, r'\1', formula)
                if new_formula != formula:
                    formula = new_formula
                    continue

            # 如果没有变化，退出循环
            break
        return formula

    def simplify_formula(self, formula: str) -> str:
        """简化公式 - 完全重构的安全版本"""
        if not isinstance(formula, str):
            return str(formula)

        original_formula = formula
        # 创建一个副本用于处理
        result = formula

        # 保存函数调用
        protected_calls = {}
        call_counter = 0

        # 保护min和max函数调用
        def protect_min_max(match):
            nonlocal call_counter
            call_id = f"__PROTECTED_CALL_{call_counter}__"
            call_counter += 1
            protected_calls[call_id] = match.group(0)
            return call_id

        # 保护min函数
        result = re.sub(r'min\([^()]*(?:\([^()]*\)[^()]*)*\)', protect_min_max, result)
        # 保护max函数
        result = re.sub(r'max\([^()]*(?:\([^()]*\)[^()]*)*\)', protect_min_max, result)
        # 简化pattern
        result = self._simplify_pattern(result)

        # 还原函数调用
        for call_id, original_call in protected_calls.items():
            result = result.replace(call_id, original_call)

        # 最后，去除最外层不必要的括号
        if (result.startswith('(') and result.endswith(')') and
                result.count('(') == result.count(')') and
                result.count('(') == 1 + result[1:-1].count('(')):
            inner = result[1:-1]
            # 检查内部是否已经是一个简单表达式
            if not (inner.startswith('(') and inner.endswith(')')):
                result = inner

        return result

    def get_loop_iterations(self, loop_data: Dict[str, Any]) -> MLIRLoopFormula:
        """获取循环次数的MLIRLoopFormula对象"""
        # 先尝试直接计算表达式的值
        start_val = self.evaluate_expression(loop_data['start_expr'])
        end_val = self.evaluate_expression(loop_data['end_expr'])
        step_val = self.evaluate_expression(loop_data['step_expr'])

        # 如果所有值都是整数，直接计算循环次数
        if isinstance(start_val, int) and isinstance(end_val, int) and isinstance(step_val, int):
            if step_val == 0:
                return MLIRLoopFormula("0", 0)
            if end_val <= start_val:
                return MLIRLoopFormula("0", 0)
            # 循环次数公式: (end - start + step - 1) // step
            iterations = (end_val - start_val + step_val - 1) // step_val
            return MLIRLoopFormula(str(iterations), iterations)

        # 否则，获取公式
        start_formula = self.simplify_formula(self.get_expression_formula(loop_data['start_expr']))
        end_formula = self.simplify_formula(self.get_expression_formula(loop_data['end_expr']))
        step_formula = self.simplify_formula(self.get_expression_formula(loop_data['step_expr']))

        # 循环次数公式: (end - start + step - 1) // step
        iterations_formula = f"(({end_formula} - {start_formula} + {step_formula} - 1) // {step_formula})"
        simplified_formula = self.simplify_formula(iterations_formula)

        return MLIRLoopFormula(simplified_formula)

    def _calculate_nested_total(self, loop_line: int, loop_formulas) -> MLIRLoopFormula:
        """计算一个循环及其所有嵌套子循环的总迭代次数"""
        if loop_line not in loop_formulas:
            return MLIRLoopFormula("1", 1)

        # 当前循环的迭代次数
        current_formula = loop_formulas[loop_line]['iterations_formula']

        # 获取所有子循环
        children = self.nesting_tree.get(loop_line, [])
        if not children:
            return current_formula

        # 计算每个子循环的总迭代次数
        child_totals = []
        for child in children:
            child_total = self._calculate_nested_total(child, loop_formulas)
            if not child_total.is_constant or child_total.constant_value != 1:
                child_totals.append(child_total)

        if not child_totals:
            return current_formula

        # 总迭代次数 = 当前循环次数 * 子循环总次数
        if len(child_totals) == 1:
            child_total_expr = str(child_totals[0])
        else:
            child_total_expr = " * ".join(f"({str(child)})" for child in child_totals)
            child_total_expr = f"({child_total_expr})"

        if current_formula.is_constant and current_formula.constant_value == 1:
            return child_totals[0] if len(child_totals) == 1 else MLIRLoopFormula(child_total_expr)
        else:
            result_formula = f"({str(current_formula)}) * {child_total_expr}"
            simplified = self.simplify_formula(result_formula)
            return MLIRLoopFormula(simplified)

    def _create_loop_formulas(self):
        """为每个循环创建MLIRLoopFormula对象"""
        loop_formulas = {}
        for loop in self.loop_info:
            loop_line = loop['start_line']

            start_formula = self.simplify_formula(self.get_expression_formula(loop['start_expr']))
            end_formula = self.simplify_formula(self.get_expression_formula(loop['end_expr']))
            step_formula = self.simplify_formula(self.get_expression_formula(loop['step_expr']))
            iterations_formula = self.get_loop_iterations(loop)

            loop_formulas[loop_line] = {
                'variable': loop['variable'],
                'return_value': loop['return_value'],
                'yield_data': loop['yield_data'],
                'start_formula': start_formula,
                'end_formula': end_formula,
                'step_formula': step_formula,
                'iterations_formula': iterations_formula,
                'range_formula': f"{start_formula} to {end_formula} step {step_formula}",
                'depth': loop['depth'],
                'parent': loop['parent'],
                'start_line': loop['start_line'],
                'end_line': loop['end_line'],
                'child': loop['child']
            }
        return loop_formulas

    def analyze(self) -> Dict[str, Any]:
        """执行完整分析"""
        self.parse_function_definition()
        self.parse_constants_and_variables()
        self.parse_variables()
        self.analyze_loop_structure()

        loop_formulas = self._create_loop_formulas()

        # 找到所有顶层循环（没有父循环的循环）
        top_level_loops = [loop for loop in self.loop_info if loop['parent'] == []]

        # 为每个顶层循环计算总迭代次数
        top_loop_totals = {}
        for loop in top_level_loops:
            loop_line = loop['start_line']
            total_formula = self._calculate_nested_total(loop_line, loop_formulas)
            top_loop_totals[loop_line] = total_formula

        # 返回顶层循环次数列表
        if top_loop_totals:
            # 创建顶层循环的列表
            top_level_results = []
            for loop in sorted(top_level_loops, key=lambda x: x['start_line']):
                loop_line = loop['start_line']
                top_level_results.append({
                    'loop_variable': loop['variable'],
                    'iterations_formula': loop_formulas[loop_line]['iterations_formula'],
                    'total_nested_formula': top_loop_totals[loop_line],
                    'range_formula': loop_formulas[loop_line]['range_formula'],
                    'depth': loop['depth']
                })

            # 所有顶层循环的总和公式
            all_top_formulas = [str(formula) for formula in top_loop_totals.values()]
            if len(all_top_formulas) > 1:
                sum_formula = " + ".join(f"({formula})" for formula in all_top_formulas)
            elif all_top_formulas:
                sum_formula = all_top_formulas[0]
            else:
                sum_formula = "0"
        else:
            top_level_results = []
            sum_formula = "0"

        return {
            'function_args': sorted(list(self.function_args)),
            'program_id_vars': sorted(list(self.program_id_vars)),
            'all_loops': loop_formulas,
            'nesting_tree': dict(self.nesting_tree),
            'top_level_loops': [loop['start_line'] for loop in top_level_loops],
            'top_level_results': top_level_results,
            'top_loop_totals': top_loop_totals,
            'sum_of_all_loops': MLIRLoopFormula(self.simplify_formula(sum_formula))
        }


# 主函数
def create_mlir_loop_calculator(mlir_code: str, core_num: int) -> Dict[str, Any]:
    """
    创建MLIR循环计算器
    
    Args:
        mlir_code: MLIR代码字符串
        
    Returns:
        包含计算器和公式的字典
    """
    analyzer = MLIRLoopAnalyzerWithLambda(mlir_code, core_num)
    formulas = analyzer.analyze()

    # 创建可调用函数
    def get_loop_iterations(**kwargs) -> Dict[str, Any]:
        """计算所有循环的迭代次数"""
        # 转换参数格式
        arg_dict = {}
        for key, value in kwargs.items():
            if key.startswith('arg'):
                arg_dict[f'%{key}'] = value

        # 计算每个循环的迭代次数
        loop_results = {}
        for loop_var, loop_info in formulas.get('all_loops', {}).items():
            formula = loop_info['iterations_formula']
            loop_results[loop_var] = formula(**kwargs)

        # 计算每个顶层循环的总嵌套迭代次数
        top_level_results = []
        for top_loop_info in formulas.get('top_level_results', []):
            loop_var = top_loop_info['loop_variable']
            total_formula = top_loop_info['total_nested_formula']
            top_level_results.append({
                'loop_variable': loop_var,
                'individual_iterations': loop_results.get(loop_var, 0),
                'total_nested_iterations': total_formula(**kwargs)
            })

        # 计算总和
        sum_formula = formulas.get('sum_of_all_loops', MLIRLoopFormula("0", 0))
        total_sum = sum_formula(**kwargs)

        return {
            'all_loop_iterations': loop_results,
            'top_level_calculations': top_level_results,
            'total_sum': total_sum
        }

    # 创建简化的顶层循环调用函数
    def get_top_level_iterations(**kwargs) -> List[Dict[str, Any]]:
        """只返回顶层循环的计算结果"""
        result = get_loop_iterations(**kwargs)
        return result['top_level_calculations']

    return {
        'formulas': formulas,
        'get_loop_iterations': get_loop_iterations,
        'get_top_level_iterations': get_top_level_iterations
    }


def expand_loop(new_mlir_lines, all_loops, current_loop_index, start_line_offset, end_line_offset) -> int:
    """核心循环展开逻辑，返回展开后的行数变化"""
    loop_info = all_loops[current_loop_index]
    if loop_info['child']:
        line_change = 0
        for child_index in sorted(loop_info['child'], reverse=True):
            # 从后往前遍历
            line_change += expand_loop(new_mlir_lines, all_loops, child_index, start_line_offset, end_line_offset)
        end_line_offset += line_change
    return_value = loop_info['return_value']
    start_val = loop_info['start_formula']
    end_val = loop_info['end_formula']
    step_val = loop_info['step_formula']
    raw_start_line = loop_info['start_line']
    raw_end_line = loop_info['end_line']
    curr_start_line = raw_start_line + start_line_offset
    curr_end_line = raw_end_line + end_line_offset

    if curr_start_line < 0 or curr_end_line >= len(new_mlir_lines):
        return 0

    loop_times = math.ceil((end_val - start_val) / step_val)
    if loop_times <= 0:
        return 0

    loop_body_lines = []
    for line_num in range(curr_start_line + 1, curr_end_line):
        line = new_mlir_lines[line_num]
        loop_body_lines.append(line)
    if not loop_body_lines:
        return 0

    expanded_body = []
    current_idx = start_val
    for i in range(loop_times):
        for body_line in loop_body_lines:
            if 'scf.yield' not in body_line:
                expanded_body.append(body_line)
            elif i == loop_times - 1:
                # 如果存在'scf.yield'并且是最后一次循环，则添加一行具有返回值的ttir
                expanded_body.append(body_line.replace('scf.yield', f'{return_value} = '))
        current_idx += step_val

    del_line_count = curr_end_line - curr_start_line + 1
    insert_line_count = len(expanded_body)
    del new_mlir_lines[curr_start_line: curr_end_line + 1]
    new_mlir_lines[curr_start_line:curr_start_line] = expanded_body
    return insert_line_count - del_line_count


def expand_all_loops(mlir_code: str, formulas: dict, loop_data: Dict[str, Any]) -> str:
    """展开ttir中的所有for循环，返回语义一致的新ttir文本"""
    mlir_lines = [line.rstrip('\n') for line in mlir_code.split('\n')]
    new_mlir_lines = mlir_lines.copy()
    all_loops = formulas['all_loops']
    for index, loop_info in all_loops.items():
        loop_info['start_formula'] = MLIRLoopFormula(loop_info['start_formula'])(**loop_data)
        loop_info['end_formula'] = MLIRLoopFormula(loop_info['end_formula'])(**loop_data)
        loop_info['step_formula'] = MLIRLoopFormula(loop_info['step_formula'])(**loop_data)
    top_level_loops = formulas['top_level_loops']
    for index in sorted(top_level_loops, reverse=True):
        expand_loop(new_mlir_lines, all_loops, index, 0, 0)

    expanded_mlir = '\n'.join(new_mlir_lines)
    return expanded_mlir


# 测试修复后的代码
if __name__ == "__main__":
    set_log_level(logger, logging.INFO)
    # 测试MLIR代码
    mlir_path = '../../../mlir/examples/hc_split_sinkhorn_kernel.ttir'
    core_num = 56
    with open(mlir_path, "r") as f:
        mlir_code = f.read()
    analyzer = MLIRLoopAnalyzerWithLambda(mlir_code, core_num)

    # 测试完整分析
    logger.info("\n\n测试完整分析...")
    formulas = analyzer.analyze()

    logger.info(f"\n循环分析结果:")
    for loop_var, info in formulas['all_loops'].items():
        formula_obj = info['iterations_formula']
        logger.info(f"  {loop_var}: {formula_obj}")

    # 测试循环计算
    logger.info("\n\n测试循环计算:")
    test_cases = [
        {"arg2": 10, "arg3": 1536},
        {"arg2": 2, "arg3": 100},
        {"arg2": 4, "arg3": 3072},
        {"arg2": 0, "arg3": 0},
    ]

    for i, args in enumerate(test_cases, 1):
        logger.info(f"\n测试用例 {i}:")
        logger.info(f"  输入参数: {args}")

        try:
            # 使用计算器计算
            calculator = create_mlir_loop_calculator(mlir_code, core_num)
            result = calculator['get_loop_iterations'](**args)

            logger.info(f"  所有循环迭代次数: {result['all_loop_iterations']}")

            logger.info(f"\n  顶层循环计算结果:")
            for j, top_calc in enumerate(result['top_level_calculations'], 1):
                logger.info(f"    顶层循环 {j} ({top_calc['loop_variable']}):")
                logger.info(f"      自身迭代次数: {top_calc['individual_iterations']}")
                logger.info(f"      总嵌套迭代次数: {top_calc['total_nested_iterations']}")

            logger.info(f"  总迭代次数: {result['total_sum']}")
        except Exception as e:
            logger.info(f"  计算出错: {e}")

    # 循环展开样例
    calculator = create_mlir_loop_calculator(mlir_code, core_num)
    formulas = calculator['formulas']
    all_loops = formulas['all_loops']
    for index, loop in all_loops.items():
        logger.info(f"index = {index}")
        logger.info(f"loop = {loop}")

    new_mlir_code = expand_all_loops(mlir_code, formulas, {})
    logger.info(new_mlir_code)