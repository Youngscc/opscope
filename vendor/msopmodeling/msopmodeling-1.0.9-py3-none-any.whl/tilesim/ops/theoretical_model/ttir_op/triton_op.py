import math
import pathlib
from abc import ABC
from typing import Any, final

from core.backend.theoretical_costmodel.basic_stage_roofline.basic_cost_api import get_ttir_op_time, ModelLevel
from core.config.arc_spec import load_arc_config
from core.pipeline.basic_operator import BasicOperator, OperatorResult, OperatorInput
from ops.theoretical_model.ttir_op.ttir_adapter import analyze_mlir_code
from ops.theoretical_model.ttir_op.loop_analyzer import create_mlir_loop_calculator, expand_all_loops
from core.common import op_registry
from core.common import OpType, BackendType
from ops.theoretical_model.ttir_op.ttir_utils import init_logger, TTIRExtraParam

logger = init_logger()


@op_registry.register(OpType.TritonOp, BackendType.THEO)
class TheoTriton(BasicOperator, ABC):
    extra_param_class = TTIRExtraParam

    def run_model(self,
                  op_input: OperatorInput,
                  mlir: pathlib.Path = None,
                  param: TTIRExtraParam = None):
        # 分析MLIR代码
        with open(mlir, "r") as f:
            mlir = f.read()
        formulas = None
        try:
            calculator = create_mlir_loop_calculator(mlir, op_input.aiv_core_num)
            formulas = calculator['formulas']
        except ValueError as e:
            logger.warning(e)

        if formulas is None:
            raise ValueError("循环解析失败")
        else:
            # 对于成功解析循环的ttir，按照循环来决定重复次数，tile_num不起作用
            args = self.op_input.input_dict
            expand_mlir = expand_all_loops(mlir, formulas, args)
            inst_event_list = analyze_mlir_code(expand_mlir)
            tile_num = 1
        arc_config = load_arc_config(op_input.accelerator)
        e2e_time, mte2_time, mte3_time, compute_time = get_ttir_op_time(inst_event_list, tile_num, arc_config,
                                                                        ModelLevel(param.model_level))

        return OperatorResult(latency=e2e_time, aiv_time=e2e_time, aiv_vec_time=compute_time, aiv_mte2_time=mte2_time,
                              aiv_mte3_time=mte3_time)

    def run(self) -> OperatorResult:
        param: TTIRExtraParam = self.op_input.param
        if not param:
            raise ValueError("[TheoOp.triton]: param is none")

        path = pathlib.Path(param.ttir_path)
        result: OperatorResult = None
        if path.exists():
            if path.is_dir():
                ttir_files = sorted(path.rglob("*.ttir"))
                file_num = len(ttir_files)
                for idx, ttir in enumerate(ttir_files):
                    logger.info(f"{idx + 1}/{file_num} ttir is simulating")
                    tmp_result = self.run_model(self.op_input, ttir, param)
                    logger.info(f"{idx + 1}/{file_num} ttir simulation finished")
                    result = tmp_result if result is None else min([tmp_result, result], key=lambda x: x.latency)
            else:
                result = self.run_model(self.op_input, path, param)
        else:
            raise ValueError(f"ttir path {path} is not exist")
        return result

    def _input_check(self):
        pass

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        pass

    @property
    @final
    def backend_type(self):
        pass

    @property
    @final
    def optim_type(self):
        pass

    @property
    def eval_type(self):
        pass
