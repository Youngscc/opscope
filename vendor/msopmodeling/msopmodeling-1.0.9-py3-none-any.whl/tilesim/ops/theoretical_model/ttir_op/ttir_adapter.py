import re
from typing import Any, Dict, List, Optional, Tuple
from core.backend.theoretical_costmodel.basic_stage_roofline.basic_cost_api import InstEvent, TensorData
from ops.theoretical_model.ttir_op.ttir_utils import init_logger, data_type_mapping

logger = init_logger()
log_debug = logger.debug


def extract_tensor_shapes(mlir_code: str) -> Dict[str, str]:
    """从MLIR代码中提取张量形状信息"""
    shape_map = {}

    # 匹配变量定义和类型声明
    pattern = r'(%[\w_]+)\s*=\s*[^:]+:\s*(tensor<[^>]+>)'
    matches = re.findall(pattern, mlir_code)

    for var_name, shape in matches:
        if var_name not in shape_map:
            shape_map[var_name] = shape
            log_debug(f"提取变量形状: {var_name} -> {shape}")

    # 特别处理常量定义
    const_pattern = r'(%[\w_]+)\s*=\s*arith\.constant[^:]+:\s*(tensor<[^>]+>)'
    const_matches = re.findall(const_pattern, mlir_code)

    for const_name, shape in const_matches:
        shape_map[const_name] = shape
        log_debug(f"提取常量形状: {const_name} -> {shape}")

    # 处理没有dense的常量定义
    const_simple_pattern = r'(%[\w_]+)\s*=\s*arith\.constant[^:]+:\s*(tensor<[^>]+>)'
    const_simple_matches = re.findall(const_simple_pattern, mlir_code)

    for const_name, shape in const_simple_matches:
        if const_name not in shape_map:
            shape_map[const_name] = shape
            log_debug(f"提取简单常量形状: {const_name} -> {shape}")

    logger.info(f"共提取{len(shape_map)}个张量形状")
    return shape_map


def parse_shape_from_string(shape_str: str) -> Tuple[List[int], str]:
    """
    从形状字符串解析形状列表和数据类型
    例如: "tensor<7x568xf32>" -> ([7, 568], "f32")
    """
    if 'unknown' in shape_str:
        return [], 'unknown'

    # 匹配 tensor<dim1xdim2x...xtype> 格式
    match = re.search(r'tensor<((?:[^<>]+|<[^<>]+>)+)>', shape_str)
    if not match:
        # 处理字符串中只含有'f32', 'f16'等的标量类型
        scalar_pattern = re.compile(r'^f(8|16|32|64)$')
        if scalar_pattern.match(shape_str):
            return [1], shape_str
        return [], 'unknown'

    dims_str = match.group(1)
    parts = dims_str.split('x')

    if not parts:
        return [1], 'unknown'  # 标量张量

    shape = []
    d_type = 'unknown'

    # 修复：正确处理包含指针类型的形状
    for part in parts:
        part = part.strip()

        # 检查是否为数字维度
        if part.isdigit():
            shape.append(int(part))
        elif part.startswith('!'):
            # 遇到指针类型（如!tt.ptr<f32>），停止收集维度
            d_type = part
            break
        else:
            # 尝试解析可能包含符号的维度
            try:
                # 如果部分可以转换为数字，则添加
                shape.append(int(part))
            except ValueError:
                # 如果不是数字，可能是类型，停止收集维度
                d_type = part
                break

    # 如果没有找到明确的类型，使用最后一部分作为类型
    if d_type == 'unknown' and parts:
        last_part = parts[-1].strip()
        if not last_part.isdigit():
            d_type = last_part

    # 如果没有维度信息，视为标量
    if not shape:
        shape = [1]

    return shape, d_type


def _parse_loop_header(line: str, line_idx: int, active_depth: int, lines: list) -> Dict[str, Any]:
    """子函数：提取循环头信息 (降低主函数深度)"""
    pattern = r'scf\.for\s+(%[\w_]+)\s*=\s*(%[\w_]+|\d+)\s+to\s+(%[\w_]+|\d+)\s+step\s+(%[\w_]+|\d+)'
    match = re.match(pattern, line.strip())
    if not match:
        return None

    # 计算 body_start
    body_start = line_idx + 1
    if not line.strip().endswith('{') and line_idx + 1 < len(lines):
        if lines[line_idx + 1].strip().startswith('{'):
            body_start = line_idx + 2

    return {
        'variable': match.group(1),
        'start': match.group(2),
        'end': match.group(3),
        'step': match.group(4),
        'start_line': line_idx,
        'end_line': -1,
        'depth': active_depth,
        'body_start': body_start
    }


def find_loop_structure(mlir_code: str) -> Dict[str, Any]:
    """优化后的MLIR循环识别函数"""
    lines = mlir_code.strip().split('\n')
    scope_stack, active_loop_indices, loops = [], [], []

    for i, line in enumerate(lines):
        stripped = line.strip()

        # 1. 处理循环开始 (使用子函数)
        loop_info = _parse_loop_header(stripped, i, len(active_loop_indices), lines)
        if loop_info:
            loops.append(loop_info)
            active_loop_indices.append(len(loops) - 1)
            scope_stack.append('loop')
            continue  # 处理完循环头，直接跳过后续判断

        # 2. 处理非循环的代码块开始
        if stripped.endswith('{') or stripped.endswith('({'):
            scope_stack.append('other')
            continue

        # 3. 处理块结束 (合并判定逻辑)
        if not (stripped.startswith('}') or stripped.startswith('})')):
            continue

        if not scope_stack:
            continue

        if scope_stack.pop() == 'loop' and active_loop_indices:
            idx = active_loop_indices.pop()
            loops[idx]['end_line'] = i

    logger.info(f"共找到{len(loops)}个循环")
    return {'loops': loops, 'loops_found': len(loops) > 0}


def calculate_data_size(shape: List[int]) -> int:
    """计算张量的数据量（元素数量）"""
    if not shape:
        return 0

    size = 1
    for dim in shape:
        if dim > 0:
            size *= int(dim)
        else:
            return 0  # 无效维度
    return size


def normalize_data_type_for_load_store(d_type: str) -> str:
    """将load/store操作的数据类型统一转换为f32格式"""
    support_dtype = data_type_mapping.keys()
    # 如果数据类型包含指针，提取基础类型
    if 'ptr<' in d_type:
        # 匹配ptr<type>格式，提取内部类型
        ptr_match = re.search(r'ptr<([^>]+)>', d_type)
        if ptr_match:
            d_type = ptr_match.group(1)

    if d_type in support_dtype:
        return d_type
    return 'f32'  # 默认转为f32


def _parse_load_store_operation(line: str, event_id: int, op_type: str):
    """解析load/store操作的数据量"""
    # 核心修改：支持匹配 !tt.ptr<tensor<...>> 或直接 tensor<...>
    # 增加对 !tt.ptr< 的可选匹配
    type_match = re.search(r':\s*(?:!tt\.ptr<)?(tensor<[^>]+(?:>[^>]*)*>)', line)
    dtype_match = re.search(r'<(.*?)>', line)
    if type_match:
        # 张量类型
        type_str = type_match.group(1)
        shape, d_type = parse_shape_from_string(type_str)
        if not shape:
            return None
    elif dtype_match:
        # 标量类型，直接提取数据类型并将shape设置成[1]
        d_type = dtype_match.group(1)
        shape = [1]
    else:
        return None

    d_type = normalize_data_type_for_load_store(d_type)
    index = 0 if op_type == 'tt.load' else 1  # 实际搬运的tensor下标
    tensor_name = re.findall(r'%[\w]+', line)[index]

    return InstEvent(event_id, [TensorData(name=tensor_name,
                                           shape=shape,
                                           d_type=data_type_mapping[d_type],
                                           mem_loc="GM",
                                           address="unknown")],
                     None, inst_name='MTE2' if op_type == 'tt.load' else 'MTE3',
                     raw_inst_name=op_type
                     )


def _parse_insert_slice_to_tensor_data(line: str, event_id: int) -> Optional[InstEvent]:
    """解析tensor.insert_slice操作并转换为TensorData对象"""
    tensors = re.findall(r'tensor<[^>]+>', line)
    if not tensors:
        return None

    # 解析源张量形状和数据类型
    input_shape, input_dtype = parse_shape_from_string(tensors[0])
    output_shape, output_dtype = parse_shape_from_string(tensors[1])

    inst_name, raw_inst_name = _get_instruction_name(line)
    output_tensor_name, input_tensor_name = re.findall(r'%[\w]+', line)[:2]
    input_tensors = [TensorData(
        name=input_tensor_name,
        shape=input_shape,
        d_type=data_type_mapping[input_dtype],
        mem_loc="UB",
        address="unknown")]
    output_tensors = [TensorData(
        name=output_tensor_name,
        shape=output_shape,
        d_type=data_type_mapping[output_dtype],
        mem_loc="UB",
        address="unknown")]
    return InstEvent(event_id, input_tensors, output_tensors, inst_name, raw_inst_name)


def _parse_multi_line_operation(lines, start_idx, operation_count):
    """单个指令占用多行ttir的情况单独解析"""
    is_reduce = 'tt.reduce' in lines[start_idx]
    inst_name = None
    multi_line_num = 0
    inst_event = None
    while not lines[start_idx + multi_line_num].strip().startswith("})"):
        sub_line = lines[start_idx + multi_line_num]
        if ("arith.add" in sub_line or "arith.addf" in sub_line) and is_reduce:
            inst_name = "VCADD"
            raw_inst_name = "tt.reduce_add"
        elif "arith.max" in sub_line and is_reduce:
            inst_name = "VCGMAX"
            raw_inst_name = "tt.reduce_max"
        multi_line_num += 1
    if is_reduce and inst_name is not None:
        # 最后一行包含了tensor信息
        matches = re.findall(r'(?:tensor<(?:[^<>]+|<[^<>]+>)+>|\bf\d+\b|\bi\d+\b)', lines[start_idx + multi_line_num])
        input_shape, d_type = parse_shape_from_string(matches[0])
        output_shape, _ = parse_shape_from_string(matches[1])
        output_tensor_name, input_tensor_name = re.findall(r'%[\w]+', lines[start_idx])
        # 创建InstEvent对象
        input_tensor = TensorData(input_tensor_name, input_shape, data_type_mapping[d_type], "UB", "unknown")
        output_tensor = TensorData(output_tensor_name, output_shape, data_type_mapping[d_type], "UB", "unknown")
        inst_event = InstEvent(operation_count, [input_tensor], [output_tensor], inst_name, raw_inst_name)
    return inst_event, multi_line_num


def _extract_arith_operations_as_tensor_data(mlir_code: str, lines, load_line, store_line) -> List[InstEvent]:
    # 提取操作并转换为TensorData
    inst_event_list = []
    operation_count = 0
    output_tensor_from_event = {}  # ttir tensor标识 : event_id, 用于构建event前序依赖
    tensor_shapes = extract_tensor_shapes(mlir_code)

    i = load_line
    while i < min(store_line + 1, len(lines)):
        if not (line := lines[i].strip()) or 'scf.for' in line or 'scf.yield' in line:
            i += 1
            continue

        operation_parsers = {
            'tt.load': (_parse_load_store_operation, [line, operation_count, 'tt.load']),
            'tt.store': (_parse_load_store_operation, [line, operation_count, 'tt.store']),
            'tensor.insert_slice': (_parse_insert_slice_to_tensor_data, [line, operation_count]),
            # 优先精确匹配
            'arith.muli': (_parse_scalar_operation, [line, operation_count, tensor_shapes, mlir_code]),
            'arith.': (_parse_operation_to_tensor_data, [line, operation_count, tensor_shapes, mlir_code]),
            'math.': (_parse_operation_to_tensor_data, [line, operation_count, tensor_shapes, mlir_code]),
            'tt.broadcast': (_parse_operation_broadcast, [line, operation_count]),
            'tt.dot': (_parse_operation_dot, [line, operation_count, tensor_shapes, mlir_code]),
            'tt.trans': (_parse_reshape_type_operation, [line, operation_count, tensor_shapes, mlir_code]),
            'arith.truncf': (_parse_reshape_type_operation, [line, operation_count, tensor_shapes, mlir_code])
        }

        extracted = any(
            process_event(inst_event_list, func, args)
            for pattern, (func, args) in operation_parsers.items()
            if pattern in line
        )

        if line.endswith("({"):
            inst_event, multi_line_num = _parse_multi_line_operation(lines, i, operation_count)
            if inst_event is not None:
                inst_event_list.append(inst_event)
                extracted = True
            i += multi_line_num

        # 处理event之间的数据依赖
        tensor_ids = re.findall(r'%[\w]+', line)
        # 找不到id的认为没有前后依赖关系，直接跳过
        if len(tensor_ids) == 0:
            i += 1
            continue
        if 'tt.store' not in line:  # store没有输出
            output_tensor_from_event[tensor_ids[0]] = operation_count
        depend_id_list = []
        for tensor_id in tensor_ids[1:]:
            if (depend_id := output_tensor_from_event.get(tensor_id)) is not None:
                depend_id_list.append(depend_id)
        if extracted:
            inst_event_list[-1].event_depend_id = depend_id_list
        else:
            # 对于未提取的ir行，解析入参和出参，用于构建event依赖。输入输出tensor只需获取名称即可
            tensor_matches = re.findall(r'tensor<[^>]+>', line)
            if tensor_matches:
                output_shape, output_dtype = parse_shape_from_string(tensor_matches[-1])
                output_dtype = data_type_mapping[output_dtype] if output_dtype != 'unknown' else 'FP32'
            else:
                output_shape, output_dtype = [1], 'FP32'
            # NEXT 此处的input tensor的shape需要确定
            input_tensors = [TensorData(tensor_id, [1], 'FP32', 'UB', 'unknown') for tensor_id in tensor_ids[1:]]
            output_tensors = [TensorData(tensor_ids[0], output_shape, output_dtype, 'UB', 'unknown')]
            operation_pattern = re.compile(r'%\w+\s*=\s*([a-zA-Z0-9_.]+)')
            match = operation_pattern.search(line)
            raw_inst_name = match.group(1) if match is not None else "unknown"
            inst_event_list.append(
                InstEvent(operation_count, input_tensors, output_tensors, "(raw) " + raw_inst_name, raw_inst_name,
                          depend_id_list))

        operation_count += 1
        i += 1
    return inst_event_list


def _find_dummy_load_line_pos(innermost_loop, lines):
    """查找load行插入位置"""
    if innermost_loop is not None:  # 优先找最内层循环开始的位置
        return innermost_loop['body_start']
    else:
        for i, line in enumerate(lines):
            tensor_ids = re.findall(r'%[\w]+', line)
            if tensor_ids and tensor_ids[0] == '%0':  # 输出为%0的位置
                return i
    logger.error(f"未找到合适的load行插入位置")
    return 0


def find_load_store_lines(mlir_code, innermost_loop):
    """查找load和store操作，并支持补全"""
    lines = mlir_code.strip().split('\n')
    load_line, store_line = _find_load_store_lines(lines, innermost_loop)
    if load_line == -1 or store_line == -1 or store_line <= load_line:
        logger.warning(f"无法找到有效的load/store对 (load: {load_line}, store: {store_line})")
        if load_line == -1 and store_line != -1:
            load_line = _find_dummy_load_line_pos(innermost_loop, lines)
            lines.insert(load_line, '%dummy_0 = tt.load %dummy_1, %dummy_2, %dummy_3 : tensor<1x!tt.ptr<f32>>')
            store_line += 1
        else:
            raise ValueError(f"不支持load/store对补全，load_line = {load_line}，store_line = {store_line}")
    logger.info(f"ttir分析范围: 第{load_line}行到第{store_line}行")
    return lines, load_line, store_line


def find_innermost_loop(mlir_code):
    """分析循环结构，找到最内层循环"""
    loop_structure = find_loop_structure(mlir_code)
    loops = loop_structure['loops']

    if not loops:
        innermost_loop = None
        logger.warning("无法找到循环结构")
    else:
        innermost_loop = max(loops, key=lambda x: x['depth'])
        logger.info(f"找到{len(loops)}个循环，最内层循环: {innermost_loop['variable']}")
    return innermost_loop


def extract_arith_operations_as_tensor_data(mlir_code: str) -> List[InstEvent]:
    """提取arith操作并转换为TensorData列表"""
    lines, load_line, store_line = find_load_store_lines(mlir_code, None)
    return _extract_arith_operations_as_tensor_data(mlir_code, lines, load_line, store_line)


def process_event(inst_event_list, parse_func, parse_func_args):
    inst_event = parse_func(*parse_func_args)
    if inst_event is not None and inst_event.inst_name != 'unknown':
        inst_event_list.append(inst_event)
        log_debug(f"提取操作 {parse_func_args[1]}: {inst_event.inst_name}, "
                  f"shape: {inst_event.input_tensors[0].shape}")
        return True
    return False


def _find_load_store_lines(lines: List[str], innermost_loop: Dict) -> Tuple[int, int]:
    """查找load和store操作的行号"""
    load_line, store_line = -1, -1
    if innermost_loop is None:
        start = 0
        end = len(lines)
    else:
        start = innermost_loop['body_start']
        end = innermost_loop['end_line']
    # 在循环体中搜索
    for i in range(start, end):
        if i >= len(lines):
            break

        line = lines[i].strip()
        if 'tt.load' in line and load_line == -1:
            load_line = i
        elif 'tt.store' in line:
            store_line = i

    # 如果没找到，在整个代码中搜索
    if load_line == -1:
        for i, line in enumerate(lines):
            if 'tt.load' in line:
                load_line = i
                break

    if store_line == -1:
        for i, line in enumerate(lines):
            if 'tt.store' in line:
                store_line = i
                break

    return load_line, store_line


def _is_select_used_for_address(line: str, all_lines: List[str], current_index: int) -> bool:
    """检查select操作是否用于地址计算"""
    result_match = re.match(r'(%[\w_]+)\s*=', line)
    if not result_match:
        return False

    result_var = result_match.group(1)

    for j in range(current_index + 1, min(current_index + 10, len(all_lines))):
        if j >= len(all_lines):
            break

        next_line = all_lines[j].strip()
        if 'tt.addptr' in next_line and result_var in next_line:
            return True
        if 'tt.store' in next_line and result_var in next_line:
            store_match = re.search(r'tt\.store\s+(%[\w_]+)', next_line)
            if store_match and store_match.group(1) == result_var:
                return True

    return False


def _parse_reshape_type_operation(line: str, event_id: int, shape_map: Dict[str, str], mlir_code: str) -> Optional[
    InstEvent]:
    """支持 tt.trans, tt.expand_dims, arith.truncf, arith.extf 等"""
    # 1. 自动识别指令名映射
    if 'tt.trans' in line:
        inst_name = 'VTRANS'
        raw_inst_name = 'tt.trans'
    elif 'tt.expand_dims' in line:
        inst_name = 'VEXPAND'
        raw_inst_name = 'tt.expand_dims'
    elif 'arith.truncf' in line:
        inst_name = 'CONV_F322F16'  # NEXT - 通过dtype判断指令类别
        raw_inst_name = 'arith.truncf'
    elif 'arith.extf' in line:
        inst_name = 'VBRCB'
        raw_inst_name = 'arith.extf'
    else:
        inst_name = 'VRESHAPE'
        raw_inst_name = 'unknown'

    # 2. 提取所有 tensor 类型声明，小于两个矩阵的返回none
    # 兼容 "tensor<...> -> tensor<...>" 和 "tensor<...> to tensor<...>"
    type_matches = re.findall(r'tensor<[^>]+>', line)
    if len(type_matches) < 2:
        return None

    input_type_str = type_matches[0]
    output_type_str = type_matches[-1]

    # 3. 解析形状和数据类型
    input_shape, input_dtype = parse_shape_from_string(input_type_str)
    output_shape, output_dtype = parse_shape_from_string(output_type_str)

    if not output_shape or not input_shape:
        return None

    # 4. 提取 Tensor 名称
    output_tensor_name, input_tensor_name = re.findall(r'%[\w]+', line)

    # 4. 构建 TensorData
    input_tensors = [TensorData(
        name=input_tensor_name,
        shape=input_shape,
        d_type=data_type_mapping.get(input_dtype, input_dtype),
        mem_loc="UB",
        address="unknown"
    )]
    output_tensors = [TensorData(
        name=output_tensor_name,
        shape=output_shape,
        d_type=data_type_mapping.get(output_dtype, output_dtype),
        mem_loc="UB",
        address="unknown"
    )]

    # 5. 为了在日志中区分类型变化，可以动态修改指令名
    if input_dtype != output_dtype:
        inst_name = f"{inst_name}"

    return InstEvent(event_id, input_tensors, output_tensors, inst_name, raw_inst_name)


def _parse_operation_to_tensor_data(line: str, event_id: int, shape_map: Dict[str, str], mlir_code: str) -> Optional[
    InstEvent]:
    """解析操作并转换为TensorData对象"""
    # 提取结果类型
    type_match = re.search(r':\s*(tensor<[^>]+>)', line)
    if not type_match:
        return None

    output_shape_str = type_match.group(1)

    # 解析输出形状和数据类型
    output_shape, d_type = parse_shape_from_string(output_shape_str)
    if not output_shape:
        return None

    # 确定操作类型
    inst_name, raw_inst_name = _get_instruction_name(line)
    if not inst_name:
        return None

    if inst_name == 'VSEL':
        # 改进正则表达式，确保正确匹配三个类型参数
        # 匹配格式：arith.select 操作数1, 操作数2, 操作数3 : 类型1, 类型2, 类型3
        select_pattern = r'arith\.select\s+[^:]+:\s*([^,]+?)\s*,\s*([^,]+?)\s*,\s*([^,]+)'
        select_match = re.search(select_pattern, line)
        if select_match:
            # 第一个类型是条件类型（i1），忽略
            # 取第二个和第三个类型（true_val和false_val的类型）
            true_val_type = select_match.group(2).strip()
            false_val_type = select_match.group(3).strip()

            # 验证后两个操作数类型是否一致
            if true_val_type != false_val_type:
                logger.warning(f"arith.select操作的后两个操作数类型不一致: {true_val_type} vs {false_val_type}")

            # 从后两个操作数的类型中提取数据类型
            true_val_d_type = _extract_data_type_from_shape(true_val_type)
            if true_val_d_type and true_val_d_type != 'i1':  # 避免使用i1类型
                d_type = true_val_d_type
                log_debug(f"arith.select操作使用后两个操作数的数据类型: {d_type}")
        else:
            # 如果正则匹配失败，尝试从操作数中推断类型
            d_type = _infer_select_data_type_from_operands(line, shape_map)

    # 提取输入变量列表并推测每个输入操作数的数据类型
    input_vars = re.findall(r'%[\w]+', line)[1:]
    input_d_types = []

    for var in input_vars:
        if var in shape_map:
            shape_str = shape_map[var]
            _, input_d_type = parse_shape_from_string(shape_str)
            input_d_types.append(input_d_type)
        else:
            input_d_types.append('unknown')

    # 记录输入操作数的数据类型推测结果
    logger.info(f"操作 {inst_name} 的输入操作数数据类型推测: {input_d_types}")

    # 特别处理常量操作数的数据类型推测
    for i, var in enumerate(input_vars):
        if var.startswith('%cst') and var in shape_map:
            shape_str = shape_map[var]
            _, const_d_type = parse_shape_from_string(shape_str)
            log_debug(f"常量操作数 {var} 的数据类型推测为: {const_d_type}")

    # 提取输入张量形状和标识符
    input_vars_shapes = _extract_input_vars_shapes(line, shape_map, mlir_code)

    # 创建InstEvent对象
    output_tensor_name = re.findall(r'%[\w]+', line)[0]
    input_tensors = [TensorData(var, shape, data_type_mapping[d_type], "UB", "unknown") for (var, shape) in
                     input_vars_shapes.items()]
    output_tensor = TensorData(output_tensor_name, output_shape, data_type_mapping[d_type], "UB", "unknown")

    return InstEvent(event_id, input_tensors, [output_tensor], inst_name, raw_inst_name)


def _parse_scalar_operation(line: str, event_id: int, shape_map: Dict[str, str], mlir_code: str) -> Optional[InstEvent]:
    """专门处理标量指令 (如 arith.muli, arith.addi : i32)"""
    inst_name, raw_inst_name = _get_instruction_name(line)
    if not inst_name:
        return None

    if ':' not in line:
        return None

    # 截取示例: " i32 loc(#loc51)" -> "i32"
    type_part = line.split(':')[-1].split('loc(')[0].strip()

    # 3. 提取类型 (i32, f32, f16 等)
    type_match = re.search(r'\b(f16|f32|i1|i8|i16|i32|i64)\b', type_part)
    if not type_match:
        return None

    d_type = type_match.group(1)

    # 4. 提取输入变量名称
    output_tensor_name = re.findall(r'%[\w]+', line)[0]
    input_vars_shapes = _extract_input_vars_shapes(line, shape_map, mlir_code)

    safe_dtype_str = data_type_mapping.get(d_type, "UNKNOWN")
    input_tensors = []
    scalar_shape = [1]

    # 5. 处理输入输出矩阵
    if not input_vars_shapes:
        # 如果没能提取到输入，作为标量运算，给两个默认的标量输入，防止报错
        input_tensors = [
            TensorData("unknown_scalar_1", scalar_shape, safe_dtype_str, "unknown", "unknown"),
            TensorData("unknown_scalar_2", scalar_shape, safe_dtype_str, "unknown", "unknown")
        ]
    else:
        # [修复] 遍历字典，将 key (变量名) 传给 TensorData
        for var_name, _ in input_vars_shapes.items():
            input_tensors.append(
                TensorData(var_name, scalar_shape, safe_dtype_str, "UB", "unknown")
            )

    output_tensor = TensorData(output_tensor_name, scalar_shape, safe_dtype_str, "UB", "unknown")

    return InstEvent(event_id, input_tensors, [output_tensor], inst_name, raw_inst_name)


def _parse_operation_dot(line: str, event_id: int, shape_map: Dict[str, str], mlir_code: str) -> Optional[InstEvent]:
    """精准解析 tt.dot A * B -> C"""
    # 1. 准确定位类型标注区（冒号之后的部分）
    if ':' not in line:
        return None
    type_part = line.split(':')[-1].split('loc(')[0].strip()

    # 2. 提取所有的 tensor 声明,少于3个tensor的时候返回None
    type_matches = re.findall(r'tensor<[^>]+>', type_part)

    if len(type_matches) < 3:
        logger.warning(f"tt.dot 类型声明不足: {type_part}")
        return None

    # 指令解析：tensor<32x128xf16> * tensor<128x256xf16> -> tensor<32x256xf32>
    input_a_str = type_matches[0]
    input_b_str = type_matches[1]
    output_c_str = type_matches[2]
    logger.info(f"匹配DOT第一个矩阵信息{input_a_str},第二个{input_b_str},第三个{output_c_str}")
    # 3. 解析具体数值
    shape_a, dtype_a = parse_shape_from_string(input_a_str)
    shape_b, dtype_b = parse_shape_from_string(input_b_str)
    shape_c, dtype_c = parse_shape_from_string(output_c_str)
    # 4. 提取变量名
    output_tensor_name = re.findall(r'%[\w]+', line)[0]
    input_vars = re.findall(r'%[\w]+', line)[1:]

    # 确保有足够的输入变量名，如果没有则使用默认名
    name_a = input_vars[0] if len(input_vars) > 0 else "unknown_dot_a"
    name_b = input_vars[1] if len(input_vars) > 1 else "unknown_dot_b"

    # 4. 构建包含完整信息的 TensorData
    input_tensors = [
        TensorData(name_a, shape_a, data_type_mapping.get(dtype_a, "f16"), "L1", "unknown"),
        TensorData(name_b, shape_b, data_type_mapping.get(dtype_b, "f16"), "L1", "unknown")
    ]

    output_tensors = [
        TensorData(output_tensor_name, shape_c, data_type_mapping.get(dtype_c, "f32"), "L0C", "unknown")
    ]

    inst_name = f"VDOT"
    return InstEvent(event_id, input_tensors, output_tensors, inst_name, "tt.dot")


def _parse_operation_broadcast(line: str, event_id: int) -> Optional[InstEvent]:
    """提取 tt.broadcast (张量->张量) 或 tt.splat (标量->张量)"""

    # 1. 识别指令名
    inst_type = 'VSPLAT' if 'tt.splat' in line else 'VBRCB'

    # 2. 提取类型声明
    # 逻辑：先找所有的 tensor<>，如果只有一个，说明是 splat
    tensor_matches = re.findall(r'tensor<[^>]+>', line)

    if 'tt.splat' in line:
        # --- 处理 tt.splat ---
        if len(tensor_matches) != 1:
            return None  # splat 必须有一个输出张量

        # 输出形状从唯一的 tensor 匹配中获取
        output_shape, d_type = parse_shape_from_string(tensor_matches[0])

        # 输入是标量，形状设为 [1]
        input_shape = [1]

        # 如果 d_type 没解析出来（因为 splat 输入可能是 !tt.ptr<f32>）
        # 我们从冒号后面手动提取一下
        if d_type == 'unknown':
            type_part = line.split(':')[-1].split('->')[0].strip()
            # 简单的指针或基础类型提取
            ptr_match = re.search(r'([fi]\d+|ptr<[^>]+>)', type_part)
            d_type = ptr_match.group(1) if ptr_match else 'unknown'

    else:
        # --- 处理普通的 tt.broadcast ---
        if len(tensor_matches) != 2:
            raise ValueError("tt.broadcast 必须包含输入和输出两个 tensor 声明")
        input_shape, d_type = parse_shape_from_string(tensor_matches[0])
        output_shape, _ = parse_shape_from_string(tensor_matches[1])

    # 3. 创建 InstEvent 对象
    # 使用 .get() 避免 KeyError
    safe_dtype = data_type_mapping.get(d_type, "DT_UNDEFINED")
    output_tensor_name, input_tensor_name = re.findall(r'%[\w]+', line)
    input_tensor = TensorData(input_tensor_name, input_shape, safe_dtype, "UB", "unknown")
    output_tensor = TensorData(output_tensor_name, output_shape, safe_dtype, "UB", "unknown")

    return InstEvent(event_id, [input_tensor], [output_tensor], inst_type)


def _infer_select_data_type_from_operands(line: str, shape_map: Dict[str, str]) -> str:
    """从操作数中推断arith.select操作的数据类型"""
    # 提取操作数变量
    operand_pattern = r'arith\.select\s+(%[\w_]+)\s*,\s*(%[\w_]+)\s*,\s*(%[\w_]+)'
    operand_match = re.search(operand_pattern, line)

    if operand_match:
        # 第二个和第三个操作数是true_val和false_val
        true_val_var = operand_match.group(2)
        false_val_var = operand_match.group(3)

        # 从shape_map中获取操作数的类型
        for var in [true_val_var, false_val_var]:
            if var not in shape_map:
                continue
            shape_str = shape_map[var]
            _, operand_d_type = parse_shape_from_string(shape_str)
            if operand_d_type and operand_d_type != 'i1':
                return operand_d_type

    return 'unknown'


def _extract_data_type_from_shape(shape_str: str) -> str:
    """从形状字符串中提取数据类型"""
    if 'unknown' in shape_str:
        return 'unknown'

    # 匹配 tensor<dim1xdim2x...xtype> 格式
    match = re.search(r'tensor<([^>]+)>', shape_str)
    if not match:
        return 'unknown'

    shape_str = match.group(0)
    parts = shape_str.split('x')

    if not parts:
        return 'unknown'

    # 最后一部分是类型
    type_part = parts[-1].rstrip('>')
    return type_part


def _extract_input_vars_shapes(line: str, shape_map: Dict[str, str], mlir_code: str) -> Dict[str, List[int]]:
    """从操作行提取所有输入张量的标识符和形状"""
    ret = {}

    # 提取所有输入变量
    input_vars = re.findall(r'%[\w]+', line)[1:]

    # 为每个输入变量获取形状
    for var in input_vars:
        if var in shape_map:
            shape_str = shape_map[var]
            shape, _ = parse_shape_from_string(shape_str)
            ret[var] = shape
            log_debug(f"找到变量 {var} 的形状: {shape}")
        else:
            # 如果不在shape_map中，尝试从MLIR代码中查找定义
            shape = _find_operand_shape_from_context(var, mlir_code)
            if shape:
                ret[var] = shape
                log_debug(f"从上下文找到变量 {var} 的形状: {shape}")
            else:
                ret[var] = []
                log_debug(f"未找到变量 {var} 的形状信息")

    return ret


def _find_operand_shape_from_context(operand: str, mlir_code: str) -> List[int]:
    """从上下文中查找操作数的形状定义"""
    lines = mlir_code.strip().split('\n')

    # 查找操作数的定义行
    for line in lines:
        if operand in line and ('arith.constant' in line or '=' in line):
            # 尝试提取形状信息
            shape_match = re.search(r'tensor<([^>]+)>', line)
            if shape_match:
                shape_str = shape_match.group(0)
                shape, _ = parse_shape_from_string(shape_str)
                return shape

    return []


def _get_instruction_name(line: str) -> tuple[str, str]:
    """从代码行提取指令名称"""
    if 'arith.addi' in line:
        return 'VADD', 'arith.addi'
    elif 'arith.addf' in line:
        return 'VADD', 'arith.addf'
    elif 'arith.muli' in line or 'arith.mulf' in line:
        return 'VMUL', 'arith.muli'
    elif 'arith.cmpi' in line:
        # NEXT: Need to correct the compare op
        return 'VCMPV_NE', 'arith.cmpi'
    elif 'arith.cmpf' in line:
        return 'VCMPV_GE', 'arith.cmpf'
    elif 'arith.select' in line:
        return 'VSEL', 'arith.select'
    elif 'arith.maxnumf' in line:
        return 'VMAX', 'arith.maxnumf'
    elif 'arith.divf' in line:
        return 'VDIV', 'arith.divf'
    elif 'math.exp' in line:
        return 'VEXP', 'math.exp'
    elif 'arith.subf' in line:
        return 'VSUB', 'arith.subf'
    elif 'tensor.insert_slice' in line:
        return 'VCOPY', 'tensor.insert_slice'
    elif 'tt.trans' in line:
        return 'VTRANS', 'tt.trans'
    elif 'math.log2' in line:
        return 'LOG', 'math.log2'
    else:
        return 'unknown', 'unknown'


def analyze_mlir_code(mlir_code: str) -> List[InstEvent]:
    """分析MLIR代码并返回TensorData列表"""
    logger.info("开始分析MLIR代码...")

    ints_event_list = extract_arith_operations_as_tensor_data(mlir_code)
    logger.info(f"分析完成，共提取{len(ints_event_list)}个算子")
    return ints_event_list


def print_tensor_data_summary(ints_event_list: List[InstEvent]):
    """打印TensorData列表的摘要信息"""
    if not ints_event_list:
        log_debug("未找到任何算子")
        return

    log_debug(f"\n共找到{len(ints_event_list)}个算子:")
    log_debug("=" * 130)
    log_debug(
        f"{'event_id':<15} {'指令':<30} {'输入形状':<30} {'输出形状':<18} {'数据类型':<10} {'前序event依赖': <10}")
    log_debug("-" * 130)

    for _, inst_event in enumerate(ints_event_list, 1):
        # 格式化输入形状
        input_shapes_str = ""
        for j, tensor_data in enumerate(inst_event.input_tensors):
            shape_str = str([dim for dim in tensor_data.shape])
            if j > 0:
                input_shapes_str += ", "
            input_shapes_str += shape_str
        if input_shapes_str == "":
            input_shapes_str = "None"
        # 格式化输出形状
        if inst_event.inst_name == 'MTE2' or inst_event.inst_name == 'MTE3' or '(raw)' in inst_event.inst_name:
            output_shape_str = "None"
            output_dtype_str = "None"
        else:
            output_shape_str = str([dim for dim in inst_event.output_tensors[0].shape])
            output_dtype_str = inst_event.output_tensors[0].d_type
        logger.info(
            f"{inst_event.event_id:<15} {inst_event.inst_name:<30} {input_shapes_str:<35} "
            f"{output_shape_str:<20} {output_dtype_str:<12} {str(inst_event.event_depend_id):<10}"
        )


def print_detailed_tensor_data(inst_event_list: List[InstEvent], detail=False):
    """打印详细的TensorData信息"""
    if not inst_event_list:
        logger.info("未找到任何算子")
        return

    logger.info(f"\n详细TensorData信息:")
    logger.info("=" * 80)

    for i, inst_event in enumerate(inst_event_list, 1):
        logger.info(f"{i}. {inst_event.inst_name}:")
        if detail:
            logger.info(f"   输入标识: {inst_event.input_tensors[0].name}")
            logger.info(f"   输入形状: {inst_event.input_tensors[0].shape}")
            logger.info(f"   输出形状: {inst_event.output_tensors[0].shape}")
            logger.info(f"   数据类型: {inst_event.input_tensors[0].d_type}")
            logger.info(f"   内存位置: {inst_event.output_tensors[0].mem_loc}")
            logger.info(f"   地址: {inst_event.output_tensors[0].address}")
        logger.info("")