import logging
from dataclasses import dataclass

from core.pipeline.basic_operator import OperatorExtraParam


@dataclass
class TTIRExtraParam(OperatorExtraParam):
    ttir_path: str = None
    model_level: int = 2


def set_log_level(logger, level):
    """设置日志级别

    Args:
        level: logging模块的等级，如logging.DEBUG, logging.INFO, logging.WARNING, logging.ERROR
    """
    logger.setLevel(level)
    logger.info(f"日志级别设置为: {logging.getLevelName(level)}")


def init_logger():
    """初始化logger实例"""
    logger_ = logging.getLogger(__name__)
    logger_.setLevel(logging.ERROR)
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('[%(levelname)s] %(message)s'))
    if not logger_.handlers:
        logger_.addHandler(handler)
    logger_.propagate = False
    return logger_


data_type_mapping = {
    'i1': 'BOOL',
    'i8': 'INT8',
    'u8': 'INT8',
    'i16': 'INT16',
    'u16': 'INT16',
    'f16': 'FP16',
    'f32': 'FP32',
    'bf16': "BF16",
    'i32': 'INT32',
    'u32': 'INT32',
    'i64': 'INT64',
    'u64': 'INT64',
    'f64': 'INT64',
    'bool': 'BOOL'
}