# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.common import op_registry
from core.common import OpType, BackendType, DType, MemLoc
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

M1 = M2 = 128
N1 = N2 = 64
dtype = DType.FP32
mem_loc = MemLoc.GM


def clip_by_value(src1: Tensor(shape=[M1, N1], dtype=dtype, mem_loc=mem_loc),
                  output: Tensor(shape=[M2, N2], dtype=dtype, mem_loc=mem_loc)
                  ):
    """
    clip_by_value 算子DSL实现
    Args:
        src1:
        output:

    Returns:

    """
    output_ub = Tensor(shape=[M2, N2], dtype=dtype, mem_loc=MemLoc.UB)
    T.TensorOp.max(src1, src1, src1)
    T.TensorOp.min(output_ub, src1, src1)
    T.TensorOp.store(output_ub)


@op_registry.register(OpType.ClipByValueV2, BackendType.THEO)
class TheoClipByValue(TheoreticalOperator):
    operator_dsl = clip_by_value

    def _input_check(self):
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes

        if len(input_shapes) != 1:
            raise ValueError(f"[TheoOp.{TheoClipByValue.op_name}]: inputs len must be 1")

        if len(output_shapes) != 1:
            raise ValueError(f"[TheoOp.{TheoClipByValue.op_name}]: outputs len must be 1")

        for shape in input_shapes:
            if len(shape) != 2:
                raise ValueError(f"[TheoOp.{TheoClipByValue.op_name}]: input dim must be 2")
            if shape[0] != output_shapes[0][0] and shape[0] != 1:
                raise ValueError(f"[TheoOp.{TheoClipByValue.op_name}]: input dim0 not match output")
            if shape[1] != output_shapes[0][1] and shape[1] != 1:
                raise ValueError(f"[TheoOp.{TheoClipByValue.op_name}]: input dim1 not match output")

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes

        dynamic_shape = {
            'M1': input_shapes[0][0],
            'N1': input_shapes[0][1],
            'M2': output_shapes[0][0],
            'N2': output_shapes[0][1],
            'dtype': self.op_input.input_dtypes[0],
            'mem_loc': MemLoc.GM,
        }
        return dynamic_shape