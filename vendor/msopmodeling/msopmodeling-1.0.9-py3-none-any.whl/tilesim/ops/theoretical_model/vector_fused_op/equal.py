# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.common import op_registry
from core.common import OpType, BackendType, DType, MemLoc
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

m1, n1, m2, n2 = [128, 128, 128, 128]


def theo_equal(src1: Tensor(shape=[m1, n1], dtype=DType.FP32, mem_loc=MemLoc.GM),
               output: Tensor(shape=[m2, n2], dtype=DType.FP32, mem_loc=MemLoc.GM)):
    """
    Equal算子DSL实现
    Args:
        src1:
        output:

    Returns:

    """

    input_cmpv_eq_x1 = Tensor(shape=[m1, n1], dtype=DType.FP32, mem_loc=MemLoc.GM)
    input_cmpv_eq_x2 = Tensor(shape=[m1, n1], dtype=DType.FP32, mem_loc=MemLoc.GM)
    cmpv_eq_out = Tensor(shape=[m1, n1], dtype=DType.FP32, mem_loc=MemLoc.UB)
    input_dup_x1 = Tensor(shape=[m1, n1], dtype=DType.FP16, mem_loc=MemLoc.UB)
    dup_out = Tensor(shape=[m1, n1], dtype=DType.FP16, mem_loc=MemLoc.UB)
    input_sel_x1 = Tensor(shape=[m1, n1], dtype=DType.FP16, mem_loc=MemLoc.UB)
    input_sel_x2 = Tensor(shape=[m1, n1], dtype=DType.FP16, mem_loc=MemLoc.UB)
    sel_out = Tensor(shape=[m1, n1], dtype=DType.FP16, mem_loc=MemLoc.UB)
    input_conv_x1 = Tensor(shape=[m1, n1], dtype=DType.FP16, mem_loc=MemLoc.UB)
    conv_out = Tensor(shape=[m2, n2], dtype=DType.INT8, mem_loc=MemLoc.UB)

    T.TensorOp.cmpv_eq(cmpv_eq_out, input_cmpv_eq_x1, input_cmpv_eq_x2)
    T.TensorOp.vector_dup(dup_out, input_dup_x1)
    T.TensorOp.select(sel_out, input_sel_x1, input_sel_x2)
    T.TensorOp.conv_f16tos8r(conv_out, input_conv_x1)
    T.TensorOp.store(conv_out)


@op_registry.register(OpType.Equal, BackendType.THEO)
class TheoEqual(TheoreticalOperator):
    operator_dsl = theo_equal

    def _input_check(self):
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        if len(input_shapes) != 1:
            raise ValueError("[TheoOp.equal]: inputs len must be 1")

        if len(output_shapes) != 1:
            raise ValueError("[TheoOp.equal]: outputs len must be 1")

        for shape in input_shapes:
            if len(shape) != 2:
                raise ValueError("[TheoOp.equal]: input dim must be 2")
            if shape[0] != output_shapes[0][0]:
                raise ValueError("[TheoOp.equal]: input dim0 not match output")
            if shape[1] != output_shapes[0][1]:
                raise ValueError("[TheoOp.equal]: input dim1 not match output")

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        dynamic_shape = {
            'm1': input_shapes[0][0],
            'n1': input_shapes[0][1],
            'm2': output_shapes[0][0],
            'n2': output_shapes[0][1]
        }
        return dynamic_shape