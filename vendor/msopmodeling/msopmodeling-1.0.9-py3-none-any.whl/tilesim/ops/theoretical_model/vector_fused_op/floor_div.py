# Copyright (c) Huawei Technologies Co., Ltd. 2025-2026. All rights reserved.

from typing import Any

from core.common.backend_config import BackendConfig, FitParamKey
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.common import op_registry
from core.common import OpType, BackendType


def floor_div():
    """
    floor_div算子DSL实现
    """
    pass


@op_registry.register(OpType.FloorDiv, BackendType.THEO)
class TheoFloorDiv(TheoreticalOperator):
    operator_dsl = floor_div

    def _input_check(self):
        pass

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        pass

    def _adjust_coeff(self, backend_config: BackendConfig):
        fit_param = backend_config.eval_config.fit_param

        if FitParamKey.BW_COEFF not in fit_param:
            fit_param[FitParamKey.BW_COEFF] = 0.0

        if FitParamKey.COMP_COEFF not in fit_param:
            fit_param[FitParamKey.COMP_COEFF] = 0.0

        if FitParamKey.SCALAR_TIME not in fit_param:
            fit_param[FitParamKey.SCALAR_TIME] = 45.51