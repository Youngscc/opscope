# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math
from typing import Any

from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.common import op_registry
from core.common import OpType, BackendType, DType, MemLoc
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

a = 128 * 128
b = 128 * 128


def theo_greater_equal(src1: Tensor(shape=[a], dtype=DType.FP32, mem_loc=MemLoc.GM),
                       output: Tensor(shape=[b], dtype=DType.FP32, mem_loc=MemLoc.GM)):
    """
    Greater Equal 算子DSL实现
    Args:
        src1:
        output:

    Returns:

    """

    input_cmpv_ge_x1 = Tensor(shape=[a], dtype=DType.FP32, mem_loc=MemLoc.GM)
    input_cmpv_ge_x2 = Tensor(shape=[a], dtype=DType.FP32, mem_loc=MemLoc.GM)
    cmpv_ge_out = Tensor(shape=[a], dtype=DType.FP16, mem_loc=MemLoc.UB)

    input_dup_x1 = Tensor(shape=[a], dtype=DType.FP16, mem_loc=MemLoc.UB)
    dup_out = Tensor(shape=[a], dtype=DType.FP16, mem_loc=MemLoc.UB)

    input_sel_x1 = Tensor(shape=[a], dtype=DType.FP16, mem_loc=MemLoc.UB)
    input_sel_x2 = Tensor(shape=[a], dtype=DType.FP16, mem_loc=MemLoc.UB)
    sel_out = Tensor(shape=[a], dtype=DType.FP16, mem_loc=MemLoc.UB)

    input_conv_x1 = Tensor(shape=[a], dtype=DType.FP16, mem_loc=MemLoc.UB)
    conv_out = Tensor(shape=[b], dtype=DType.INT8, mem_loc=MemLoc.UB)

    T.TensorOp.cmpv_eq(cmpv_ge_out, input_cmpv_ge_x1, input_cmpv_ge_x2)
    T.TensorOp.vector_dup(dup_out, input_dup_x1)
    T.TensorOp.select(sel_out, input_sel_x1, input_sel_x2)
    T.TensorOp.conv_f16tos8r(conv_out, input_conv_x1)
    T.TensorOp.store(conv_out)


@op_registry.register(OpType.GreaterEqual, BackendType.THEO)
class TheoGreaterEqual(TheoreticalOperator):
    operator_dsl = theo_greater_equal

    def _input_check(self):
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        if len(input_shapes) != 1:
            raise ValueError("[TheoOp.greaterequal]: inputs len must be 1")

        if len(output_shapes) != 1:
            raise ValueError("[TheoOp.greaterequal]: outputs len must be 1")

        for i, shape in enumerate(input_shapes[0]):
            if shape != output_shapes[0][i]:
                raise ValueError(f"[TheoOp.greaterequal]: input dim{i} not match output")

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        dynamic_shape = {
            'a': math.prod(input_shapes[0]),
            'b': math.prod(output_shapes[0])
        }
        return dynamic_shape