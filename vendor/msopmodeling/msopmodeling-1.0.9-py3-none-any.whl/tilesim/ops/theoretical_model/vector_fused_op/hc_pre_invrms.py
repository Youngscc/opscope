# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.common import OpType, BackendType, MemLoc, DType
from core.common import op_registry
from core.common.backend_config import BackendConfig, FitParamKey
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

T, HC, D, HC_D, dtype = T.define_symbol(5)


# 常见shape：HC = 4，D = 4096

def hc_pre_invrms(x: Tensor(shape=[T, HC, D], dtype=dtype, mem_loc=MemLoc.GM),
                  inv_rms_out: Tensor(shape=[T, 1], dtype=dtype, mem_loc=MemLoc.GM)
                  ):
    """hc_pre_invrms 算子DSL实现，返回 1 / Rms(x)"""
    x_2d = Tensor(shape=[T, HC_D], dtype=dtype, mem_loc=MemLoc.UB)
    x_fp32 = Tensor(shape=[T, HC_D], dtype=DType.FP32, mem_loc=MemLoc.UB)
    x_rms_reduce = Tensor(shape=[T, 1], dtype=DType.FP32, mem_loc=MemLoc.UB)
    scalar = Tensor(shape=[1], dtype=DType.FP32, mem_loc=MemLoc.UB)

    T.TensorOp.null_op(x_2d, x)
    T.TensorOp.cast(x_fp32, x_2d)

    T.TensorOp.mul(x_fp32, x_fp32, x_fp32)  # x * x
    T.TensorOp.reduce_sum(x_rms_reduce, x_fp32, config={
        'reduce_axis': -1, 'keepdim': True
    })
    T.TensorOp.muls(x_rms_reduce, x_rms_reduce, scalar)
    T.TensorOp.adds(x_rms_reduce, x_rms_reduce, scalar)
    T.TensorOp.sqrt(x_rms_reduce, x_rms_reduce)

    T.TensorOp.div(x_rms_reduce, scalar, x_rms_reduce)  # 1 / rms_res
    T.TensorOp.store(x_rms_reduce)  # inv_rms_out


@op_registry.register(OpType.HcPreInvRms, BackendType.THEO)
class TheoHcPreInvRms(TheoreticalOperator):
    operator_dsl = hc_pre_invrms

    def _input_check(self):
        pass

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        shape_T = self.op_input.input_shapes[0][0]
        shape_HC = self.op_input.input_shapes[0][1]
        shape_D = self.op_input.input_shapes[0][2]
        dynamic_shape = {
            'T': shape_T,
            'HC': shape_HC,
            'D': shape_D,
            'HC_D': shape_HC * shape_D,
            'dtype': self.op_input.input_dtypes[0],
        }
        return dynamic_shape

    def _adjust_coeff(self, backend_config: BackendConfig):
        fit_param = backend_config.eval_config.fit_param

        if FitParamKey.BW_COEFF not in fit_param:
            fit_param[FitParamKey.BW_COEFF] = 0.3

        if FitParamKey.COMP_COEFF not in fit_param:
            fit_param[FitParamKey.COMP_COEFF] = 1.0

        if FitParamKey.SCALAR_TIME not in fit_param:
            fit_param[FitParamKey.SCALAR_TIME] = 0.0