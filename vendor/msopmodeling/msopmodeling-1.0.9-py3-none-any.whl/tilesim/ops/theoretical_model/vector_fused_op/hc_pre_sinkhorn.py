# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.common import OpType, BackendType, MemLoc, DType
from core.common import op_registry
from core.common.backend_config import BackendConfig, FitParamKey
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

T, HC, D, MIX_HC, HC_D, HC_HC, dtype = T.define_symbol(7)


def mhc_pre_sinkhorn(mm_res: Tensor(shape=[T, MIX_HC], dtype=DType.FP32, mem_loc=MemLoc.GM),
                     inv_rms: Tensor(shape=[T, 1], dtype=DType.FP32, mem_loc=MemLoc.GM),
                     hc_scale_: Tensor(shape=[3], dtype=DType.FP32, mem_loc=MemLoc.GM),
                     hc_base_: Tensor(shape=[MIX_HC], dtype=DType.FP32, mem_loc=MemLoc.GM),
                     x: Tensor(shape=[T, HC, D], dtype=dtype, mem_loc=MemLoc.GM),
                     y_out: Tensor(shape=[T, D], dtype=dtype, mem_loc=MemLoc.GM),
                     post_out: Tensor(shape=[T, HC], dtype=DType.FP32, mem_loc=MemLoc.GM),
                     comb_out: Tensor(shape=[T, HC, HC], dtype=DType.FP32, mem_loc=MemLoc.GM),
                     ):
    """mhc_pre_sinkhorn 算子DSL实现"""
    x_2d = Tensor(shape=[T, HC_D], dtype=dtype, mem_loc=MemLoc.UB)
    x_fp32 = Tensor(shape=[T, HC_D], dtype=DType.FP32, mem_loc=MemLoc.UB)
    scalar = Tensor(shape=[1], dtype=DType.FP32, mem_loc=MemLoc.UB)
    rms_res_broadcast = Tensor(shape=[T, MIX_HC], dtype=DType.FP32, mem_loc=MemLoc.UB)
    hc_scale_hc = Tensor(shape=[3, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)
    hc_base_ub = Tensor(shape=[MIX_HC], dtype=DType.FP32, mem_loc=MemLoc.UB)
    # NEXT -- 下方的slice后的tensor需要关联切分前的
    rms_res_slice_0 = Tensor(shape=[T, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)  # rms_res_broadcast[:, :hc]
    rms_res_slice_1 = Tensor(shape=[T, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)  # rms_res_broadcast[:, hc : 2 * hc]
    rms_res_slice_2 = Tensor(shape=[T, HC_HC], dtype=DType.FP32, mem_loc=MemLoc.UB)  # rms_res_broadcast[:, 2 * hc :]
    hc_scale_hc_slice_0 = Tensor(shape=[1, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)  # hc_scale_hc[0:1, :]
    hc_scale_hc_slice_1 = Tensor(shape=[1, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)  # hc_scale_hc[1:2, :]
    hc_scale_hc_slice_2 = Tensor(shape=[1, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)  # hc_scale_hc[2:3, :]
    hc_base_slice_0 = Tensor(shape=[1, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)  # hc_base[:, :hc]
    hc_base_slice_1 = Tensor(shape=[1, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)  # hc_base[:, hc : 2 * hc]
    hc_base_slice_2 = Tensor(shape=[T, HC_HC], dtype=DType.FP32, mem_loc=MemLoc.UB)  # hc_base[:, 2 * hc :]
    pre = Tensor(shape=[T, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)
    post = Tensor(shape=[T, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)
    x_reduce = Tensor(shape=[T, D], dtype=DType.FP32, mem_loc=MemLoc.UB)
    x_reduce_out = Tensor(shape=[T, D], dtype=dtype, mem_loc=MemLoc.UB)
    comb = Tensor(shape=[T, HC_HC], dtype=DType.FP32, mem_loc=MemLoc.UB)
    comb_reshape = Tensor(shape=[T, HC, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)
    comb_reduce_row = Tensor(shape=[T, HC, 1], dtype=DType.FP32, mem_loc=MemLoc.UB)  # 按照sinkhorn定义的row，规约轴为-1
    comb_reduce_col = Tensor(shape=[T, 1, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)

    T.TensorOp.null_op(x_2d, x)
    T.TensorOp.cast(x_fp32, x_2d)
    T.TensorOp.null_op(hc_base_ub, hc_base_)
    T.TensorOp.broadcast(hc_scale_hc, hc_scale_)  # hc_scale_hc = hc_scale.expand_clone([3, hc])
    T.TensorOp.mul(rms_res_broadcast, mm_res, inv_rms)  # rms_res = mm_res * inv_rms

    # =============== 计算y开始 =================
    T.TensorOp.mul(pre, rms_res_slice_0, hc_scale_hc_slice_0)  # pre = rms_res[:, :hc] * (hc_scale_hc[0:1, :])
    T.TensorOp.add(pre, pre, hc_base_slice_0)  # pre = pre + hc_base[:, :hc]
    # =============== 计算sigmoid(pre)开始 =================
    T.TensorOp.muls(pre, pre, scalar)  # x_neg = pypto.mul(x, -1.0)
    T.TensorOp.exp(pre, pre)  # exp_neg = pypto.exp(x_neg)
    T.TensorOp.div(pre, pre, pre)  # sigmoid = pypto.div(ones, exp_neg + 1.0)，其中ones的shape和pre相同
    # =============== 计算sigmoid(pre)结束 =================
    T.TensorOp.adds(pre, pre, scalar)  # pre = sigmoid(pre) + hc_eps
    T.TensorOp.mul(x_fp32, pre, x_fp32)  # mul_res = pre_3d * x_fp32_3d
    T.TensorOp.reduce_sum(x_reduce, x_fp32, config={
        'reduce_axis': -2
    })  # res_fp32 = pypto.sum(mul_res, dim=-2)
    T.TensorOp.cast(x_reduce_out, x_reduce)  # res_bf16 = pypto.cast(res_fp32, pypto.DT_BF16)
    T.TensorOp.store(x_reduce_out)  # y_out
    # =============== 计算y结束 =================

    # =============== 计算post开始 =================
    T.TensorOp.mul(post, rms_res_slice_1, hc_scale_hc_slice_1)
    T.TensorOp.add(post, post, hc_base_slice_1)
    # =============== 计算sigmoid(post)开始 =================
    T.TensorOp.muls(post, post, scalar)
    T.TensorOp.exp(post, post)
    T.TensorOp.div(post, post, post)
    # =============== 计算sigmoid(post)结束 =================
    T.TensorOp.muls(post, post, scalar)
    T.TensorOp.store(post)  # post_out
    # =============== 计算post结束 =================

    # =============== 计算comb开始 =================
    T.TensorOp.broadcast(hc_scale_hc, hc_scale_)  # hc_scale_hc = hc_scale.expand_clone([3, 4 * hc])
    T.TensorOp.mul(comb, rms_res_slice_2, hc_scale_hc_slice_2)
    T.TensorOp.add(comb, comb, hc_base_slice_2)
    T.TensorOp.null_op(comb_reshape, comb)  # reshape
    # =============== 计算hc_split_sinkhorn开始 =================
    T.TensorOp.reduce_max(comb_reduce_row, comb_reshape, config={
        'reduce_axis': -1, 'keepdim': True
    })  # row_max = pypto.amax(comb_flag, -1, True)
    T.TensorOp.sub(comb_reshape, comb_reshape, comb_reduce_row)  # comb_flag - row_max
    T.TensorOp.exp(comb_reshape, comb_reshape)
    for i in range(20):
        T.TensorOp.reduce_sum(comb_reduce_row, comb_reshape, config={
            'reduce_axis': -1, 'keepdim': True
        })  # row_sum = pypto.sum(comb_flag, -1, True)
        T.TensorOp.adds(comb_reduce_row, comb_reduce_row, scalar)
        T.TensorOp.div(comb_reshape, comb_reshape, comb_reduce_row)  # comb_flag / row_sum
        T.TensorOp.reduce_sum(comb_reduce_col, comb_reshape, config={
            'reduce_axis': -2, 'keepdim': True
        })  # col_sum = pypto.sum(comb_flag, -2, True)
        T.TensorOp.adds(comb_reduce_col, comb_reduce_col, scalar)
        T.TensorOp.div(comb_reshape, comb_reshape, comb_reduce_col)  # comb_flag / row_sum
    # =============== 计算hc_split_sinkhorn结束 =================
    T.TensorOp.store(comb_reshape)  # comb_out
    # =============== 计算comb结束 =================


@op_registry.register(OpType.HcPreSinkhorn, BackendType.THEO)
class TheoHcPreSinkhorn(TheoreticalOperator):
    operator_dsl = mhc_pre_sinkhorn

    def _input_check(self):
        pass

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        shape_T = self.op_input.input_shapes[4][0]
        shape_HC = self.op_input.input_shapes[4][1]
        shape_D = self.op_input.input_shapes[4][2]
        dynamic_shape = {
            'T': shape_T,
            'HC': shape_HC,
            'D': shape_D,
            'MIX_HC': (2 + shape_HC) * shape_HC,
            'HC_D': shape_HC * shape_D,
            'HC_HC': shape_HC * shape_HC,
            'dtype': self.op_input.input_dtypes[4],
        }
        return dynamic_shape

    def _adjust_coeff(self, backend_config: BackendConfig):
        fit_param = backend_config.eval_config.fit_param

        if FitParamKey.BW_COEFF not in fit_param:
            fit_param[FitParamKey.BW_COEFF] = 0.12

        if FitParamKey.COMP_COEFF not in fit_param:
            fit_param[FitParamKey.COMP_COEFF] = 1.0

        if FitParamKey.SCALAR_TIME not in fit_param:
            fit_param[FitParamKey.SCALAR_TIME] = 0.0