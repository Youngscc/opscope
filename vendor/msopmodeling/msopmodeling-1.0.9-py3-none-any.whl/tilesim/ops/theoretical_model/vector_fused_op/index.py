# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math
from typing import Any

from core.common import OpType, BackendType, MemLoc, DType
from core.common import op_registry
from core.common.backend_config import FitParamKey, BackendConfig
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

a, b, c, dtype = T.define_symbol(4)


def index(self: Tensor(shape=[a], dtype=dtype, mem_loc=MemLoc.GM),
          indices: Tensor(shape=[b], dtype=DType.INT32, mem_loc=MemLoc.GM),
          out: Tensor(shape=[c], dtype=dtype, mem_loc=MemLoc.GM)
          ):
    """Index 算子DSL实现，实际搬运量与self无关，只与indices有关"""
    indices_ub = Tensor(shape=[b], dtype=DType.INT32, mem_loc=MemLoc.UB)
    out_ub = Tensor(shape=[c], dtype=dtype, mem_loc=MemLoc.UB)
    T.TensorOp.null_op(indices_ub, indices)
    T.TensorOp.copy(out_ub, out_ub)
    T.TensorOp.store(out_ub)


@op_registry.register(OpType.Index, BackendType.THEO)
class TheoIndex(TheoreticalOperator):
    operator_dsl = index

    def _input_check(self):
        if len(self.op_input.input_shapes) < 4:
            raise ValueError("[TheoIndex] input length must >= 4")
        if not self.op_input.output_shapes:
            raise ValueError("[TheoIndex] output length must >= 1")

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        dynamic_shape = {
            'a': math.prod(self.op_input.input_shapes[0]),
            'b': math.prod(self.op_input.input_shapes[3]),
            'c': math.prod(self.op_input.output_shapes[0]),
            'dtype': self.op_input.input_dtypes[0],
        }
        return dynamic_shape

    def _adjust_coeff(self, backend_config: BackendConfig):
        fit_param = backend_config.eval_config.fit_param

        if FitParamKey.BW_COEFF not in fit_param:
            fit_param[FitParamKey.BW_COEFF] = 0.004

        if FitParamKey.COMP_COEFF not in fit_param:
            fit_param[FitParamKey.COMP_COEFF] = 1

        if FitParamKey.SCALAR_TIME not in fit_param:
            fit_param[FitParamKey.SCALAR_TIME] = 8.0