# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math
from typing import Any

from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.common import op_registry
from core.common import OpType, BackendType, DType, MemLoc
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor
from ops.theoretical_model.vector_fused_op.reduce_max import ReduceExtraParam

d1, d2 = 128, 128
d_type = DType.FP32
mem_loc = MemLoc.GM
r = 1
e = 64


def reduce_sum_basic(
        src: Tensor(shape=[d1, d2], dtype=d_type, mem_loc=mem_loc),
        dst: Tensor(shape=[d1, 1], dtype=d_type, mem_loc=mem_loc),
):
    """
    ReduceSum 算子DSL实现
    Args:
        src:
        dst:
        r:
        e:

    Returns:

    """

    tmp = Tensor(shape=[d1, e], dtype=d_type, mem_loc=MemLoc.UB)
    tmp_output = Tensor(shape=[d1, e], dtype=d_type, mem_loc=MemLoc.UB)
    dst_ub = Tensor(shape=[d1, 1], dtype=d_type, mem_loc=MemLoc.UB)
    for _ in range(r):
        T.TensorOp.view(tmp, src)
        T.TensorOp.add(tmp_output, tmp, tmp_output)

    T.TensorOp.reduce_sum(dst_ub, tmp_output, config={"axis": 1})
    T.TensorOp.store(dst_ub)


@op_registry.register(OpType.ReduceSum, BackendType.THEO)
class TheoReduceSum(TheoreticalOperator):
    extra_param_class = ReduceExtraParam
    operator_dsl = reduce_sum_basic

    def _input_check(self):
        pass

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        a_axis = 1
        r_axis = 1
        has_r_axis = False
        param: ReduceExtraParam = self.op_input.param
        if param.reduce_axis is None or len(param.reduce_axis) == 0:
            reduce_axis = [-1]
        else:
            reduce_axis = param.reduce_axis

        for i in reduce_axis:
            r_axis *= self.op_input.input_shapes[0][i]
            has_r_axis = True

        for i in range(len(self.op_input.input_shapes[0])):
            a_axis *= self.op_input.input_shapes[0][i]

        a_axis /= r_axis

        if not has_r_axis:
            raise ValueError("[TheoOp.reduce_sum]: reduce_axis must have at least one element")

        dynamic_shape = {
            "d1": int(a_axis),
            "d2": r_axis,
            "r": math.ceil(r_axis / e),
            "e": int(256 / self.op_input.input_dtypes[0].size),
            "d_type": self.op_input.input_dtypes[0],
            "mem_loc": MemLoc.GM,
        }

        return dynamic_shape