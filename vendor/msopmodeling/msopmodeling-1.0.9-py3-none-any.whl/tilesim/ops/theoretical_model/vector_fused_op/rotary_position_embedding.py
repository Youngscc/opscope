# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math
from typing import Any

from core.common.backend_config import BackendConfig, FitParamKey
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.common import op_registry
from core.common import OpType, BackendType, MemLoc
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

x_size, sin_cos_size, dtype = T.define_symbol(3)


def rotary_position_embedding(x: Tensor(shape=[x_size], dtype=dtype, mem_loc=MemLoc.GM),
                              sin: Tensor(shape=[sin_cos_size], dtype=dtype, mem_loc=MemLoc.GM),
                              cos: Tensor(shape=[sin_cos_size], dtype=dtype, mem_loc=MemLoc.GM),
                              out: Tensor(shape=[x_size], dtype=dtype, mem_loc=MemLoc.GM),
                              ):
    """
    rotary_position_embedding算子DSL实现
    """
    input_ub = Tensor(shape=[x_size], dtype=dtype, mem_loc=MemLoc.UB)
    _cs = Tensor(shape=[sin_cos_size], dtype=dtype, mem_loc=MemLoc.UB)
    _out = Tensor(shape=[x_size], dtype=dtype, mem_loc=MemLoc.UB)

    T.TensorOp.null_op(input_ub, x)
    T.TensorOp.null_op(_cs, sin)
    T.TensorOp.null_op(_cs, cos)

    # NEXT 此处暂时省去VMULS,该指令可能用于实现广播
    T.TensorOp.mul(input_ub, input_ub, _cs)
    T.TensorOp.copy(input_ub, input_ub)
    T.TensorOp.mul(input_ub, input_ub, _cs)
    # NEXT 此处暂时省去VMULS,该指令可能用于实现广播
    T.TensorOp.add(_out, input_ub, input_ub)
    T.TensorOp.store(_out)


@op_registry.register(OpType.RotaryPositionEmbedding, BackendType.THEO)
class TheoRotaryPositionEmbedding(TheoreticalOperator):
    operator_dsl = rotary_position_embedding

    def _input_check(self):
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        if len(input_shapes) != 3:
            raise ValueError(f"[TheoOp.{TheoRotaryPositionEmbedding.op_name}]: inputs len must be 3")
        if len(output_shapes) != 1:
            raise ValueError(f"[TheoOp.{TheoRotaryPositionEmbedding.op_name}]: outputs len must be 1")
        if input_shapes[1] != input_shapes[2]:
            raise ValueError(f"[TheoOp.{TheoRotaryPositionEmbedding.op_name}]: sin shape and cos shape must be equal")
        if input_shapes[0][-1] != output_shapes[0][-1] or input_shapes[1][-1] != output_shapes[0][-1] \
                or input_shapes[2][-1] != output_shapes[0][-1]:
            raise ValueError(
                f"[TheoOp.{TheoRotaryPositionEmbedding.op_name}]: input_shape and output_shape last dim must be equal")
        pass

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        """
            InputShapes:
            1.x
            2.cos
            3.sin

            OutputShapes:
            1.output
        """
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        input_dtypes = self.op_input.input_dtypes
        dynamic_shape = {
            'x_size': math.prod(output_shapes[0]),
            'sin_cos_size': math.prod(input_shapes[1]),
            'dtype': input_dtypes[0]
        }
        return dynamic_shape

    def _adjust_coeff(self, backend_config: BackendConfig):
        fit_param = backend_config.eval_config.fit_param

        if FitParamKey.BW_COEFF not in fit_param:
            fit_param[FitParamKey.BW_COEFF] = 0.04

        if FitParamKey.COMP_COEFF not in fit_param:
            fit_param[FitParamKey.COMP_COEFF] = 1.0

        if FitParamKey.SCALAR_TIME not in fit_param:
            fit_param[FitParamKey.SCALAR_TIME] = 2.7