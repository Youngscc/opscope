# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.common import op_registry
from core.common import OpType, BackendType, DType, MemLoc
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

M1 = M2 = 128
N1 = N2 = 64
M3 = N3 = 128
M4 = N4 = 128
dtype = DType.FP32
mem_loc = MemLoc.GM


def select_v2(
        x: Tensor(shape=[M1, N1], dtype=dtype, mem_loc=mem_loc),
        y: Tensor(shape=[M2, N2], dtype=dtype, mem_loc=mem_loc),
        condition: Tensor(shape=[M3, N3], dtype=dtype, mem_loc=mem_loc),
        out: Tensor(shape=[M4, N4], dtype=dtype, mem_loc=mem_loc)):
    """
    select_v2 算子DSL实现
    Args:
        x:
        y:
        condition:
        out:

    Returns:

    """
    out_ub = Tensor(shape=[M4, N4], dtype=dtype, mem_loc=MemLoc.UB)
    T.TensorOp.broadcast(out_ub, x)
    T.TensorOp.broadcast(out_ub, y)
    T.TensorOp.broadcast(out_ub, condition)
    T.TensorOp.vcmpvs(out_ub, out_ub, out_ub)
    T.TensorOp.store(out_ub)


@op_registry.register(OpType.SelectV2, BackendType.THEO)
class TheoSelectV2(TheoreticalOperator):
    operator_dsl = select_v2

    def _input_check(self):
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        if len(input_shapes) != 1:
            raise ValueError(f"[TheoOp.{TheoSelectV2.op_name}]: inputs len must be 1")

        if len(output_shapes) != 1:
            raise ValueError(f"[TheoOp.{TheoSelectV2.op_name}]: outputs len must be 1")

        for shape in input_shapes:
            if len(shape) != 2:
                raise ValueError(f"[TheoOp.{TheoSelectV2.op_name}]: input dim must be 2")
            if shape[0] != output_shapes[0][0] and shape[0] != 1:
                raise ValueError(f"[TheoOp.{TheoSelectV2.op_name}]: input dim0 not match output")
            if shape[1] != output_shapes[0][1] and shape[1] != 1:
                raise ValueError(f"[TheoOp.{TheoSelectV2.op_name}]: input diM1 not match output")

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        dynamic_shape = {
            'M1': self.op_input.input_shapes[0][0],
            'N1': self.op_input.input_shapes[0][1],
            'M2': self.op_input.output_shapes[0][0],
            'N2': self.op_input.output_shapes[0][1],
            'dtype': self.op_input.input_dtypes[0],
            'mem_loc': MemLoc.GM,
        }

        return dynamic_shape