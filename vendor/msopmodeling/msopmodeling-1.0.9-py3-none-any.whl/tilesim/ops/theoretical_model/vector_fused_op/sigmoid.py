# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math
from typing import Any

from core.common.backend_config import BackendConfig, FitParamKey
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.common import op_registry
from core.common import OpType, BackendType, DType, MemLoc
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

i_shape, dtype = T.define_symbol(2)


def sigmoid(x: Tensor(shape=[i_shape], dtype=dtype, mem_loc=MemLoc.GM),
            out: Tensor(shape=[i_shape], dtype=dtype, mem_loc=MemLoc.GM)
            ):
    """
    sigmoid算子DSL实现
    """
    input_ub = Tensor(shape=[i_shape], dtype=dtype, mem_loc=MemLoc.UB)
    _one = Tensor(shape=[1], dtype=DType.FP32, mem_loc=MemLoc.UB)
    _out = Tensor(shape=[i_shape], dtype=dtype, mem_loc=MemLoc.UB)

    T.TensorOp.null_op(input_ub, x)
    T.TensorOp.muls(input_ub, input_ub, _one)
    T.TensorOp.exp(input_ub, input_ub)
    T.TensorOp.adds(input_ub, input_ub, _one)
    T.TensorOp.div(_out, _one, input_ub)
    T.TensorOp.store(_out)


@op_registry.register(OpType.Sigmoid, BackendType.THEO)
class TheoSigmoid(TheoreticalOperator):
    operator_dsl = sigmoid

    def _input_check(self):
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        if len(input_shapes) != 1:
            raise ValueError(f"[TheoOp.{TheoSigmoid.op_name}]: inputs len must be 1")
        if len(output_shapes) != 1:
            raise ValueError(f"[TheoOp.{TheoSigmoid.op_name}]: outputs len must be 1")
        pass

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        """
            InputShapes:
            1. x

            OutputShapes:
            1. out
        """
        input_shapes = self.op_input.input_shapes
        input_dtypes = self.op_input.input_dtypes
        dynamic_shape = {
            'i_shape': math.prod(input_shapes[0]),
            'dtype': input_dtypes[0]
        }
        return dynamic_shape

    def _adjust_coeff(self, backend_config: BackendConfig):
        fit_param = backend_config.eval_config.fit_param

        if FitParamKey.BW_COEFF not in fit_param:
            fit_param[FitParamKey.BW_COEFF] = 0.04

        if FitParamKey.COMP_COEFF not in fit_param:
            fit_param[FitParamKey.COMP_COEFF] = 3.0

        if FitParamKey.SCALAR_TIME not in fit_param:
            fit_param[FitParamKey.SCALAR_TIME] = 1.5