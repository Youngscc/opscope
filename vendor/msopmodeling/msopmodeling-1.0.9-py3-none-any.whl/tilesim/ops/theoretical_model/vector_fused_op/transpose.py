# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math
from typing import Any

from core.common import OpType, BackendType, MemLoc
from core.common import op_registry
from core.common.backend_config import FitParamKey, BackendConfig
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

a, dtype = T.define_symbol(2)


def transpose(x: Tensor(shape=[a], dtype=dtype, mem_loc=MemLoc.GM),
              out: Tensor(shape=[a], dtype=dtype, mem_loc=MemLoc.GM)
              ):
    """Transpose 算子DSL实现"""
    out_ub = Tensor(shape=[a], dtype=dtype, mem_loc=MemLoc.UB)
    T.TensorOp.null_op(out_ub, x)
    T.TensorOp.store(out_ub)


@op_registry.register(OpType.Transpose, BackendType.THEO)
class TheoTranspose(TheoreticalOperator):
    operator_dsl = transpose

    def _input_check(self):
        if len(self.op_input.output_shapes) < 1:
            raise ValueError("[TheoTranspose] input length must >= 1")
        if len(self.op_input.output_shapes) != 1:
            raise ValueError("[TheoTranspose] output length must be 1")
        input_size = math.prod(self.op_input.input_shapes[0])
        output_size = math.prod(self.op_input.output_shapes[0])
        if input_size != output_size:
            raise ValueError("[TheoTranspose] input and output size must be equal")

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        dynamic_shape = {
            'a': math.prod(self.op_input.input_shapes[0]),
            'dtype': self.op_input.input_dtypes[0],
        }
        return dynamic_shape

    def _adjust_coeff(self, backend_config: BackendConfig):
        fit_param = backend_config.eval_config.fit_param

        if FitParamKey.BW_COEFF not in fit_param:
            fit_param[FitParamKey.BW_COEFF] = 0.5

        if FitParamKey.COMP_COEFF not in fit_param:
            fit_param[FitParamKey.COMP_COEFF] = 1.0

        if FitParamKey.SCALAR_TIME not in fit_param:
            fit_param[FitParamKey.SCALAR_TIME] = 10.0