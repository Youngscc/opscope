# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math
from typing import Any

from core.common.backend_config import FitParamKey, BackendConfig
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.common import op_registry
from core.common import OpType, BackendType, MemLoc
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

DEST_SIZE, SRC_SIZE, dtype = T.define_symbol(3)


def view_copy(dest: Tensor(shape=[DEST_SIZE], dtype=dtype, mem_loc=MemLoc.GM),
              src: Tensor(shape=[SRC_SIZE], dtype=dtype, mem_loc=MemLoc.GM)
              ):
    """view_copy算子DSL实现"""
    _dest = Tensor(shape=[DEST_SIZE], dtype=dtype, mem_loc=MemLoc.UB)
    _src = Tensor(shape=[SRC_SIZE], dtype=dtype, mem_loc=MemLoc.UB)

    T.TensorOp.null_op(_dest, dest)
    T.TensorOp.null_op(_src, src)
    T.TensorOp.copy(_dest, _src)
    T.TensorOp.store(_dest)


@op_registry.register(OpType.ViewCopy, BackendType.THEO)
class TheoViewCopy(TheoreticalOperator):
    operator_dsl = view_copy

    def _input_check(self):
        # 输入为如下8个：
        # dst：代表输入的dst的storage，它的shape为storage的大小，如[8, 8400, 4]。
        # dst_size：一个一维tensor，如[3]，其中具体的value值为dst的size大小，如[8, 8400, 2]。
        # dst_stride：一个一维tensor，如[3]，其中具体的value值为dst的stride大小，如[33600,4,1]。
        # dst_storage_offset：一个一维tensor，如[1]，其中具体的value值为dst的offset大小，如[0]。
        # src：代表输入的src的storage，它的shape为storage的大小，如[8, 8400, 2]。
        # src_size：一个一维tensor，如[3]，其中具体的value值为src的size大小，如[8, 8400, 2]。
        # src_stride：一个一维tensor，如[3]，其中具体的value值为src的stride大小，如[16800,2,1]。
        # src_storage_offset：一个一维tensor，如[1]，其中具体的value值为src的offset大小，如[0]。
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        if len(input_shapes) != 8 and len(input_shapes) != 2:  # 输入个数为2的情况对应CopyInplace
            raise ValueError(f"[TheoOp.{TheoViewCopy.op_name}]: inputs len must be 8")
        if len(output_shapes) != 1:
            raise ValueError(f"[TheoOp.{TheoViewCopy.op_name}]: outputs len must be 1")
        if input_shapes[0] != output_shapes[0]:
            raise ValueError(f"[TheoOp.{TheoViewCopy.op_name}]: input_shapes[0] and output_shapes[0] must be equal")

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        input_dtypes = self.op_input.input_dtypes
        dynamic_shape = {
            'DEST_SIZE': math.prod(output_shapes[0]),  # NEXT -- 实际搬运大小由src_size确定，需要抓具体的值
            'SRC_SIZE': math.prod(input_shapes[4]) if len(input_shapes) == 8 else math.prod(input_shapes[1]),
            'dtype': input_dtypes[0]
        }
        return dynamic_shape

    def _adjust_coeff(self, backend_config: BackendConfig):
        fit_param = backend_config.eval_config.fit_param

        if FitParamKey.BW_COEFF not in fit_param:
            fit_param[FitParamKey.BW_COEFF] = 0.05

        if FitParamKey.COMP_COEFF not in fit_param:
            fit_param[FitParamKey.COMP_COEFF] = 1.0

        if FitParamKey.SCALAR_TIME not in fit_param:
            fit_param[FitParamKey.SCALAR_TIME] = 8.0