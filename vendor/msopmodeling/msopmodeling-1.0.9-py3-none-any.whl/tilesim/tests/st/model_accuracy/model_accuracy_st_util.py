# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math
import os

import pandas as pd

from api.operator_api.models.operator_api_models import OperatorPredictRequest
from api.operator_api.op_latency_predict import op_latency_predict as dsl_predict
from api.operator_api.op_latency_predict_engineering import op_latency_predict as classic_predict
from core.common import BackendType
from tests.st.profiling_convert_util import ProfilingDataFormat, get_profiling_data


def _run_predict(prof, accelerator_config_path, enable_fit: bool, backend_type: BackendType = BackendType.THEO):
    op_input = OperatorPredictRequest(op_name=prof['op_name'],
                                      input_shapes=prof['input_shapes'],
                                      output_shapes=prof['output_shapes'],
                                      input_precision=prof['input_precision'],
                                      output_precision=prof['output_precision'],
                                      accelerator=accelerator_config_path,
                                      core_num=prof['block_dim'],
                                      extra_param=prof.get('extra_param'))

    if enable_fit:
        if op_input.extra_param is None:
            op_input.extra_param = {}
        op_input.extra_param['enable_fit'] = True

    if backend_type == BackendType.THEO:
        op_input.backend_type = backend_type.value

    if backend_type == BackendType.ENG_CLASSIC:
        op_output = classic_predict(op_input)
    else:
        op_output = dsl_predict(op_input)
    return op_output


def _calculate_accuracy(true_data, predict_data):
    accuracy = 1 - abs(predict_data - true_data) / true_data
    return round(accuracy * 100, 2)


def model_check(accelerator: str,
                profiling_file_path: str,
                accuracy_required: float,
                profiling_format: ProfilingDataFormat = ProfilingDataFormat.ZHANLU,
                op_type_for_test: str = None,
                verbose=False,
                generate_csv=False):
    """理论极限、工程可达、旧版工程可达通用的st入口"""
    all_ops_result = {}  # {op_type: [total_prof_time, total_predict_time]}
    model_profiling_sum = 0
    df = pd.read_csv(profiling_file_path)
    accelerator_config_path = f"../../../../../core/config/arc_config/{accelerator}/{accelerator}.yaml"
    case_cache = {}
    print()
    for index, row in df.iterrows():
        prof = get_profiling_data(row, profiling_format)
        op_name = prof['op_name']
        input_shapes = prof['input_shapes']
        output_shapes = prof['output_shapes']
        input_precision = prof['input_precision']
        output_precision = prof['output_precision']
        block_dim = prof['block_dim']
        profiling_time = prof['profiling_time']
        parameters_input = prof.get('parameters_input', '')
        if op_type_for_test is not None and op_name != op_type_for_test:
            continue
        if math.isnan(profiling_time):
            # profiling采集不到时延数据，直接跳过
            continue

        # 计算时间
        key = f'{op_name}_{input_shapes}_{output_shapes}_{input_precision}_{output_precision}_{block_dim}_{parameters_input}'
        if key in case_cache:
            op_output = case_cache[key]
        else:
            for backend_type in [BackendType.ENG_CLASSIC, BackendType.THEO]:
                op_output = _run_predict(prof, accelerator_config_path, True, backend_type)
                if 'error' not in op_output:
                    break
                elif verbose:
                    print(op_output['error'])
            case_cache[key] = op_output
        latency = op_output.get('latency', 0)

        # 计算相对精度和绝对精度
        if verbose:
            accuracy = _calculate_accuracy(profiling_time, latency)
            absolute_accuracy = latency / profiling_time
            print(f'index = {index}, '
                  f'op_name = {op_name}, '
                  f'accuracy = {accuracy}%, '
                  f'absolute_accuracy = {round(absolute_accuracy * 100, 2)}%, '
                  f'predict_latency = {round(latency, 2)}, '
                  f'profiling = {round(profiling_time, 2)}, '
                  f'input_shapes = {input_shapes}, '
                  f'block_dim = {block_dim}')

        all_ops_result.setdefault(op_name, [0, 0])
        all_ops_result[op_name][0] += profiling_time
        all_ops_result[op_name][1] += latency
        model_profiling_sum += profiling_time

    # 累计精度比较
    acc_check_success = True
    op_name_list = []
    accumulate_accuracy_list = []
    op_proportion_list = []
    op_type_num = 0
    supported_op_type_num = 0
    supported_profiling_sum = 0
    supported_predict_sum = 0
    profiling_sum = 0
    for op_name, (profiling_total, predict_total) in all_ops_result.items():
        op_proportion = round(profiling_total / model_profiling_sum * 100, 2)
        op_proportion_list.append(op_proportion)
        accumulate_accuracy = _calculate_accuracy(profiling_total, predict_total)
        print(f'op_name: {op_name}, accumulate_accuracy = {accumulate_accuracy}%, op_proportion = {op_proportion}%')
        op_type_num += 1
        profiling_sum += profiling_total
        if predict_total > 0:
            supported_op_type_num += 1
            supported_profiling_sum += profiling_total
            supported_predict_sum += predict_total
        op_name_list.append(op_name)
        accumulate_accuracy_list.append(accumulate_accuracy)
        if accumulate_accuracy <= accuracy_required:
            acc_check_success = False
    if generate_csv:
        basename = os.path.basename(profiling_file_path)
        output_file_name = os.path.splitext(basename)[0] + '_tilesim_output.csv'
        df = pd.DataFrame({'op_name': op_name_list, 'accumulate_accuracy (%)': accumulate_accuracy_list,
                           'op_proportion (%)': op_proportion_list})
        df.to_csv(output_file_name, index=False, encoding="utf-8")
    model_total_acc = _calculate_accuracy(supported_profiling_sum, supported_predict_sum)
    cover_rate = supported_profiling_sum / profiling_sum * 100
    if op_type_for_test is None:
        # 不是单算子验证，则输出模型总体精度和算子覆盖率
        print(f'模型算子总体精度：{model_total_acc} %')
        print(f'算子覆盖率：{cover_rate} %')
    print("acc_check_success: ", acc_check_success)
    # NEXT -- 添加assert
    return op_name_list, accumulate_accuracy_list, op_proportion_list, model_total_acc, cover_rate
