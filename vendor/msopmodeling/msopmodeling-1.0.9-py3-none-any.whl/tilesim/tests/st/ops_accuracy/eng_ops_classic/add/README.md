# 1. 输入格式
输入格式要求 双目输入/单目输入，当单目输入的时候，认为第二个入参和第一个入参相同维度，支持1~n维的张量输入。
当维度为1的时候，认为rows = 维度大小，cols = 1。
当维度大于1时候，认为rows = 前n-1个维度乘积，cols = 最后一个维度大小

# 2. 精度说明
# 2.1 shape覆盖
基于：
Deepseek-v3-no-quant
Deepseek-v3-w8a8c8
Deepseek-v3.2
Qwen3-VL-MoE-image
Qwen3-VL-MoE-video
Qwen3Nex
的模型采集的相关Add数据
总体累计精度 约为49% ，shape较小的时候误差较大

# 2.2 微架构覆盖
覆盖910B4_1平台
