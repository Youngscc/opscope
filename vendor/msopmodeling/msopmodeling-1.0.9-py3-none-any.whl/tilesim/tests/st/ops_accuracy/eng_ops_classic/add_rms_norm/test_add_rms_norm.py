# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from tests.st.ops_accuracy.eng_ops_classic.eng_classic_ops_test_util import eng_classic_operator_check


def test_add_rms_norm_zhanlu_910B4_1():
    accelerator = '910B4-1'
    profiling_path = f'addrmsnorm_zhanlu_profiling_910B4_1.csv'
    eng_classic_operator_check(accelerator, profiling_path, accuracy_required=0.84, accumulate_accuracy=True)


def test_add_rms_norm_zhanlu_deepseek_bf16_910B4_1():
    accelerator = '910B4-1'
    profiling_path = f'addrmsnorm_zhanlu_deepseek_bf16_910B4_1.csv'
    eng_classic_operator_check(accelerator, profiling_path, accuracy_required=0.70, accumulate_accuracy=False)