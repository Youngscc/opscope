# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from tests.st.ops_accuracy.eng_ops_classic.eng_classic_ops_test_util import eng_classic_operator_check
from tests.st.profiling_convert_util import ProfilingDataFormat


def test_ascend_quant_v2_zhanlu_910B4_1():
    accelerator = '910B4-1'
    profiling_path = f'ascendquantv2_zhanlu_profiling_910B4_1.csv'
    eng_classic_operator_check(accelerator, profiling_path, accuracy_required=0.73, accumulate_accuracy=True)


def test_ascend_quant_v2_zhanlu_910B1_dpskv4():
    accelerator = '910B1'
    profiling_path = f'ascendquantv2_dpsk-v4-a3_zhanlu_profiling_910B1.csv'
    eng_classic_operator_check(accelerator, profiling_path, accuracy_required=0.25, accumulate_accuracy=True, profiling_format=ProfilingDataFormat.ZHANLU_PROF)
