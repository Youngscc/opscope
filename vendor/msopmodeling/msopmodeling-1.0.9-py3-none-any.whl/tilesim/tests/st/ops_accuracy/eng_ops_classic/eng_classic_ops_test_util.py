# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.common import BackendType
from tests.st.ops_accuracy.op_accuracy_st_util import ProfilingDataFormat, operator_check


def eng_classic_operator_check(accelerator: str, profiling_file_path: str, accuracy_required: float,
                               accumulate_accuracy: bool = False,
                               profiling_format: ProfilingDataFormat = ProfilingDataFormat.ZHANLU):
    """工程latency精度回归测试"""
    operator_check(
        accelerator=accelerator,
        profiling_file_path=profiling_file_path,
        accuracy_required=accuracy_required,
        accumulate_accuracy=accumulate_accuracy,
        enable_fit=False,
        profiling_format=profiling_format,
        backend_type=BackendType.ENG_CLASSIC
    )
