# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from tests.st.ops_accuracy.eng_ops_classic.eng_classic_ops_test_util import eng_classic_operator_check


def test_fusedinferattenionscore_zhanlu_deepseek_bf16_decode_910B4_1():
    accelerator = '910B4-1'
    profiling_path = f'fusedinferattenionscore_zhanlu_deepseek_bf16_910B4-1.csv'
    eng_classic_operator_check(accelerator, profiling_path, accuracy_required=0.87, accumulate_accuracy=True)


def test_fusedinferattenionscore_zhanlu_deepseek_quant_bf16_decode_910B4_1():
    accelerator = '910B4-1'
    profiling_path = f'fusedinferattenionscore_zhanlu_deepseek_quant_bf16_910B4-1.csv'
    eng_classic_operator_check(accelerator, profiling_path, accuracy_required=0.91, accumulate_accuracy=True)
