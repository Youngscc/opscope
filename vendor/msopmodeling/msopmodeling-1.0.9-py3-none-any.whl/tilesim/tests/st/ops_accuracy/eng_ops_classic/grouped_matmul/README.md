# 1. 输入格式

输入格式要求参照:

| tensor名字    | 数据类型 | 数据格式 | 维度信息            | cpu/npu |
|-------------|------|------|-----------------|---------|
| `queryNope` | bf16 | nd   | [1228, 16, 128] | npu     |
| `queryRope` | bf16 | nd   | [1228, 16, 64]  | npu     |
| `keyNope`   | bf16 | nd   | [828, 8, 128]   | npu     |
| `keyRope`   | bf16 | nd   | [828, 8, 64]    | npu     |
| `value`     | bf16 | nd   | [828, 8, 128]   | npu     |

# 2. 精度说明

# 2.1 shape覆盖

基于：
Deepseek-v3-no-quant
Deepseek-v3-w8a8c8
Deepseek-v3.2
Qwen3-VL-MoE-image
Qwen3-VL-MoE-video
Qwen3Nex
的模型采集的相关Add数据
总体累计精度 约为95.6% 

注意，本数据做了如下临时假设（尚未确认输入逻辑与计算逻辑），后续需要重新处理
1. 当MLA输入时，认为默认开启了Page Attention，当不传入实际的token数量的时候，认为使用了一半的s2大小
2. 当MLA计算的时候，默认开启triu，对于triu的处理为：认为计算量/访存量都减半，粗暴的在最终时间计算处处理成了0.5

# 2.2 微架构覆盖

覆盖910B4_1平台
