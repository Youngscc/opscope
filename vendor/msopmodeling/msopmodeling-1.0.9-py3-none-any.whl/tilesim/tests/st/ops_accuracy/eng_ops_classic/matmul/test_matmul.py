# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from tests.st.ops_accuracy.eng_ops_classic.eng_classic_ops_test_util import eng_classic_operator_check
from tests.st.profiling_convert_util import ProfilingDataFormat


# 也可以所有场景都放到一起测试（这样没覆盖的场景可能会过不了）
def test_matmul_general():
    """matmul的算子精度测试"""
    accelerator = '910B1'
    profiling_path = f'op_summary_910B1.csv'
    eng_classic_operator_check(accelerator=accelerator, profiling_file_path=profiling_path, accuracy_required=0.9, profiling_format=ProfilingDataFormat.MSPROF)


def test_matmul2_zhanlu_910B4_1():
    accelerator = '910B4-1'
    profiling_path = f'matmulv2_zhanlu_profiling_910B4_1.csv'
    eng_classic_operator_check(accelerator, profiling_path, accuracy_required=0.71, accumulate_accuracy=True)


def test_matmul3_zhanlu_910B4_1():
    accelerator = '910B4-1'
    profiling_path = f'matmulv3_zhanlu_profiling_910B4_1.csv'
    eng_classic_operator_check(accelerator, profiling_path, accuracy_required=0.93, accumulate_accuracy=True)
