# 1. 输入格式
目前验证了：(k1，n1，n0，k0) 或 (n1，k1，k0，n0) 格式，其中ceil(k / k0) = k1，ceil(n / n0) = n1输入格式

# 2. 精度说明
# 2.1 shape覆盖
覆盖DeepseekV3 Prefill阶段用到的QBMM。
tiling设置为
INT8: m,n,k1,k0 = 128,256,256,64
FP16: m,n,k1,k0 = 128,128,256,64
FP32: m,n,k1,k0 = 128,64,256,64
除 case12~14外，精度为 80%+

# 2.2 微架构覆盖
覆盖910B4平台
