# 1. 输入格式
src1：[...] 多维向量

src2：[...] 多维向量，可以不输入

无论src2的shape如何，以src1的shape为计算量

# 2. 精度说明

# 2.1 理论极限性能
[a] 平台： 910B4-1 平台

[b] 场景：
Deepseek-v3-no-quant
Deepseek-v3-w8a8c8
Deepseek-v3.2
Qwen3-VL-MoE-image
Qwen3-VL-MoE-video
Qwen3Next

[c] 精度：
8.95%

# 2.2 理论极限性能+系数拟合
[a] 平台： 910B4-1 平台

[b] 场景：
Deepseek-v3-no-quant
Deepseek-v3-w8a8c8
Deepseek-v3.2
Qwen3-VL-MoE-image
Qwen3-VL-MoE-video
Qwen3Next

[c] 精度：
97.07%
