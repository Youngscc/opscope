# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from tests.st.profiling_convert_util import ProfilingDataFormat
from tests.st.ops_accuracy.theo_ops.theo_ops_test_util import theo_operator_check


def test_compressor_zhanlu_build_in_910B1_fit():
    accelerator = '910B1'
    profiling_path = f'compressor_dpsk-v4-build-in_zhanlu_profiling_910B1.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.80, accumulate_accuracy=True, enable_fit=True, profiling_format=ProfilingDataFormat.ZHANLU)


def test_compressor_zhanlu_build_in_910B1_limit():
    accelerator = '910B1'
    profiling_path = f'compressor_dpsk-v4-build-in_zhanlu_profiling_910B1.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.087, accumulate_accuracy=True, profiling_format=ProfilingDataFormat.ZHANLU)
