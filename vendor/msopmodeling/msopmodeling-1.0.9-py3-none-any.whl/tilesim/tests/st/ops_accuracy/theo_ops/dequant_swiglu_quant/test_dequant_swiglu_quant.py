# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from tests.st.ops_accuracy.theo_ops.theo_ops_test_util import theo_operator_check
from tests.st.profiling_convert_util import ProfilingDataFormat


def test_dequant_swiglu_quant_fit():
    # NEXT 拟合之前预测时间比实测长
    accelerator = '910B1'
    profiling_path = f'dequant_swiglu_quant.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.99, accumulate_accuracy=True, enable_fit=True,
                        profiling_format=ProfilingDataFormat.SGLANG_PROF)
