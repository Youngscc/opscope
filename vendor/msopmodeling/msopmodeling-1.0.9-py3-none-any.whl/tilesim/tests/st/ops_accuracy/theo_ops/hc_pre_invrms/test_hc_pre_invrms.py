# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from tests.st.profiling_convert_util import ProfilingDataFormat
from tests.st.ops_accuracy.theo_ops.theo_ops_test_util import theo_operator_check


def test_hc_pre_invrms_910B1():
    accelerator = '910B1'
    profiling_path = f'hc_pre_invrms.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.28, accumulate_accuracy=True,
                        enable_fit=False, profiling_format=ProfilingDataFormat.MSPROF)


def test_hc_pre_invrms_910B1_fit():
    accelerator = '910B1'
    profiling_path = f'hc_pre_invrms.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.96, accumulate_accuracy=True, enable_fit=True,
                        profiling_format=ProfilingDataFormat.MSPROF)
