# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from tests.st.ops_accuracy.theo_ops.theo_ops_test_util import theo_operator_check


def test_index_zhanlu_910B1():
    accelerator = '910B1'
    profiling_path = f'index_dpsk-v4-a3_zhanlu_profiling_910B1.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0, accumulate_accuracy=True, enable_fit=False)


def test_index_zhanlu_910B1_fit():
    accelerator = '910B1'
    profiling_path = f'index_dpsk-v4-a3_zhanlu_profiling_910B1.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.95, accumulate_accuracy=True, enable_fit=True)


def test_index_zhanlu_910B4_1():
    accelerator = '910B4-1'
    profiling_path = f'index_command_optimized_deepseek_bf16_016_zhanlu_profiling_910B4-1.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.004, accumulate_accuracy=True, enable_fit=False)


def test_index_zhanlu_910B4_1_fit():
    accelerator = '910B4-1'
    profiling_path = f'index_command_optimized_deepseek_bf16_016_zhanlu_profiling_910B4-1.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.98, accumulate_accuracy=True, enable_fit=True)
