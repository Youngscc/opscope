# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from tests.st.profiling_convert_util import ProfilingDataFormat
from tests.st.ops_accuracy.theo_ops.theo_ops_test_util import theo_operator_check


def test_matmul_matmalv3_910B1():
    accelerator = '910B1'
    profiling_path = f'op_summary_910B1.csv'
    theo_operator_check(accelerator=accelerator, profiling_file_path=profiling_path, accuracy_required=0.9, profiling_format=ProfilingDataFormat.MSPROF)


def test_matmul2_zhanlu_910B4_1():
    accelerator = '910B4-1'
    profiling_path = f'matmulv2_zhanlu_profiling_910B4_1.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.71, accumulate_accuracy=True, profiling_format=ProfilingDataFormat.ZHANLU, enable_fit=True)
