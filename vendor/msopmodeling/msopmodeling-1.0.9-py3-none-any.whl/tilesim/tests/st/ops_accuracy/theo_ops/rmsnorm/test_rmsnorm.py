# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from tests.st.ops_accuracy.theo_ops.theo_ops_test_util import theo_operator_check


def test_rmsnorm_zhanlu_910B4_1():
    accelerator = '910B4-1'
    profiling_path = f'rmsnorm_zhanlu_profiling_910B4_1.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.14, accumulate_accuracy=True, enable_fit=False)
