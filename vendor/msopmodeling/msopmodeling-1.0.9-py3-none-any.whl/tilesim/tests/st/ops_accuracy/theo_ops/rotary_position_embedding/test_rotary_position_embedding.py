# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from tests.st.ops_accuracy.theo_ops.theo_ops_test_util import theo_operator_check
from tests.st.profiling_convert_util import ProfilingDataFormat


def test_rotary_position_embedding():
    accelerator = '910B1'
    profiling_path = f'rotary_position_embedding.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.02, accumulate_accuracy=True,
                        enable_fit=False, profiling_format=ProfilingDataFormat.SGLANG_PROF)


def test_rotary_position_embedding_fit():
    accelerator = '910B1'
    profiling_path = f'rotary_position_embedding.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.85, accumulate_accuracy=True,
                        enable_fit=True, profiling_format=ProfilingDataFormat.SGLANG_PROF)
