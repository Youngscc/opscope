# Copyright (c) Huawei Technologies Co., Ltd. 2025-2026. All rights reserved.
from tests.st.ops_accuracy.theo_ops.theo_ops_test_util import theo_operator_check
from tests.st.profiling_convert_util import ProfilingDataFormat


def test_sparse_attn_sharedkv_metadata_zhanlu_910B1_fit():
    accelerator = '910B1'
    profiling_path = f'sparse_attn_sharedkv_metadata.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.90, accumulate_accuracy=True, enable_fit=True,
        profiling_format=ProfilingDataFormat.SGLANG_PROF)
