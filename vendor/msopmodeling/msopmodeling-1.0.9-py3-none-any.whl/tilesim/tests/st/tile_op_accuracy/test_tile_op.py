# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from tests.st.tile_op_accuracy.tile_op_accuracy_st_util import tile_op_check


def test_basic_binary_tile_op():
    tile_op_check("tile_op_profiling.csv", "tile_op_test_case.csv", 0.0)