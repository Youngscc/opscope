# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
"""
Integration tests for set_flag/wait_flag in EvalRulePipeImpl

This file tests the flag processing logic in eval_by_rule_pipe.py
that handles TileOpCode.SET_FLAG and TileOpCode.WAIT_FLAG operations.
"""

import pytest
from unittest.mock import MagicMock, patch
from dataclasses import dataclass, field
from typing import Optional

from core.common.entity import CoreUnit, CoreType, MemLoc, OpLevel
from core.common.tile_op_enum import TileOpCode


@dataclass
class MockTensorEntity:
    """Mock TensorEntity for testing"""
    name: str
    shape: list
    mem_loc: MemLoc
    dtype: str = "FP16"

    def get_slice_name(self):
        return self.name


@dataclass
class MockTileEntity:
    """Mock TileEntity for testing"""
    shape: list
    buffer_type: MemLoc
    data_type_str: MagicMock = field(default_factory=lambda: MagicMock(size=2))


@dataclass
class MockOpEntity:
    """Mock OpEntity for testing"""
    op_code: TileOpCode
    inputs: list
    outputs: list
    config: dict = field(default_factory=dict)
    level: OpLevel = OpLevel.TILE_OP


class TestProcessSetFlag:
    """Test _process_set_flag method"""

    def test_process_set_flag_single_unit(self):
        """Test processing set_flag with single unit"""
        from core.backend.engineering_costmodel.evaluation.by_rule_pipeline.eval_by_rule_pipe import EvalRulePipeImpl

        # Create mock config
        mock_backend_config = MagicMock()
        mock_backend_config.accelerator = "mock_config"
        mock_backend_config.aic_core_num = 1
        mock_backend_config.aiv_core_num = 1
        mock_backend_config.eval_config.pipe_exclusive_config = MagicMock()
        mock_backend_config.eval_config.fit_param = {}

        mock_eval_ctx = MagicMock()

        with patch('core.backend.engineering_costmodel.evaluation.by_rule_pipeline.eval_by_rule_pipe.load_arc_config') as mock_load_arc:
            mock_arc = MagicMock()
            mock_arc.clock_freq = 1.0
            mock_load_arc.return_value = mock_arc

            with patch.object(EvalRulePipeImpl, '_fit_coeff'):
                eval_impl = EvalRulePipeImpl(mock_backend_config, mock_eval_ctx)

        # Create set_flag op
        op = MockOpEntity(
            op_code=TileOpCode.SET_FLAG,
            inputs=[],
            outputs=[],
            config={
                "flag_id": "test_flag_0",
                "units": ["cube"]
            }
        )

        # Process the flag
        eval_impl.pipe_manager.update_core_index(0)
        eval_impl.pipe_manager.update_pipe([CoreUnit.CUBE], 100.0)
        eval_impl._process_set_flag(op)

        # Verify flag was set
        assert "test_flag_0" in eval_impl.pipe_manager.unit_wait_manager

    def test_process_set_flag_multiple_units(self):
        """Test processing set_flag with multiple units"""
        from core.backend.engineering_costmodel.evaluation.by_rule_pipeline.eval_by_rule_pipe import EvalRulePipeImpl

        mock_backend_config = MagicMock()
        mock_backend_config.accelerator = "mock_config"
        mock_backend_config.aic_core_num = 1
        mock_backend_config.aiv_core_num = 1
        mock_backend_config.eval_config.pipe_exclusive_config = MagicMock()
        mock_backend_config.eval_config.fit_param = {}

        mock_eval_ctx = MagicMock()

        with patch('core.backend.engineering_costmodel.evaluation.by_rule_pipeline.eval_by_rule_pipe.load_arc_config') as mock_load_arc:
            mock_arc = MagicMock()
            mock_arc.clock_freq = 1.0
            mock_load_arc.return_value = mock_arc

            with patch.object(EvalRulePipeImpl, '_fit_coeff'):
                eval_impl = EvalRulePipeImpl(mock_backend_config, mock_eval_ctx)

        op = MockOpEntity(
            op_code=TileOpCode.SET_FLAG,
            inputs=[],
            outputs=[],
            config={
                "flag_id": "multi_unit_flag",
                "units": ["cube", "aic_mte2", "vec"]
            }
        )

        eval_impl.pipe_manager.update_core_index(0)
        eval_impl.pipe_manager.update_pipe([CoreUnit.CUBE], 100.0)
        eval_impl.pipe_manager.update_pipe([CoreUnit.AIC_MTE2], 80.0)
        eval_impl.pipe_manager.update_pipe([CoreUnit.VEC], 120.0)

        eval_impl._process_set_flag(op)

        # Verify all units are in the flag
        flag_manager = eval_impl.pipe_manager.unit_wait_manager["multi_unit_flag"]
        from core.backend.engineering_costmodel.evaluation.by_rule_pipeline.pipe_manager import CoreUnitPipeKey
        assert CoreUnitPipeKey(CoreUnit.CUBE, 0) in flag_manager
        assert CoreUnitPipeKey(CoreUnit.AIC_MTE2, 0) in flag_manager
        assert CoreUnitPipeKey(CoreUnit.VEC, 0) in flag_manager

    def test_process_set_flag_missing_flag_id(self):
        """Test that missing flag_id raises ValueError"""
        from core.backend.engineering_costmodel.evaluation.by_rule_pipeline.eval_by_rule_pipe import EvalRulePipeImpl

        mock_backend_config = MagicMock()
        mock_backend_config.accelerator = "mock_config"
        mock_backend_config.aic_core_num = 1
        mock_backend_config.aiv_core_num = 1
        mock_backend_config.eval_config.pipe_exclusive_config = MagicMock()
        mock_backend_config.eval_config.fit_param = {}

        mock_eval_ctx = MagicMock()

        with patch('core.backend.engineering_costmodel.evaluation.by_rule_pipeline.eval_by_rule_pipe.load_arc_config') as mock_load_arc:
            mock_arc = MagicMock()
            mock_arc.clock_freq = 1.0
            mock_load_arc.return_value = mock_arc

            with patch.object(EvalRulePipeImpl, '_fit_coeff'):
                eval_impl = EvalRulePipeImpl(mock_backend_config, mock_eval_ctx)

        op = MockOpEntity(
            op_code=TileOpCode.SET_FLAG,
            inputs=[],
            outputs=[],
            config={"units": ["cube"]}  # Missing flag_id
        )

        with pytest.raises(ValueError, match="flag_id not in op config"):
            eval_impl._process_set_flag(op)


class TestProcessWaitFlag:
    """Test _process_wait_flag method"""

    def test_process_wait_flag_returns_time(self):
        """Test that wait_flag returns the correct sync time"""
        from core.backend.engineering_costmodel.evaluation.by_rule_pipeline.eval_by_rule_pipe import EvalRulePipeImpl

        mock_backend_config = MagicMock()
        mock_backend_config.accelerator = "mock_config"
        mock_backend_config.aic_core_num = 1
        mock_backend_config.aiv_core_num = 1
        mock_backend_config.eval_config.pipe_exclusive_config = MagicMock()
        mock_backend_config.eval_config.fit_param = {}

        mock_eval_ctx = MagicMock()

        with patch('core.backend.engineering_costmodel.evaluation.by_rule_pipeline.eval_by_rule_pipe.load_arc_config') as mock_load_arc:
            mock_arc = MagicMock()
            mock_arc.clock_freq = 1.0
            mock_load_arc.return_value = mock_arc

            with patch.object(EvalRulePipeImpl, '_fit_coeff'):
                eval_impl = EvalRulePipeImpl(mock_backend_config, mock_eval_ctx)

        # Set up flag
        eval_impl.pipe_manager.update_core_index(0)
        eval_impl.pipe_manager.update_pipe([CoreUnit.CUBE], 150.0)
        eval_impl.pipe_manager.set_unit_flag([CoreUnit.CUBE], "sync_flag")

        # Wait for flag
        op = MockOpEntity(
            op_code=TileOpCode.WAIT_FLAG,
            inputs=[],
            outputs=[],
            config={"flag_id": "sync_flag"}
        )

        sync_time = eval_impl._process_wait_flag(op)
        assert sync_time == 150.0

    def test_process_wait_flag_missing_flag_id(self):
        """Test that missing flag_id in wait_flag raises ValueError"""
        from core.backend.engineering_costmodel.evaluation.by_rule_pipeline.eval_by_rule_pipe import EvalRulePipeImpl

        mock_backend_config = MagicMock()
        mock_backend_config.accelerator = "mock_config"
        mock_backend_config.aic_core_num = 1
        mock_backend_config.aiv_core_num = 1
        mock_backend_config.eval_config.pipe_exclusive_config = MagicMock()
        mock_backend_config.eval_config.fit_param = {}

        mock_eval_ctx = MagicMock()

        with patch('core.backend.engineering_costmodel.evaluation.by_rule_pipeline.eval_by_rule_pipe.load_arc_config') as mock_load_arc:
            mock_arc = MagicMock()
            mock_arc.clock_freq = 1.0
            mock_load_arc.return_value = mock_arc

            with patch.object(EvalRulePipeImpl, '_fit_coeff'):
                eval_impl = EvalRulePipeImpl(mock_backend_config, mock_eval_ctx)

        op = MockOpEntity(
            op_code=TileOpCode.WAIT_FLAG,
            inputs=[],
            outputs=[],
            config={}  # Missing flag_id
        )

        with pytest.raises(ValueError, match="flag_id not in op config"):
            eval_impl._process_wait_flag(op)

    def test_process_wait_flag_nonexistent_flag(self):
        """Test wait_flag for nonexistent flag raises ValueError

        Note: The current implementation raises ValueError when the flag
        was never set (max of empty sequence).
        """
        from core.backend.engineering_costmodel.evaluation.by_rule_pipeline.eval_by_rule_pipe import EvalRulePipeImpl

        mock_backend_config = MagicMock()
        mock_backend_config.accelerator = "mock_config"
        mock_backend_config.aic_core_num = 1
        mock_backend_config.aiv_core_num = 1
        mock_backend_config.eval_config.pipe_exclusive_config = MagicMock()
        mock_backend_config.eval_config.fit_param = {}

        mock_eval_ctx = MagicMock()

        with patch('core.backend.engineering_costmodel.evaluation.by_rule_pipeline.eval_by_rule_pipe.load_arc_config') as mock_load_arc:
            mock_arc = MagicMock()
            mock_arc.clock_freq = 1.0
            mock_load_arc.return_value = mock_arc

            with patch.object(EvalRulePipeImpl, '_fit_coeff'):
                eval_impl = EvalRulePipeImpl(mock_backend_config, mock_eval_ctx)

        op = MockOpEntity(
            op_code=TileOpCode.WAIT_FLAG,
            inputs=[],
            outputs=[],
            config={"flag_id": "nonexistent_flag"}
        )

        with pytest.raises(ValueError):
            eval_impl._process_wait_flag(op)


class TestSetWaitFlagSequence:
    """Test set_flag and wait_flag in sequence"""

    def test_producer_consumer_pattern(self):
        """Test typical producer-consumer synchronization pattern

        AIC produces data -> set_flag -> AIV wait_flag -> consume data
        """
        from core.backend.engineering_costmodel.evaluation.by_rule_pipeline.eval_by_rule_pipe import EvalRulePipeImpl

        mock_backend_config = MagicMock()
        mock_backend_config.accelerator = "mock_config"
        mock_backend_config.aic_core_num = 1
        mock_backend_config.aiv_core_num = 1
        mock_backend_config.eval_config.pipe_exclusive_config = MagicMock()
        mock_backend_config.eval_config.fit_param = {}

        mock_eval_ctx = MagicMock()

        with patch('core.backend.engineering_costmodel.evaluation.by_rule_pipeline.eval_by_rule_pipe.load_arc_config') as mock_load_arc:
            mock_arc = MagicMock()
            mock_arc.clock_freq = 1.0
            mock_load_arc.return_value = mock_arc

            with patch.object(EvalRulePipeImpl, '_fit_coeff'):
                eval_impl = EvalRulePipeImpl(mock_backend_config, mock_eval_ctx)

        eval_impl.pipe_manager.update_core_index(0)

        # Producer (AIC) operations
        eval_impl.pipe_manager.update_pipe([CoreUnit.AIC_MTE2], 10.0)
        eval_impl.pipe_manager.update_pipe([CoreUnit.CUBE], 100.0)
        eval_impl.pipe_manager.update_pipe([CoreUnit.AIC_FIXPIPE], 110.0)

        # Set flag indicating data is ready
        set_op = MockOpEntity(
            op_code=TileOpCode.SET_FLAG,
            inputs=[],
            outputs=[],
            config={
                "flag_id": "data_ready",
                "units": ["aiv_mte2"]
            }
        )
        eval_impl._process_set_flag(set_op)

        # Consumer (AIV) waits for flag
        wait_op = MockOpEntity(
            op_code=TileOpCode.WAIT_FLAG,
            inputs=[],
            outputs=[],
            config={"flag_id": "data_ready"}
        )
        sync_ready_time = eval_impl._process_wait_flag(wait_op)

        # AIV should wait until AIC finishes (110.0)
        assert sync_ready_time == 110.0

    def test_multiple_sync_points(self):
        """Test multiple synchronization points in sequence"""
        from core.backend.engineering_costmodel.evaluation.by_rule_pipeline.eval_by_rule_pipe import EvalRulePipeImpl

        mock_backend_config = MagicMock()
        mock_backend_config.accelerator = "mock_config"
        mock_backend_config.aic_core_num = 1
        mock_backend_config.aiv_core_num = 1
        mock_backend_config.eval_config.pipe_exclusive_config = MagicMock()
        mock_backend_config.eval_config.fit_param = {}

        mock_eval_ctx = MagicMock()

        with patch('core.backend.engineering_costmodel.evaluation.by_rule_pipeline.eval_by_rule_pipe.load_arc_config') as mock_load_arc:
            mock_arc = MagicMock()
            mock_arc.clock_freq = 1.0
            mock_load_arc.return_value = mock_arc

            with patch.object(EvalRulePipeImpl, '_fit_coeff'):
                eval_impl = EvalRulePipeImpl(mock_backend_config, mock_eval_ctx)

        eval_impl.pipe_manager.update_core_index(0)

        # First sync point
        eval_impl.pipe_manager.update_pipe([CoreUnit.CUBE], 50.0)
        eval_impl._process_set_flag(MockOpEntity(
            op_code=TileOpCode.SET_FLAG,
            inputs=[], outputs=[],
            config={"flag_id": "sync_1", "units": ["vec"]}
        ))

        # Continue AIC operations
        eval_impl.pipe_manager.update_pipe([CoreUnit.CUBE], 100.0)
        eval_impl._process_set_flag(MockOpEntity(
            op_code=TileOpCode.SET_FLAG,
            inputs=[], outputs=[],
            config={"flag_id": "sync_2", "units": ["vec"]}
        ))

        # Verify both sync points
        assert eval_impl._process_wait_flag(MockOpEntity(
            op_code=TileOpCode.WAIT_FLAG,
            inputs=[], outputs=[],
            config={"flag_id": "sync_1"}
        )) == 50.0

        assert eval_impl._process_wait_flag(MockOpEntity(
            op_code=TileOpCode.WAIT_FLAG,
            inputs=[], outputs=[],
            config={"flag_id": "sync_2"}
        )) == 100.0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])