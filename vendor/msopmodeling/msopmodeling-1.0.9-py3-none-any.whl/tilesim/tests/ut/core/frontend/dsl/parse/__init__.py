# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
"""前端DSL解析测试包"""