# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
"""
SSA Completeness Tests for tilesim

Tests SSA implementation correctness from theoretical perspective:
1. Basic SSA properties (each variable defined once)
2. Phi functions at join points
3. Loop-carrying variables
4. Nested control flow
5. Scope balance
"""

import ast
import pytest


def get_original_var_name(name: str) -> str:
    """从变量名中提取原始变量名（去除版本号后缀）"""
    return name.split('.')[0] if '.' in name else name


def test_basic_property_single_assign():
    """Single assignment should have single version"""
    from core.frontend.dsl.parse.ssa_env import SSAEnv
    from core.frontend.ir.core.ir_entity import VarIR
    from core.frontend.ir.core.ir_math import ConstExprIR

    env = SSAEnv()
    var = VarIR(name="x", value=ConstExprIR(5))
    env.write_var(var)

    assert var.name == "x"


def test_basic_property_multiple_assign():
    """Multiple assignments should create multiple versions"""
    from core.frontend.dsl.parse.ssa_env import SSAEnv
    from core.frontend.ir.core.ir_entity import VarIR
    from core.frontend.ir.core.ir_math import ConstExprIR

    env = SSAEnv()
    versions = []

    for i in range(5):
        var = VarIR(name="x", value=ConstExprIR(i))
        env.write_var(var)
        versions.append(var.name)

    expected = ["x", "x.1", "x.2", "x.3", "x.4"]
    assert versions == expected


def test_read_returns_latest_version():
    """Reading a variable should return the latest version"""
    from core.frontend.dsl.parse.ssa_env import SSAEnv
    from core.frontend.ir.core.ir_entity import VarIR
    from core.frontend.ir.core.ir_math import ConstExprIR

    env = SSAEnv()
    env.write_var(VarIR(name="x", value=ConstExprIR(1)))
    env.write_var(VarIR(name="x", value=ConstExprIR(2)))

    read_var = env.read_var("x")
    assert read_var.name == "x.1"


def test_undefined_variable_raises_error():
    """Using an undefined variable should raise NameError"""
    from core.frontend.dsl.parse.ssa_env import SSAEnv

    env = SSAEnv()

    with pytest.raises(NameError, match="used before definition"):
        env.read_var("undefined")


def test_scope_inheritance():
    """Child scopes should inherit variables from parent"""
    from core.frontend.dsl.parse.ssa_env import SSAEnv
    from core.frontend.ir.core.ir_entity import VarIR
    from core.frontend.ir.core.ir_math import ConstExprIR

    env = SSAEnv()

    # Define in root scope
    var_x = VarIR(name="x", value=ConstExprIR(10))
    env.write_var(var_x)

    # Push child scope
    env.push_stack("child")

    # Should be able to read parent's variable
    read_var = env.read_var("x")
    assert read_var.name == "x"

    env.pop_stack()


def test_phi_at_if_else_join():
    """Phi function should be generated at if-else join point"""
    from core.frontend.dsl.parse.ssa_env import SSAEnv
    from core.frontend.ir.core.ir_entity import VarIR
    from core.frontend.ir.core.ir_math import ConstExprIR

    env = SSAEnv()

    # Initial value
    var_x = VarIR(name="x", value=ConstExprIR(0))
    env.write_var(var_x)

    # If-else structure
    env.push_stack("if-outer")

    # If branch
    env.push_stack("if-branch")
    env.write_var(VarIR(name="x", value=ConstExprIR(1)))
    env.pop_stack()

    # Else branch
    env.push_stack("else-branch")
    env.write_var(VarIR(name="x", value=ConstExprIR(2)))
    env.pop_stack()

    # Pop outer - should generate phi
    env.pop_stack()

    # Check if phi was generated
    # result_name is the merged version (e.g., "x.3"), not original name "x"
    phi_for_x = any(get_original_var_name(phi.result_name) == "x" for phi in env.phi_func_list)
    assert phi_for_x, "Phi function should be generated for x at if-else join point"


def test_phi_referred_names_correct():
    """Phi function should reference correct variable versions"""
    from core.frontend.dsl.parse.ssa_env import SSAEnv
    from core.frontend.ir.core.ir_entity import VarIR
    from core.frontend.ir.core.ir_math import ConstExprIR

    env = SSAEnv()
    env.write_var(VarIR(name="x", value=ConstExprIR(0)))

    env.push_stack("if-outer")

    env.push_stack("if-branch")
    env.write_var(VarIR(name="x", value=ConstExprIR(1)))
    env.pop_stack()

    env.push_stack("else-branch")
    env.write_var(VarIR(name="x", value=ConstExprIR(2)))
    env.pop_stack()

    env.pop_stack()

    # Find phi for x
    phi_x = next((phi for phi in env.phi_func_list if get_original_var_name(phi.result_name) == "x"), None)
    assert phi_x is not None

    # Phi should reference at least 2 versions
    assert len(phi_x.referred_name) >= 2

    # scope_referrers should map correctly
    for scope_id, ref_name in phi_x.scope_referrers.items():
        assert ref_name in phi_x.referred_name


def test_no_phi_without_merge():
    """No phi should be generated without variable version merge"""
    from core.frontend.dsl.parse.ssa_env import SSAEnv

    env = SSAEnv()

    # Simple scope nesting, no variable modification
    env.push_stack("outer")
    env.push_stack("inner")
    env.pop_stack()
    env.pop_stack()

    # Should have no phi functions
    assert len(env.phi_func_list) == 0


def test_for_parse_scope_balance():
    """
    CRITICAL: For loop parse should balance scope stack

    Issue: _for_parse pushes stack but doesn't pop!
    """
    from core.frontend.dsl.parse.ssa_env import SSAEnv
    from core.frontend.dsl.parse import dsl_to_logistic_ir

    env = SSAEnv()

    code = """
for i in range(10):
    x = i
"""
    tree = ast.parse(code)
    for_node = tree.body[0]

    stack_size_before = len(env._scope)
    dsl_to_logistic_ir._for_parse(for_node, env)
    stack_size_after = len(env._scope)

    # This will FAIL because _for_parse doesn't pop the inner scope!
    if stack_size_before != stack_size_after:
        print(f"BUG: For loop scope imbalance!")
        print(f"  Stack before: {stack_size_before}, after: {stack_size_after}")
        print(f"  Unpopped scopes: {stack_size_after - stack_size_before}")

    assert stack_size_before == stack_size_after, \
        f"For loop scope stack imbalance: {stack_size_after - stack_size_before} scopes not popped"


def test_if_parse_scope_balance():
    """
    Check if-else scope balance
    """
    from core.frontend.dsl.parse.ssa_env import SSAEnv
    from core.frontend.dsl.parse import dsl_to_logistic_ir

    env = SSAEnv()

    code = """
if True:
    x = 1
else:
    x = 2
"""
    tree = ast.parse(code)
    if_node = tree.body[0]

    stack_size_before = len(env._scope)
    dsl_to_logistic_ir._if_parse(if_node, env)
    stack_size_after = len(env._scope)

    assert stack_size_before == stack_size_after, \
        f"If statement scope imbalance: {stack_size_after - stack_size_before} scopes not popped"


def test_if_single_branch_scope_balance():
    """Check if with only if branch (no else)"""
    from core.frontend.dsl.parse.ssa_env import SSAEnv
    from core.frontend.dsl.parse import dsl_to_logistic_ir

    env = SSAEnv()

    code = """
if True:
    x = 1
"""
    tree = ast.parse(code)
    if_node = tree.body[0]

    stack_size_before = len(env._scope)
    dsl_to_logistic_ir._if_parse(if_node, env)
    stack_size_after = len(env._scope)

    assert stack_size_before == stack_size_after, \
        f"If (single branch) scope imbalance: {stack_size_after - stack_size_before} scopes not popped"


def test_task_parse_scope_balance():
    """
    Check Task scope balance
    """
    from core.frontend.dsl.parse.ssa_env import SSAEnv
    from core.frontend.dsl.parse import dsl_to_logistic_ir

    env = SSAEnv()

    code = """
with T.Task(name="test", range=[10, 20]) as ([i, j]):
    x = i + j
"""
    tree = ast.parse(code)
    with_node = tree.body[0]

    try:
        stack_size_before = len(env._scope)
        dsl_to_logistic_ir._task_parse(with_node, env)
        stack_size_after = len(env._scope)

        assert stack_size_before == stack_size_after, \
            f"Task scope imbalance: {stack_size_after - stack_size_before} scopes not popped"
    except Exception as e:
        pytest.skip(f"Task parse test skipped: {e}")


def test_loop_carrying_variable_phi():
    """
    Test loop-carrying variable - complex SSA case
    """
    from core.frontend.dsl.parse.ssa_env import SSAEnv
    from core.frontend.ir.core.ir_entity import VarIR
    from core.frontend.ir.core.ir_math import ConstExprIR

    env = SSAEnv()

    # Initialize variable before loop
    acc = VarIR(name="acc", value=ConstExprIR(0))
    env.write_var(acc)

    # Simulating loop structure
    # For proper SSA, we need a phi at the loop entry
    # that merges the initial value with the loop-carry value

    # Current implementation may not handle this correctly


def test_multiple_variables_phi():
    """Multiple variables should each get their own phi"""
    from core.frontend.dsl.parse.ssa_env import SSAEnv
    from core.frontend.ir.core.ir_entity import VarIR
    from core.frontend.ir.core.ir_math import ConstExprIR

    env = SSAEnv()

    # Define two variables
    env.write_var(VarIR(name="x", value=ConstExprIR(0)))
    env.write_var(VarIR(name="y", value=ConstExprIR(0)))

    # If-else structure modifying both
    env.push_stack("if-outer")

    env.push_stack("if-branch")
    env.write_var(VarIR(name="x", value=ConstExprIR(1)))
    env.write_var(VarIR(name="y", value=ConstExprIR(1)))
    env.pop_stack()

    env.push_stack("else-branch")
    env.write_var(VarIR(name="x", value=ConstExprIR(2)))
    env.write_var(VarIR(name="y", value=ConstExprIR(2)))
    env.pop_stack()

    env.pop_stack()

    # Should have phi for both x and y
    var_names_with_phi = set(get_original_var_name(phi.result_name) for phi in env.phi_func_list)
    assert "x" in var_names_with_phi
    assert "y" in var_names_with_phi


def test_phi_three_branches():
    """Phi handling for three branches"""
    from core.frontend.dsl.parse.ssa_env import SSAEnv
    from core.frontend.ir.core.ir_entity import VarIR
    from core.frontend.ir.core.ir_math import ConstExprIR

    env = SSAEnv()

    env.write_var(VarIR(name="x", value=ConstExprIR(0)))

    # Structure with 3 branches
    env.push_stack("outer")

    env.push_stack("branch-1")
    env.write_var(VarIR(name="x", value=ConstExprIR(1)))
    env.pop_stack()

    env.push_stack("branch-2")
    env.write_var(VarIR(name="x", value=ConstExprIR(2)))
    env.pop_stack()

    env.push_stack("branch-3")
    env.write_var(VarIR(name="x", value=ConstExprIR(3)))
    env.pop_stack()

    env.pop_stack()

    # Find phi for x
    phi_x = next((phi for phi in env.phi_func_list if get_original_var_name(phi.result_name) == "x"), None)
    assert phi_x is not None

    # Phi should reference 3 versions
    assert len(phi_x.scope_referrers) == 3


def test_version_counter_independence():
    """Different variables should have independent version counters"""
    from core.frontend.dsl.parse.ssa_env import SSAEnv
    from core.frontend.ir.core.ir_entity import VarIR
    from core.frontend.ir.core.ir_math import ConstExprIR

    env = SSAEnv()

    # Assign to 'a' 10 times
    for i in range(10):
        env.write_var(VarIR(name="a", value=ConstExprIR(i)))
    last_a = env.read_var("a")

    # Assign to 'b' 5 times
    for i in range(5):
        env.write_var(VarIR(name="b", value=ConstExprIR(i)))
    last_b = env.read_var("b")

    assert last_a.name == "a.9"
    assert last_b.name == "b.4"


def test_nested_for_scope_balance():
    """Test nested for loop scope balance"""
    from core.frontend.dsl.parse.ssa_env import SSAEnv
    from core.frontend.dsl.parse import dsl_to_logistic_ir

    env = SSAEnv()

    code = """
for i in range(10):
    for j in range(5):
        x = i + j
"""
    tree = ast.parse(code)
    outer_for = tree.body[0]

    stack_before = len(env._scope)
    dsl_to_logistic_ir._for_parse(outer_for, env)
    stack_after = len(env._scope)

    # This will likely fail due to scope imbalance in inner loop
    print(f"Nested for: stack before={stack_before}, after={stack_after}")
    assert stack_before == stack_after, \
        f"Nested for scope imbalance: {stack_after - stack_before} scopes not popped"


class TestSSAEquivalence:
    """Test SSA equivalence properties"""

    def test_ssa_form_property_1(self):
        """SSA Property 1: Each variable defined exactly once"""
        from core.frontend.dsl.parse.ssa_env import SSAEnv
        from core.frontend.ir.core.ir_entity import VarIR
        from core.frontend.ir.core.ir_math import ConstExprIR

        env = SSAEnv()

        # Write 'x' multiple times
        env.write_var(VarIR(name="x", value=ConstExprIR(1)))
        env.write_var(VarIR(name="x", value=ConstExprIR(2)))
        env.write_var(VarIR(name="x", value=ConstExprIR(3)))

        # Each write creates a new variable version
        # In SSA: x, x.1, x.2 are all different variables
        # So 'x' (by original name) should not be written multiple times

        # Check that version counter increases
        assert env._version_counter.get("x", 0) == 3


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])